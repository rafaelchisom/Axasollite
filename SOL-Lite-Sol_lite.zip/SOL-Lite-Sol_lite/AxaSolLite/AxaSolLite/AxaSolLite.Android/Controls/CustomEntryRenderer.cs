﻿using Android.Content;
using Android.Content.Res;
using Android.Graphics.Drawables;
using Android.Views;
using AxaSolLite.Controls;
using AxaSolLite.Droid.Controls;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ExportRenderer(typeof(CustomEntry), typeof(CustomEntryRenderer))]

namespace AxaSolLite.Droid.Controls
{
    public class CustomEntryRenderer : EntryRenderer
    {
        public CustomEntryRenderer(Context context) : base(context)
        {
        }

        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);

            if (Control != null)
            {
                Control.CustomSelectionActionModeCallback = new Callback();
                Control.CustomInsertionActionModeCallback = new Callback();
                Control.LongClickable = false;
                //GradientDrawable gd = new GradientDrawable();
                //gd.SetColor(global::Android.Graphics.Color.White);

                //this.Control.SetBackgroundDrawable(gd);
                //this.Control.SetRawInputType(InputTypes.TextFlagNoSuggestions);

                //gd.SetCornerRadius(5);

                //Control.SetBackgroundColor(global::Android.Graphics.Color.Transparent);
                Control.SetBackgroundColor(global::Android.Graphics.Color.Transparent);
                Control.Bottom = 5;
                int[][] states = new int[][] {
                new int[] { -Android.Resource.Attribute.StateFocused},
                new int[] {Android.Resource.Attribute.StateFocused} // disabled


            };
                int[] colors = new int[] { Color.LightGray.ToAndroid(), Color.FromHex("#FCD385").ToAndroid() };

                ColorStateList myList = new ColorStateList(states, colors);

                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.SetCornerRadius(2);
                Control.Background = gradientDrawable;
                gradientDrawable.SetStroke(2, myList);
            }
        }

        public class Callback : Java.Lang.Object, ActionMode.ICallback
        {
            public bool OnActionItemClicked(ActionMode mode, IMenuItem item)
            {
                return false;
            }
            public bool OnCreateActionMode(ActionMode mode, IMenu menu)
            {
                return false;
            }
            public void OnDestroyActionMode(ActionMode mode) { }
            public bool OnPrepareActionMode(ActionMode mode, IMenu menu)
            {
                return false;
            }
            public bool canPaste(ActionMode mode, IMenu menu)
            {
                return false;
            }
            //@Override
            public bool isSuggestionsEnabled(ActionMode mode, IMenu menu)
            {
                return false;
            }
        }
    }
}