﻿using System.IO;
using AxaSolLite.Services.Contracts;
using SQLite.Net.Interop;
using SQLite.Net.Platform.XamarinAndroid;

namespace AxaSolLite.Droid.Services
{
    public class AndroidDBConnectionParameters : IDBConnectionParameters
    {
        public AndroidDBConnectionParameters()
        {
            FilePath = GetDbPath();
            Platform = new SQLitePlatformAndroid();
        }

        private string GetDbPath()
        {
            string documentsPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
            return Path.Combine(documentsPath, "AXASolLiteDBProduction_V1.db3");
        }

        public string FilePath { get; private set; }
        public ISQLitePlatform Platform { get; private set; }
    }
}