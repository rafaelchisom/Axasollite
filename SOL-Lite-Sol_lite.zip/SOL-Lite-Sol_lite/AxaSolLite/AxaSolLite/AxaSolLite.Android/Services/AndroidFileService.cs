﻿using AxaSolLite.Services.Contracts;
using System;
using System.IO;

namespace AxaSolLite.Droid.Services
{
    public class AndroidFileService : IFileService
    {
        private string _FolderPath;

        public string FolderPath
        {
            get { return _FolderPath; }
        }

        public AndroidFileService()
        {
            if (string.IsNullOrEmpty(FolderPath))
            {
                _FolderPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
            }
        }

        public byte[] Open(string fileName)
        {
            try
            {
                string filePath = System.IO.Path.Combine(_FolderPath, fileName);
                return File.ReadAllBytes(filePath);
            }
            catch (Exception ex)
            {
                var error = ex.ToString();
            }

            return null;
        }

        public string Save(byte[] payload, string fileName)
        {
            try
            {
                string filePath = System.IO.Path.Combine(_FolderPath, fileName);
                File.WriteAllBytes(filePath, payload);
                return filePath;
            }
            catch (Exception ex)
            {
                var error = ex.ToString();
            }

            return string.Empty;
        }

        public bool Delete(string FileName)
        {
            try
            {
                string filePath = System.IO.Path.Combine(_FolderPath, FileName);
                File.Delete(filePath);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}