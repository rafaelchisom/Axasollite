﻿using Android.App;
using Android.Content.PM;
using Android.OS;
using Android.Widget;
using AxaSolLite.Droid.Services;
using AxaSolLite.Services.Contracts;
using ImageCircle.Forms.Plugin.Droid;
using Prism;
using Prism.Ioc;
using System;
using System.IO;
using Xamarin.Forms;
using Environment = Android.OS.Environment;


namespace AxaSolLite.Droid
{
    
    [Activity(Name = "md540444133079050779c82bcde9a8651d4.MainActivity", Label = "AXA Sol Lite", Icon = "@drawable/axasol_lite_icon_small", Theme = "@style/MainTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
    {
       
        protected override void OnCreate(Bundle bundle)
        {
            try
            {
                
                TabLayoutResource = Resource.Layout.Tabbar;
                ToolbarResource = Resource.Layout.Toolbar;
                
                base.RequestedOrientation = ScreenOrientation.Unspecified;

                base.OnCreate(bundle);
                Rg.Plugins.Popup.Popup.Init(this);
                ImageCircleRenderer.Init();              
                global::Xamarin.Forms.Forms.Init(this, bundle);
                Xamarin.Essentials.Platform.Init(this, bundle);

                LoadApplication(new App(new AndroidInitializer()));

            }
            catch(System.Exception ex)
            {
                ex.Message.ToString();
            }
        }
        public override void OnBackPressed()
        {
            Rg.Plugins.Popup.Popup.SendBackPressed(base.OnBackPressed);
        }



    }
   

    public class AndroidInitializer : IPlatformInitializer
    {
        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.Register<IFileService, AndroidFileService>();
            containerRegistry.Register<IDBConnectionParameters, AndroidDBConnectionParameters>();
            containerRegistry.Register<IDevice, AndroidDevice>();
        }
    }

}

