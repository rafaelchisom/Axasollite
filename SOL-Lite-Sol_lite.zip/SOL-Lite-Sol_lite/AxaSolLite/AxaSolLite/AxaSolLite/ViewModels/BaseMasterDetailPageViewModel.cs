﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AxaSolLite.ViewModels
{
    public class BaseMasterDetailPageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IAgentRepository _agentRepository;
        private readonly Logical _logical;

        private bool _isNotAdvisor;

        public bool IsNotAdvisor
        {
            get { return _isNotAdvisor; }
            set { SetProperty(ref _isNotAdvisor, value); }
        }
        public Agent Agent { get; set; }

        private DelegateCommand _logOutCommand;
        private DelegateCommand _generalLogCommand;
        private DelegateCommand _prospectListCommand;
        private DelegateCommand _commissionCommand;
        private DelegateCommand _homeCommand;
        private DelegateCommand _appSupportCommand;
        private DelegateCommand _myProfileCommand;
        private DelegateCommand _dashboardCommand;
        private DelegateCommand _trainingVideoCommand;
        private DelegateCommand _getReferralLinkCommand;
        private DelegateCommand _productVideoCommand;
        private DelegateCommand _paperFnaCommand;
        private DelegateCommand _eformCommand;
        private DelegateCommand _approvalLogCommand;
        private DelegateCommand _investmentCommand;

        public DelegateCommand LogOutCommand => _logOutCommand ?? (_logOutCommand = new DelegateCommand(ExecuteLogOutCommand));
        public DelegateCommand GeneralLogCommand => _generalLogCommand ?? (_generalLogCommand = new DelegateCommand(ExecuteGeneralLogCommand));
        public DelegateCommand ProspectListCommand => _prospectListCommand ?? (_prospectListCommand = new DelegateCommand(ExecuteProspectListCommand));
        public DelegateCommand CommissionCommand => _commissionCommand ?? (_commissionCommand = new DelegateCommand(ExecuteCommissionCommand));
        public DelegateCommand HomeCommand => _homeCommand ?? (_homeCommand = new DelegateCommand(ExecuteHomeCommand));
        public DelegateCommand AppSupportCommand => _appSupportCommand ?? (_appSupportCommand = new DelegateCommand(ExecuteAppSupportCommand));
        public DelegateCommand MyProfileCommand => _myProfileCommand ?? (_myProfileCommand = new DelegateCommand(ExecuteMyProfileCommand));
        public DelegateCommand DashboardCommand => _dashboardCommand ?? (_dashboardCommand = new DelegateCommand(ExecuteDashboardCommand));
        public DelegateCommand TrainingVideoCommand => _trainingVideoCommand ?? (_trainingVideoCommand = new DelegateCommand(ExecuteTrainingVideoCommand));
        public DelegateCommand ProductVideoCommand => _productVideoCommand ?? (_productVideoCommand = new DelegateCommand(ExecuteProductVideoCommand));
        public DelegateCommand GetReferralLinkCommand => _getReferralLinkCommand ?? (_getReferralLinkCommand = new DelegateCommand(ExecuteGetReferralLink));
        public DelegateCommand PaperFnaCommand => _paperFnaCommand ?? (_paperFnaCommand = new DelegateCommand(ExecutePaperFna));
        public DelegateCommand EformCommand => _eformCommand ?? (_eformCommand = new DelegateCommand(ExecuteEform));
        public DelegateCommand ApprovalLogCommand => _approvalLogCommand ?? (_approvalLogCommand = new DelegateCommand(ExecuteApprovalLogCommand));
        public DelegateCommand InvestmentCommand => _investmentCommand ?? (_investmentCommand = new DelegateCommand(ExecuteInvestment));

        public BaseMasterDetailPageViewModel(INavigationService navigationService, IPageDialogService pageDialogService, IAgentRepository agentRepository, Logical logical)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _agentRepository = agentRepository;
            _logical = logical;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            try
            {
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        Agent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }
                if(Agent.IsAdvisor)
                {
                    IsNotAdvisor = false;
                }
                else
                {
                    IsNotAdvisor = true;
                }
            }
            catch (Exception ex)
            {

            }
        }

        private async void ExecuteProspectListCommand()
        {
            try
            {
                NavigationParameters navigationParameter = new NavigationParameters();
                navigationParameter.Add("AgentId", Agent.Id);
                FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                {
                    MenuName = "ProspectListPage"
                };
                bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProspectListPage", navigationParameter);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteCommissionCommand()
        {
            try
            {
                if (Agent.IsAdvisor == true)
                {
                    NavigationParameters navigationParameter = new NavigationParameters();
                    navigationParameter.Add("AgentId", Agent.Id);
                    FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                    {
                        MenuName = "AdvisorCommissionPage"
                    };
                    bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                    await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/AdvisorCommissionPage", navigationParameter);

                }
                else if (Agent.IsTeamManager == true)
                {
                    NavigationParameters navigationParameter = new NavigationParameters();
                    navigationParameter.Add("AgentId", Agent.Id);
                    FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                    {
                        MenuName = "TeamManagerCommissionPage"
                    };
                    bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                    await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/TeamManagerCommissionPage", navigationParameter);

                }
                else
                {
                    NavigationParameters navigationParameter = new NavigationParameters();
                    navigationParameter.Add("AgentId", Agent.Id);
                    FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                    {
                        MenuName = "PssCommissionPage"
                    };
                    bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                    await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/PssCommissionPage", navigationParameter);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteGeneralLogCommand()
        {
            try
            {
                NavigationParameters navigationParameter = new NavigationParameters();
                navigationParameter.Add("AgentId", Agent.Id);
                FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                {
                    MenuName = "GeneralLogPage"
                };
                bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/GeneralLogPage", navigationParameter);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteHomeCommand()
        {
            try
            {
                NavigationParameters navigationParameter = new NavigationParameters();
                navigationParameter.Add("AgentId", Agent.Id);
                FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                {
                    MenuName = "BaseNavigationPage"
                };
                bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/HomeRenewalPage", navigationParameter);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteAppSupportCommand()
        {
            try
            {
                NavigationParameters navigationParameter = new NavigationParameters();
                navigationParameter.Add("AgentId", Agent.Id);
                FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                {
                    MenuName = "AgentFeedbackPage"
                };
                bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/AgentFeedbackPage", navigationParameter);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteMyProfileCommand()
        {
            try
            {
                NavigationParameters navigationParameter = new NavigationParameters();
                navigationParameter.Add("AgentId", Agent.Id);
                FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                {
                    MenuName = "MyProfilePage"
                };
                bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/MyProfilePage", navigationParameter);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecutePaperFna()
        {
            try
            {
                NavigationParameters navigationParameter = new NavigationParameters();
                navigationParameter.Add("AgentId", Agent.Id);
                FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                {
                    MenuName = "PaperFnaPage"
                };
                bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/PaperFnaPage", navigationParameter);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

        }

        private async void ExecuteEform()
        {
            try
            {
                NavigationParameters navigationParameter = new NavigationParameters();
                navigationParameter.Add("AgentId", Agent.Id);
                FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                {
                    MenuName = "EFormsPage"
                };
                bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/EFormsPageNew", navigationParameter);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

        }

        private async void ExecuteDashboardCommand()
        {
            await _pageDialogService.DisplayAlertAsync("Ooops!", "Coming soon........", "Ok");
        }

        private async void ExecuteTrainingVideoCommand()
        {
            try
            {
                NavigationParameters navigationParameter = new NavigationParameters();
                navigationParameter.Add("AgentId", Agent.Id);
                FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                {
                    MenuName = "TrainingVideoPage"
                };
                bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/TrainingVideoPage", navigationParameter);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteGetReferralLink()
        {
            try
            {
                NavigationParameters navigationParameter = new NavigationParameters();
                navigationParameter.Add("AgentId", Agent.Id);
                FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                {
                    MenuName = "AgentReferralLink"
                };
                bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/AgentReferralLink", navigationParameter);
            }
            catch (Exception ex)
            {

            }
        }

        public async void ExecuteLogOutCommand()
        {
            
           
                bool result = await _pageDialogService.DisplayAlertAsync("Notice", "Confirm Log out", "Yes", "No");

                if (result)
                {
                FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                {
                    MenuName = "LoginPage"
                };
                bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                await _navigationService.NavigateAsync("LoginPage"); //check this....
                }
            
            
        }

        private async void ExecuteProductVideoCommand()
        {
            NavigationParameters navigationParameter = new NavigationParameters();
            navigationParameter.Add("AgentId", Agent.Id);
            FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
            {
                MenuName = "ProductVideoPage"
            };
            bool inserted = await _logical.InsertFeatureUsage(featureUsage);
            await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductVideoPage", navigationParameter);
        }

        private async void ExecuteApprovalLogCommand()
        {
            try
            {
                NavigationParameters navigationParameter = new NavigationParameters();
                navigationParameter.Add("AgentId", Agent.Id);
                FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                {
                    MenuName = "ApprovalLogPage"
                };
                bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ApprovalLogPage", navigationParameter);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteInvestment()
        {
            try
            {
                NavigationParameters navigationParameter = new NavigationParameters();
                navigationParameter.Add("AgentId", Agent.Id);
                FeatureUsage featureUsage = new FeatureUsage //assigning value to the object
                {
                    MenuName = "InvestmentOnboardPage"
                };
                bool inserted = await _logical.InsertFeatureUsage(featureUsage);
                await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/InvestmentOnboardPage", navigationParameter);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

        }
    }
}
