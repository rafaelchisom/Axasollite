﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AxaSolLite.ViewModels
{
	public class FirstTimeLoginPageViewModel : BindableBase, INavigationAware
    {
        private readonly IRepositoryManager _repositoryManager;
        private readonly IUserManager _userService;
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;

        private DelegateCommand _loginCommand;
        private string _password;
        private string _confirmpassword;
        private string _agentCode;
        private bool _isBusy;

        #region PROPERTIES
        public string AgentCode
        {
            get { { return _agentCode; } }
            set { SetProperty(ref _agentCode, value); }
        }

        public string Password
        {
            get { { return _password; } }
            set { SetProperty(ref _password, value); }
        }
        public string ConfirmPassword
        {
            get { { return _confirmpassword; } }
            set { SetProperty(ref _confirmpassword, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        #endregion
        #region COMMANDS

        public DelegateCommand LoginCommand => _loginCommand ?? (_loginCommand = new DelegateCommand(ExecuteLogin));
        Logical logical = null;
        #endregion

        public FirstTimeLoginPageViewModel(IUserManager userService,
            INavigationService navigationService,
            IPageDialogService pageDialogService,
            IRepositoryManager repositoryManager)
        {
            _userService = userService;
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _repositoryManager = repositoryManager;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            
        }
        public async void ExecuteLogin()
        {
            try
            {
                IsBusy = true;
                
                if (!String.IsNullOrEmpty(this.AgentCode))
                {
                    this.AgentCode = this.AgentCode.Trim();
                }
                if (Password == ConfirmPassword)
                {
                    logical = new Logical();
                    UpdateExternalAgentPasswordRequest updateAgentPassword = new UpdateExternalAgentPasswordRequest();
                    updateAgentPassword.username = AgentCode;
                    updateAgentPassword.password = Password;
                    var updateAgentPasswordResponse = await logical.UpdateExternalAgentResponseAsync(updateAgentPassword);


                    if (updateAgentPasswordResponse.Message.ToLower().Contains("password update successful"))
                    {


                        await _pageDialogService.DisplayAlertAsync("Successful", "Password Reset Successful", "Ok");
                        await _navigationService.NavigateAsync("ExternalAgentLoginPage");

                    }
                    else if (updateAgentPasswordResponse.Message.ToLower().Contains("password should contain at least one upper case and lower case letter, a number, at least 8 characters long and at least a special character"))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Password should be at least 8 characters long and should contain at least one upper case, one lower case letter, a number, and at least a special character", "Ok");
                    }
                    else if (updateAgentPasswordResponse.Message.ToLower().Contains("password update not successful"))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Password Reset UnSuccessful", "Ok");
                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Please Try Again", "Ok");
                    }
                }
                else
                {
                    await _pageDialogService.DisplayAlertAsync("Password Mismatch", "Please input matching entries into password fields", "Ok");
                }
                IsBusy = false;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
    }
}
