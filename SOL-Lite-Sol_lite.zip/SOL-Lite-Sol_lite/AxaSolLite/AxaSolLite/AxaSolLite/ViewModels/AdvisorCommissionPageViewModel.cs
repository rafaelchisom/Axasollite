﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AxaSolLite.ViewModels
{
	public class AdvisorCommissionPageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IAgentRepository _agentRepository;
        private readonly ICalculatorService _calculatorService;
        private readonly IProspectRepository _prospectRepository;
        private readonly Logical _logical;
        Logical logical = null;

        #region Fields
        private string _lifeCommission;
        private long _lifeBonus;
        private string _actual;
        private string _budget;
        private string _individualLifeInflow;
        private string _individualLifeCommission;
        private long _individualLifeBonus;
        private string _percentageAchieved;
        private string _groupLifeInflow;
        private string _groupLifeCommission;
        private long _groupLifeBonus;
        private string _lifeInflow;
        private string _totalOverride;
        private string _username;
        private string _title;
        private bool _isBusy;
        private bool _isCommissioned;
        private int _selectedYear;
        private int _selectedMonth;
        private string _Month;
        private List<int> _year;

        #endregion
        #region Commands
        private DelegateCommand _monthlyCommissionCommand;
        private DelegateCommand _ytdCommissionCommand;
        public DelegateCommand MonthlyCommissionCommand => _monthlyCommissionCommand ?? (_monthlyCommissionCommand = new DelegateCommand(ExecuteMonthlyCommissionCommand));
        public DelegateCommand YtdCommissionCommand => _ytdCommissionCommand ?? (_ytdCommissionCommand = new DelegateCommand(ExecuteYtdCommissionCommand));
        #endregion
        #region Properties
        public string LifeCommission
        {
            get { return _lifeCommission; }
            set { SetProperty(ref _lifeCommission, value); }
        }
        public long LifeBonus
        {
            get { return _lifeBonus; }
            set { SetProperty(ref _lifeBonus, value); }
        }
        public string Actual
        {
            get { return _actual; }
            set { SetProperty(ref _actual, value); }
        }
        public string Budget
        {
            get { return _budget; }
            set { SetProperty(ref _budget, value); }
        }
        public string IndividualLifeInflow
        {
            get { return _individualLifeInflow; }
            set { SetProperty(ref _individualLifeInflow, value); }
        }
        public string IndividualLifeCommission
        {
            get { return _individualLifeCommission; }
            set { SetProperty(ref _individualLifeCommission, value); }
        }
        public long IndividualLifeBonus
        {
            get { return _individualLifeBonus; }
            set { SetProperty(ref _individualLifeBonus, value); }
        }
        public string PercentageAchieved
        {
            get { return _percentageAchieved; }
            set { SetProperty(ref _percentageAchieved, value); }
        }
        public string GroupLifeInflow
        {
            get { return _groupLifeInflow; }
            set { SetProperty(ref _groupLifeInflow, value); }
        }
        public string GroupLifeCommission
        {
            get { return _groupLifeCommission; }
            set { SetProperty(ref _groupLifeCommission, value); }
        }
        public long GroupLifeBonus
        {
            get { return _groupLifeBonus; }
            set { SetProperty(ref _groupLifeBonus, value); }
        }
        public string LifeInflow
        {
            get { return _lifeInflow; }
            set { SetProperty(ref _lifeInflow, value); }
        }
        public string TotalOverride
        {
            get { return _totalOverride; }
            set { SetProperty(ref _totalOverride, value); }
        }
        public string Username
        {
            get { return _username; }
            set { SetProperty(ref _username, value); }
        }
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public List<int> Year
        {
            get { return _year; }
            set { SetProperty(ref _year, value); }
        }
        public int SelectedYear
        {
            get { return _selectedYear; }
            set { SetProperty(ref _selectedYear, value); }
        }
        public int SelectedMonth
        {
            get { return _selectedMonth; }
            set { SetProperty(ref _selectedMonth, value); }
        }
        public string Month
        {
            get { return _Month; }
            set { SetProperty(ref _Month, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public bool IsCommissioned
        {
            get { return _isCommissioned; }
            set { SetProperty(ref _isCommissioned, value); }
        }
        public Agent LoggedAgent { get; set; }

        #endregion
        public AdvisorCommissionPageViewModel(INavigationService navigationService, IPageDialogService pageDialogService, IAgentRepository agentRepository, Logical logical,
            ICalculatorService calculatorService, IProspectRepository prospectRepository)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _agentRepository = agentRepository;
            _logical = logical;
            _calculatorService = calculatorService;
            _prospectRepository = prospectRepository;

        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;
            IsCommissioned = false;
            try
            {
                var startYear = new DateTime(1970, 1, 1).Year;
                var endYear = DateTime.Now.Year;

                var yearCount = YearCount(endYear, startYear);

                var MyList = Enumerable.Range(startYear, yearCount + 1).Reverse().ToList();

                Year = MyList;
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }
               
            }
            catch (Exception ex)
            {

            }
            IsBusy = false;


        }
        public int YearCount(int startDate, int endDate)
        {
            return startDate - endDate;
        }
        public async void ExecuteMonthlyCommissionCommand()
        {
            try
            {
                #region Months
                if (Month.Contains("January"))
                {
                    SelectedMonth = 1;
                }
                else if (Month.Contains("February"))
                {
                    SelectedMonth = 2;
                }
                else if (Month.Contains("March"))
                {
                    SelectedMonth = 3;
                }
                else if (Month.Contains("April"))
                {
                    SelectedMonth = 4;
                }
                else if (Month.Contains("May"))
                {
                    SelectedMonth = 5;
                }
                else if (Month.Contains("June"))
                {
                    SelectedMonth = 6;
                }
                else if (Month.Contains("July"))
                {
                    SelectedMonth = 7;
                }
                else if (Month.Contains("August"))
                {
                    SelectedMonth = 8;
                }
                else if (Month.Contains("September"))
                {
                    SelectedMonth = 9;
                }
                else if (Month.Contains("October"))
                {
                    SelectedMonth = 10;
                }
                else if (Month.Contains("November"))
                {
                    SelectedMonth = 11;
                }
                else if (Month.Contains("December"))
                {
                    SelectedMonth = 12;
                }
                #endregion
                if (SelectedYear <= 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Year", "Ok");

                }
                else if (SelectedMonth < 1)
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Month", "Ok");

                }
                else if (LoggedAgent.AgentCode == null || LoggedAgent.AgentCode == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "AgentCode", "Ok");

                }
                else
                {
                    logical = new Logical();
                    IsBusy = true;
                    IsCommissioned = false;
                    var agentcode = LoggedAgent.AgentCode;
                    var response = await logical.GetMonthlyDashboardForAdvisors(SelectedYear, SelectedMonth, LoggedAgent.SubAgentCode);
                    if (response.Count == 1)
                    {
                        IsBusy = false;
                        IsCommissioned = true;
                        Title = "Monthly Commission Report";
                        foreach (var item in response)
                        {
                            Username = item.Username;
                            Budget = item.MonthlyBudget;
                            Actual = item.MonthlyActual;                          
                            IndividualLifeInflow = item.IndividualLifeInflow;
                            IndividualLifeCommission = item.IndividualLifeCommission;
                            IndividualLifeBonus = item.IndividualLifeBonus;
                            PercentageAchieved = Convert.ToString(item.PercentageAchieved);
                            LifeInflow = item.LifeInflow;
                            LifeCommission = item.LifeCommission;
                            GroupLifeInflow = item.GroupLifeInflow;
                            GroupLifeCommission = item.GroupLifeCommission;
                            GroupLifeBonus = item.GroupLifeBonus;
                            LifeBonus = item.LifeBonus;                           
                            TotalOverride = item.Total;
                        }
                    }
                    else
                    {
                        IsBusy = false;
                        IsCommissioned = false;
                        await _pageDialogService.DisplayAlertAsync("Error", "Error getting Commission Report. Please try again", "Ok");
                    }
                }

            }
            catch (Exception ex)
            {
                IsBusy = false;
                await _pageDialogService.DisplayAlertAsync("Error", "Error getting Commission Report. Please try again", "Ok");

            }



        }
        public async void ExecuteYtdCommissionCommand()
        {
            try
            {
                #region Months
                if (Month.Contains("January"))
                {
                    SelectedMonth = 1;
                }
                else if (Month.Contains("February"))
                {
                    SelectedMonth = 2;
                }
                else if (Month.Contains("March"))
                {
                    SelectedMonth = 3;
                }
                else if (Month.Contains("April"))
                {
                    SelectedMonth = 4;
                }
                else if (Month.Contains("May"))
                {
                    SelectedMonth = 5;
                }
                else if (Month.Contains("June"))
                {
                    SelectedMonth = 6;
                }
                else if (Month.Contains("July"))
                {
                    SelectedMonth = 7;
                }
                else if (Month.Contains("August"))
                {
                    SelectedMonth = 8;
                }
                else if (Month.Contains("September"))
                {
                    SelectedMonth = 9;
                }
                else if (Month.Contains("October"))
                {
                    SelectedMonth = 10;
                }
                else if (Month.Contains("November"))
                {
                    SelectedMonth = 11;
                }
                else if (Month.Contains("December"))
                {
                    SelectedMonth = 12;
                }
                #endregion
                if (SelectedYear <= 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Year", "Ok");

                }
                else if (SelectedMonth < 1)
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Month", "Ok");

                }
                else if (LoggedAgent.AgentCode == null || LoggedAgent.AgentCode == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "AgentCode", "Ok");

                }
                else
                {
                    logical = new Logical();
                    IsBusy = true;
                    IsCommissioned = false;
                    var response = await logical.GetYearToDateDashboardForAdvisors(SelectedYear, SelectedMonth, LoggedAgent.SubAgentCode);
                    if (response.Count == 1)
                    {
                        IsBusy = false;
                        IsCommissioned = true;
                        Title = "Year to date Commission Report";
                        foreach (var item in response)
                        {
                            Username = item.Username;
                            Budget = item.MonthlyBudget;
                            Actual = item.MonthlyActual;
                            IndividualLifeInflow = item.IndividualLifeInflow;
                            IndividualLifeCommission = item.IndividualLifeCommission;
                            IndividualLifeBonus = item.IndividualLifeBonus;
                            PercentageAchieved = Convert.ToString(item.PercentageAchieved);
                            LifeInflow = item.LifeInflow;
                            LifeCommission = item.LifeCommission;
                            GroupLifeInflow = item.GroupLifeInflow;
                            GroupLifeCommission = item.GroupLifeCommission;
                            GroupLifeBonus = item.GroupLifeBonus;
                            LifeBonus = item.LifeBonus;
                            TotalOverride = item.Total;
                        }
                    }
                    else
                    {
                        IsBusy = false;
                        IsCommissioned = false;
                        await _pageDialogService.DisplayAlertAsync("Error", "Error getting Commission Report. Please try again", "Ok");
                    }
                }

            }
            catch (Exception ex)
            {
                IsBusy = false;
                await _pageDialogService.DisplayAlertAsync("Error", "Error getting Commission Report. Please try again", "Ok");
            }

        }
    }
}
