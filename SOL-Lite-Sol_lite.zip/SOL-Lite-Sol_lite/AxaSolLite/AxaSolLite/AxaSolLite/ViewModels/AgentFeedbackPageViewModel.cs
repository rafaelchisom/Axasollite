﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AxaSolLite.ViewModels
{
	public class AgentFeedbackPageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IAgentRepository _agentRepository;
        private readonly ICalculatorService _calculatorService;
        private readonly IProspectRepository _prospectRepository;
        private readonly Logical _logical;

        private string _agentFullName;
        private string _agentEmailAddress;
        private string _agentCode;
        private string _agentPhoneNumber;
        private string _comment;
        private bool _isBusy;

        public string AgentFullName
        {
            get { return _agentFullName; }
            set { SetProperty(ref _agentFullName, value); }
        }
        public string AgentEmailAddress
        {
            get { return _agentEmailAddress; }
            set { SetProperty(ref _agentEmailAddress, value); }
        }
        public string AgentCode
        {
            get { return _agentCode; }
            set { SetProperty(ref _agentCode, value); }
        }
        public string AgentPhoneNumber
        {
            get { return _agentPhoneNumber; }
            set { SetProperty(ref _agentPhoneNumber, value); }
        }
        public string Comment
        {
            get { return _comment; }
            set { SetProperty(ref _comment, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public Agent LoggedAgent { get; set; }

        private DelegateCommand _proceedCommand;

        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProccedCommand));
        public AgentFeedbackPageViewModel(INavigationService navigationService, IPageDialogService pageDialogService, IAgentRepository agentRepository, Logical logical,
            ICalculatorService calculatorService, IProspectRepository prospectRepository)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _agentRepository = agentRepository;
            _logical = logical;
            _calculatorService = calculatorService;
            _prospectRepository = prospectRepository;

        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            try
            {
                IsBusy = true ;
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                        AgentFullName = LoggedAgent.FullName;
                        AgentEmailAddress = LoggedAgent.EmailAddress;
                        AgentCode = LoggedAgent.AgentCode;
                        AgentPhoneNumber = LoggedAgent.MobileNo;
                    }
                }
                IsBusy = false;
                
            }
            catch (Exception ex)
            {

            }

        }

        public async void ExecuteProccedCommand()
        {
            IsBusy = true;
            try
            {
                if (AgentFullName == "" || AgentFullName == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Agent Fullname", "Ok");

                }
                else if (AgentEmailAddress == null || AgentEmailAddress == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Agent EmailAddress", "Ok");

                }
                else if (AgentCode == null || AgentCode == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "AgentCode", "Ok");

                }
                else if (AgentPhoneNumber == null || AgentPhoneNumber == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Agent PhoneNumber", "Ok");

                }
                else if (Comment == null || Comment== "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Add a comment", "Ok");

                }
               
                
                else
                {
                    FeedbackRequest req = new FeedbackRequest();
                    req.AgentEmailAddress = AgentEmailAddress;
                    req.AgentCode = AgentCode;
                    req.Body = Comment;
                    
                    var sent = await _logical.SendFeedbackMail(req);
                    if (sent)
                    {
                        await _pageDialogService.DisplayAlertAsync("Mail Sent", "Your complain has been sent to the support team", "Ok");
                        AxaSolLiteProcessEfficiency processEfficiency = new AxaSolLiteProcessEfficiency //assigning value to the object
                        {
                            AgentCode = AgentCode,
                            Complaint = Comment,
                            IsResolved = false,
                            AgentFullName = LoggedAgent.FullName
                        };
                        bool inserted = await _logical.InsertFeedbackDetails(processEfficiency);
                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Mail Not Sent", "Try Again", "Ok");
                    }
                }
                IsBusy = false;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
    }
}
