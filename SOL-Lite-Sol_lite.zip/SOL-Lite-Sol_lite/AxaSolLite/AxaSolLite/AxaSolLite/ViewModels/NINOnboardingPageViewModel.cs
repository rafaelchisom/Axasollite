﻿using AxaSolLite.Models;
using AxaSolLite.Models.CustomerOnboardingCreateCase;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Plugin.FilePicker;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AxaSolLite.ViewModels
{
    public class NINOnboardingPageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly IMediaManager _deviceManager;
        private readonly IStatesRepository _statesRepository;
        private readonly ICountryRepository _countryRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        private bool _isBusy;
        private Prospect _selectedProspect;
        private Agent _loggedAgent;
        private string _customerNumber;
        private CustomerDetailsReponse _customer;
        private string _nIN;
        private string _address;
        private bool _isSameAddress;
        private bool _hasRetrievedNINDetails;
        private string _firstName;
        private string _middleName;
        private string _lastName;
        private string _maidenName;
        private string _dateOfBirth;
        private string _phoneNumber;
        private string _emailAddress;
        private string _stateOfOrigin;
        private string _stateOfResidence;
        private string _nationality;
        private string _occupation;
        private string _city;
        private bool _needsToUploadDocument;
        private string[] _fileTypes;
        private byte[] _contents;
        private string _contentType;
        private string _fileLabel;
        private string _fileLabelPath;
        private string _fileSize;
        private byte[] _photo;
        private List<ResultSample> _myCities = new List<ResultSample>();
        private List<string> _cities = new List<string>();
        private List<string> _states = new List<string>();
        private string _title;
        private string _residentialAddress;
        private string _gender;
        private Guid _prospectId;
        private byte[] _displayPicture;

        public byte[] DisplayPicture
        {
            get { return _displayPicture; }
            set { SetProperty(ref _displayPicture, value); }
        }
        public string Gender
        {
            get { return _gender; }
            set { SetProperty(ref _gender, value); }
        }
        public string ResidentialAddress
        {
            get { return _residentialAddress; }
            set { SetProperty(ref _residentialAddress, value); }
        }
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public List<string> States
        {
            get { return _states; }
            set { SetProperty(ref _states, value); }
        }
        public List<string> Cities
        {
            get { return _cities; }
            set { SetProperty(ref _cities, value); }
        }
        public List<ResultSample> MyCities
        {
            get { return _myCities; }
            set { SetProperty(ref _myCities, value); }
        }
        public byte[] Photo
        {
            get { return _photo; }
            set { SetProperty(ref _photo, value); }
        }
        public string FileSize
        {
            get { return _fileSize; }
            set { SetProperty(ref _fileSize, value); }
        }
        public string FileLabelPath
        {
            get { return _fileLabelPath; }
            set { SetProperty(ref _fileLabelPath, value); }
        }
        public byte[] Contents
        {
            get { return _contents; }
            set { SetProperty(ref _contents, value); }
        }
        public string ContentType
        {
            get { return _contentType; }
            set { SetProperty(ref _contentType, value); }
        }
        public string FileLabel
        {
            get { return _fileLabel; }
            set { SetProperty(ref _fileLabel, value); }
        }
        public string[] FileTypes
        {
            get { return _fileTypes; }
            set { SetProperty(ref _fileTypes, value); }
        }
        public bool NeedsToUploadDocument
        {
            get { return _needsToUploadDocument; }
            set { SetProperty(ref _needsToUploadDocument, value); }
        }
        public string City
        {
            get { return _city; }
            set { SetProperty(ref _city, value); }
        }
        public string Occupation
        {
            get { return _occupation; }
            set { SetProperty(ref _occupation, value); }
        }
        public string Nationality
        {
            get { return _nationality; }
            set { SetProperty(ref _nationality, value); }
        }
        public string StateOfResidence
        {
            get { return _stateOfResidence; }
            set { SetProperty(ref _stateOfResidence, value); }
        }
        public string StateOfOrigin
        {
            get { return _stateOfOrigin; }
            set { SetProperty(ref _stateOfOrigin, value); }
        }
        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }
        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { SetProperty(ref _phoneNumber, value); }
        }
        public string DateOfBirth
        {
            get { return _dateOfBirth; }
            set { SetProperty(ref _dateOfBirth, value); }
        }
        public string MaidenName
        {
            get { return _maidenName; }
            set { SetProperty(ref _maidenName, value); }
        }
        public string LastName
        {
            get { return _lastName; }
            set { SetProperty(ref _lastName, value); }
        }
        public string MiddleName
        {
            get { return _middleName; }
            set { SetProperty(ref _middleName, value); }
        }
        public string FirstName
        {
            get { return _firstName; }
            set { SetProperty(ref _firstName, value); }
        }
        public bool HasRetrievedNINDetails
        {
            get { return _hasRetrievedNINDetails; }
            set { SetProperty(ref _hasRetrievedNINDetails, value); }
        }
        public bool IsSameAddress
        {
            get { return _isSameAddress; }
            set { SetProperty(ref _isSameAddress, value); }
        }
        public string Address
        {
            get { return _address; }
            set { SetProperty(ref _address, value); }
        }
        public string NIN
        {
            get { return _nIN; }
            set { SetProperty(ref _nIN, value); }
        }
        public CustomerDetailsReponse Customer
        {
            get { return _customer; }
            set { SetProperty(ref _customer, value); }
        }
        public string CustomerNumber
        {
            get { return _customerNumber; }
            set { SetProperty(ref _customerNumber, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public Agent LoggedAgent
        {
            get { return _loggedAgent; }
            set { SetProperty(ref _loggedAgent, value); }
        }
        public Prospect SelectedProspect
        {
            get { return _selectedProspect; }
            set { SetProperty(ref _selectedProspect, value); }
        }
        public NINResponse NINResponse { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }

        private DelegateCommand _getNINDetailsCommand;
        private DelegateCommand _enterAddressCommand;
        private DelegateCommand _completeOnboarding;
        private DelegateCommand _pickfileCommand;
        private DelegateCommand _getCitiesCommand;
        public DelegateCommand GetNINDetailsCommand => _getNINDetailsCommand ?? (_getNINDetailsCommand = new DelegateCommand(ExecuteGetNINDetailsCommmand));
        public DelegateCommand EnterAddressCommand => _enterAddressCommand ?? (_enterAddressCommand = new DelegateCommand(ExecuteEnterAddressCommand));
        public DelegateCommand PickFileCommand => _pickfileCommand ?? (_pickfileCommand = new DelegateCommand(ExecutePickFileCommand));
        public DelegateCommand GetCitiesCommand => _getCitiesCommand ?? (_getCitiesCommand = new DelegateCommand(ExecuteGetCitiesCommand));
        public DelegateCommand CompleteOnboardingCommand => _completeOnboarding ?? (_completeOnboarding = new DelegateCommand(ExecuteCompleteOnboardingCommand));

        public NINOnboardingPageViewModel(INavigationService navigationService, IPageDialogService pageDialogService, IMediaManager mediaManager, IStatesRepository statesRepository,
            Logical logical, IProspectRepository prospectRepository, IAgentRepository agentRepository, IProductPlansRepository productPlansRepository, ICountryRepository countryRepository,
            EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _prospectRepository = prospectRepository;
            _agentRepository = agentRepository;
            _productPlansRepository = productPlansRepository;
            _deviceManager = mediaManager;
            _statesRepository = statesRepository;
            _countryRepository = countryRepository;
            _logical = logical;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            //Guid prospectId;
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteGetNINDetailsCommmand()
        {
            IsBusy = true;
            try
            {
                if (string.IsNullOrEmpty(NIN))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Kindly enter your nin", "Ok");
                }
                else
                {
                    NINRequest nINRequest = new NINRequest
                    {
                        IdentityNo = NIN,
                        Firstname = SelectedProspect.FirstName,
                        Lastname = SelectedProspect.LastName,
                        DOB = SelectedProspect.Birthdate
                    };
                    var response = await _logical.GetNINDetails(nINRequest);
                    //response.Data.StateOfOrigin = "Oyo"; //REMOVE LATER
                    if (response != null && response.IsSuccessful && response.Data != null)
                    {
                        NINResponse = response;
                        int gender = 0;
                        if (response.Data.Gender == "m")
                            gender = 1;

                        if(response.Data.Firstname.ToLower().Trim() != SelectedProspect.FirstName.ToLower().Trim() || response.Data.Lastname.ToLower().Trim() != SelectedProspect.LastName.ToLower().Trim() || Convert.ToDateTime(response.Data.Birthdate) != SelectedProspect.Birthdate || gender != SelectedProspect.Gender)
                        {
                            bool choice = await _pageDialogService.DisplayAlertAsync("Notice", "Customer information appears to be different. Kindly proceed with manual onboarding", "Yes", "No");
                            if (choice)
                            {
                                NavigationParameters parameters = new NavigationParameters();
                                parameters.Add("ProspectId", SelectedProspect.Id);
                                parameters.Add("AgentId", LoggedAgent.Id);
                                parameters.Add("NINResponse", NINResponse);
                                await _navigationService.NavigateAsync("CustomerOnboardingPage", parameters);
                            }
                            else
                            {
                                SelectedProspect.IsEkycStatus = true;
                                string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                                EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                                int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                                //await _prospectRepository.UpdateAsync(SelectedProspect);

                                NavigationParameters parameters = new NavigationParameters();
                                parameters.Add("ProspectId", SelectedProspect.Id);
                                parameters.Add("AgentId", LoggedAgent.Id);
                                await _navigationService.NavigateAsync("ProductLogPage", parameters);
                            }
                        }
                        else
                        {
                            HasRetrievedNINDetails = true;
                            IsSameAddress = true;

                            Title = response.Data.Title;
                            FirstName = response.Data.Firstname;
                            LastName = response.Data.Lastname;
                            DateOfBirth = response.Data.Birthdate;
                            MiddleName = response.Data.Middlename;
                            PhoneNumber = response.Data.Phone;
                            EmailAddress = response.Data.Email;
                            StateOfOrigin = response.Data.StateOfOrigin;
                            StateOfResidence = response.Data.Residence.State;
                            Nationality = response.Data.Nationality;
                            Occupation = response.Data.Profession;
                            City = response.Data.PlaceOfOrigin;
                            ResidentialAddress = response.Data.Residence.Address1;
                            Gender = response.Data.Gender == "m" ? "Male" : "Female";
                            DisplayPicture = Convert.FromBase64String(response.Data.Photo);
                        }
                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Ooops!", "Unable to verify NIN details at the moment", "Ok");
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                await _pageDialogService.DisplayAlertAsync("Ooops!", "Unable to verify NIN details at the moment as there was an exception.", "Ok");
            }
            IsBusy = false;
        }

        private async void ExecuteEnterAddressCommand()
        {
            IsBusy = true;
            try
            {
                if (!IsSameAddress)
                {
                    bool choice = await _pageDialogService.DisplayAlertAsync("Notice", "Kindly proceed with manual onboarding", "Yes", "No");
                    if (choice)
                    {
                        NavigationParameters parameters = new NavigationParameters();
                        parameters.Add("ProspectId", SelectedProspect.Id);
                        parameters.Add("AgentId", LoggedAgent.Id);
                        parameters.Add("NINResponse", NINResponse);
                        await _navigationService.NavigateAsync("CustomerOnboardingPage", parameters);
                    }
                    else
                    {
                        SelectedProspect.IsEkycStatus = true;
                        string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                        EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                        int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                        //await _prospectRepository.UpdateAsync(SelectedProspect);
                        NavigationParameters parameters = new NavigationParameters();
                        parameters.Add("ProspectId", SelectedProspect.Id);
                        parameters.Add("AgentId", LoggedAgent.Id);
                        await _navigationService.NavigateAsync("ProductLogPage", parameters);
                    }
                }
            }
            catch (Exception xe)
            {
                xe.Message.ToString();
            }
            IsBusy = false;
        }

        private async void ExecuteGetCitiesCommand()
        {
            IsBusy = true;
            try
            {
                Cities.Clear();
                var SelectedStateOfResidence = await _statesRepository.GetStateCodeByState(StateOfResidence);
                MyCities = await _logical.GetCities(SelectedStateOfResidence.StateCode);

                if (MyCities != null)
                {
                    foreach (var item in MyCities)
                    {
                        Cities.Add(item.NAME);
                    }
                    Cities = Cities.ToList();
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async void ExecutePickFileCommand()
        {
            IsBusy = true;
            try
            {
                bool choice = await _pageDialogService.DisplayAlertAsync("Confirm", "Please select how you wish to upload a document", "Camera", "Gallery");

                if (choice)
                {
                    if (_deviceManager.CameraAvailable)
                    {
                        var newPhoto = await _deviceManager.TakePhotoAsync();

                        if (newPhoto != null && newPhoto.FileContent.Length <= 4194304)
                        {
                            Photo = newPhoto.FileContent;
                            Contents = Photo;
                            FileVariable CameraTaken = new FileVariable
                            {
                                FileName = newPhoto.FileName,
                                FileContent = Convert.ToBase64String(Contents),
                                FieldName = string.Empty,
                                ContentType = "image/jpg",
                                Extension = "jpg"
                            };
                            FileLabel = newPhoto.FileName;
                        }
                    }
                }
                else
                {
                    if (Device.RuntimePlatform == Device.Android)
                    {
                        FileTypes = new string[] { "image/png", "image/jpeg", "application/pdf" };
                    }

                    await PickedFiles(FileTypes);

                    FileVariable motorFile = new FileVariable
                    {
                        FileName = FileLabel,
                        FieldName = "Utility Bill",
                        FileContent = Convert.ToBase64String(Contents),
                        ContentType = ContentType,
                        Extension = !ContentType.ToLower().Contains("jpeg") ? ContentType.Substring((ContentType.Length - 3), 3) : ContentType.Substring((ContentType.Length - 4), 4)
                    };

                    FileLabel = FileLabel;
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        public async Task PickedFiles(string[] fileTypes)
        {
            try
            {
                var pickedFile = await CrossFilePicker.Current.PickFile(fileTypes);

                if (pickedFile != null)
                {
                    FileLabel = pickedFile.FileName;
                    FileLabelPath = pickedFile.FilePath;

                    if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase))
                    {
                        Contents = pickedFile.DataArray;

                        if (pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "application/pdf";
                        }
                        else if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "image" + "/jpg";
                        }
                        else if (pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "image" + "/png";
                        }
                        else
                            ContentType = "image" + "/jpeg";
                    }

                    //FileSize = FileSizeFormatter.FormatSize(Contents.Length);

                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteCompleteOnboardingCommand()
        {
            IsBusy = true;
            try
            {
                PMRequestParam customerCaseRequest = new PMRequestParam();

                if (IsSameAddress)
                {
                    
                    if (NINResponse != null && NINResponse.Data != null && string.IsNullOrEmpty(NINResponse.Data.StateOfOrigin))
                    {
                        bool choice = await _pageDialogService.DisplayAlertAsync("Notice", "Customer information appears to be missing state of origin. Kindly proceed with manual onboarding", "Yes", "No");
                        if (choice)
                        {
                            NavigationParameters parameters = new NavigationParameters();
                            parameters.Add("ProspectId", SelectedProspect.Id);
                            parameters.Add("AgentId", LoggedAgent.Id);
                            parameters.Add("NINResponse", NINResponse);
                            await _navigationService.NavigateAsync("CustomerOnboardingPage", parameters);
                        }
                        else
                        {
                            SelectedProspect.IsEkycStatus = true;
                            string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                            EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                            int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                            //await _prospectRepository.UpdateAsync(SelectedProspect);

                            NavigationParameters parameters = new NavigationParameters();
                            parameters.Add("ProspectId", SelectedProspect.Id);
                            parameters.Add("AgentId", LoggedAgent.Id);
                            await _navigationService.NavigateAsync("ProductLogPage", parameters);
                        }
                        return;
                    }
                    else if (NINResponse != null && NINResponse.Data != null && NINResponse.Data.Residence != null && string.IsNullOrEmpty(NINResponse.Data.Residence.State))
                    {
                        bool choice = await _pageDialogService.DisplayAlertAsync("Notice", "Customer information appears to be missing state of residence. Kindly proceed with manual onboarding", "Yes", "No");
                        if (choice)
                        {
                            NavigationParameters parameters = new NavigationParameters();
                            parameters.Add("ProspectId", SelectedProspect.Id);
                            parameters.Add("AgentId", LoggedAgent.Id);
                            parameters.Add("NINResponse", NINResponse);
                            await _navigationService.NavigateAsync("CustomerOnboardingPage", parameters);
                        }
                        else
                        {
                            SelectedProspect.IsEkycStatus = true;
                            string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                            EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                            int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                            //await _prospectRepository.UpdateAsync(SelectedProspect);

                            NavigationParameters parameters = new NavigationParameters();
                            parameters.Add("ProspectId", SelectedProspect.Id);
                            parameters.Add("AgentId", LoggedAgent.Id);
                            await _navigationService.NavigateAsync("ProductLogPage", parameters);
                        }
                        return;
                    }

                    CustomerUpdate customerUpdate = new CustomerUpdate
                    {
                        Address = NINResponse.Data.Residence.Address1,
                        GenderCode = SelectedProspect.Gender == 0 ? 2 : 1,
                        CustomerNo = SelectedProspect.CustomerNumber,
                        Email = SelectedProspect.Email,
                        FullName = NINResponse.Data.Firstname + " " + NINResponse.Data.Middlename + " " + NINResponse.Data.Lastname,
                        DobCode = SelectedProspect.Birthdate,
                        TelephoneNo = SelectedProspect.MobileNumber,
                        Title = Convert.ToInt32(SelectedProspect.TitleId),
                        Sbu = Convert.ToInt32(LoggedAgent.SBU),
                        Bvn = "",
                        Firstname = NINResponse.Data.Firstname,
                        Dob = SelectedProspect.Birthdate.ToString("MM/dd/yyyy"),
                        Gender = SelectedProspect.Gender == 0 ? "Female" : "Male",
                        Lastname = NINResponse.Data.Lastname,
                        Middlename = NINResponse.Data.Middlename,
                        Nationality = NINResponse.Data.Nationality,
                        Nin = NINResponse.Data.Nin,
                        ReligionCode = 1,
                        NationalityCode = 1
                    };                    

                    if (StateOfOrigin != null)
                    {
                        var SelectedState = await _statesRepository.GetStateCodeByState(StateOfOrigin);
                        if (SelectedState != null)
                        {
                            customerUpdate.StateCode = SelectedState.StateCode;
                        }
                        else
                            customerUpdate.StateCode = 99;
                    }
                    else
                    {
                        customerUpdate.StateCode = 99;
                    }

                    if(customerUpdate.StateCode != 0 && customerUpdate.StateCode != 99)
                    {
                        var MyCities = await _logical.GetCities(customerUpdate.StateCode);
                        if (!string.IsNullOrEmpty(NINResponse.Data.PlaceOfOrigin))
                        {
                            var City = MyCities.Where(x => x.NAME.ToLower() == NINResponse.Data.PlaceOfOrigin.ToLower()).FirstOrDefault();
                            if(City != null)
                            {
                                customerUpdate.CityCode = City.CODE;
                            }
                            else
                            {
                                customerUpdate.CityCode = 408;
                            }                            
                        } 
                        else
                            customerUpdate.CityCode = 408;
                    }
                    else
                    {
                        customerUpdate.CityCode = 408;
                    }

                    if(Occupation != null)
                    {
                        var Occupations = await _logical.GetOccupationList();
                        if (Occupations != null)
                        {
                            var jobs = Occupations.Result.ToList();
                            var myJob = jobs.Where(x => x.NAME == Occupation).FirstOrDefault();
                            if (myJob != null)
                            {
                                customerUpdate.OccupationCode = myJob.CODE;
                            }
                            else
                                customerUpdate.OccupationCode = 395;
                        }
                        else
                            customerUpdate.OccupationCode = 395;
                    }
                    else
                    {
                        customerUpdate.OccupationCode = 395;
                    }

                    var updateResponse = await _logical.UpdateCustomerDetails(customerUpdate);

                    if(updateResponse != null && updateResponse.ActionStatus)
                    {
                        var ProductPlan = await _productPlansRepository.GetProductPlansByProspectId(SelectedProspect.Id);
                        
                        foreach (var item in ProductPlan.ToList())
                        {
                            item.IsNotPolicyId = true;
                            await _productPlansRepository.UpdateAsync(item);
                        }
                        SelectedProspect.IsEkycStatus = false;
                        SelectedProspect.CaseCreated = true;
                        string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                        EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                        int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                        //await _prospectRepository.UpdateAsync(SelectedProspect);
                        await _pageDialogService.DisplayAlertAsync("Successful", "E-kyc completed", "Okay");
                        ProspectCaseCreated prospectCaseCreated = new ProspectCaseCreated
                        {
                            CaseCreated = true,
                            CustomerNumber = SelectedProspect.CustomerNumber
                        };

                        await _logical.ConfirmOnboardingCaseCreated(prospectCaseCreated);

                        EkycReportRequest req = new EkycReportRequest();
                        req.CaseID = Convert.ToInt32(SelectedProspect.CustomerName);
                        req.DateSent = DateTime.Now;
                        if (LoggedAgent.IsAdvisor)
                        {
                            req.CurrentUser = LoggedAgent.SubAgentCode + "/" + LoggedAgent.FullName;
                            req.SentBy = LoggedAgent.SubAgentCode + "/" + LoggedAgent.FullName;
                        }
                        else
                        {
                            req.CurrentUser = LoggedAgent.AgentCode + "/" + LoggedAgent.FullName;
                            req.SentBy = LoggedAgent.AgentCode + "/" + LoggedAgent.FullName;
                        }
                        req.CaseStatus = "COMPLETED";
                        req.PolicyRegion = Convert.ToInt32(LoggedAgent.SBU);
                        req.ApprovalLevel = "NiN Onboared";
                        
                        req.CaseTitle = " NIN Onboarding for Lead Account";

                                            
                       var res = await _logical.EkycReport(req);

                        bool MailSent = await _logical.SendEkycCompletedMail(SelectedProspect.CustomerNumber, SelectedProspect.FullName, SelectedProspect.Email, LoggedAgent.EmailAddress);
                        if (MailSent)
                        {
                            await _pageDialogService.DisplayAlertAsync("Mail Sent", "Email has been sent to the customer successfully", "Okay");
                        }
                        NavigationParameters parameters = new NavigationParameters();
                        parameters.Add("ProspectId", SelectedProspect.Id);
                        parameters.Add("AgentId", LoggedAgent.Id);
                        await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", parameters);
                    }
                    else
                    {
                        SelectedProspect.IsEkycStatus = true;
                        string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                        EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                        int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                        //await _prospectRepository.UpdateAsync(SelectedProspect);
                        await _pageDialogService.DisplayAlertAsync("Error", "Unable to complete e-kyc. Please try again", "Okay");
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                await _pageDialogService.DisplayAlertAsync("Error", ex.Message.ToString(), "Okay");
            }
            IsBusy = false;
        }

        public string GetTransRef()
        {
            Guid guid = Guid.NewGuid();
            var TransRef = Convert.ToBase64String(guid.ToByteArray());
            return TransRef.Replace("=", "");
        }
    }
}
