﻿using AxaSolLite.Models;
using AxaSolLite.Models.CustomerOnboardingCreateCase;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Plugin.FilePicker;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AxaSolLite.ViewModels
{
    public class MotorValuationPageViewModel : BindableBase, INavigationAware
    {
        private readonly IRepositoryManager _repositoryManager;
        private readonly IUserManager _userService;
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IMediaManager _deviceManager;
        private readonly IProspectRepository _prospectRepository;
        private readonly IProductPlansRepository _productPlanRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly EncryptUtils _encryptUtils;

        #region Fields
        private List<int> _vehicleYear;
        private MotorDetailSample _myVehicleMakes;
        private MakeModeDetailsSample _myVehicleModels;
        private ObservableCollection<string> _vehicleMakes = new ObservableCollection<string>();
        private ObservableCollection<string> _vehicleModels = new ObservableCollection<string>();
        private ObservableCollection<string> _vehicleReturned = new ObservableCollection<string>();
        private string _selectedVehicleMake;
        private string _SelectedVehicleModel;
        private double _vehicleValue;
        private int _SelectedVehicleYear;
        private bool _isMaintainValue;
        private bool _isConsentForm;
        private bool _isReviseValue;
        private string _policyType;
        private string _text;
        private string _fileLabel;
        private string _fileLabelPath;
        private string[] _fileTypes;
        private string _fileSize;
        private Image _fileImagePreview;
        private ObservableCollection<FileVariable> _fileNameList = new ObservableCollection<FileVariable>();
        private Dictionary<string, object> _fileByteList;
        private byte[] _contents;
        private Guid _prospectId;
        private Guid _productPlanId;
        private ProductPlan _productPlan;
        List<object> vehicleMakes = new List<object>();
        private double _checkiMaxValue;
        private double _checkiMinValue;
        private MakeList _motorMake;
        private ModelList _motorModel;
        private string _contentType;
        private FileVariable _uploadedFile = new FileVariable();
        private string _proofOfValuation;
        private string _consentForm;
        private int _checkiRemark;
        private bool _isBusy;
        #endregion

        #region Properties 
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public string ConsentForm
        {
            get { return _consentForm; }
            set { SetProperty(ref _consentForm, value); }
        }
        public string ProofOfValuation
        {
            get { return _proofOfValuation; }
            set { SetProperty(ref _proofOfValuation, value); }
        }
        public FileVariable UploadedFile
        {
            get { return _uploadedFile; }
            set { SetProperty(ref _uploadedFile, value); }
        }
        public string ContentType
        {
            get { return _contentType; }
            set { SetProperty(ref _contentType, value); }
        }
        public ModelList MotorModel
        {
            get { return _motorModel; }
            set { SetProperty(ref _motorModel, value); }
        }
        public MakeList MotorMake
        {
            get { return _motorMake; }
            set { SetProperty(ref _motorMake, value); }
        }
        public double CheckiMinValue
        {
            get { return _checkiMinValue; }
            set { SetProperty(ref _checkiMinValue, value); }
        }
        public double CheckiMaxValue
        {
            get { return _checkiMaxValue; }
            set { SetProperty(ref _checkiMaxValue, value); }
        }
        public List<int> VehicleYear
        {
            get { return _vehicleYear; }
            set { SetProperty(ref _vehicleYear, value); }
        }
        public int SelectedYear
        {
            get { return _SelectedVehicleYear; }
            set { SetProperty(ref _SelectedVehicleYear, value); }
        }
        public int CheckiRemark
        {
            get { return _checkiRemark; }
            set { SetProperty(ref _checkiRemark, value); }
        }
        public string SelectedVehicleMake
        {
            get { return _selectedVehicleMake; }
            set { SetProperty(ref _selectedVehicleMake, value); }
        }
        public string SelectedVehicleModel
        {
            get { return _SelectedVehicleModel; }
            set { SetProperty(ref _SelectedVehicleModel, value); }
        }
        public string PolicyType
        {
            get { return _policyType; }
            set { SetProperty(ref _policyType, value); }
        }
        public string Text
        {
            get { return _text; }
            set { SetProperty(ref _text, value); }
        }
        public MotorDetailSample MyVehicleMakes
        {
            get { return _myVehicleMakes; }
            set { SetProperty(ref _myVehicleMakes, value); }
        }
        public MakeModeDetailsSample MyVehicleModels
        {
            get { return _myVehicleModels; }
            set { SetProperty(ref _myVehicleModels, value); }
        }
        public ObservableCollection<string> VehicleMakes
        {
            get { return _vehicleMakes; }
            set { SetProperty(ref _vehicleMakes, value); }
        }
        public ObservableCollection<string> VehicleModels
        {
            get { return _vehicleModels; }
            set { SetProperty(ref _vehicleModels, value); }
        }
        public ObservableCollection<string> VehicleReturned
        {
            get { return _vehicleReturned; }
            set { SetProperty(ref _vehicleReturned, value); }
        }
        public double VehicleValue
        {
            get { return _vehicleValue; }
            set { SetProperty(ref _vehicleValue, value); }
        }
        public bool IsMainTainValue
        {
            get { return _isMaintainValue; }
            set { SetProperty(ref _isMaintainValue, value); }
        }
        public bool IsConsentForm
        {
            get { return _isConsentForm; }
            set { SetProperty(ref _isConsentForm, value); }
        }
        public bool IsReviseValue
        {
            get { return _isReviseValue; }
            set { SetProperty(ref _isReviseValue, value); }
        }
        public ObservableCollection<FileVariable> FileNameList
        {
            get { return _fileNameList; }
            set { SetProperty(ref _fileNameList, value); }
        }
        public Dictionary<string, object> FileByteList
        {
            get { return _fileByteList; }
            set { SetProperty(ref _fileByteList, value); }
        }
        public byte[] Contents
        {
            get { return _contents; }
            set { SetProperty(ref _contents, value); }
        }
        public string FileLabel
        {
            get { return _fileLabel; }
            set { SetProperty(ref _fileLabel, value); }
        }
        public string FileLabelPath
        {
            get { return _fileLabelPath; }
            set { SetProperty(ref _fileLabelPath, value); }
        }
        public string FileSize
        {
            get { return _fileSize; }
            set { SetProperty(ref _fileSize, value); }
        }
        public string[] FileTypes
        {
            get { return _fileTypes; }
            set { SetProperty(ref _fileTypes, value); }
        }
        public Image FileImagePreview
        {
            get { return _fileImagePreview; }
            set { SetProperty(ref _fileImagePreview, value); }
        }
        public Prospect SelectedProspect { get; private set; }
        public Agent LoggedAgent { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }
        public ProductPlan ProductPlan
        {
            get { return _productPlan = _productPlan ?? (_productPlan = new ProductPlan()); }
            set { SetProperty(ref _productPlan, value); }
        }
        #endregion

        #region Command
        private DelegateCommand<string> _changeVehicleMakeCommand;
        private DelegateCommand<string> _checkiCommand;
        private DelegateCommand _proceedCommand;
        private DelegateCommand _pickDocumentCommand;
        //private DelegateCommand _pickConsentFormCommand;
        private DelegateCommand<string> _fileDeleteCommand;

        public DelegateCommand<string> ChangeVehicleMakeCommand => _changeVehicleMakeCommand ?? (_changeVehicleMakeCommand = new DelegateCommand<string>(ExecuteChangeVehicleMakeCommand));
        public DelegateCommand<string> CheckiCommand => _checkiCommand ?? (_checkiCommand = new DelegateCommand<string>(ExecuteCheckiCommand));
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProceedCommand));
        public DelegateCommand PickDocumentCommand => _pickDocumentCommand ?? (_pickDocumentCommand = new DelegateCommand(ExecutePickDocumentCommand));
        //public DelegateCommand PickConsentFormCommand => _pickConsentFormCommand ?? (_pickConsentFormCommand = new DelegateCommand(ExecutePickConsentFormCommand));
        public DelegateCommand<string> FileDeleteCommand => _fileDeleteCommand ?? (_fileDeleteCommand = new DelegateCommand<string>(ExecuteFileDeleteCommand));
        Logical logical = null;
        #endregion

        public MotorValuationPageViewModel(IUserManager userService,
            INavigationService navigationService,
            IPageDialogService pageDialogService,
            IRepositoryManager repositoryServices,
            IProspectRepository prospectRepository,
            IProductPlansRepository productPlanRepository,
            IMediaManager deviceManager, IAgentRepository agentRepository, EncryptUtils encryptUtils)
        {
            _userService = userService;
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _repositoryManager = repositoryServices;
            _prospectRepository = prospectRepository;
            _productPlanRepository = productPlanRepository;
            _deviceManager = deviceManager;
            _agentRepository = agentRepository;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }

                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }

                if (parameters.ContainsKey("ProductPlanId"))
                {
                    Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId);
                    ProductPlan = await _productPlanRepository.GetProductPlanByProductPlanId(_productPlanId);
                }


                IsReviseValue = true;
                IsMainTainValue = false;
                IsConsentForm = false;
                PolicyType = ProductPlan.PlanCategory;
                logical = new Logical();
                var m = await logical.GetMotorMakes();
                MyVehicleMakes = m;
                foreach (var item in m.Result.MakeList)
                {
                    var pre = item.Name;
                    VehicleMakes.Add(pre);
                }
                var startYear = new DateTime(1970, 1, 1).Year;
                var endYear = DateTime.Now.Year;
                var yearCount = YearCount(endYear, startYear);
                var MyList = Enumerable.Range(startYear, yearCount + 1).Reverse().ToList();
                VehicleYear = MyList;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        public int YearCount(int startDate, int endDate)
        {
            return startDate - endDate;
        }

        public async void ExecuteChangeVehicleMakeCommand(string make)
        {
            IsBusy = true;
            List<string> motorModels = new List<string>();
            try
            {
                if (Regex.IsMatch(SelectedVehicleMake, @"\d"))
                {
                    VehicleModels.Clear();
                    var models = await logical.GetMotorModels(Convert.ToInt32(SelectedVehicleMake));
                    foreach (var item in models.Result.ModelList)
                    {
                        if (item.Name != null)
                        {
                            VehicleModels.Add(item.Name);
                        }
                        else
                        {
                            VehicleModels.Add(string.Empty);
                        }
                    }

                }
                else if (SelectedVehicleMake != null)
                {
                    VehicleModels.Clear();
                    make = SelectedVehicleMake;

                    var res = MyVehicleMakes.Result.MakeList.Where(x => x.Name == make).FirstOrDefault();
                    var var = await logical.GetMotorModels(Convert.ToInt32(res.Id));
                    MyVehicleModels = var;
                    foreach (var item in var.Result.ModelList)
                    {
                        var pre = item.Name;

                        VehicleModels.Add(pre);
                    }
                }
                else
                {
                    return;
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        public async void ExecuteCheckiCommand(string make)
        {
            IsBusy = true;
            try
            {
                CheckiRemark = 0;
                bool isChoice;
                if (SelectedVehicleMake == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Vehicle Make", "Ok");
                }
                else if (SelectedVehicleModel == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Vehicle Model", "Ok");
                }
                else if (SelectedYear == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Vehicle Year", "Ok");
                }
                else if (VehicleValue == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Vehicle Value", "Ok");
                }
                else
                {
                    var makes = SelectedVehicleMake;
                    var res = MotorMake = MyVehicleMakes.Result.MakeList.Where(x => x.Name == makes).FirstOrDefault();
                    var models = SelectedVehicleModel;
                    var mod = MotorModel = MyVehicleModels.Result.ModelList.Where(x => x.Name == models).FirstOrDefault();

                    logical = new Logical();
                    MotorTruePriceRequestDto checkiReq = new MotorTruePriceRequestDto();
                    checkiReq.make = Convert.ToString(res.Name);
                    checkiReq.model = Convert.ToString(mod.Name);
                    checkiReq.year_of_manufacture = Convert.ToString(SelectedYear);

                    var checkiResponse = await logical.GetMotorTruePriceAsync(checkiReq);


                    if (checkiResponse.Result.Message.Contains("success"))
                    {
                        var min = checkiResponse.Result.Data.Price.FairCondition;
                        var max = checkiResponse.Result.Data.Price.GoodCondition;

                        if (VehicleValue < min || VehicleValue > max)
                        {
                            isChoice = await _pageDialogService.DisplayAlertAsync("Value Mismatch", "The value provided for this vehicle does not match the current market value. Kindly enter a value between the range " + min.ToString("N0") + " - " + max.ToString("N0") + " " + "By maintaining this value ,You are agreeing to the terms and conditions of under-insurance", "Maintain value", "Revise value");
                            if (isChoice)
                            {
                                IsReviseValue = false;
                                IsMainTainValue = true;
                                IsConsentForm = true;
                                CheckiRemark = (VehicleValue < min) ? 1 : 2;
                            }
                            else
                            {
                                IsReviseValue = true;
                                IsMainTainValue = false;
                                IsConsentForm = false;
                            }
                        }
                        else
                        {
                            IsReviseValue = false;
                            IsMainTainValue = false;
                            IsConsentForm = false;
                            CheckiMaxValue = checkiResponse.Result.Data.Price.GoodCondition;
                            CheckiMinValue = checkiResponse.Result.Data.Price.FairCondition;
                            await _pageDialogService.DisplayAlertAsync("Confirmed", "Valuation is successful. click proceed", "Ok");
                        }
                    }
                    else
                    {
                        IsReviseValue = false;
                        IsMainTainValue = true;
                        IsConsentForm = true;
                        await _pageDialogService.DisplayAlertAsync("Value not available", "Kindly upload proof of payment", "Ok");
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                await _pageDialogService.DisplayAlertAsync("Error", "Unable to verify car value. Please try again.", "Ok");
            }
            IsBusy = false;
        }

        private async void ExecutePickDocumentCommand()
        {
            IsBusy = true;
            try
            {
                //var choice = await _pageDialogService.DisplayAlertAsync("Notice", "What document do you wish to upload?", "Proof of Valuation", "Consent Form");
                if (Device.RuntimePlatform == Device.Android)
                {
                    FileTypes = new string[] { "image/png", "image/jpeg", "application/pdf" };
                }
                FileNameList.Clear();
                await PickedFiles(FileTypes);
                ProofOfValuation = FileLabel;
                FileVariable customerFile = new FileVariable
                {
                    FileName = FileLabel,
                    FileContent = Convert.ToBase64String(Contents),
                    FieldName = "Users Valuation Document",
                    //FieldName = choice ? "User's Valuation Document" : "Consent Form",
                    ContentType = ContentType,
                    Extension = !ContentType.ToLower().Contains("jpeg") ? ContentType.Substring((ContentType.Length - 3), 3) : ContentType.Substring((ContentType.Length - 4), 4)
                };
                FileNameList.Add(customerFile);

                await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");

            }
            catch (Exception ex)

            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        //private async void ExecutePickConsentFormCommand()
        //{
        //    IsBusy = true;
        //    try
        //    {
        //        if (Device.RuntimePlatform == Device.Android)
        //        {
        //            FileTypes = new string[] { "image/png", "image/jpeg", "application/pdf" };
        //        }

        //        await PickedFiles(FileTypes);
        //        ConsentForm = FileLabel;
        //        FileVariable customerFile = new FileVariable
        //        {
        //            FileName = FileLabel,
        //            FileContent = Convert.ToBase64String(Contents),
        //            FieldName = "Consent Form",
        //            ContentType = ContentType,
        //            Extension = !ContentType.ToLower().Contains("jpeg") ? ContentType.Substring((ContentType.Length - 3), 3) : ContentType.Substring((ContentType.Length - 4), 4)
        //        };
        //        FileNameList.Add(customerFile);

        //        await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");

        //    }
        //    catch (Exception ex)

        //    {
        //        ex.Message.ToString();
        //    }
        //    IsBusy = false;
        //}

        public async Task PickedFiles(string[] fileTypes)
        {
            try
            {
                var pickedFile = await CrossFilePicker.Current.PickFile(fileTypes);

                if (pickedFile != null)
                {
                    FileLabel = pickedFile.FileName;
                    FileLabelPath = pickedFile.FilePath;

                    if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("jpeg", StringComparison.OrdinalIgnoreCase))
                    {
                        Contents = pickedFile.DataArray;
                        if (pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "application/pdf";
                        }
                        else if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "image" + "/jpg";
                        }
                        else if (pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "image" + "/png";
                        }
                        else
                            ContentType = "image" + "/jpeg";
                    }
                    else
                        await _pageDialogService.DisplayAlertAsync("Error", "Only .pdf, .png and .jpg files can be uploaded", "Ok");
                    //FileSize = FileSizeFormatter.FormatSize(Contents.Length);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public static class FileSizeFormatter
        {
            static readonly string[] suffixes = { "Bytes", "KB", "MB", "GB", "TB", "PB" };

            public static string FormatSize(long bytes)
            {
                int counter = 0;
                decimal number = (decimal)bytes;
                while (Math.Round(number / 1024) >= 1)
                {
                    number = number / 1024;
                    counter++;
                }
                return string.Format("{0:n1}{1}", number, suffixes[counter]);
            }
        }

        public void ExecuteFileDeleteCommand(string FileLabel)
        {
            IsBusy = true;
            try
            {
                if (ProofOfValuation != null && ProofOfValuation == FileLabel)
                {
                    ProofOfValuation = null;
                    FileVariable uploadFile = FileNameList.Where(x => x.FileName == FileLabel).FirstOrDefault();
                    uploadFile.FileContent = null;
                    uploadFile.FileName = null;
                    uploadFile.Extension = null;
                    uploadFile.FieldName = null;
                    uploadFile.ContentType = null;

                    FileNameList.Remove(uploadFile);
                }
                //if (ConsentForm != null && ConsentForm == FileLabel)
                //{
                //    ConsentForm = null;
                //    FileVariable uploadFile = FileNameList.Where(x => x.FileName == FileLabel).FirstOrDefault();
                //    uploadFile.FileContent = null;
                //    uploadFile.FileName = null;
                //    uploadFile.Extension = null;
                //    uploadFile.FieldName = null;
                //    uploadFile.ContentType = null;

                //    FileNameList.Remove(uploadFile);
                //}
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        public async void ExecuteProceedCommand()
        {
            IsBusy = true;
            try
            {
                if (IsReviseValue == false)
                {
                    if (IsMainTainValue == true)
                    {

                        if (FileNameList != null && FileNameList.Count > 0)
                        {
                            var navigationParameter = new NavigationParameters();
                            navigationParameter.Add("ProspectId", SelectedProspect.Id);
                            navigationParameter.Add("PolicyType", PolicyType);
                            navigationParameter.Add("VehicleValue", VehicleValue);
                            navigationParameter.Add("VehicleMake", SelectedVehicleMake);
                            navigationParameter.Add("VehicleModel", SelectedVehicleModel);
                            navigationParameter.Add("VehicleYear", SelectedYear);
                            navigationParameter.Add("CheckiMax", CheckiMaxValue);
                            navigationParameter.Add("CheckiMin", CheckiMinValue);
                            navigationParameter.Add("MotorMakes", MotorMake);
                            navigationParameter.Add("MotorModels", MotorModel);
                            navigationParameter.Add("CheckiRemark", CheckiRemark);
                            navigationParameter.Add("PersonalValuationDocument", FileNameList.ToList());
                            navigationParameter.Add("ProductPlanId", ProductPlan.Id);
                            navigationParameter.Add("AgentId", LoggedAgent.Id);
                            await _navigationService.NavigateAsync("VehicleDetailsPage", navigationParameter);
                            //await _navigationService.NavigateAsync("VehicleRenewalDetails", navigationParameter);
                        }
                        else
                        {
                            await _pageDialogService.DisplayAlertAsync("Notice", "Kindly upload proof of payment or consent form before proceeding", "Ok");
                        }

                    }
                    else
                    {
                        var navigationParameter = new NavigationParameters();
                        navigationParameter.Add("ProspectId", SelectedProspect.Id);
                        navigationParameter.Add("PolicyType", PolicyType);
                        navigationParameter.Add("VehicleValue", VehicleValue);
                        navigationParameter.Add("VehicleMake", SelectedVehicleMake);
                        navigationParameter.Add("VehicleModel", SelectedVehicleModel);
                        navigationParameter.Add("VehicleYear", SelectedYear);
                        navigationParameter.Add("CheckiMax", CheckiMaxValue);
                        navigationParameter.Add("CheckiMin", CheckiMinValue);
                        navigationParameter.Add("MotorMakes", MotorMake);
                        navigationParameter.Add("MotorModels", MotorModel);
                        navigationParameter.Add("ProductPlanId", ProductPlan.Id);
                        navigationParameter.Add("AgentId", LoggedAgent.Id);
                        navigationParameter.Add("CheckiRemark", CheckiRemark);
                        await _navigationService.NavigateAsync("VehicleDetailsPage", navigationParameter);
                        //await _navigationService.NavigateAsync("VehicleRenewalDetails", navigationParameter);
                    }
                }
                else
                {
                    await _pageDialogService.DisplayAlertAsync("Notice", "Please Click on the Get Value Button", "Ok");
                }
            }
            catch (Exception ex)
            {

            }
            IsBusy = false;
        }
    }
}
