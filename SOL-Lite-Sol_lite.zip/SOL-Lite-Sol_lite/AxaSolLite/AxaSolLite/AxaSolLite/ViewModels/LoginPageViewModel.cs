﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AxaSolLite.ViewModels
{
	public class LoginPageViewModel : BindableBase, INavigationAware
    {
        private readonly IRepositoryManager _repositoryManager;
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly EncryptUtils _encryptUtils;

        private string _password;
        private string _username;
        private string _authToken;
        private bool _isBusy;
        private string _title;
        private bool _isExternal;
        private bool _isPassword;
        private bool _isChecked;
        private int _count;
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public string UserName
        {
            get { { return _username; } }
            set { SetProperty(ref _username, value); }
        }
        public int Count
        {
            get { { return _count; } }
            set { SetProperty(ref _count, value); }
        }
        public string AuthToken
        {
            get { { return _authToken; } }
            set { SetProperty(ref _authToken, value); }
        }
        public string Password
        {
            get { { return _password; } }
            set { SetProperty(ref _password, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public bool IsExternal
        {
            get { return _isExternal; }
            set { SetProperty(ref _isExternal, value); }
        }
        public bool IsPassword
        {
            get { return _isPassword; }
            set { SetProperty(ref _isPassword, value); }
        }
        public bool IsChecked
        {
            get { return _isChecked; }
            set { SetProperty(ref _isChecked, value); }
        }

        private DelegateCommand _loginCommand;
        private DelegateCommand _externalLoginCommand;
        private DelegateCommand _feedbackCommand;
        private DelegateCommand _checkedCommand;
        private DelegateCommand _goToPopupCommand;

        public DelegateCommand LoginCommand => _loginCommand ?? (_loginCommand = new DelegateCommand(ExecuteLogin));
        public DelegateCommand ExternalLoginCommand => _externalLoginCommand ?? (_externalLoginCommand = new DelegateCommand(ExecuteExternalLogin));
        public DelegateCommand FeedbackCommand => _feedbackCommand ?? (_feedbackCommand = new DelegateCommand(ExecuteFeedback));
        public DelegateCommand CheckedCommand => _checkedCommand ?? (_checkedCommand = new DelegateCommand(ExecuteChecked));
        public DelegateCommand GoToPopupCommand => _goToPopupCommand ?? (_goToPopupCommand = new DelegateCommand(ExecuteGoToPopupCommand));
        Logical logical = null;

        public LoginPageViewModel(INavigationService navigationService,
            IPageDialogService pageDialogService,
            IRepositoryManager repositoryManager, EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _repositoryManager = repositoryManager;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            UserName = parameters.GetValue<string>("Username");
            await InitializeApplication();
        }

        public async Task InitializeApplication()
        {            
            IsPassword = true;
            //UserName = "oakano";
            //Password = "!German20it0";
            if (AxaSolUrls.TestorLive.Contains("online.axamansard.com"))
            {
                Title = "AXASOL LITE LIVE";
            }
            else
            {
                Title = "AXA SOL LITE";
            }

            _ = new Logical();
            try
            {
                await _repositoryManager.Initialize();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public async void ExecuteLogin()
        {
            IsBusy = true;
            try
            {
                DateTime date = new DateTime();
                var Pw = "P@ssw0rds";
                if (!String.IsNullOrEmpty(this.UserName))
                {
                    this.UserName = this.UserName.Trim();
                }
                
                logical = new Logical();
                DmtSignInReq loginReq = new DmtSignInReq();
                loginReq.username = UserName;
                loginReq.password = Password;
                loginReq.appVersion = "6.6.6";
                var AgentSignResponse = await logical.SignIn(loginReq);
                if (AgentSignResponse.AuthenticateUserResult == true)
                {   
                    var navigationParameter = new NavigationParameters();
                    navigationParameter.Add("Username", this.UserName.Trim());
                    await _navigationService.NavigateAsync("AxaSolLite://MyNavigationPage/AgentWelcomePage", navigationParameter);
                    //await _navigationService.NavigateAsync("PersonalAccidentSummaryPage", navigationParameter);
                }
                else
                {
                    await _pageDialogService.DisplayAlertAsync("Unsuccessful", "Authentication failed. This error is subject to two reasons. 1.Wrong combination of login credentials 2.Expired password: Kindly proceed to change your password if you're certain that your login credential is correct and the error message persist upon subsequent attempts", "Ok");
                    var Num = Count + 1;
                    Count = Num;
                    if(Num < 5)
                    {
                        InsertAccountStatus req = new InsertAccountStatus();
                        req.UserName = UserName;
                        req.LoginCount = Num;
                        var res = await logical.InsertUserAccountStatus(req);
                    }
                    else if(Num == 5)
                    {
                        InsertAccountStatus req = new InsertAccountStatus();
                        req.UserName = UserName;
                        req.LoginCount = Num;
                        await _pageDialogService.DisplayAlertAsync("ACCOUNT LOCKED", "Please try again after 5 minutes", "Ok");
                        var res = await logical.InsertUserAccountStatus(req);
                        date = DateTime.Now;

                    }
                    else if(Num >5)
                    {
                        var checkdate = date.AddMinutes(5);
                        if(DateTime.Now < checkdate)
                        {
                            await _pageDialogService.DisplayAlertAsync("ACCOUNT LOCKED", "Please try again later", "Ok");

                        }
                        else
                        {
                            InsertAccountStatus req = new InsertAccountStatus();
                            req.UserName = UserName;
                            req.LoginCount = Num;
                            Count = 0;
                            var res = await logical.InsertUserAccountStatus(req);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
            //await _navigationService.NavigateAsync("NavigationPage/SeekerProfile");
        }

        public async void ExecuteExternalLogin()
        {
           
            await _navigationService.NavigateAsync("ExternalAgentLoginPage");
        }

        public  void ExecuteChecked()
        {
            if(IsChecked == false)
            {
                IsPassword = true;
            }
            else
            {
                IsPassword = false;
            }
        }

        public async void ExecuteFeedback()
        {

            await _navigationService.NavigateAsync("AgentFeedbackPage",null,null,false);
        }

        public async void ExecuteGoToPopupCommand()
        {
            MyPopupViewModel myPopup = new MyPopupViewModel("Efosa", async (option) =>
            {
                Console.WriteLine(option);

                await Task.CompletedTask;
            });
            await _navigationService.NavigateAsync("MyPopup", null, true, true);
        }
    }
}
