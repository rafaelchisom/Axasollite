﻿using AxaSolLite.Extensions;
using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Xamarin.Forms;


namespace AxaSolLite.ViewModels
{
    public class ApprovalLogInformationPageViewModel : BindableBase, INavigationAware
    {
        private readonly IPageDialogService _pageDialogService;
        private readonly INavigationService _navigationService;
        private readonly IAgentRepository _agentRepository;
        private Logical _logical;

        #region Fields
        private Approval_details _approvalLogInformation = new Approval_details();
        public string _agentCode;
        public string _productType;
        public string _premium;
        public string _startDate;
        public string _endDate;
        public string _customerNumber;
        public string _paymentType;
        public string _caseId;
        public bool _isRejected;
        public bool _isApproved;
        public string _approvalType;
        public string _comments;
        public string _modifiedBy;
        public string _dateModified;     
        public bool _isBusy;
        private bool _isComments;
        private bool _isNoComments;
        public bool _isLoading;
        ArrayToImageConverter converter = new ArrayToImageConverter();
        private ImageSource _signaturePicture;
        private const string ResourceNamespace = "AxaSolLite.Resources.Assets.";
        public bool _isMotor;
        public bool _isLife;

        #region Proposal details
        public string _customerFullName;
        public string _customerDateofBirth ;
        public string _phoneNumber ;
        public string _emailAddress ;
        public string _amountPaid ;
        public string _policyTerm ;
        public string _sumAssured ;
        public string _paymentFrequency ;
        public string _beneficiaryFullName ;
        public string _beneficiaryPhoneNumber ;
        public string _beneficiaryDateofBirth ;
        public string _motorType ;
        public string _motorModel ;
        public string _regNo ;
        public string _engNo ;

        public string CustomerFullName
        {
            get { return _customerFullName; }
            set { SetProperty(ref _customerFullName, value); }
        }
        public string CustomerDateofBirth
        {
            get { return _customerDateofBirth; }
            set { SetProperty(ref _customerDateofBirth, value); }
        }
        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { SetProperty(ref _phoneNumber, value); }
        }
        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }
        public string AmountPaid
        {
            get { return _amountPaid; }
            set { SetProperty(ref _amountPaid, value); }
        }
        public string PolicyTerm
        {
            get { return _policyTerm; }
            set { SetProperty(ref _policyTerm, value); }
        }
        public string SumAssured
        {
            get { return _sumAssured; }
            set { SetProperty(ref _sumAssured, value); }
        }
        public string PaymentFrequency
        {
            get { return _paymentFrequency; }
            set { SetProperty(ref _paymentFrequency, value); }
        }
        public string BeneficiaryFullName
        {
            get { return _beneficiaryFullName; }
            set { SetProperty(ref _beneficiaryFullName, value); }
        }
        public string BeneficiaryPhoneNumber
        {
            get { return _beneficiaryPhoneNumber; }
            set { SetProperty(ref _beneficiaryPhoneNumber, value); }
        }
        public string BeneficiaryDateofBirth
        {
            get { return _beneficiaryDateofBirth; }
            set { SetProperty(ref _beneficiaryDateofBirth, value); }
        }
        public string MotorType
        {
            get { return _motorType; }
            set { SetProperty(ref _motorType, value); }
        }
        public string MotorModel
        {
            get { return _motorModel; }
            set { SetProperty(ref _motorModel, value); }
        }
        public string RegNo
        {
            get { return _regNo; }
            set { SetProperty(ref _regNo, value); }
        }
        public string EngNo
        {
            get { return _engNo; }
            set { SetProperty(ref _engNo, value); }
        }
        #endregion

        #endregion
        #region Properties
        public string AgentCode
        {
            get { return _agentCode; }
            set { SetProperty(ref _agentCode, value); }
        }
        public string ProductType
        {
            get { return _productType; }
            set { SetProperty(ref _productType, value); }
        }
        public string Premium
        {
            get { return _premium; }
            set { SetProperty(ref _premium, value); }
        }
        public string StartDate
        {
            get { return _startDate; }
            set { SetProperty(ref _startDate, value); }
        }
        public string EndDate
        {
            get { return _endDate; }
            set { SetProperty(ref _endDate, value); }
        }
        public string CustomerNumber
        {
            get { return _customerNumber; }
            set { SetProperty(ref _customerNumber, value); }
        }
        public string PaymentType
        {
            get { return _paymentType; }
            set { SetProperty(ref _paymentType, value); }
        }
        public string CaseId
        {
            get { return _caseId; }
            set { SetProperty(ref _caseId, value); }
        }
        public bool IsRejected
        {
            get { return _isRejected; }
            set { SetProperty(ref _isRejected, value); }
        }
        public bool IsApproved
        {
            get { return _isApproved; }
            set { SetProperty(ref _isApproved, value); }
        }
        public string ApprovalType
        {
            get { return _approvalType; }
            set { SetProperty(ref _approvalType, value); }
        }
        public string Comments
        {
            get { return _comments; }
            set { SetProperty(ref _comments, value); }
        }
        public string ModifiedBy
        {
            get { return _modifiedBy; }
            set { SetProperty(ref _modifiedBy, value); }
        }
        public string DateModified
        {
            get { return _dateModified; }
            set { SetProperty(ref _dateModified, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public bool IsLoading
        {
            get { return _isLoading; }
            set { SetProperty(ref _isLoading, value); }
        }
        public bool IsComments
        {
            get { return _isComments; }
            set { SetProperty(ref _isComments, value); }
        }
        public bool IsNoComments
        {
            get { return _isNoComments; }
            set { SetProperty(ref _isNoComments, value); }
        }
        public Approval_details ApprovalLogInformation
        {
            get { return _approvalLogInformation; }
            set { SetProperty(ref _approvalLogInformation, value); }
        }
        public ImageSource SignaturePicture
        {
            get { return _signaturePicture; }
            set { SetProperty(ref _signaturePicture, value); }
        }
        public bool IsMotor
        {
            get { return _isMotor; }
            set { SetProperty(ref _isMotor, value); }
        }
        public bool IsLife
        {
            get { return _isLife; }
            set { SetProperty(ref _isLife, value); }
        }

        public Agent Agent { get; set; }
        #endregion
        #region Commands
        private DelegateCommand _approveCommand;
        private DelegateCommand _rejectCommand;
        private DelegateCommand _doneCommand;
        public DelegateCommand ApproveCommand => _approveCommand ?? (_approveCommand = new DelegateCommand(ExecuteApprove));
        public DelegateCommand RejectCommand => _rejectCommand ?? (_rejectCommand = new DelegateCommand(ExecuteReject));
        public DelegateCommand DoneCommand => _doneCommand ?? (_doneCommand = new DelegateCommand(ExecuteDone));
        #endregion

        public ApprovalLogInformationPageViewModel(IPageDialogService pageDialogService, INavigationService navigationService,
              IAgentRepository agentRepository, Logical logical)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _logical = logical;
            _agentRepository = agentRepository;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
           
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = false;
            IsLoading = false;
            try
            {
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        Agent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }
                ApprovalLogInformation = parameters.GetValue<Approval_details>("Approvaldetails");
                InitializeDefaultValues();

            }
            catch(Exception ex)
            {

            }
           
        }
        private async void InitializeDefaultValues()
        {
            try
            {
                AgentCode = ApprovalLogInformation.AgentCode;
                CustomerNumber = ApprovalLogInformation.CustomerNumber;
                ProductType = ApprovalLogInformation.ProductType;
                Premium = ApprovalLogInformation.Premium;
                StartDate = ApprovalLogInformation.StartDate;
                EndDate = ApprovalLogInformation.EndDate;
               
                PaymentType = ApprovalLogInformation.PaymentType;
                CaseId = ApprovalLogInformation.CaseId;
                IsRejected = ApprovalLogInformation.IsRejected;
                IsApproved = ApprovalLogInformation.IsApproved;
                ApprovalType = ApprovalLogInformation.ApprovalType;
                Comments = ApprovalLogInformation.Comments;
                ModifiedBy = ApprovalLogInformation.ModifiedBy;
                DateModified = ApprovalLogInformation.DateModified;
                CustomerFullName = ApprovalLogInformation.CustomerFullName;
                CustomerDateofBirth = ApprovalLogInformation.CustomerDateofBirth;
                PhoneNumber = ApprovalLogInformation.PhoneNumber;
                EmailAddress = ApprovalLogInformation.EmailAddress;
                AmountPaid = ApprovalLogInformation.AmountPaid;
                PolicyTerm = ApprovalLogInformation.PolicyTerm;
                SumAssured = ApprovalLogInformation.SumAssured;
                PaymentFrequency = ApprovalLogInformation.PaymentFrequency;
                BeneficiaryFullName = ApprovalLogInformation.BeneficiaryFullName;
                BeneficiaryPhoneNumber = ApprovalLogInformation.BeneficiaryPhoneNumber;
                BeneficiaryDateofBirth = ApprovalLogInformation.CustomerDateofBirth;
                MotorType = ApprovalLogInformation.MotorType;
                MotorModel = ApprovalLogInformation.MotorModel;
                RegNo = ApprovalLogInformation.RegNo;
                EngNo = ApprovalLogInformation.EngNo;
                if (!ApprovalLogInformation.IsApproved && !ApprovalLogInformation.IsRejected)
                {
                    IsComments = false;
                    IsNoComments = true;
                    IsBusy = false;

                }
                else
                {
                    IsComments = true;
                    IsNoComments = false;
                    IsBusy = false;

                }
                if(ApprovalLogInformation.Product.Contains("Life"))
                {
                    IsMotor = false;
                    IsLife = true;

                }
                else
                {
                    IsMotor = true;
                    IsLife = false;

                }


            }
            catch (Exception ex)
            {

            }
        }

        public async void ExecuteApprove()
        {
            try
            {
                IsLoading = true;
                UpdateApprovaLog request = new UpdateApprovaLog
                {
                    CaseId = CaseId,
                    IsApproved = true,
                    IsRejected = false,
                    ModifiedBy = Agent.FullName,
                    Comment = "Approved"

                };
                var response = await _logical.UpdateApprovalLog(request);
                if(response)
                {
                    var email = "";
                    var fullname = "";
                    var res = await _logical.GetAdvisorsDetailsByAgentcode(ApprovalLogInformation.AgentCode);
                    foreach (var item in res)
                    {
                        email = item.Email;
                        fullname = item.AgentName;
                    }
                    ApprovalMail req = new ApprovalMail
                    {
                        EmailAddress = "raphael.ariguzor@axamansard.com",
                        AgentEmail = Agent.EmailAddress,
                        FullName = fullname,
                        CaseId = CaseId,
                        Comments = request.Comment,
                        ApprovalType = "Approved",
                        IsApproved = true

                    };
                    var mailsent = await _logical.SendApprovalMail(req);
                    IsLoading = false;
                    await _pageDialogService.DisplayAlertAsync("Policy Approved", "The policy with case Id:" + CaseId + " has been Approved", "Ok");
                    NavigationParameters navigationParameter = new NavigationParameters();
                    navigationParameter.Add("AgentId", Agent.Id);
                    await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ApprovalLogPage", navigationParameter);

                }
                else
                {
                    IsLoading = false;
                    await _pageDialogService.DisplayAlertAsync("Error", "Please Try again later", "Ok");

                }

            }
            catch(Exception ex)
            {
                IsLoading = false;
                await _pageDialogService.DisplayAlertAsync("Error", "Please Try again later" + ex.Message.ToString(), "Ok");

            }

        }
        public async void Reject()
        {
            IsLoading = true;
            try
            {
                UpdateApprovaLog request = new UpdateApprovaLog
                {
                    CaseId = CaseId,
                    IsApproved = false,
                    IsRejected = true,
                    ModifiedBy = Agent.FullName,
                    Comment = Comments

                };
                var response = await _logical.UpdateApprovalLog(request);
                if (response)
                {
                    var email = "";
                    var fullname = "";
                    var res = await _logical.GetAdvisorsDetailsByAgentcode(ApprovalLogInformation.AgentCode);
                    foreach (var item in res)
                    {
                        email = item.Email;
                        fullname = item.AgentName;
                    }
                    ApprovalMail req = new ApprovalMail
                    {
                        EmailAddress = "raphael.ariguzor@axamansard.com",
                        AgentEmail = Agent.EmailAddress,
                        FullName = fullname,
                        CaseId = CaseId,
                        Comments = request.Comment,
                        ApprovalType = "Rejected",
                        IsApproved = false

                    };
                    var mailsent = await _logical.SendApprovalMail(req);
                    IsLoading = false;
                    await _pageDialogService.DisplayAlertAsync("Policy Rejected", "The policy with case Id:" + CaseId + " has been Rejected", "Ok");
                    NavigationParameters navigationParameter = new NavigationParameters();
                    navigationParameter.Add("AgentId", Agent.Id);
                    await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ApprovalLogPage", navigationParameter);

                }
                else
                {
                    IsLoading = false;
                    await _pageDialogService.DisplayAlertAsync("Error", "Please Try again later", "Ok");

                }

            }
            catch (Exception ex)
            {
                IsLoading = false;
                await _pageDialogService.DisplayAlertAsync("Error", "Please Try again later" + ex.Message.ToString(), "Ok");


            }

        }
        public async void ExecuteReject()
        {
            try
            {
                IsNoComments = false;
                IsComments = true;
                IsBusy = true;


              
             

            }
            catch (Exception ex)
            {
                


            }

        }
        public async void ExecuteDone()
        {
            try
            {
                if(string.IsNullOrEmpty(Comments))
                {
                    await _pageDialogService.DisplayAlertAsync("Required", "Please Input a Comment", "Ok");


                }
                else
                {
                    Reject();

                }





            }
            catch (Exception ex)
            {



            }

        }

        
        


    }
}
