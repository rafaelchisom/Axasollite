﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AxaSolLite.ViewModels
{
    public class HealthSummaryPageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly IProductPlansRepository _productPlanRepository;
        private readonly IPageDialogService _pageDialogService;
        private readonly EncryptUtils _encryptUtils;
        private readonly Logical _logical;

        private bool _isBusy;
        private string _firstName;
        private string _lastName;
        private string _middleName;
        private string _dateOfBirth;
        private string _phoneNumber;
        private string _gender;
        private string _emailAddress;
        private string _plan;
        private string _ownershipType;
        private string _genotype;
        private string _hospitalLocation;
        private string _hospital;
        private List<string> _preExistingCondition = new List<string>();
        private List<string> _beneficiaries = new List<string>();
        private string _noOfBeneficiaries;
        private string _amountPayable;
        private List<HealthBeneficiary> _healthBeneficiaries = new List<HealthBeneficiary>();
        private bool _hasBeneficiaries;
        private List<HealthPreExistingConditions> _myPreExistingConditions = new List<HealthPreExistingConditions>();
        private bool _hasExistingConditions;
        private Guid _prospectId;
        private string _paymentOption;

        public string PaymentOption
        {
            get { return _paymentOption; }
            set { SetProperty(ref _paymentOption, value); }
        }
        public bool HasExistingConditions
        {
            get { return _hasExistingConditions; }
            set { SetProperty(ref _hasExistingConditions, value); }
        }
        public List<HealthPreExistingConditions> MyPreExistingConditions
        {
            get { return _myPreExistingConditions; }
            set { SetProperty(ref _myPreExistingConditions, value); }
        }
        public bool HasBeneficiaries
        {
            get { return _hasBeneficiaries; }
            set { SetProperty(ref _hasBeneficiaries, value); }
        }
        public string AmountPayable
        {
            get { return _amountPayable; }
            set { SetProperty(ref _amountPayable, value); }
        }
        public string NoOfBeneficiaries
        {
            get { return _noOfBeneficiaries; }
            set { SetProperty(ref _noOfBeneficiaries, value); }
        }
        public List<string> PreExistingConditions
        {
            get { return _preExistingCondition; }
            set { SetProperty(ref _preExistingCondition, value); }
        }
        public List<string> Beneficiaries
        {
            get { return _beneficiaries; }
            set { SetProperty(ref _beneficiaries, value); }
        }
        public string Hospital
        {
            get { return _hospital; }
            set { SetProperty(ref _hospital, value); }
        }
        public string HospitalLocation
        {
            get { return _hospitalLocation; }
            set { SetProperty(ref _hospitalLocation, value); }
        }
        public string Genotype
        {
            get { return _genotype; }
            set { SetProperty(ref _genotype, value); }
        }
        public string OwnershipType
        {
            get { return _ownershipType; }
            set { SetProperty(ref _ownershipType, value); }
        }
        public string Plan
        {
            get { return _plan; }
            set { SetProperty(ref _plan, value); }
        }
        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }
        public string Gender
        {
            get { return _gender; }
            set { SetProperty(ref _gender, value); }
        }
        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { SetProperty(ref _phoneNumber, value); }
        }
        public string DateOfBirth
        {
            get { return _dateOfBirth; }
            set { SetProperty(ref _dateOfBirth, value); }
        }
        public string MiddleName
        {
            get { return _middleName; }
            set { SetProperty(ref _middleName, value); }
        }
        public string LastName
        {
            get { return _lastName; }
            set { SetProperty(ref _lastName, value); }
        }
        public string FirstName
        {
            get { return _firstName; }
            set { SetProperty(ref _firstName, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public Prospect SelectedProspect { get; set; }
        public Agent LoggedAgent { get; set; }  
        public ProductPlan ProductPlan { get; set; }
        public HealthProduct HealthProduct { get; set; }
        public List<HealthBeneficiary> HealthBeneficiaries
        {
            get { return _healthBeneficiaries; }
            set { SetProperty(ref _healthBeneficiaries, value); }
        }
        public EncryptedProspect EncryptedProspect { get; set; }


        private DelegateCommand _payNowCommand;
        public DelegateCommand PayNowCommand => _payNowCommand ?? (_payNowCommand = new DelegateCommand(ExecutePayNowCommand));

        public HealthSummaryPageViewModel(INavigationService navigationService, IProspectRepository prospectRepository,
            IAgentRepository agentRepository, IProductPlansRepository productPlansRepository, IPageDialogService pageDialogService, EncryptUtils encryptUtils, Logical logical)
        {
            _navigationService = navigationService;
            _prospectRepository = prospectRepository;
            _agentRepository = agentRepository;
            _productPlanRepository = productPlansRepository;
            _encryptUtils = encryptUtils;
            _pageDialogService = pageDialogService;
            _logical = logical;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public  async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }

                if (parameters.ContainsKey("AgentId"))
                {
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out Guid agentId))
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                }

                if (parameters.ContainsKey("ProductPlanId"))
                {
                    if (Guid.TryParse(parameters["ProductPlanId"].ToString(), out Guid _productPlanId))
                        ProductPlan = await _productPlanRepository.GetProductPlanByProductPlanId(_productPlanId);
                }

                if (parameters.ContainsKey("HealthProduct"))
                    HealthProduct = parameters.GetValue<HealthProduct>("HealthProduct");

                if (parameters.ContainsKey("Beneficiaries"))
                    HealthBeneficiaries = parameters.GetValue<List<HealthBeneficiary>>("Beneficiaries");

                await InitializeDefaultValues();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async Task InitializeDefaultValues()
        {
            try
            {
                FirstName = SelectedProspect.FirstName;
                LastName = SelectedProspect.LastName;
                MiddleName = string.IsNullOrEmpty(SelectedProspect.MiddleName) ? "N/A" : SelectedProspect.MiddleName;
                DateOfBirth = SelectedProspect.Birthdate.ToString("dd/MM/yyyy");
                PhoneNumber = SelectedProspect.MobileNumber;
                Gender = SelectedProspect.Gender == 1 ? "Male" : "Female";
                EmailAddress = SelectedProspect.Email;
                Plan = ProductPlan.PlanCategory;
                OwnershipType = HealthProduct.OwnershipType == 1 ? "Myself" : (HealthProduct.OwnershipType == 2 ? "Someone Else" : "Group");
                Genotype = HealthProduct.Genotype;
                HospitalLocation = HealthProduct.OwnershipType == 2 ? HealthBeneficiaries.FirstOrDefault().PreferredHospitalLocation : HealthProduct.PreferredHospitalLocation;
                Hospital = HealthProduct.OwnershipType == 2 ? HealthBeneficiaries.FirstOrDefault().PreferredHospital : HealthProduct.PreferredHospital;
                NoOfBeneficiaries = HealthProduct.OwnershipType == 3 ? (HealthBeneficiaries.Count).ToString() : "0";
                AmountPayable = "N" + HealthProduct.Value.ToString("N0");

              
                MyPreExistingConditions =  HealthProduct.PreExistingConditions.Where(x => x.IsToggled).ToList();

                foreach(HealthPreExistingConditions item in MyPreExistingConditions)
                {
                    string condition = string.Empty;
                    condition = item.PreexistingCondition1;
                    PreExistingConditions.Add(condition);
                }
                PreExistingConditions = PreExistingConditions.ToList();
                if(PreExistingConditions != null && PreExistingConditions.Count > 0)
                {
                    HasExistingConditions = true;
                }

                if (HealthProduct.OwnershipType == 2 || HealthProduct.OwnershipType == 3)
                {
                    HasBeneficiaries = true;
                }

                if(HealthProduct.OwnershipType == 2)
                {
                    NoOfBeneficiaries = "1";
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private async void ExecutePayNowCommand()
        {
            IsBusy = true;
            try
            {
                SelectedHospitals.SelectedHospitalName = null;
                SelectedHospitals.HospitalName = null;
                if (string.IsNullOrEmpty(PaymentOption))
                {
                    //await _pageDialogService.DisplayAlertAsync("Kindly select a payment method", "", "Okay");
                    return;
                }
                if (PaymentOption.Contains("Pay with Paystack"))
                {
                    ProductPlan.IsAccountBalance = false;
                    int updated = await _productPlanRepository.UpdateAsync(ProductPlan);
                    var parameters = new NavigationParameters();
                    parameters.Add("ProspectId", SelectedProspect.Id);
                    parameters.Add("ProductPlanId", ProductPlan.Id);
                    parameters.Add("AgentId", LoggedAgent.Id);
                    parameters.Add("PolicyType", ProductPlan.PlanCategory);
                    parameters.Add("FNAProduct", ProductPlan.PlanCategory);
                    parameters.Add("HealthProduct", HealthProduct);

                    await _navigationService.NavigateAsync("PayNowPage", parameters);

                }
                else if (PaymentOption.Contains("Pay with QuoteID"))
                {
                    ProductPlan.IsAccountBalance = false;
                    int updated = await _productPlanRepository.UpdateAsync(ProductPlan);
                    var parameters = new NavigationParameters();
                    parameters.Add("ProspectId", SelectedProspect.Id);
                    parameters.Add("ProductPlanId", ProductPlan.Id);
                    parameters.Add("AgentId", LoggedAgent.Id);
                    parameters.Add("PolicyType", ProductPlan.PlanCategory);
                    parameters.Add("FNAProduct", ProductPlan.PlanCategory);
                    parameters.Add("HealthProduct", HealthProduct);

                    await _navigationService.NavigateAsync("PayLaterPage", parameters);

                }
                else if (PaymentOption.Contains("Pay with Customer Account Balance"))
                {
                    var response = await _logical.GetCustomerAccountBalance(SelectedProspect.CustomerNumber);
                    //Balance accountBalanceResponse = new Balance()
                    //{
                    //    availBalance = 500000
                    //};
                    //response.balances = accountBalanceResponse;
                    await _pageDialogService.DisplayAlertAsync("Account Balance", "Customer account balance:" + response.balances.availBalance, "Ok");
                    if (Convert.ToDouble(ProductPlan.AmountPaid) <= response.balances.availBalance)
                    {
                        ProductPlan.IsAccountBalance = true;

                        int updated = await _productPlanRepository.UpdateAsync(ProductPlan);
                        SelectedProspect.LifeAimsBalance = response.balances.lifeBalance.ToString();
                        SelectedProspect.NonLifeAimsBalance = response.balances.nonLifeBalance.ToString();
                        SelectedProspect.TotalAimsBalance = response.balances.availBalance.ToString();

                        string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                        EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                        int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                        //int update = await _prospectRepository.UpdateAsync(SelectedProspect);
                        var parameters = new NavigationParameters();
                        parameters.Add("ProspectId", SelectedProspect.Id);
                        parameters.Add("ProductPlanId", ProductPlan.Id);
                        parameters.Add("AgentId", LoggedAgent.Id);
                        parameters.Add("PolicyType", ProductPlan.PlanCategory);
                        parameters.Add("FNAProduct", ProductPlan.PlanCategory);
                        parameters.Add("HealthProduct", HealthProduct);

                        await _navigationService.NavigateAsync("PayNowPage", parameters);
                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Insufficent Fund", "Kindly inform the customer to credit account or use a different payment option", "Ok");
                    }
                }
                else
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a payment option", "Ok");
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }
    }
}
