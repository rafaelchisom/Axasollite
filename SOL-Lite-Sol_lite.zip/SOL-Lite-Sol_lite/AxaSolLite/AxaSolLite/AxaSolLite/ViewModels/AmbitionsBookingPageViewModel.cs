﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace AxaSolLite.ViewModels
{
    public class AmbitionsBookingPageViewModel : BindableBase, INavigationAware
    {
        private const string AccountNumberRegex = @"^[0-9]+$";

        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly IBookOnlineRepository _bookOnlineRepository;
        private readonly IBranchesRepository _branchesRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        private bool _isBusy;
        private string _agentName;
        private string _sbuName;
        private string _selectedDSA;
        private List<string> _myDSAs;
        private bool _isExternalAgent;
        private Prospect _selectedProspect;
        private Agent _loggedAgent;
        private string _title;
        private List<string> _premiumList;
        private string _paymentFrequency;
        private double _sumAssured;
        private int _policyDuration;
        private DateTime _policyStartDate;
        private DateTime _policyEndDate;
        private string _premium;
        private string _age;
        private int _ageAtNextBirthday;
        private string _customerNumber;
        private string _totalPremium;
        private List<DSAUnderPSS> _dSAs;
        private DSAUnderPSS _dSA;
        private List<string> _branchList;
        private string _selectedbranch;
        private SyncDataSample _branches;
        private Branches _branch;
        private int _branchCode;
        private List<Branches> _branchToSave = new List<Branches>();
        private string _agentCode;
        private string _emailAddress;
        private string _sbuCode;
        private string _initiationDate;
        private List<string> _policyDurations = new List<string>();
        private int _ageAtEndOfPolicy;
        private string _selectedPolicyDuration;
        private bool _isPremium;
        private double _contribution;
        private double _calculatedPremium;
        private double _lifeCoverValue;
        private double _annualPremium;
        private decimal _maxMaturityValue;
        private decimal _minMaturityValue;
        private List<string> _reasons = new List<string>();
        private string _reason;
        private Guid _prospectId;
        private string _accountNumber;
        private List<string> _bankList = new List<string>();
        private string _bankName;

        public string BankName
        {
            get { return _bankName; }
            set { SetProperty(ref _bankName, value); }
        }
        public List<string> BankList
        {
            get { return _bankList; }
            set { SetProperty(ref _bankList, value); }
        }
        public string AccountNumber
        {
            get { return _accountNumber; }
            set { SetProperty(ref _accountNumber, value); }
        }
        public string Reason
        {
            get { return _reason; }
            set { SetProperty(ref _reason, value); }
        }
        public List<string> Reasons
        {
            get { return _reasons; }
            set { SetProperty(ref _reasons, value); }
        }
        public decimal MaxMaturityValue
        {
            get { return _maxMaturityValue; }
            set { SetProperty(ref _maxMaturityValue, value); }
        }
        public decimal MinMaturityValue
        {
            get { return _minMaturityValue; }
            set { SetProperty(ref _minMaturityValue, value); }
        }
        public double AnnualPremium
        {
            get { return _annualPremium; }
            set { SetProperty(ref _annualPremium, value); }
        }
        public double LifeCoverValue
        {
            get { return _lifeCoverValue; }
            set { SetProperty(ref _lifeCoverValue, value); }
        }
        public double CalcuatedPremium
        {
            get { return _calculatedPremium; }
            set { SetProperty(ref _calculatedPremium, value); }
        }
        public double Contribution
        {
            get { return _contribution; }
            set { SetProperty(ref _contribution, value); }
        }
        public List<Branches> BranchToSave
        {
            get { return _branchToSave; }
            set { SetProperty(ref _branchToSave, value); }
        }
        public bool IsPremium
        {
            get { return _isPremium; }
            set { SetProperty(ref _isPremium, value); }
        }
        public string SelectedPolicyDuration
        {
            get { return _selectedPolicyDuration; }
            set { SetProperty(ref _selectedPolicyDuration, value); }
        }
        public int AgeAtEndOfPolicy
        {
            get { return _ageAtEndOfPolicy; }
            set { SetProperty(ref _ageAtEndOfPolicy, value); }
        }
        public List<string> PolicyDurations
        {
            get { return _policyDurations; }
            set { SetProperty(ref _policyDurations, value); }
        }
        public string InitiationDate
        {
            get { return _initiationDate; }
            set { SetProperty(ref _initiationDate, value); }
        }
        public string SbuCode
        {
            get { return _sbuCode; }
            set { SetProperty(ref _sbuCode, value); }
        }
        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }
        public string AgentCode
        {
            get { return _agentCode; }
            set { SetProperty(ref _agentCode, value); }
        }
        public int BranchCode
        {
            get { return _branchCode; }
            set { SetProperty(ref _branchCode, value); }
        }
        public SyncDataSample Branches
        {
            get { return _branches; }
            set { SetProperty(ref _branches, value); }
        }
        public DSAUnderPSS DSA
        {
            get { return _dSA; }
            set { SetProperty(ref _dSA, value); }
        }
        public List<DSAUnderPSS> DSAs
        {
            get { return _dSAs; }
            set { SetProperty(ref _dSAs, value); }
        }
        public Branches Branch
        {
            get { return _branch; }
            set { SetProperty(ref _branch, value); }
        }
        public string TotalPremium
        {
            get { return _totalPremium; }
            set { SetProperty(ref _totalPremium, value); }
        }
        public List<string> BranchList
        {
            get { return _branchList; }
            set { SetProperty(ref _branchList, value); }
        }
        public string SelectedBranch
        {
            get { return _selectedbranch; }
            set { SetProperty(ref _selectedbranch, value); }
        }
        public string CustomerNumber
        {
            get { return _customerNumber; }
            set { SetProperty(ref _customerNumber, value); }
        }
        public int AgeAtNextBirthday
        {
            get { return _ageAtNextBirthday; }
            set { SetProperty(ref _ageAtNextBirthday, value); }
        }
        public string Age
        {
            get { return _age; }
            set { SetProperty(ref _age, value); }
        }
        public string Premium
        {
            get { return _premium; }
            set { SetProperty(ref _premium, value); }
        }
        public DateTime PolicyEndDate
        {
            get { return _policyEndDate; }
            set { SetProperty(ref _policyEndDate, value); }
        }
        public DateTime PolicyStartDate
        {
            get { return _policyStartDate; }
            set { SetProperty(ref _policyStartDate, value); }
        }
        public int PolicyDuration
        {
            get { return _policyDuration; }
            set { SetProperty(ref _policyDuration, value); }
        }
        public double SumAssured
        {
            get { return _sumAssured; }
            set { SetProperty(ref _sumAssured, value); }
        }
        public string PaymentFrequency
        {
            get { return _paymentFrequency; }
            set { SetProperty(ref _paymentFrequency, value); }
        }
        public List<string> PremiumList
        {
            get { return _premiumList; }
            set { SetProperty(ref _premiumList, value); }
        }
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public Agent LoggedAgent
        {
            get { return _loggedAgent; }
            set { SetProperty(ref _loggedAgent, value); }
        }
        public Prospect Prospect
        {
            get { return _selectedProspect; }
            set { SetProperty(ref _selectedProspect, value); }
        }
        public bool IsExternalAgent
        {
            get { return _isExternalAgent; }
            set { SetProperty(ref _isExternalAgent, value); }
        }
        public List<string> MyDSAs
        {
            get { return _myDSAs; }
            set { SetProperty(ref _myDSAs, value); }
        }
        public string SelectedDSA
        {
            get { return _selectedDSA; }
            set { SetProperty(ref _selectedDSA, value); }
        }
        public string SbuName
        {
            get { return _sbuName; }
            set { SetProperty(ref _sbuName, value); }
        }
        public string AgentName
        {
            get { return _agentName; }
            set { SetProperty(ref _agentName, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public ProductPlan ProductPlan { get; set; }
        public BookOnline BookOnline { get; set; }

        private DelegateCommand _changePaymentCommand;
        private DelegateCommand _fetchCommand;
        private DelegateCommand _resetCommand;
        private DelegateCommand _proceedCommand;
        private DelegateCommand _changePolicyDuration;

        public DelegateCommand ChangePaymentCommand => _changePaymentCommand ?? (_changePaymentCommand = new DelegateCommand(ExecuteChangePaymentCommand));
        public DelegateCommand FetchCommand => _fetchCommand ?? (_fetchCommand = new DelegateCommand(ExecuteFetchCommand));
        public DelegateCommand ResetCommand => _resetCommand ?? (_resetCommand = new DelegateCommand(ExecuteResetCommand));
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProceed));
        public DelegateCommand ChangePolicyDuration => _changePolicyDuration ?? (_changePolicyDuration = new DelegateCommand(ExecuteChangePolicyDuration));

        public AmbitionsBookingPageViewModel(INavigationService navigationService, IPageDialogService pageDialogService, IProspectRepository prospectRepository,
            IProductPlansRepository productPlansRepository, IAgentRepository agentRepository, Logical logical, IBookOnlineRepository bookOnlineRepository, IBranchesRepository branchesRepository, EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _prospectRepository = prospectRepository;
            _agentRepository = agentRepository;
            _productPlansRepository = productPlansRepository;
            _bookOnlineRepository = bookOnlineRepository;
            _branchesRepository = branchesRepository;
            _logical = logical;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;

            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    //Guid prospectId;
                    //if (Guid.TryParse(parameters["ProspectId"].ToString(), out prospectId))
                    //{
                    //    Prospect = await _prospectRepository.GetById(prospectId);
                    //}

                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect encryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(encryptedProspect.Prospect);
                    Prospect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }

                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }

                if (parameters.ContainsKey("ProductPlanId"))
                {
                    Guid _productPlanId;
                    if (Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId))
                    {
                        ProductPlan = await _productPlansRepository.GetProductPlanByProductPlanId(_productPlanId);
                    }
                }

                InitializeDefaultValues();
            }
            catch (Exception ex)
            {

            }
            IsBusy = false;
        }

        private async void InitializeDefaultValues()
        {
            try
            {
                List<BankDTO> MyBanks = await _logical.GetBankList();
                foreach(BankDTO item in MyBanks)
                {
                    string bankName = string.Empty;
                    bankName = item.NameField;
                    BankList.Add(bankName);
                }
                BankList = BankList.Where(x => x != "-- Select One--").ToList();

                Title = "Ambitions Booking Page";
                AgentName = LoggedAgent.FullName;
                AgentCode = LoggedAgent.AgentCode;
                EmailAddress = LoggedAgent.EmailAddress;
                SbuName = LoggedAgent.SbuName;
                SbuCode = LoggedAgent.SBU;
                //PaymentFrequency = "Annual";
                //PolicyDuration = "1 year";
                PolicyStartDate = DateTime.Today;
                InitiationDate = DateTime.Today.ToString("MM-dd-yyyy");
                Age = Prospect.Age.ToString();
                AgeAtNextBirthday = (Prospect.Age + 1);
                CustomerNumber = Prospect.CustomerNumber;
                var Branches = await _branchesRepository.GetBranches();
                BranchList = Branches.Select(x => x.Branch).ToList();
                BranchList = BranchList.Where(x => x != "BRANCHES").ToList();

                List<string> Numbers = new List<string>();
                for (int i = 5; i < 31; i++)
                {
                    Numbers.Add(i.ToString());
                }
                PolicyDurations = Numbers;

                if (!LoggedAgent.IsAdvisor && !LoggedAgent.IsTeamManager)
                {
                    IsExternalAgent = false;

                    DSAs = await _logical.GetDSAsUnderPss(LoggedAgent.AgentCode);

                    if (DSAs.Count > 0 && DSAs.First().PSSCode != null)
                    {
                        MyDSAs = DSAs.Select(x => x.FullName).ToList();
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        public async void ExecuteChangePaymentCommand()
        {
            try
            {
                if (PaymentFrequency.Contains("Annual") && Contribution > 0)
                {
                    if (Contribution < 60000)
                    {
                        await _pageDialogService.DisplayAlertAsync("Warning", "Value entered does not match the required value for the payment frequency selected", "Ok");
                        LifeCoverValue = 0;
                        TotalPremium = string.Empty;
                    }
                    else
                    {
                        AnnualPremium = Contribution;
                        LifeCoverValue = AnnualPremium * 5;
                        TotalPremium = (AnnualPremium * Convert.ToInt32(SelectedPolicyDuration)).ToString("N0");
                    }
                }
                else if (PaymentFrequency.Contains("Monthly") && Contribution > 0)
                {
                    if (Contribution < 5000)
                    {
                        await _pageDialogService.DisplayAlertAsync("Warning", "Value entered does not match the required value for the payment frequency selected", "Ok");
                        LifeCoverValue = 0;
                        TotalPremium = string.Empty;
                    }
                    else
                    {
                        AnnualPremium = Contribution * 12;
                        LifeCoverValue = AnnualPremium * 5;
                        TotalPremium = (AnnualPremium * Convert.ToInt32(SelectedPolicyDuration)).ToString("N0");
                    }
                }
                else if (PaymentFrequency.Contains("Quarterly") && Contribution > 0)
                {
                    if (Contribution < 15000)
                    {
                        await _pageDialogService.DisplayAlertAsync("Warning", "Value entered does not match the required value for the payment frequency selected", "Ok");
                        LifeCoverValue = 0;
                        TotalPremium = string.Empty;
                    }
                    else
                    {
                        AnnualPremium = Contribution * 4;
                        LifeCoverValue = AnnualPremium * 5;
                        TotalPremium = (AnnualPremium * Convert.ToInt32(SelectedPolicyDuration)).ToString("N0");
                    }
                }
                else if (PaymentFrequency.Contains("Half yearly") && Contribution > 0)
                {
                    if (Contribution < 30000)
                    {
                        await _pageDialogService.DisplayAlertAsync("Warning", "Value entered does not match the required value for the payment frequency selected", "Ok");
                        LifeCoverValue = 0;
                        TotalPremium = string.Empty;
                    }
                    else
                    {
                        AnnualPremium = Contribution * 2;
                        LifeCoverValue = AnnualPremium * 5;
                        TotalPremium = (AnnualPremium * Convert.ToInt32(SelectedPolicyDuration)).ToString("N0");
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteFetchCommand()
        {
            IsBusy = true;
            IsPremium = false;
            try
            {
                if (Contribution == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Please input contribution", "Ok");
                    IsBusy = false;

                }
                else if (string.IsNullOrEmpty(SelectedPolicyDuration))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Please select policy duration", "Ok");
                    IsBusy = false;
                }
                else
                {
                    getMaxBenefitRequest getMaxBenefit = new getMaxBenefitRequest();
                    getMaxBenefit.CustomerAge = Prospect.Age;
                    getMaxBenefit.PolTerm = Convert.ToInt32(SelectedPolicyDuration);
                    getMaxBenefit.SumAssured = Convert.ToDouble(LifeCoverValue);
                    getMaxBenefit.annualPremium = Convert.ToDouble(AnnualPremium);
                    getMaxBenefit.invOption = 1;

                    var getMaxBenefitResponse = await _logical.GetBenefitResponseAsync(getMaxBenefit);
                    if (getMaxBenefitResponse.MaturityAcctBalanceHigherField != 0.0 || getMaxBenefitResponse.MaturityAcctBalanceLowerField != 0.0)
                    {
                        IsBusy = false;
                        IsPremium = true;
                        MaxMaturityValue = getMaxBenefitResponse.MaturityAcctBalanceHigherField;
                        MinMaturityValue = getMaxBenefitResponse.MaturityAcctBalanceLowerField;

                        Reasons = await _logical.GetReasonsForAmbition();
                        PolicyStartDate = DateTime.Now;
                        PolicyEndDate = PolicyStartDate.AddYears(Convert.ToInt32(SelectedPolicyDuration));
                    }
                    else
                    {
                        {
                            IsBusy = false;
                            IsPremium = false;
                            await _pageDialogService.DisplayAlertAsync("Error", "Error fetching booking details,Please try again", "Ok");
                        }
                    }

                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                IsBusy = false;
                await _pageDialogService.DisplayAlertAsync("Error", "Error fetching booking details,Please try again", "Ok");
            }

        }

        private void ExecuteResetCommand()
        {
            try
            {
                IsBusy = false;
                IsPremium = false;
                Contribution = 0;
                CalcuatedPremium = 0;
                SumAssured = 0;
                LifeCoverValue = 0;
                TotalPremium = string.Empty;
                AgeAtEndOfPolicy = 0;
                SelectedPolicyDuration = string.Empty;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteChangePolicyDuration()
        {
            IsBusy = true;
            try
            {
                AgeAtEndOfPolicy = AgeAtNextBirthday + Convert.ToInt32(SelectedPolicyDuration);
                if (AgeAtEndOfPolicy > 65)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Age at the end of policy cannot be greater than 65years", "Ok");
                    SelectedPolicyDuration = string.Empty;
                    AgeAtEndOfPolicy = 0;
                    TotalPremium = string.Empty;
                    return;
                }
                ExecuteChangePaymentCommand();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async void ExecuteProceed()
        {
            IsBusy = true;
            try
            {
                if (string.IsNullOrEmpty(SelectedBranch))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Please select agent branch", "Ok");
                }
                else if (string.IsNullOrEmpty(Reason))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Kindly select a reason for buying this product", "Ok");
                }
                else if (string.IsNullOrEmpty(BankName))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a bank", "Ok");
                }
                else if (string.IsNullOrEmpty(AccountNumber))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Kindly enter bank account number", "Ok");
                }
                else if(AccountNumber.Length != 10)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Account number must be 10 digits", "Ok");
                }
                else if (!Regex.IsMatch(AccountNumber, AccountNumberRegex))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Account number must be in a correct format", "Ok");
                }
                else
                {
                    var v = await _branchesRepository.GetBranchCodeByBranch(SelectedBranch);
                    if(v != null)
                    {
                        BranchCode = v.BranchCode;
                    }

                    if (!(string.IsNullOrEmpty(SelectedDSA)))
                    {
                        DSA = DSAs.Where(x => x.FullName == SelectedDSA).FirstOrDefault();
                    }

                    BookOnline = new BookOnline
                    {
                        Id = Guid.NewGuid(),
                        ProductPlanId = ProductPlan.Id,
                        AgentName = LoggedAgent.FullName,
                        AgeBeginPolicy = Convert.ToInt32(Age),
                        AgeEndPolicy = AgeAtEndOfPolicy,
                        AgentCode = LoggedAgent.AgentCode,
                        AnnualPremium = Convert.ToDecimal(AnnualPremium),
                        Assurer = LoggedAgent.FullName,
                        CustomerNo = Prospect.CustomerNumber,
                        DateCreated = DateTime.Now,
                        EmailAddress = Prospect.Email,
                        IntiationDate = DateTime.Now.ToString("MM/dd/yyyy"),
                        SumAssured = Convert.ToDecimal(LifeCoverValue),
                        TransactionType = "New",
                        SBU = LoggedAgent.SBU,
                        DSA = SelectedDSA,
                        TotalPremium = Convert.ToDecimal(TotalPremium),
                        Amount = Convert.ToDecimal(Contribution),
                        PolicyTerm = Convert.ToInt32(SelectedPolicyDuration),
                        LifeCoverValue = Convert.ToDecimal(LifeCoverValue),
                        PolicyStartDate = DateTime.Today.ToString("MM/dd/yyyy"),
                        PolicyEndDate = PolicyStartDate.AddYears(PolicyDuration).ToString("MM/dd/yyyy"),
                        PaymentFrequency = PaymentFrequency,
                        Contribution = (decimal)Contribution,
                        MaxMaturityValue = Convert.ToDouble(MaxMaturityValue),
                        MinMaturityValue = Convert.ToDouble(MinMaturityValue),
                        DSACode = DSA?.AgentCode,
                        BranchCode = BranchCode,
                        AmbitionReason = Reason,
                        BankAccountNumber = AccountNumber,
                        BankName = BankName
                    };

                    getMaxBenefitRequest getMaxBenefit = new getMaxBenefitRequest();
                    EPPprojectionsheetRequest req = new EPPprojectionsheetRequest();
                    getMaxBenefit.CustomerAge = Convert.ToInt32(Age);
                    getMaxBenefit.PolTerm = Convert.ToInt32(SelectedPolicyDuration);
                    getMaxBenefit.SumAssured = Convert.ToDouble(LifeCoverValue);
                    getMaxBenefit.annualPremium = Convert.ToDouble(AnnualPremium);
                    getMaxBenefit.invOption = 1;

                    var getMaxBenefitResponse = await _logical.GetBenefitResponseAsync(getMaxBenefit);

                    #region eppprojectionsheet

                    ProjectionsField[] res = new ProjectionsField[28];

                    res = getMaxBenefitResponse.ProjectionsField;

                    #region variable declaration
                    req.Year_1 = string.Empty;
                    req.Contribution_1 = string.Empty;
                    req.Lower_Sum_Assured_1 = string.Empty;
                    req.Lower_Policy_Value_1 = string.Empty;
                    req.Lower_Surrender_Value_1 = string.Empty;
                    req.Higher_Sum_Assured_1 = string.Empty;
                    req.Higher_Policy_Value_1 = string.Empty;
                    req.Higher_Surrender_Value_1 = string.Empty;

                    req.Year_2 = string.Empty;
                    req.Contribution_2 = string.Empty;
                    req.Lower_Sum_Assured_2 = string.Empty;
                    req.Lower_Policy_Value_2 = string.Empty;
                    req.Lower_Surrender_Value_2 = string.Empty;
                    req.Higher_Sum_Assured_2 = string.Empty;
                    req.Higher_Policy_Value_2 = string.Empty;
                    req.Higher_Surrender_Value_2 = string.Empty;

                    req.Year_3 = string.Empty;
                    req.Contribution_3 = string.Empty;
                    req.Lower_Sum_Assured_3 = string.Empty;
                    req.Lower_Policy_Value_3 = string.Empty;
                    req.Lower_Surrender_Value_3 = string.Empty;
                    req.Higher_Sum_Assured_3 = string.Empty;
                    req.Higher_Policy_Value_3 = string.Empty;
                    req.Higher_Surrender_Value_3 = string.Empty;


                    req.Year_4 = string.Empty;
                    req.Contribution_4 = string.Empty;
                    req.Lower_Sum_Assured_4 = string.Empty;
                    req.Lower_Policy_Value_4 = string.Empty;
                    req.Lower_Surrender_Value_4 = string.Empty;
                    req.Higher_Sum_Assured_4 = string.Empty;
                    req.Higher_Policy_Value_4 = string.Empty;
                    req.Higher_Surrender_Value_4 = string.Empty;

                    req.Year_5 = string.Empty;
                    req.Contribution_5 = string.Empty;
                    req.Lower_Sum_Assured_5 = string.Empty;
                    req.Lower_Policy_Value_5 = string.Empty;
                    req.Lower_Surrender_Value_5 = string.Empty;
                    req.Higher_Sum_Assured_5 = string.Empty;
                    req.Higher_Policy_Value_5 = string.Empty;
                    req.Higher_Surrender_Value_5 = string.Empty;

                    req.Year_6 = string.Empty;
                    req.Contribution_6 = string.Empty;
                    req.Lower_Sum_Assured_6 = string.Empty;
                    req.Lower_Policy_Value_6 = string.Empty;
                    req.Lower_Surrender_Value_6 = string.Empty;
                    req.Higher_Sum_Assured_6 = string.Empty;
                    req.Higher_Policy_Value_6 = string.Empty;
                    req.Higher_Surrender_Value_6 = string.Empty;

                    req.Year_7 = string.Empty;
                    req.Contribution_7 = string.Empty;
                    req.Lower_Sum_Assured_7 = string.Empty;
                    req.Lower_Policy_Value_7 = string.Empty;
                    req.Lower_Surrender_Value_7 = string.Empty;
                    req.Higher_Sum_Assured_7 = string.Empty;
                    req.Higher_Policy_Value_7 = string.Empty;
                    req.Higher_Surrender_Value_7 = string.Empty;

                    req.Year_8 = string.Empty;
                    req.Contribution_8 = string.Empty;
                    req.Lower_Sum_Assured_8 = string.Empty;
                    req.Lower_Policy_Value_8 = string.Empty;
                    req.Lower_Surrender_Value_8 = string.Empty;
                    req.Higher_Sum_Assured_8 = string.Empty;
                    req.Higher_Policy_Value_8 = string.Empty;
                    req.Higher_Surrender_Value_8 = string.Empty;

                    req.Year_9 = string.Empty;
                    req.Contribution_9 = string.Empty;
                    req.Lower_Sum_Assured_9 = string.Empty;
                    req.Lower_Policy_Value_9 = string.Empty;
                    req.Lower_Surrender_Value_9 = string.Empty;
                    req.Higher_Sum_Assured_9 = string.Empty;
                    req.Higher_Policy_Value_9 = string.Empty;
                    req.Higher_Surrender_Value_9 = string.Empty;

                    req.Year_10 = string.Empty;
                    req.Contribution_10 = string.Empty;
                    req.Lower_Sum_Assured_10 = string.Empty;
                    req.Lower_Policy_Value_10 = string.Empty;
                    req.Lower_Surrender_Value_10 = string.Empty;
                    req.Higher_Sum_Assured_10 = string.Empty;
                    req.Higher_Policy_Value_10 = string.Empty;
                    req.Higher_Surrender_Value_10 = string.Empty;

                    req.Year_11 = string.Empty;
                    req.Contribution_11 = string.Empty;
                    req.Lower_Sum_Assured_11 = string.Empty;
                    req.Lower_Policy_Value_11 = string.Empty;
                    req.Lower_Surrender_Value_11 = string.Empty;
                    req.Higher_Sum_Assured_11 = string.Empty;
                    req.Higher_Policy_Value_11 = string.Empty;
                    req.Higher_Surrender_Value_11 = string.Empty;

                    req.Year_12 = string.Empty;
                    req.Contribution_12 = string.Empty;
                    req.Lower_Sum_Assured_12 = string.Empty;
                    req.Lower_Policy_Value_12 = string.Empty;
                    req.Lower_Surrender_Value_12 = string.Empty;
                    req.Higher_Sum_Assured_12 = string.Empty;
                    req.Higher_Policy_Value_12 = string.Empty;
                    req.Higher_Surrender_Value_12 = string.Empty;

                    req.Year_13 = string.Empty;
                    req.Contribution_13 = string.Empty;
                    req.Lower_Sum_Assured_13 = string.Empty;
                    req.Lower_Policy_Value_13 = string.Empty;
                    req.Lower_Surrender_Value_13 = string.Empty;
                    req.Higher_Sum_Assured_13 = string.Empty;
                    req.Higher_Policy_Value_13 = string.Empty;
                    req.Higher_Surrender_Value_13 = string.Empty;

                    req.Year_14 = string.Empty;
                    req.Contribution_14 = string.Empty;
                    req.Lower_Sum_Assured_14 = string.Empty;
                    req.Lower_Policy_Value_14 = string.Empty;
                    req.Lower_Surrender_Value_14 = string.Empty;
                    req.Higher_Sum_Assured_14 = string.Empty;
                    req.Higher_Policy_Value_14 = string.Empty;
                    req.Higher_Surrender_Value_14 = string.Empty;

                    req.Year_15 = string.Empty;
                    req.Contribution_15 = string.Empty;
                    req.Lower_Sum_Assured_15 = string.Empty;
                    req.Lower_Policy_Value_15 = string.Empty;
                    req.Lower_Surrender_Value_15 = string.Empty;
                    req.Higher_Sum_Assured_15 = string.Empty;
                    req.Higher_Policy_Value_15 = string.Empty;
                    req.Higher_Surrender_Value_15 = string.Empty;

                    req.Year_16 = string.Empty;
                    req.Contribution_16 = string.Empty;
                    req.Lower_Sum_Assured_16 = string.Empty;
                    req.Lower_Policy_Value_16 = string.Empty;
                    req.Lower_Surrender_Value_16 = string.Empty;
                    req.Higher_Sum_Assured_16 = string.Empty;
                    req.Higher_Policy_Value_16 = string.Empty;
                    req.Higher_Surrender_Value_16 = string.Empty;

                    req.Year_17 = string.Empty;
                    req.Contribution_17 = string.Empty;
                    req.Lower_Sum_Assured_17 = string.Empty;
                    req.Lower_Policy_Value_17 = string.Empty;
                    req.Lower_Surrender_Value_17 = string.Empty;
                    req.Higher_Sum_Assured_17 = string.Empty;
                    req.Higher_Policy_Value_17 = string.Empty;
                    req.Higher_Surrender_Value_17 = string.Empty;

                    req.Year_18 = string.Empty;
                    req.Contribution_18 = string.Empty;
                    req.Lower_Sum_Assured_18 = string.Empty;
                    req.Lower_Policy_Value_18 = string.Empty;
                    req.Lower_Surrender_Value_18 = string.Empty;
                    req.Higher_Sum_Assured_18 = string.Empty;
                    req.Higher_Policy_Value_18 = string.Empty;
                    req.Higher_Surrender_Value_18 = string.Empty;

                    req.Year_19 = string.Empty;
                    req.Contribution_19 = string.Empty;
                    req.Lower_Sum_Assured_19 = string.Empty;
                    req.Lower_Policy_Value_19 = string.Empty;
                    req.Lower_Surrender_Value_19 = string.Empty;
                    req.Higher_Sum_Assured_19 = string.Empty;
                    req.Higher_Policy_Value_19 = string.Empty;
                    req.Higher_Surrender_Value_19 = string.Empty;

                    req.Year_20 = string.Empty;
                    req.Contribution_20 = string.Empty;
                    req.Lower_Sum_Assured_20 = string.Empty;
                    req.Lower_Policy_Value_20 = string.Empty;
                    req.Lower_Surrender_Value_20 = string.Empty;
                    req.Higher_Sum_Assured_20 = string.Empty;
                    req.Higher_Policy_Value_20 = string.Empty;
                    req.Higher_Surrender_Value_20 = string.Empty;

                    req.Year_21 = string.Empty;
                    req.Contribution_21 = string.Empty;
                    req.Lower_Sum_Assured_21 = string.Empty;
                    req.Lower_Policy_Value_21 = string.Empty;
                    req.Lower_Surrender_Value_21 = string.Empty;
                    req.Higher_Sum_Assured_21 = string.Empty;
                    req.Higher_Policy_Value_21 = string.Empty;
                    req.Higher_Surrender_Value_21 = string.Empty;

                    req.Year_22 = string.Empty;
                    req.Contribution_22 = string.Empty;
                    req.Lower_Sum_Assured_22 = string.Empty;
                    req.Lower_Policy_Value_22 = string.Empty;
                    req.Lower_Surrender_Value_22 = string.Empty;
                    req.Higher_Sum_Assured_22 = string.Empty;
                    req.Higher_Policy_Value_22 = string.Empty;
                    req.Higher_Surrender_Value_22 = string.Empty;

                    req.Year_23 = string.Empty;
                    req.Contribution_23 = string.Empty;
                    req.Lower_Sum_Assured_23 = string.Empty;
                    req.Lower_Policy_Value_23 = string.Empty;
                    req.Lower_Surrender_Value_23 = string.Empty;
                    req.Higher_Sum_Assured_23 = string.Empty;
                    req.Higher_Policy_Value_23 = string.Empty;
                    req.Higher_Surrender_Value_23 = string.Empty;

                    req.Year_24 = string.Empty;
                    req.Contribution_24 = string.Empty;
                    req.Lower_Sum_Assured_24 = string.Empty;
                    req.Lower_Policy_Value_24 = string.Empty;
                    req.Lower_Surrender_Value_24 = string.Empty;
                    req.Higher_Sum_Assured_24 = string.Empty;
                    req.Higher_Policy_Value_24 = string.Empty;
                    req.Higher_Surrender_Value_24 = string.Empty;

                    req.Year_25 = string.Empty;
                    req.Contribution_25 = string.Empty;
                    req.Lower_Sum_Assured_25 = string.Empty;
                    req.Lower_Policy_Value_25 = string.Empty;
                    req.Lower_Surrender_Value_25 = string.Empty;
                    req.Higher_Sum_Assured_25 = string.Empty;
                    req.Higher_Policy_Value_25 = string.Empty;
                    req.Higher_Surrender_Value_25 = string.Empty;

                    req.Year_26 = string.Empty;
                    req.Contribution_26 = string.Empty;
                    req.Lower_Sum_Assured_26 = string.Empty;
                    req.Lower_Policy_Value_26 = string.Empty;
                    req.Lower_Surrender_Value_26 = string.Empty;
                    req.Higher_Sum_Assured_26 = string.Empty;
                    req.Higher_Policy_Value_26 = string.Empty;
                    req.Higher_Surrender_Value_26 = string.Empty;

                    req.Year_27 = string.Empty;
                    req.Contribution_27 = string.Empty;
                    req.Lower_Sum_Assured_27 = string.Empty;
                    req.Lower_Policy_Value_27 = string.Empty;
                    req.Lower_Surrender_Value_27 = string.Empty;
                    req.Higher_Sum_Assured_27 = string.Empty;
                    req.Higher_Policy_Value_27 = string.Empty;
                    req.Higher_Surrender_Value_27 = string.Empty;

                    req.Year_28 = string.Empty;
                    req.Contribution_28 = string.Empty;
                    req.Lower_Sum_Assured_28 = string.Empty;
                    req.Lower_Policy_Value_28 = string.Empty;
                    req.Lower_Surrender_Value_28 = string.Empty;
                    req.Higher_Sum_Assured_28 = string.Empty;
                    req.Higher_Policy_Value_28 = string.Empty;
                    req.Higher_Surrender_Value_28 = string.Empty;








                    #endregion


                    if (res.Length >= 1 && res[0] != null)
                    {

                        req.Year_1 = (Prospect.Age + res[0].PolYearField).ToString();
                        req.Contribution_1 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_1 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_1 = res[0].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_1 = res[0].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_1 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_1 = res[0].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_1 = res[0].SurrValHigherField.ToString("N0");

                    }

                    if (res.Length >= 2 && res[1] != null)
                    {

                        req.Year_2 = (Prospect.Age + res[1].PolYearField).ToString();
                        req.Contribution_2 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_2 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_2 = res[1].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_2 = res[1].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_2 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_2 = res[1].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_2 = res[1].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 3 && res[2] != null)
                    {

                        req.Year_3 = (Prospect.Age + res[2].PolYearField).ToString();
                        req.Contribution_3 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_3 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_3 = res[2].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_3 = res[2].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_3 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_3 = res[2].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_3 = res[2].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 4 && res[3] != null)
                    {

                        req.Year_4 = (Prospect.Age + res[3].PolYearField).ToString();
                        req.Contribution_4 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_4 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_4 = res[3].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_4 = res[3].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_4 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_4 = res[3].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_4 = res[3].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 5 && res[4] != null)
                    {

                        req.Year_5 = (Prospect.Age + res[4].PolYearField).ToString();
                        req.Contribution_5 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_5 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_5 = res[4].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_5 = res[4].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_5 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_5 = res[4].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_5 = res[4].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 6 && res[5] != null)
                    {

                        req.Year_6 = (Prospect.Age + res[5].PolYearField).ToString();
                        req.Contribution_6 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_6 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_6 = res[5].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_6 = res[5].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_6 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_6 = res[5].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_6 = res[5].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 7 && res[6] != null)
                    {

                        req.Year_7 = (Prospect.Age + res[6].PolYearField).ToString();
                        req.Contribution_7 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_7 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_7 = res[6].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_7 = res[6].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_7 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_7 = res[6].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_7 = res[6].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 8 && res[7] != null)
                    {

                        req.Year_8 = (Prospect.Age + res[7].PolYearField).ToString();
                        req.Contribution_8 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_8 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_8 = res[7].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_8 = res[7].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_8 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_8 = res[7].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_8 = res[7].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 9 && res[8] != null)
                    {

                        req.Year_9 = (Prospect.Age + res[8].PolYearField).ToString();
                        req.Contribution_9 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_9 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_9 = res[8].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_9 = res[8].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_9 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_9 = res[8].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_9 = res[8].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 10 && res[9] != null)
                    {

                        req.Year_10 = (Prospect.Age + res[9].PolYearField).ToString();
                        req.Contribution_10 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_10 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_10 = res[9].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_10 = res[9].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_10 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_10 = res[9].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_10 = res[9].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 11 && res[10] != null)
                    {

                        req.Year_11 = (Prospect.Age + res[10].PolYearField).ToString();
                        req.Contribution_11 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_11 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_11 = res[10].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_11 = res[10].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_11 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_11 = res[10].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_11 = res[10].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 12 && res[11] != null)
                    {

                        req.Year_12 = (Prospect.Age + res[11].PolYearField).ToString();
                        req.Contribution_12 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_12 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_12 = res[11].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_12 = res[11].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_12 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_12 = res[11].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_12 = res[11].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 13 && res[12] != null)
                    {

                        req.Year_13 = (Prospect.Age + res[12].PolYearField).ToString();
                        req.Contribution_13 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_13 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_13 = res[12].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_13 = res[12].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_13 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_13 = res[12].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_13 = res[12].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 14 && res[13] != null)
                    {

                        req.Year_14 = (Prospect.Age + res[13].PolYearField).ToString();
                        req.Contribution_14 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_14 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_14 = res[13].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_14 = res[13].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_14 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_14 = res[13].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_14 = res[13].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 15 && res[14] != null)
                    {

                        req.Year_15 = (Prospect.Age + res[14].PolYearField).ToString();
                        req.Contribution_15 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_15 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_15 = res[14].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_15 = res[14].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_15 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_15 = res[14].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_15 = res[14].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 16 && res[15] != null)
                    {

                        req.Year_16 = (Prospect.Age + res[15].PolYearField).ToString();
                        req.Contribution_16 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_16 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_16 = res[15].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_16 = res[15].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_16 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_16 = res[15].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_16 = res[15].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 17 && res[16] != null)
                    {

                        req.Year_17 = (Prospect.Age + res[16].PolYearField).ToString();
                        req.Contribution_17 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_17 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_17 = res[16].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_17 = res[16].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_17 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_17 = res[16].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_17 = res[16].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 18 && res[17] != null)
                    {

                        req.Year_18 = (Prospect.Age + res[17].PolYearField).ToString();
                        req.Contribution_18 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_18 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_18 = res[17].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_18 = res[17].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_18 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_18 = res[17].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_18 = res[17].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 19 && res[18] != null)
                    {

                        req.Year_19 = (Prospect.Age + res[18].PolYearField).ToString();
                        req.Contribution_19 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_19 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_19 = res[18].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_19 = res[18].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_19 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_19 = res[18].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_19 = res[18].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 20 && res[19] != null)
                    {

                        req.Year_20 = (Prospect.Age + res[19].PolYearField).ToString();
                        req.Contribution_20 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_20 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_20 = res[19].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_20 = res[19].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_20 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_20 = res[19].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_20 = res[19].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 21 && res[20] != null)
                    {

                        req.Year_21 = (Prospect.Age + res[20].PolYearField).ToString();
                        req.Contribution_21 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_21 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_21 = res[20].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_21 = res[20].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_21 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_21 = res[20].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_21 = res[20].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 22 && res[21] != null)
                    {

                        req.Year_22 = (Prospect.Age + res[21].PolYearField).ToString();
                        req.Contribution_22 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_22 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_22 = res[21].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_22 = res[21].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_22 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_22 = res[21].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_22 = res[21].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 23 && res[22] != null)
                    {

                        req.Year_23 = (Prospect.Age + res[22].PolYearField).ToString();
                        req.Contribution_23 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_23 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_23 = res[22].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_23 = res[22].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_23 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_23 = res[22].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_23 = res[22].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 24 && res[23] != null)
                    {

                        req.Year_24 = (Prospect.Age + res[23].PolYearField).ToString();
                        req.Contribution_24 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_24 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_24 = res[23].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_24 = res[23].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_24 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_24 = res[23].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_24 = res[23].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 25 && res[24] != null)
                    {

                        req.Year_25 = (Prospect.Age + res[24].PolYearField).ToString();
                        req.Contribution_25 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_25 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_25 = res[24].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_25 = res[24].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_25 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_25 = res[24].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_25 = res[24].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 26 && res[25] != null)
                    {

                        req.Year_26 = (Prospect.Age + res[25].PolYearField).ToString();
                        req.Contribution_26 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_26 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_26 = res[25].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_26 = res[25].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_26 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_26 = res[25].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_26 = res[25].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 27 && res[26] != null)
                    {

                        req.Year_27 = (Prospect.Age + res[26].PolYearField).ToString();
                        req.Contribution_27 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_27 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_27 = res[26].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_27 = res[26].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_27 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_27 = res[26].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_27 = res[26].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 28 && res[27] != null)
                    {

                        req.Year_28 = (Prospect.Age + res[27].PolYearField).ToString();
                        req.Contribution_28 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_28 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_28 = res[27].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_28 = res[27].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_28 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_28 = res[27].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_28 = res[27].SurrValHigherField.ToString("N0");
                    };

                    req.Agent_Name = LoggedAgent.FullName;
                    req.AgentEmail = "raphael.ariguzor@axamansard.com";
                    //req.AgentEmail = LoggedAgent.EmailAddress;
                    req.Issue_Date = DateTime.Now.ToString("dd-MM-yyyy");
                    req.Customer_Name = Prospect.FullName;
                    req.Phone_Number = Prospect.MobileNumber;
                    //req.Email = Prospect.Email;
                    req.Email = Prospect.Email;
                    req.Address = Prospect.Address;
                    req.Total_Premium = (AnnualPremium * Convert.ToInt32( SelectedPolicyDuration)).ToString("N0");
                    req.Premium_Frequency = PaymentFrequency;
                    req.Policy_Term = Convert.ToString(SelectedPolicyDuration) + " Years";
                    req.Customer_Signature = Prospect.FullName;
                    req.Lower_Maturity_Value = getMaxBenefitResponse.MaturityAcctBalanceLowerField.ToString("N0");
                    req.Higher_Maturity_Value = getMaxBenefitResponse.MaturityAcctBalanceHigherField.ToString("N0");
                    req.Product = ProductPlan.PlanCategory;

                    var response = await _logical.GenerateEppProjectionSheet(req);
                    if (response.IsSuccess == true)
                    {
                        BookOnline.ProjectionSheetDocument = response.DocumentString;
                        IsBusy = false;
                        await _pageDialogService.DisplayAlertAsync("Successful", "Projection sheet sent", "Ok");
                    }
                    else
                    {
                        IsBusy = false;
                        await _pageDialogService.DisplayAlertAsync("Unsuccessful", "Projection sheet not sent", "Ok");
                    }
                    #endregion

                    var parameters = new NavigationParameters();
                    parameters.Add("ProspectId", Prospect.Id);
                    parameters.Add("ProductPlanId", ProductPlan.Id);
                    parameters.Add("AgentId", LoggedAgent.Id);
                    parameters.Add("BookOnlineId", BookOnline);

                    await _navigationService.NavigateAsync("AddBeneficiaryPage", parameters);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }
    }
}
