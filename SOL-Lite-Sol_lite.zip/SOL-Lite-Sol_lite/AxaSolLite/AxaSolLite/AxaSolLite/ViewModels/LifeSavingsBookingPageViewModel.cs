﻿using AxaSolLite.Extensions;
using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Xamarin.Forms;

namespace AxaSolLite.ViewModels
{
    public class LifeSavingsBookingPageViewModel : BindableBase, INavigationAware
    {
        private const string AccountNumberRegex = @"^[0-9]+$";

        private readonly INavigationService _navigationService;
        private readonly IValidationService _validationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly ICalculatorService _calculatorService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IProductPlansRepository _productPlanRepository;
        private readonly IMediaManager _deviceManager;
        private readonly IAgentRepository _agentRepository;
        private readonly IBookOnlineRepository _bookOnlineRepository;
        private readonly IBranchesRepository _branchesRepository;
        private readonly EncryptUtils _encryptUtils;

        #region Fields
        private bool _isBusy;
        private bool _isVisible;
        private string _title;
        private string _agentName;
        private string _agentCode;
        private string _sbu;
        private string _customerNo;
        private string _intiationDate;
        private string _emailAddress;
        private string _policyClass;
        private int _policyTerm;
        private decimal _sumAssured;
        private int _ageBeginPolicy;
        private int _ageEndPolicy;
        private decimal _expectedInterest;
        private decimal _totalSavings;
        private decimal _expectedFuture;
        private string _paymentFrequency;
        private string _paymentFrequencyLabel;
        private decimal _annualPremium;
        private decimal _totalPremium;
        private decimal _contribution;
        private string _policyStartDate;
        private string _policyEndDate;
        private string _paymentDate;
        private decimal _lifeCoverValue;
        private List<int> _policyDuration;
        private int _selectedPolicyDuration;
        private string _sbuName;
        private string _selectedDSA;
        private List<string> _myDSAs;
        private bool _isExternalAgent;
        private List<DSAUnderPSS> _dSAs;
        private DSAUnderPSS _dSA;
        private ImageSource _signaturePicture;
        private byte[] _newSignaturePicture;
        private Prospect _prospect;
        private Guid _prospectId;
        private Guid _productPlanId;
        private ProductPlan _productPlan;
        private UploadFile _uploadFile;
        private string _fileLabel;
        private string _fileLabelPath;
        private string[] _fileTypes;
        private string _fileSize;
        private Image _fileImagePreview;
        private string _text;
        private List<string> _fileNameList;
        private Dictionary<string, object> _fileByteList;
        private string _contents;
        private List<string> _branchList;
        private string _selectedbranch;
        private int _branchCode;
        private DelegateCommand _changePaymentCommand;
        private DelegateCommand _fileDeleteCommand;
        private DelegateCommand _pickfileCommand;
        private DelegateCommand _fetchCommand;
        private DelegateCommand _resetCommand;
        private DelegateCommand _proceedCommand;
        private const string ResourceNamespace = "AxaSolLite.Resources.Assets.";
        Logical logical = null;
        ArrayToImageConverter converter = new ArrayToImageConverter();
        private string _accountNumber;
        private List<string> _bankList = new List<string>();
        private string _bankName;
        #endregion

        #region Properties
        public string BankName
        {
            get { return _bankName; }
            set { SetProperty(ref _bankName, value); }
        }
        public List<string> BankList
        {
            get { return _bankList; }
            set { SetProperty(ref _bankList, value); }
        }
        public string AccountNumber
        {
            get { return _accountNumber; }
            set { SetProperty(ref _accountNumber, value); }
        }
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }

        public string AgentName
        {
            get { return _agentName; }
            set { SetProperty(ref _agentName, value); }
        }

        public string AgentCode
        {
            get { return _agentCode; }
            set { SetProperty(ref _agentCode, value); }
        }

        public string Sbu
        {
            get { return _sbu; }
            set { SetProperty(ref _sbu, value); }
        }

        public string CustomerNo
        {
            get { return _customerNo; }
            set { SetProperty(ref _customerNo, value); }
        }
        public List<string> BranchList
        {
            get { return _branchList; }
            set { SetProperty(ref _branchList, value); }
        }
        public string SelectedBranch
        {
            get { return _selectedbranch; }
            set { SetProperty(ref _selectedbranch, value); }
        }
        public int BranchCode
        {
            get { return _branchCode; }
            set { SetProperty(ref _branchCode, value); }
        }
        public string IntiationDate
        {
            get { return _intiationDate; }
            set { SetProperty(ref _intiationDate, value); }
        }

        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }

        public string PolicyClass
        {
            get { return _policyClass; }
            set { SetProperty(ref _policyClass, value); }
        }
        public int PolicyTerm
        {
            get { return _policyTerm; }
            set { SetProperty(ref _policyTerm, value); }
        }

        public decimal SumAssured
        {
            get { return _sumAssured; }
            set { SetProperty(ref _sumAssured, value); }
        }

        public int AgeBeginPolicy
        {
            get { return _ageBeginPolicy; }
            set { SetProperty(ref _ageBeginPolicy, value); }
        }

        public int AgeEndPolicy
        {
            get { return _ageEndPolicy; }
            set { SetProperty(ref _ageEndPolicy, value); }
        }

        public decimal ExpectedInterest
        {
            get { return _expectedInterest; }
            set { SetProperty(ref _expectedInterest, value); }
        }

        public decimal TotalSavings
        {
            get { return _totalSavings; }
            set { SetProperty(ref _totalSavings, value); }
        }
        public decimal ExpectedFuture
        {
            get { return _expectedFuture; }
            set { SetProperty(ref _expectedFuture, value); }
        }

        public string PaymentFrequency
        {
            get { return _paymentFrequency; }
            set { SetProperty(ref _paymentFrequency, value); }
        }

        public string PaymentFrequencyLabel
        {
            get { return _paymentFrequencyLabel; }
            set { SetProperty(ref _paymentFrequencyLabel, value); }
        }

        public decimal AnnualPremium
        {
            get { return _annualPremium; }
            set { SetProperty(ref _annualPremium, value); }
        }

        public decimal TotalPremium
        {
            get { return _totalPremium; }
            set { SetProperty(ref _totalPremium, value); }
        }

        public decimal Contribution
        {
            get { return _contribution; }
            set { SetProperty(ref _contribution, value); }
        }

        public string PolicyStartDate
        {
            get { return _policyStartDate; }
            set { SetProperty(ref _policyStartDate, value); }
        }

        public string PolicyEndDate
        {
            get { return _policyEndDate; }
            set { SetProperty(ref _policyEndDate, value); }
        }

        public string PaymentDate
        {
            get { return _paymentDate; }
            set { SetProperty(ref _paymentDate, value); }
        }
        public decimal LifeCoverValue
        {
            get { return _lifeCoverValue; }
            set { SetProperty(ref _lifeCoverValue, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }

        public bool IsVisible
        {
            get { return _isVisible; }
            set { SetProperty(ref _isVisible, value); }
        }
        public ImageSource SignaturePicture
        {
            get { return _signaturePicture; }
            set { SetProperty(ref _signaturePicture, value); }
        }

        public byte[] NewSignaturePicture
        {
            get { return _newSignaturePicture; }
            set { SetProperty(ref _newSignaturePicture, value); }
        }
        public List<int> PolicyDuration
        {
            get { return _policyDuration; }
            set { SetProperty(ref _policyDuration, value); }
        }
        public int SelectedPolicyDuration
        {
            get { return _selectedPolicyDuration; }
            set { SetProperty(ref _selectedPolicyDuration, value); }
        }
        public List<string> FileNameList
        {
            get { return _fileNameList; }
            set { SetProperty(ref _fileNameList, value); }
        }
        public Dictionary<string, object> FileByteList
        {
            get { return _fileByteList; }
            set { SetProperty(ref _fileByteList, value); }
        }
        public string Contents
        {
            get { return _contents; }
            set { SetProperty(ref _contents, value); }
        }
        public string FileLabel
        {
            get { return _fileLabel; }
            set { SetProperty(ref _fileLabel, value); }
        }
        public string FileLabelPath
        {
            get { return _fileLabelPath; }
            set { SetProperty(ref _fileLabelPath, value); }
        }
        public string FileSize
        {
            get { return _fileSize; }
            set { SetProperty(ref _fileSize, value); }
        }
        public string[] FileTypes
        {
            get { return _fileTypes; }
            set { SetProperty(ref _fileTypes, value); }
        }
        public Image FileImagePreview
        {
            get { return _fileImagePreview; }
            set { SetProperty(ref _fileImagePreview, value); }
        }

        public Prospect Prospect
        {
            get { return _prospect = _prospect ?? (_prospect = new Prospect()); }
            set { SetProperty(ref _prospect, value); }
        }
        public ProductPlan ProductPlan
        {
            get { return _productPlan = _productPlan ?? (_productPlan = new ProductPlan()); }
            set { SetProperty(ref _productPlan, value); }
        }
        public UploadFile UploadFile
        {
            get { return _uploadFile = _uploadFile ?? (_uploadFile = new UploadFile()); }
            set { SetProperty(ref _uploadFile, value); }
        }
        public DSAUnderPSS DSA
        {
            get { return _dSA; }
            set { SetProperty(ref _dSA, value); }
        }
        public List<DSAUnderPSS> DSAs
        {
            get { return _dSAs; }
            set { SetProperty(ref _dSAs, value); }
        }
        public bool IsExternalAgent
        {
            get { return _isExternalAgent; }
            set { SetProperty(ref _isExternalAgent, value); }
        }
        public List<string> MyDSAs
        {
            get { return _myDSAs; }
            set { SetProperty(ref _myDSAs, value); }
        }
        public string SelectedDSA
        {
            get { return _selectedDSA; }
            set { SetProperty(ref _selectedDSA, value); }
        }
        public string SbuName
        {
            get { return _sbuName; }
            set { SetProperty(ref _sbuName, value); }
        }
        public Agent LoggedAgent { get; set; }
        public BookOnline BookOnline { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }
        #endregion
        #region Commands
        public DelegateCommand ChangePaymentCommand => _changePaymentCommand ?? (_changePaymentCommand = new DelegateCommand(ExecuteChangePaymentCommand));
        public DelegateCommand FetchCommand => _fetchCommand ?? (_fetchCommand = new DelegateCommand(ExecuteFetchCommand));
        public DelegateCommand ResetCommand => _resetCommand ?? (_resetCommand = new DelegateCommand(ExecuteResetCommand));
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProceed));
        #endregion
        public LifeSavingsBookingPageViewModel(INavigationService navigationService,
            IValidationService validationService, IPageDialogService pageDialogService,
            ICalculatorService calculatorService,
            IProspectRepository prospectRepository,
            IMediaManager mediaManager,
             IProductPlansRepository productPlanRepository,
             IBookOnlineRepository bookOnlineRepository,
             IAgentRepository agentRepository,
             IBranchesRepository branchesRepository, EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _validationService = validationService;
            _pageDialogService = pageDialogService;
            _calculatorService = calculatorService;
            _prospectRepository = prospectRepository;
            _deviceManager = mediaManager;
            _branchesRepository = branchesRepository;
            _bookOnlineRepository = bookOnlineRepository;
            _productPlanRepository = productPlanRepository;
            _agentRepository = agentRepository;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsVisible = false;
            IsBusy = false;
            IsExternalAgent = true;
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    //Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    //Prospect = await _prospectRepository.GetById(_prospectId);
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    Prospect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);

                    CustomerNo = Prospect.CustomerNumber;

                }
                if (parameters.ContainsKey("ProductPlanId"))
                {
                    Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId);
                    ProductPlan = await _productPlanRepository.GetProductPlanByProductPlanId(_productPlanId);
                    PolicyClass = ProductPlan.PlanCategory;

                }
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                        AgentName = LoggedAgent.FullName;
                        if (LoggedAgent.IsAdvisor)
                        {
                            AgentCode = LoggedAgent.SubAgentCode;
                        }
                        else
                        {
                            AgentCode = LoggedAgent.AgentCode;
                        }
                        EmailAddress = LoggedAgent.EmailAddress;
                        Sbu = LoggedAgent.SBU;

                    }
                }
                InitializeDefaultValues();

            }
            catch (Exception ex)
            {


            }


        }

        private async void InitializeDefaultValues()
        {
            logical = new Logical();
            List<BankDTO> MyBanks = await logical.GetBankList();
            foreach (BankDTO item in MyBanks)
            {
                string bankName = string.Empty;
                bankName = item.NameField;
                BankList.Add(bankName);
            }
            BankList = BankList.Where(x => x != "-- Select One--").ToList();

            IntiationDate = DateTime.Now.ToString("MMMM dd yyyy");
            PolicyStartDate = DateTime.Now.ToString("MM/dd/yyyy");
            PolicyEndDate = DateTime.Now.AddYears(SelectedPolicyDuration).ToString("MM/dd/yyyy");
            AgeBeginPolicy = _calculatorService.GetInsuranceAge(Prospect.Birthdate);
            AgeEndPolicy = AgeBeginPolicy + SelectedPolicyDuration;
            PaymentFrequency = "Monthly";

            PaymentDate = DateTime.Now.ToString("MM/dd/yyyy");
            SbuName = LoggedAgent.SbuName;
            var Branches = await _branchesRepository.GetBranches();
            BranchList = Branches.Select(x => x.Branch).ToList();
            BranchList = BranchList.Where(x => x != "BRANCHES").ToList();


            List<int> Numbers = new List<int>();
            for (int i = 1; i < 16; i++)
            {
                Numbers.Add(i);
            }
            PolicyDuration = Numbers;
            var convertedImage = converter.Convert(NewSignaturePicture, null, null, null) as ImageSource;
            SignaturePicture = "add_photo.png";
            if (LoggedAgent.IsAdvisor || LoggedAgent.IsTeamManager)
            {
                IsExternalAgent = true;
            }

            else
            {
                IsExternalAgent = false;
                DSAs = await logical.GetDSAsUnderPss(LoggedAgent.AgentCode);

                if (DSAs.Count > 0 && DSAs.First().PSSCode != null)
                {
                    MyDSAs = DSAs.Select(x => x.FullName).ToList();
                }
            }

        }

        private void ExecuteChangePaymentCommand()
        {
            try
            {
                if (PaymentFrequency.Contains("Annual"))
                {
                    Contribution = 0;
                    AnnualPremium = Contribution;


                }
                else if (PaymentFrequency.Contains("Monthly"))
                {

                    Contribution = 0;
                    AnnualPremium = Contribution * 12;



                }
                else if (PaymentFrequency.Contains("Quarterly"))
                {

                    Contribution = 0;
                    AnnualPremium = Contribution * 4;



                }
                else if (PaymentFrequency.Contains("Half yearly"))
                {

                    Contribution = 0;
                    AnnualPremium = Contribution * 2;


                }
                PaymentFrequencyLabel = PaymentFrequency + "  " + "Premium";
                TotalPremium = AnnualPremium * SelectedPolicyDuration;



            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private void ExecuteResetCommand()
        {
            IsBusy = false;
            IsVisible = false;
            Contribution = 0;
            LifeCoverValue = 0;
            SelectedPolicyDuration = 0;


        }

        private async void ExecuteFetchCommand()
        {
            IsBusy = true;
            IsVisible = false;
            try
            {
                if (Contribution == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Input contribution", "Ok");
                    IsBusy = false;

                }
                else if (SelectedPolicyDuration == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Please select policy duration", "Ok");
                    IsBusy = false;
                }
                else
                {
                    logical = new Logical();
                    LifeSavingsRequest getMaxBenefit = new LifeSavingsRequest();

                    if (PaymentFrequency.Contains("Annual"))
                    {
                        getMaxBenefit.PaymentFrequency = 4;
                      

                    }
                    else if (PaymentFrequency.Contains("Monthly"))
                    {

                        getMaxBenefit.PaymentFrequency = 1;


                    }
                    else if (PaymentFrequency.Contains("Quarterly"))
                    {


                        getMaxBenefit.PaymentFrequency = 2;

                    }
                    else if (PaymentFrequency.Contains("Half yearly"))
                    {

                        getMaxBenefit.PaymentFrequency = 3;

                    }

                    getMaxBenefit.Period = SelectedPolicyDuration;
                    getMaxBenefit.SavingsAmt = Convert.ToDouble(Contribution);
                  

                    var getMaxBenefitResponse = await logical.GetLifeSavingsQuote(getMaxBenefit);
                    if (getMaxBenefitResponse != null)
                    {
                        IsBusy = false;
                        IsVisible = true;
                        ExpectedInterest = Convert.ToDecimal( getMaxBenefitResponse.TotalInterest);
                        ExpectedFuture = Convert.ToDecimal(getMaxBenefitResponse.TotalBalance);
                        LifeCoverValue = Convert.ToDecimal(getMaxBenefitResponse.LifeCover);

                    }
                    else
                    {
                        {
                            IsBusy = false;
                            IsVisible = false;
                            await _pageDialogService.DisplayAlertAsync("Error", "Error fetching booking details,Please try again", "Ok");
                        }
                    }



                }
                PolicyEndDate = DateTime.Now.AddYears(SelectedPolicyDuration).ToString("MM/dd/yyyy");
                AgeEndPolicy = AgeBeginPolicy + SelectedPolicyDuration;
                //AnnualPremium = Contribution;
                TotalPremium = AnnualPremium * SelectedPolicyDuration;

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                IsBusy = false;
                await _pageDialogService.DisplayAlertAsync("Error", "Error fetching booking details,Please try again", "Ok");
            }

        }

        private async void ExecuteProceed()
        {
            try
            {
                if (Contribution == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please Enter a Contribution", "Ok");
                }
                else if (SelectedPolicyDuration == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a policy duration", "Ok");
                }
                else if (string.IsNullOrEmpty(SelectedBranch))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a branch", "Ok");
                }
                else if (string.IsNullOrEmpty(BankName))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a bank", "Ok");
                }
                else if (string.IsNullOrEmpty(AccountNumber))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Kindly enter bank account number", "Ok");
                }
                else if (AccountNumber.Length != 10)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Account number must be 10 digits", "Ok");
                }
                else if (!Regex.IsMatch(AccountNumber, AccountNumberRegex))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Account number must be in a correct format", "Ok");
                }
                else
                {
                    if (!(string.IsNullOrEmpty(SelectedDSA)))
                    {
                        DSA = DSAs.Where(x => x.FullName == SelectedDSA).FirstOrDefault();

                    }
                    if (!(string.IsNullOrEmpty(SelectedBranch)))
                    {

                        var v = await _branchesRepository.GetBranchCodeByBranch(SelectedBranch);
                        BranchCode = v.BranchCode;

                    }

                    BookOnline = new BookOnline
                    {
                        Id = Guid.NewGuid(),
                        ProductPlanId = ProductPlan.Id,
                        AgentName = LoggedAgent.FullName,
                        AgeBeginPolicy = Convert.ToInt32(AgeBeginPolicy),
                        AgeEndPolicy = Convert.ToInt32(AgeEndPolicy),
                        AgentCode = LoggedAgent.AgentCode,
                        AnnualPremium = Convert.ToDecimal(AnnualPremium),
                        Assurer = LoggedAgent.FullName,
                        CustomerNo = Prospect.CustomerNumber,
                        DateCreated = DateTime.Now,
                        EmailAddress = Prospect.Email,
                        IntiationDate = DateTime.Now.ToString("MM/dd/yyyy"),
                        SumAssured = Convert.ToDecimal(LifeCoverValue),
                        TransactionType = "New",
                        SBU = LoggedAgent.SBU,
                        DSA = SelectedDSA,
                        DSACode = DSA?.AgentCode,
                        TotalPremium = Convert.ToDecimal(TotalPremium),
                        Amount = Contribution,
                        PolicyTerm = SelectedPolicyDuration,
                        LifeCoverValue = Convert.ToDecimal(LifeCoverValue),
                        PolicyStartDate = PolicyStartDate,
                        PolicyEndDate = PolicyEndDate,
                        PaymentFrequency = PaymentFrequency,
                        Contribution = Contribution,
                        PolicyClass = PolicyClass,
                        // MaxMaturityValue = Convert.ToDouble(MaxMaturityValue),
                        //MinMaturityValue = Convert.ToDouble(MinMaturityValue),
                        ExpectedInterest = ExpectedInterest,
                        ExpectedFuture = ExpectedFuture,
                        BranchCode = BranchCode,
                        BankAccountNumber = AccountNumber,
                        BankName = BankName
                    };

                    //int saved = await _bookOnlineRepository.SaveBooking(BookOnline);

                    var parameters = new NavigationParameters();
                    parameters.Add("ProspectId", Prospect.Id);
                    parameters.Add("ProductPlanId", ProductPlan.Id);
                    parameters.Add("AgentId", LoggedAgent.Id);
                    parameters.Add("BookOnlineId", BookOnline);

                    await _navigationService.NavigateAsync("AddBeneficiaryPage", parameters);
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}
