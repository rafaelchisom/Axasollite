﻿using AxaSolLite.Extensions;
using AxaSolLite.Models;
using AxaSolLite.Models.CustomerOnboardingCreateCase;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Plugin.FilePicker;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AxaSolLite.ViewModels
{
    public class PaperFnaPageViewModel : BindableBase, INavigationAware
    {
        private readonly IAgentRepository _agentRepository;
        private readonly IProspectRepository _prospectRepository;
        private readonly IPageDialogService _pageDialogService;
        private readonly IGenBizBranchRepository _genBizBranchRepository;
        private readonly IBranchesRepository _branchesRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly INavigationService _navigationService;
        private readonly IValidationService _validationService;
        private readonly IMediaManager _deviceManager;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        private string _firstName;
        private string _lastName;
        private string _emailAddress;
        private string _uploadFiles;
        private string _extension;
        private DateTime _date;
        private bool _isBusy;
        private ImageSource _signaturePicture;
        private byte[] _newSignaturePicture;
        private string _fileLabel;
        private string _fileLabelPath;
        private string[] _fileTypes;
        private string _fileSize;
        private Image _fileImagePreview;
        private string _text;
        private List<string> _fileNameList;
        private Dictionary<string, object> _fileByteList;
        private string _contents;
        private string _contentType;
        private FileVariable _files;
        private UploadFile _uploadFile;
        private const string ResourceNamespace = "AxaSolLite.Resources.Assets.";
        ArrayToImageConverter converter = new ArrayToImageConverter();
        private DelegateCommand _fileDeleteCommand;
        private DelegateCommand _pickfileCommand;
        private Guid _prospectId;


        public string FirstName
        {
            get { return _firstName; }
            set { SetProperty(ref _firstName, value); }
        }
        public string LastName
        {
            get { return _lastName; }
            set { SetProperty(ref _lastName, value); }
        }
        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }
        public string UploadFiles
        {
            get { return _uploadFiles; }
            set { SetProperty(ref _uploadFiles, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public DateTime Date
        {
            get { return _date; }
            set { SetProperty(ref _date, value); }
        }
        public ImageSource SignaturePicture
        {
            get { return _signaturePicture; }
            set { SetProperty(ref _signaturePicture, value); }
        }
        public byte[] NewSignaturePicture
        {
            get { return _newSignaturePicture; }
            set { SetProperty(ref _newSignaturePicture, value); }
        }
        public List<string> FileNameList
        {
            get { return _fileNameList; }
            set { SetProperty(ref _fileNameList, value); }
        }
        public Dictionary<string, object> FileByteList
        {
            get { return _fileByteList; }
            set { SetProperty(ref _fileByteList, value); }
        }
        public string Contents
        {
            get { return _contents; }
            set { SetProperty(ref _contents, value); }
        }
        public string FileLabel
        {
            get { return _fileLabel; }
            set { SetProperty(ref _fileLabel, value); }
        }
        public string FileLabelPath
        {
            get { return _fileLabelPath; }
            set { SetProperty(ref _fileLabelPath, value); }
        }
        public string FileSize
        {
            get { return _fileSize; }
            set { SetProperty(ref _fileSize, value); }
        }
        public string[] FileTypes
        {
            get { return _fileTypes; }
            set { SetProperty(ref _fileTypes, value); }
        }
        public string Extension
        {
            get { return _extension; }
            set { SetProperty(ref _extension, value); }
        }
        public Image FileImagePreview
        {
            get { return _fileImagePreview; }
            set { SetProperty(ref _fileImagePreview, value); }
        }
        public UploadFile UploadFile
        {
            get { return _uploadFile = _uploadFile ?? (_uploadFile = new UploadFile()); }
            set { SetProperty(ref _uploadFile, value); }
        }
        public string ContentType
        {
            get { return _contentType; }
            set { SetProperty(ref _contentType, value); }
        }
        public FileVariable Files
        {
            get { return _files; }
            set { SetProperty(ref _files, value); }
        }
        public Agent Agent { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }

        private Logical logical = null;

        private DelegateCommand _saveCommand;
        public DelegateCommand SaveCommand => _saveCommand ?? (_saveCommand = new DelegateCommand(ExecuteSaveCommand));
        public DelegateCommand PickFileCommand => _pickfileCommand ?? (_pickfileCommand = new DelegateCommand(ExecutePickFileCommand));
        public DelegateCommand FileDeleteCommand => _fileDeleteCommand ?? (_fileDeleteCommand = new DelegateCommand(ExecuteFileDeleteCommand));



        public PaperFnaPageViewModel(INavigationService navigationService, IAgentRepository agentRepository, IProspectRepository prospectRepository,
            IGenBizBranchRepository genBizBranchRepository, IBranchesRepository branchesRepository,
             IPageDialogService pageDialogService,
              IMediaManager mediaManager,
              IValidationService validationService,
            IProductPlansRepository productPlansRepository, EncryptUtils encryptUtils)
        {
            _agentRepository = agentRepository;
            _navigationService = navigationService;
            _prospectRepository = prospectRepository;
            _pageDialogService = pageDialogService;
            _branchesRepository = branchesRepository;
            _deviceManager = mediaManager;
            _validationService = validationService;
            _genBizBranchRepository = genBizBranchRepository;
            _productPlansRepository = productPlansRepository;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }
        public async void OnNavigatedTo(INavigationParameters parameters)
        {

            try
            {
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        Agent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }
                Date = DateTime.Now;
                SignaturePicture = "add_photo.png";
            }
            catch (Exception ex)
            {

            }

        }
        private async void ExecutePickFileCommand()
        {
            try
            {

                bool choice = await _pageDialogService.DisplayAlertAsync("Confirm", "Please select how you wish to upload a document", "Gallery", "Camera");
                if (choice)
                {
                    if (Device.RuntimePlatform == Device.Android)
                    {
                        FileTypes = new string[] { "image/png", "image/jpeg", "application/pdf" };
                    }

                    await PickedFiles(FileTypes);
                    FileVariable signatureFile = new FileVariable
                    {
                        FileName = FileLabel,
                        FieldName = "Captured Signature",
                        FileContent = Convert.ToBase64String(NewSignaturePicture),
                        ContentType = ContentType,
                        Extension = !ContentType.ToLower().Contains("jpeg") ? ContentType.Substring((ContentType.Length - 3), 3) : ContentType.Substring((ContentType.Length - 4), 4)
                    };

                    Files = signatureFile;

                    if (FileLabel != null || Contents != null)
                    {
                        if (Contents.Length > 2097152)
                        {
                            FileLabel = null;
                            Contents = null;
                            await _pageDialogService.DisplayAlertAsync("Error", "File size too large. Please upload a document not larger than 2MB in size", "Cancel");
                        }
                        else
                            UploadFiles = signatureFile.FileContent;
                        Extension = signatureFile.Extension;
                        await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");
                    }

                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Unsuccessful", "Document failed to upload. Please try again.", "Ok");
                    }
                }
                else
                {
                    if (_deviceManager.CameraAvailable)
                    {
                        var newPhoto = await _deviceManager.TakePhotoAsync();

                        if (newPhoto != null)
                        {
                            NewSignaturePicture = newPhoto.FileContent;

                            FileVariable CameraTaken = new FileVariable
                            {
                                FileName = newPhoto.FileName,
                                FileContent = Convert.ToBase64String(NewSignaturePicture),
                                FieldName = "Captured Signature",
                                ContentType = "image/jpg",
                                Extension = "jpg"
                            };
                            Extension = CameraTaken.Extension;
                            Files = CameraTaken;
                            UploadFiles = CameraTaken.FileContent;
                            await _pageDialogService.DisplayAlertAsync("File Uploaded", "Photo successfully captured", "Okay");
                        }
                        else
                        {

                            await _pageDialogService.DisplayAlertAsync("Oooops!!!", "File too large, recapture the document or upload another document", "Cancel");
                        }
                    }

                }
                var convertedImage = converter.Convert(NewSignaturePicture, null, null, null) as ImageSource;

                SignaturePicture = convertedImage ?? ImageSource.FromResource(ResourceNamespace + "add_photo.png");

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
        public async Task PickedFiles(string[] fileTypes)
        {
            try
            {

                var pickedFile = await CrossFilePicker.Current.PickFile(fileTypes);

                if (pickedFile != null)
                {
                    FileLabel = pickedFile.FileName;
                    FileLabelPath = pickedFile.FilePath;
                    //NewSignaturePicture = pickedFile.DataArray;

                    if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase))
                    {
                        Contents = System.Text.Encoding.UTF8.GetString(pickedFile.DataArray, 0, pickedFile.DataArray.Length);
                        NewSignaturePicture = pickedFile.DataArray;

                        if (pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "application/pdf";
                        }
                        else if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "image" + "/jpg";
                        }
                        else if (pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "image" + "/png";
                        }
                        else
                            ContentType = "image" + "/jpeg";
                    }

                    // FileSize = FileSizeFormatter.FormatSize(Contents.Length);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public static class FileSizeFormatter
        {
            static readonly string[] suffixes = { "Bytes", "KB", "MB", "GB", "TB", "PB" };

            public static string FormatSize(long bytes)
            {
                int counter = 0;
                decimal number = (decimal)bytes;
                while (Math.Round(number / 1024) >= 1)
                {
                    number = number / 1024;
                    counter++;
                }
                return string.Format("{0:n1}{1}", number, suffixes[counter]);
            }
        }

        private async void ExecuteFileDeleteCommand()
        {
            try
            {
                if (FileLabel != null || Contents != null)
                {
                    FileLabel = null;
                    Contents = null;
                    SignaturePicture = null;
                    await _pageDialogService.DisplayAlertAsync("Done", "Uploaded file deleted successfully", "Ok");
                }
                else
                    await _pageDialogService.DisplayAlertAsync("Notice", "There is no document to be deleted", "Ok");
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
        private async void ExecuteSaveCommand()
        {
            IsBusy = true;
            try
            {
                var errors = _validationService.ValidateEmailPattern(EmailAddress);
                if (string.IsNullOrEmpty(FirstName))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please enter a firstname", "Ok");
                }
                else if (string.IsNullOrEmpty(LastName))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please enter a lastname", "Ok");
                }
                else if (string.IsNullOrEmpty(EmailAddress))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please enter Emailaddress", "Ok");
                }
                else if (string.IsNullOrEmpty(UploadFiles))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please upload a file", "Ok");
                }
                else if (!errors)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Email Address format is wrong", "Ok");
                }
                else
                {
                    logical = new Logical();
                    PaperFna req = new PaperFna();
                    req.FirstName = FirstName;
                    req.LastName = LastName;
                    req.EmailAddress = EmailAddress;
                    req.DateOfUpload = Date;
                    req.UploadedFile = UploadFiles;
                    req.AgentCode = Agent.AgentCode;
                    req.AgentName = Agent.FullName;
                    req.Sbu = Agent.SBU;
                    var Inserted = await logical.InsertPaperFnaIntoDB(req);
                    if (Inserted)
                    {
                        await _pageDialogService.DisplayAlertAsync("Successful", "Paper FNA saved", "ok");
                        PaperFnaRequest request = new PaperFnaRequest();
                        request.FullName = FirstName + " " + LastName;
                        request.EmailAddress = EmailAddress;
                        request.AgentName = Agent.FullName;
                        request.AgentEmail = Agent.EmailAddress;
                        request.PaperFnaFile = UploadFiles;
                        request.ContentType = Extension;
                        var sent = await logical.SendPaperFNAMail(request);
                        if (sent)
                        {
                            await _pageDialogService.DisplayAlertAsync("Success!", "Uploaded FNA result has been sent to the customer's mail", "ok");
                            await _navigationService.GoBackAsync();

                        }
                        else
                        {
                            await _pageDialogService.DisplayAlertAsync("Failed! ", "Kindly try again", "ok");

                        }





                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Unsucessful", "Try again", "ok");

                    }
                }


            }
            catch (Exception ex)
            {

            }
            IsBusy = false;
        }
    }
}
