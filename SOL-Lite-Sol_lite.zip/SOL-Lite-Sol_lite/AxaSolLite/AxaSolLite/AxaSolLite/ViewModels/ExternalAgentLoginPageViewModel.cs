﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AxaSolLite.ViewModels
{
    public class ExternalAgentLoginPageViewModel : BindableBase, INavigationAware
    {
        private readonly IRepositoryManager _repositoryManager;
        private readonly IUserManager _userService;
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;

        private DelegateCommand _forgotPasswordCommand;
        private DelegateCommand _loginCommand;
        private DelegateCommand _checkedCommand;
        private DelegateCommand _feedbackCommand;

        private string _password;
        private string _agentCode;
        private string _userName;
        private string _emailAddress;
        private bool _isBusy;
        private bool _isExternal;
        private bool _isChecked;
        private bool _isPassword;

        public string AgentCode
        {
            get { { return _agentCode; } }
            set { SetProperty(ref _agentCode, value); }
        }
        public string UserName
        {
            get { { return _userName; } }
            set { SetProperty(ref _userName, value); }
        }
        public string EmailAddress
        {
            get { { return _emailAddress; } }
            set { SetProperty(ref _emailAddress, value); }
        }

        public string Password
        {
            get { { return _password; } }
            set { SetProperty(ref _password, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public bool IsExternal
        {
            get { return _isExternal; }
            set { SetProperty(ref _isExternal, value); }
        }
        public bool IsChecked
        {
            get { return _isChecked; }
            set { SetProperty(ref _isChecked, value); }
        }
        public bool IsPassword
        {
            get { return _isPassword; }
            set { SetProperty(ref _isPassword, value); }
        }
        #region COMMANDS
        public DelegateCommand ForgotPasswordCommand => _forgotPasswordCommand ?? (_forgotPasswordCommand = new DelegateCommand(ExecuteForgotPassword));
        public DelegateCommand LoginCommand => _loginCommand ?? (_loginCommand = new DelegateCommand(ExecuteLogin));
        public DelegateCommand FeedbackCommand => _feedbackCommand ?? (_feedbackCommand = new DelegateCommand(ExecuteFeedback));
        public DelegateCommand CheckedCommand => _checkedCommand ?? (_checkedCommand = new DelegateCommand(ExecuteChecked));

        Logical logical = null;

        #endregion
        public ExternalAgentLoginPageViewModel(IUserManager userService,
            INavigationService navigationService,
            IPageDialogService pageDialogService,
            IRepositoryManager repositoryManager)
        {
            _userService = userService;
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _repositoryManager = repositoryManager;

        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            IsPassword = true;
            AgentCode = "3432301310";

        }
        public async void ExecuteLogin()
        {
            try
            {

                IsBusy = true;
                if (!String.IsNullOrEmpty(this.UserName))
                {
                    this.UserName = this.UserName.Trim();
                }

                logical = new Logical();
                DmtSignInReq loginReq = new DmtSignInReq();
                loginReq.username = UserName;
                loginReq.password = Password;
                loginReq.appVersion = "6.6.6";
                var AgentSignResponse = await logical.SignIn(loginReq);
                if (AgentSignResponse.AuthenticateUserResult == true)
                {
                    EmailAddress = AgentSignResponse.Email;
                    IsExternal = true;

                    var navigationParameter = new NavigationParameters();

                    navigationParameter.Add("Email", EmailAddress);
                    navigationParameter.Add("AgentCode", this.AgentCode.Trim());
                    navigationParameter.Add("IsExternal", IsExternal);
                    await _navigationService.NavigateAsync("AxaSolLite://MyNavigationPage/AgentWelcomePage", navigationParameter);

                }
                else
                {

                    await _pageDialogService.DisplayAlertAsync("Unsuccessful", "Authentication failed. This error is subject to two reasons. 1.Wrong combination of login credentials 2.Expired password: Kindly proceed to change your password if you're certain that your login credential is correct and the error message persist upon subsequent attempts", "Ok");
                    IsBusy = false;
                }
                IsBusy = false;
            }

            catch (Exception ex)
            {
                ex.Message.ToString();
                await _pageDialogService.DisplayAlertAsync("Error", "Login Failed", "Ok");
            }
        }
        public async void ExecuteForgotPassword()
        {

            await _navigationService.NavigateAsync("ExternalAgentForgotPasswordPage");
        }
        public void ExecuteChecked()
        {
            if (IsChecked == false)
            {
                IsPassword = true;
            }
            else
            {
                IsPassword = false;
            }



        }
        public async void ExecuteFeedback()
        {

            await _navigationService.NavigateAsync("AgentFeedbackPage", null, null, false);
        }
    }
}
