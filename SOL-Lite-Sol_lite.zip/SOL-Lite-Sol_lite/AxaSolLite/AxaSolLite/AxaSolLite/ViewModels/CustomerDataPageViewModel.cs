﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Xamarin.Forms;
namespace AxaSolLite.ViewModels
{
    public class CustomerDataPageViewModel : BindableBase, INavigationAware
    {
        private readonly IProspectRepository _prospectRepository;
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IUserManager _userManager;
        private readonly IUserRepository _userRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly IProductPlansRepository _productPlanRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;


        private string _title;
        private string _labelText;
        private string _fileLabel;
        private string _fileLabelPath;
        private string _fullName;
        private string _firstName;
        private string _lastName;
        private string _email;
        private string _phoneNumber;
        private bool _isBusy;
        private bool _isVisible;
        private Prospect _selectedProspect;
        private Guid _customerNo;
        private List<Result> _searchedCustomers;
        private Guid _prospectId;

        private ObservableCollection<Result> _CustomerSearchResponse;

        private List<Result> _oldCustomerSearchRes;
        private bool _toggled;
        private string _searchText { get; set; }
        public IList<ProductPlan> ProductPlan { get; set; }
        #region PROPERTIES
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public string LabelText
        {
            get { return _labelText; }
            set { SetProperty(ref _labelText, value); }
        }
        public string FileLabel
        {
            get { return _fileLabel; }
            set { SetProperty(ref _fileLabel, value); }
        }
        public string FileLabelPath
        {
            get { return _fileLabelPath; }
            set { SetProperty(ref _fileLabelPath, value); }
        }
        public string FullName
        {
            get { return _fullName; }
            set { SetProperty(ref _fullName, value); }
        }
        public string FirstName
        {
            get { return _firstName; }
            set { SetProperty(ref _firstName, value); }
        }
        public string LastName
        {
            get { return _lastName; }
            set { SetProperty(ref _lastName, value); }
        }
        public string Email
        {
            get { return _email; }
            set { SetProperty(ref _email, value); }
        }
        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { SetProperty(ref _phoneNumber, value); }
        }
        public Guid CustomerNo
        {
            get { return _customerNo; }
            set { SetProperty(ref _customerNo, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public bool IsVisible
        {
            get { return _isVisible; }
            set { SetProperty(ref _isVisible, value); }
        }
        public Prospect SelectedProspect
        {
            get { return _selectedProspect; }
            set { SetProperty(ref _selectedProspect, value); }
        }
        public Agent LoggedAgent { get; set; }
        public List<Result> searchCustomers
        {
            get { return _searchedCustomers; }
            set { SetProperty(ref _searchedCustomers, value); }
        }
        public Guid ProspectId
        {
            get { return _prospectId; }
            set { SetProperty(ref _prospectId, value); }
        }
        public ObservableCollection<Result> CustomerSearchResponses
        {
            get { return _CustomerSearchResponse; }
            set { SetProperty(ref _CustomerSearchResponse, value); }
        }
        public List<Result> OriginalCustomerSearchRes
        {
            get { return _oldCustomerSearchRes; }
            set { SetProperty(ref _oldCustomerSearchRes, value); }
        }
        public IEnumerable<List<Result>> Results { get; set; }
        public Result SearchCustomer { get; set; }
        public bool IsCustomerToggled
        {
            get { return _toggled; }
            set { SetProperty(ref _toggled, value); }
        }
        public string[] FileTypes { get; set; }
        public long BookNowClickCount { get; set; }
        public long ToggleClickCount { get; set; }
        public string SearchText
        {
            get { return _searchText; }
            set
            {
                if (_searchText != value)
                {
                    _searchText = value;
                }
                RaisePropertyChanged();
            }
        }
        public double EduSumAssured { get; set; }
        public double SmartRetirementSumAssured { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }
        #endregion
        private DelegateCommand<string> _selectedCustomerCommand;
        private DelegateCommand _bookCustomerCommand;
        private ICommand _searchBarTextChangeCommand;

        public DelegateCommand<string> SelectedCustomerCommand => _selectedCustomerCommand ?? (_selectedCustomerCommand = new DelegateCommand<string>(ExecuteSelectedCustomer));
        public DelegateCommand BookCustomerCommand => _bookCustomerCommand ?? (_bookCustomerCommand = new DelegateCommand(ExecuteBookCustomerCommand));


        public CustomerDataPageViewModel(INavigationService navigationService,
                                           IPageDialogService pageDialogService,
                                           IProspectRepository prospectRepository,
                                           IUserManager userManager,
                                           IUserRepository userRepository, IAgentRepository agentRepository,
                                           IProductPlansRepository productPlanRepository, Logical logical, EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _prospectRepository = prospectRepository;
            _userManager = userManager;
            _userRepository = userRepository;
            _agentRepository = agentRepository;
            _productPlanRepository = productPlanRepository;
            _logical = logical;
            _encryptUtils = encryptUtils;
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;
            IsVisible = true;
            Guid prospectId;
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                    //SelectedProspect = await _prospectRepository.GetById(prospectId);
                }
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }
                if (parameters.ContainsKey("searchCustomers"))
                {
                    Results = parameters.GetValues<List<Result>>("searchCustomers");
                }

                InitializeDefaultValues();

                IsBusy = false;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();

            }
            finally
            {
                InitializeDefaultValues();
                //ExecuteSearchCustomer();
            }
        }

        public int YearCount(int startDate, int endDate)
        {
            return startDate - endDate;
        }

        private void InitializeDefaultValues()
        {
            Result customerResult = new Result();
            ObservableCollection<Result> customerSearchRes = new ObservableCollection<Result>();

            foreach (var item in Results)
            {
                foreach (var res in item)
                {
                    customerResult.CustomerName = res.CustomerName;
                    customerResult.CustomerNumber = res.CustomerNumber;
                    customerResult.DateOfBirth = res.DateOfBirth;
                    customerResult.EmailAddress = res.EmailAddress;
                    customerResult.PhoneNumber = res.PhoneNumber;
                    customerResult.CustomerAddress = res.CustomerAddress;
                    customerResult.IsToggled = res.IsToggled;
                    res.IsToggled = false;
                    customerSearchRes.Add(res);
                }
            }
            CustomerSearchResponses = customerSearchRes;
        }

        private void ExecuteSelectedCustomer(string obj)
        {
            try
            {
                BookNowClickCount = 1;

                if (ToggleClickCount == 0)
                {
                    ToggleClickCount += 1;
                    var customersCount = CustomerSearchResponses.Where(e => e.CustomerNumber == obj);
                    SearchCustomer = new Result();
                    SearchCustomer = CustomerSearchResponses.FirstOrDefault(i => i.IsToggled == true || i.CustomerNumber.Equals(obj));
                }
                else if (ToggleClickCount == 1 && SearchCustomer != null && SearchCustomer.IsToggled == true)
                {
                    return;
                }
                else if (ToggleClickCount == 1 && SearchCustomer.CustomerNumber != null || SearchCustomer.CustomerNumber == null)
                {
                    RemoveToggledOption(obj);

                    var customersCount = CustomerSearchResponses.Where(e => e.CustomerNumber == obj).SingleOrDefault();
                    SearchCustomer = new Result();
                    SearchCustomer = CustomerSearchResponses.FirstOrDefault(i => i.IsToggled == true || i.CustomerNumber.Equals(obj));
                }
            }
            catch (Exception ex)
            {

            }

        }

        public void RemoveToggledOption(string obj)
        {
            IsBusy = true;
            try
            {
                if (CustomerSearchResponses != null)
                {
                    List<Result> workBenchCustomerSearches = new List<Result>();

                    var workBenchCustomers = CustomerSearchResponses;
                    foreach (var item in CustomerSearchResponses)
                    {
                        if (item.CustomerNumber != obj)
                        {
                            item.IsToggled = false;
                        }
                        workBenchCustomerSearches.Add(item);
                    }

                    CustomerSearchResponses.Clear();
                    foreach (var i in workBenchCustomerSearches)
                    {
                        CustomerSearchResponses.Add(i);
                    }

                    ToggleClickCount = 0;
                }
            }
            catch (Exception ex)
            {

            }
            IsBusy = false;
        }

        public ICommand SearchBarTextChangeCommand => _searchBarTextChangeCommand ?? (_searchBarTextChangeCommand = new Command<string>((text) =>
        {
            var CustomerSearchRes = CustomerSearchResponses;

            if (text.Length >= 1)
            {
                var suggestions = CustomerSearchResponses.Where(c => c.CustomerName.ToLower().StartsWith(text.ToLower())
                    || c.CustomerNumber.ToLower().StartsWith(text.ToLower())).ToList();
                CustomerSearchResponses.Clear();
                foreach (var item in suggestions)
                    CustomerSearchResponses.Add(item);

            }
            else if (text.Length <= 1 && text.Length == 0)
            {
                var suggestions = CustomerSearchResponses.Where(c => c.CustomerName.ToLower().StartsWith(text.ToLower())).ToList();
                var newSuggestions = OriginalCustomerSearchRes.Where(e => e.CustomerName.ToLower().StartsWith(text.ToLower())).ToList();

                CustomerSearchResponses.Clear();
                foreach (var item in newSuggestions)
                {
                    if (item != null)
                    {
                        CustomerSearchResponses.Add(item);
                    }
                }
            }
            else
            {
                // WorkBenchCustomerSearchResponses = OriginalWorkBenchCustomerSearchRes;
                foreach (var item in OriginalCustomerSearchRes)
                {
                    CustomerSearchResponses.Add(item);
                }
            }

        }));

        private async void ExecuteBookCustomerCommand()
        {
            IsBusy = true;
            try
            {
                if (SearchCustomer != null && SearchCustomer.IsToggled == true)
                {
                    SelectedProspect.CustomerName = SearchCustomer.CustomerName.Trim();
                    string[] strarr = SearchCustomer.CustomerName.Split(' ');
                    var inx = strarr.Length;

                    var Name = 0;

                    if (inx == 2)
                    {
                        Name = 1;
                    }
                    else if (inx >= 3)
                    {
                        Name = inx -1;
                    }


                    if ((strarr[0] != null))
                    {
                        AimsCustomerUpdateModel aimsCustomerUpdateModel = new AimsCustomerUpdateModel
                        {
                            FirstName = SelectedProspect.FirstName,
                            LastName = SelectedProspect.LastName,
                            EmailAddress = SelectedProspect.Email,
                            PhoneNumber = SelectedProspect.MobileNumber,
                            DateOfBirth = SelectedProspect.Birthdate,
                            
                            NewFirstName = strarr[0],
                            NewLastName = strarr[Name],
                            NewDateOfBirth = Convert.ToDateTime( SearchCustomer.DateOfBirth),
                            NewEmailAddress = SearchCustomer.EmailAddress,
                            NewPhoneNumber = SearchCustomer.PhoneNumber,
                            CustomerNumber = SearchCustomer.CustomerNumber,
                            
                            CustoemerAddress = SearchCustomer.CustomerAddress
                        };

                        bool prospectUpdated = await _logical.UpdateCustomerInformationWithAimsRecord(aimsCustomerUpdateModel);
                    }

                    //SelectedProspect.FirstName = strarr[0];
                    //SelectedProspect.LastName = strarr[Name];
                    SelectedProspect.FullName = SearchCustomer.CustomerName;

                    SelectedProspect.CustomerNumber = SearchCustomer.CustomerNumber;

                    if (SearchCustomer.PhoneNumber != null)
                    {
                        SelectedProspect.MobileNumber = SearchCustomer.PhoneNumber;
                    }
                    if (SearchCustomer.DateOfBirth != null)
                    {
                        SelectedProspect.Birthdate = Convert.ToDateTime(SearchCustomer.DateOfBirth);
                    }
                    if (SearchCustomer.CustomerAddress != null)
                    {
                        SelectedProspect.Address = SearchCustomer.CustomerAddress;
                    }



                    SelectedProspect.CaseCreated = true;

                    var res = await _logical.GetLeadAccountStatus(SelectedProspect.CustomerNumber);
                    if (res.IsLeadAccount && res.IsFullyKyCed)
                    {
                        SelectedProspect.CaseCreated = true;
                        var ProductPlan = await _productPlanRepository.GetProductPlansByProspectId(SelectedProspect.Id);
                        foreach (var item in ProductPlan.ToList())
                        {
                            item.IsNotPolicyId = true;
                            await _productPlanRepository.UpdateAsync(item);
                        }

                        string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                        EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                        int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                        //await _prospectRepository.UpdateAsync(SelectedProspect);

                        //ProspectToUpdate prospectToUpdate = null;
                        //prospectToUpdate = new ProspectToUpdate
                        //{
                        //    CustomerNumber = SelectedProspect.CustomerNumber,
                        //    EmailAddress = SelectedProspect.Email,
                        //    DateOfBirth = SelectedProspect.Birthdate,
                        //    FirstName = SelectedProspect.FirstName,
                        //    LastName = SelectedProspect.LastName,
                        //    PhoneNumber = SelectedProspect.MobileNumber
                        //};

                        // bool updated = await _logical.UpdateProspectDetails(prospectToUpdate);

                        var navigationParameter = new NavigationParameters();
                        navigationParameter.Add("ProspectId", SelectedProspect.Id);
                        navigationParameter.Add("AgentId", LoggedAgent.Id);

                        await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", navigationParameter);

                    }
                    else if (res.IsLeadAccount && !res.IsFullyKyCed)
                    {
                        var Ischoice = await _pageDialogService.DisplayAlertAsync("Customer not fully Ekyced", "Complete customer onboarding Now", "YES", "NO");
                        if (Ischoice)
                        {
                            bool useNIN = await _pageDialogService.DisplayAlertAsync("", "Confirm how to complete onboarding", "Use NIN", "Use Manual");
                            if (useNIN)
                            {

                                var navigationParameters = new NavigationParameters();
                                navigationParameters.Add("ProspectId", SelectedProspect.Id);
                                navigationParameters.Add("AgentId", LoggedAgent.Id);
                                await _navigationService.NavigateAsync("NINOnboardingPage", navigationParameters, null, false);
                            }
                            else
                            {
                                var navigationParameters = new NavigationParameters();
                                navigationParameters.Add("ProspectId", SelectedProspect.Id);
                                navigationParameters.Add("AgentId", LoggedAgent.Id);
                                await _navigationService.NavigateAsync("CustomerOnboardingPage", navigationParameters, null, false);

                            }


                        }
                        else
                        {
                            SelectedProspect.IsEkycStatus = true;
                            string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                            EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                            int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                            //await _prospectRepository.UpdateAsync(SelectedProspect);

                            var navigationParameter = new NavigationParameters();
                            navigationParameter.Add("ProspectId", SelectedProspect.Id);
                            navigationParameter.Add("AgentId", LoggedAgent.Id);

                            await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", navigationParameter);


                        }
                    }
                    else if (!res.IsLeadAccount && !res.IsFullyKyCed)
                    {
                        SelectedProspect.IsEkycStatus = true;
                        await _prospectRepository.UpdateAsync(EncryptedProspect);
                        var navigationParameter = new NavigationParameters();
                        navigationParameter.Add("ProspectId", SelectedProspect.Id);
                        navigationParameter.Add("AgentId", LoggedAgent.Id);

                        await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", navigationParameter);

                    }


                }

                else
                {
                    await _pageDialogService.DisplayAlertAsync("Please select a customer", "", "Ok");
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();

            }
            IsBusy = false;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }
    }
}
