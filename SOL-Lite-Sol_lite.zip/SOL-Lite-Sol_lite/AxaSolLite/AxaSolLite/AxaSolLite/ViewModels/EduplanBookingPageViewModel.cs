﻿using AxaSolLite.Extensions;
using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Plugin.FilePicker;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AxaSolLite.ViewModels
{
	public class EduplanBookingPageViewModel : BindableBase, INavigationAware
    {
        private const string AccountNumberRegex = @"^[0-9]+$";

        private readonly INavigationService _navigationService;
        private readonly IValidationService _validationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly ICalculatorService _calculatorService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IProductPlansRepository _productPlanRepository;
        private readonly IMediaManager _deviceManager;
        private readonly IAgentRepository _agentRepository;
        private readonly IBookOnlineRepository _bookOnlineRepository;
        private readonly IBranchesRepository _branchesRepository;
        private readonly EncryptUtils _encryptUtils;

        #region Fields
        private bool _isBusy;       
        private bool _isVisible;
        private string _title;
        private string _agentName;
        private string _agentCode;
        private string _sbu;
        private string _customerNo;
        private string _intiationDate;
        private string _emailAddress;
        private string _policyClass;
        private int _policyTerm;
        private decimal _sumAssured;
        private int _ageBeginPolicy;
        private int _ageEndPolicy;
        private decimal _maxMaturityValue;
        private decimal _minMaturityValue;
        private string _paymentFrequency;
        private string _paymentFrequencyLabel;
        private decimal _annualPremium;
        private decimal _totalPremium;
        private decimal _contribution;
        private string _policyStartDate;
        private string _policyEndDate;
        private string _paymentDate;
        private decimal _lifeCoverValue;
        private List<int> _policyDuration;
        private int _selectedPolicyDuration;
        private string _sbuName;
        private string _selectedDSA;
        private List<string> _myDSAs;
        private bool _isExternalAgent;
        private List<DSAUnderPSS> _dSAs;
        private DSAUnderPSS _dSA;
        private ImageSource _signaturePicture;
        private byte[] _newSignaturePicture;
        private Prospect _prospect;
        private Guid _prospectId;
        private Guid _productPlanId;
        private ProductPlan _productPlan;
        private UploadFile _uploadFile;
        private string _fileLabel;
        private string _fileLabelPath;
        private string[] _fileTypes;
        private string _fileSize;
        private Image _fileImagePreview;
        private string _text;
        private List<string> _fileNameList;
        private Dictionary<string, object> _fileByteList;
        private string _contents;
        private List<string> _branchList;
        private string _selectedbranch;
        private int _branchCode;
        private DelegateCommand _changePaymentCommand;
        private DelegateCommand _fileDeleteCommand;
        private DelegateCommand _pickfileCommand;
        private DelegateCommand _fetchCommand;
        private DelegateCommand _resetCommand;
        private DelegateCommand _proceedCommand;
        private const string ResourceNamespace = "AxaSolLite.Resources.Assets.";
        Logical logical = null;
        ArrayToImageConverter converter = new ArrayToImageConverter();
        private string _accountNumber;
        private List<string> _bankList = new List<string>();
        private string _bankName;
        #endregion

        public string BankName
        {
            get { return _bankName; }
            set { SetProperty(ref _bankName, value); }
        }
        public List<string> BankList
        {
            get { return _bankList; }
            set { SetProperty(ref _bankList, value); }
        }
        public string AccountNumber
        {
            get { return _accountNumber; }
            set { SetProperty(ref _accountNumber, value); }
        }

        #region Properties
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }

        public string AgentName
        {
            get { return _agentName; }
            set { SetProperty(ref _agentName, value); }
        }

        public string AgentCode
        {
            get { return _agentCode; }
            set { SetProperty(ref _agentCode, value); }
        }

        public string Sbu
        {
            get { return _sbu; }
            set { SetProperty(ref _sbu, value); }
        }

        public string CustomerNo
        {
            get { return _customerNo; }
            set { SetProperty(ref _customerNo, value); }
        }
        public List<string> BranchList
        {
            get { return _branchList; }
            set { SetProperty(ref _branchList, value); }
        }
        public string SelectedBranch
        {
            get { return _selectedbranch; }
            set { SetProperty(ref _selectedbranch, value); }
        }
        public int BranchCode
        {
            get { return _branchCode; }
            set { SetProperty(ref _branchCode, value); }
        }
        public string IntiationDate
        {
            get { return _intiationDate; }
            set { SetProperty(ref _intiationDate, value); }
        }

        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }

        public string PolicyClass
        {
            get { return _policyClass; }
            set { SetProperty(ref _policyClass, value); }
        }
        public int PolicyTerm
        {
            get { return _policyTerm; }
            set { SetProperty(ref _policyTerm, value); }
        }

        public decimal SumAssured
        {
            get { return _sumAssured; }
            set { SetProperty(ref _sumAssured, value); }
        }

        public int AgeBeginPolicy
        {
            get { return _ageBeginPolicy; }
            set { SetProperty(ref _ageBeginPolicy, value); }
        }

        public int AgeEndPolicy
        {
            get { return _ageEndPolicy; }
            set { SetProperty(ref _ageEndPolicy, value); }
        }

        public decimal MaxMaturityValue
        {
            get { return _maxMaturityValue; }
            set { SetProperty(ref _maxMaturityValue, value); }
        }

        public decimal MinMaturityValue
        {
            get { return _minMaturityValue; }
            set { SetProperty(ref _minMaturityValue, value); }
        }

        public string PaymentFrequency
        {
            get { return _paymentFrequency; }
            set { SetProperty(ref _paymentFrequency, value); }
        }

        public string PaymentFrequencyLabel
        {
            get { return _paymentFrequencyLabel; }
            set { SetProperty(ref _paymentFrequencyLabel, value); }
        }

        public decimal AnnualPremium
        {
            get { return _annualPremium; }
            set { SetProperty(ref _annualPremium, value); }
        }

        public decimal TotalPremium
        {
            get { return _totalPremium; }
            set { SetProperty(ref _totalPremium, value); }
        }

        public decimal Contribution
        {
            get { return _contribution; }
            set { SetProperty(ref _contribution, value); }
        }

        public string PolicyStartDate
        {
            get { return _policyStartDate; }
            set { SetProperty(ref _policyStartDate, value); }
        }

        public string PolicyEndDate
        {
            get { return _policyEndDate; }
            set { SetProperty(ref _policyEndDate, value); }
        }

        public string PaymentDate
        {
            get { return _paymentDate; }
            set { SetProperty(ref _paymentDate, value); }
        }
        public decimal LifeCoverValue
        {
            get { return _lifeCoverValue; }
            set { SetProperty(ref _lifeCoverValue, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }

        public bool IsVisible
        {
            get { return _isVisible; }
            set { SetProperty(ref _isVisible, value); }
        }
        public ImageSource SignaturePicture
        {
            get { return _signaturePicture; }
            set { SetProperty(ref _signaturePicture, value); }
        }

        public byte[] NewSignaturePicture
        {
            get { return _newSignaturePicture; }
            set { SetProperty(ref _newSignaturePicture, value); }
        }
        public List<int> PolicyDuration
        {
            get { return _policyDuration; }
            set { SetProperty(ref _policyDuration, value); }
        }
        public int SelectedPolicyDuration
        {
            get { return _selectedPolicyDuration; }
            set { SetProperty(ref _selectedPolicyDuration, value); }
        }
        public List<string> FileNameList
        {
            get { return _fileNameList; }
            set { SetProperty(ref _fileNameList, value); }
        }
        public Dictionary<string, object> FileByteList
        {
            get { return _fileByteList; }
            set { SetProperty(ref _fileByteList, value); }
        }
        public string Contents
        {
            get { return _contents; }
            set { SetProperty(ref _contents, value); }
        }
        public string FileLabel
        {
            get { return _fileLabel; }
            set { SetProperty(ref _fileLabel, value); }
        }
        public string FileLabelPath
        {
            get { return _fileLabelPath; }
            set { SetProperty(ref _fileLabelPath, value); }
        }
        public string FileSize
        {
            get { return _fileSize; }
            set { SetProperty(ref _fileSize, value); }
        }
        public string[] FileTypes
        {
            get { return _fileTypes; }
            set { SetProperty(ref _fileTypes, value); }
        }
        public Image FileImagePreview
        {
            get { return _fileImagePreview; }
            set { SetProperty(ref _fileImagePreview, value); }
        }

        public Prospect Prospect
        {
            get { return _prospect = _prospect ?? (_prospect = new Prospect()); }
            set { SetProperty(ref _prospect, value); }
        }
        public ProductPlan ProductPlan
        {
            get { return _productPlan = _productPlan ?? (_productPlan = new ProductPlan()); }
            set { SetProperty(ref _productPlan, value); }
        }
        public UploadFile UploadFile
        {
            get { return _uploadFile = _uploadFile ?? (_uploadFile = new UploadFile()); }
            set { SetProperty(ref _uploadFile, value); }
        }
        public DSAUnderPSS DSA
        {
            get { return _dSA; }
            set { SetProperty(ref _dSA, value); }
        }
        public List<DSAUnderPSS> DSAs
        {
            get { return _dSAs; }
            set { SetProperty(ref _dSAs, value); }
        }
        public bool IsExternalAgent
        {
            get { return _isExternalAgent; }
            set { SetProperty(ref _isExternalAgent, value); }
        }
        public List<string> MyDSAs
        {
            get { return _myDSAs; }
            set { SetProperty(ref _myDSAs, value); }
        }
        public string SelectedDSA
        {
            get { return _selectedDSA; }
            set { SetProperty(ref _selectedDSA, value); }
        }
        public string SbuName
        {
            get { return _sbuName; }
            set { SetProperty(ref _sbuName, value); }
        }
        public Agent LoggedAgent { get; set; }
        public BookOnline BookOnline { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }
        #endregion

        #region Commands
        public DelegateCommand ChangePaymentCommand => _changePaymentCommand ?? (_changePaymentCommand = new DelegateCommand(ExecuteChangePaymentCommand));
        public DelegateCommand PickFileCommand => _pickfileCommand ?? (_pickfileCommand = new DelegateCommand(ExecutePickFileCommand));
        public DelegateCommand FileDeleteCommand => _fileDeleteCommand ?? (_fileDeleteCommand = new DelegateCommand(ExecuteFileDeleteCommand));
        public DelegateCommand FetchCommand => _fetchCommand ?? (_fetchCommand = new DelegateCommand(ExecuteFetchCommand));
        public DelegateCommand ResetCommand => _resetCommand ?? (_resetCommand = new DelegateCommand(ExecuteResetCommand));
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProceed));
        #endregion

        public EduplanBookingPageViewModel(INavigationService navigationService,
            IValidationService validationService, IPageDialogService pageDialogService,
            ICalculatorService calculatorService,
            IProspectRepository prospectRepository,
            IMediaManager mediaManager,
             IProductPlansRepository productPlanRepository,
             IBookOnlineRepository bookOnlineRepository,
             IAgentRepository agentRepository,
             IBranchesRepository branchesRepository, EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _validationService = validationService;
            _pageDialogService = pageDialogService;
            _calculatorService = calculatorService;
            _prospectRepository = prospectRepository;
            _deviceManager = mediaManager;
            _branchesRepository = branchesRepository;
            _bookOnlineRepository = bookOnlineRepository;
            _productPlanRepository = productPlanRepository;
            _agentRepository = agentRepository;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
           
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsVisible = false;
            IsBusy = false;
            IsExternalAgent = true;
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    //Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    //Prospect = await _prospectRepository.GetById(_prospectId);

                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    Prospect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                    CustomerNo = Prospect.CustomerNumber;
                   
                }
                if (parameters.ContainsKey("ProductPlanId"))
                {
                    Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId);
                    ProductPlan = await _productPlanRepository.GetProductPlanByProductPlanId(_productPlanId);
                    PolicyClass = ProductPlan.PlanCategory;

                }
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                        AgentName = LoggedAgent.FullName;
                        if (LoggedAgent.IsAdvisor)
                        {
                            AgentCode = LoggedAgent.SubAgentCode;
                        }
                        else
                        {
                            AgentCode = LoggedAgent.AgentCode;
                        }
                        
                        EmailAddress = LoggedAgent.EmailAddress;
                        Sbu = LoggedAgent.SBU;

                    }
                }
                InitializeDefaultValues();

            }
            catch (Exception ex)
            {
                

            }

        }

        private async void InitializeDefaultValues()
        {
            logical = new Logical();
            List<BankDTO> MyBanks = await logical.GetBankList();
            foreach (BankDTO item in MyBanks)
            {
                string bankName = string.Empty;
                bankName = item.NameField;
                BankList.Add(bankName);
            }
            BankList = BankList.Where(x => x != "-- Select One--").ToList();

            IntiationDate = DateTime.Now.ToString("MMMM dd yyyy");
            PolicyStartDate = DateTime.Now.ToString("MM/dd/yyyy");
            PolicyEndDate = DateTime.Now.AddYears(SelectedPolicyDuration).ToString("MM/dd/yyyy");
            AgeBeginPolicy = _calculatorService.GetInsuranceAge(Prospect.Birthdate);
            AgeEndPolicy = AgeBeginPolicy + SelectedPolicyDuration;
            PaymentFrequency = "Annual";
            PaymentDate = DateTime.Now.ToString("MM/dd/yyyy");
            SbuName = LoggedAgent.SbuName;
            var Branches = await _branchesRepository.GetBranches();
            BranchList = Branches.Select(x => x.Branch).ToList();
            BranchList = BranchList.Where(x => x != "BRANCHES").ToList();


            List<int> Numbers = new List<int>();
            for (int i = 5; i < 31; i++)
            {
                Numbers.Add(i);
            }
            PolicyDuration = Numbers;
            var convertedImage = converter.Convert(NewSignaturePicture, null, null, null) as ImageSource;
            SignaturePicture =  "add_photo.png";
            if (LoggedAgent.IsAdvisor || LoggedAgent.IsTeamManager)
            {
                IsExternalAgent = true;
            }
            else
            {
                IsExternalAgent = false;



                DSAs = await logical.GetDSAsUnderPss(LoggedAgent.AgentCode);



                if (DSAs.Count > 0 && DSAs.First().PSSCode != null)
                {
                    MyDSAs = DSAs.Select(x => x.FullName).ToList();
                }
            }


        }

        private void ExecuteChangePaymentCommand()
        {
            try
            {
                if (PaymentFrequency.Contains("Annual"))
                {
                    Contribution = 0;
                    AnnualPremium = Contribution;
                    
                    LifeCoverValue = AnnualPremium * 5;
                }
                else if (PaymentFrequency.Contains("Monthly"))
                {

                    Contribution = 0;
                    AnnualPremium = Contribution * 12;

                    
                    LifeCoverValue = AnnualPremium * 5;
                }
                else if (PaymentFrequency.Contains("Quarterly"))
                {

                    Contribution = 0;
                    AnnualPremium = Contribution * 4;

                    
                    LifeCoverValue = AnnualPremium * 5;
                }
                else if (PaymentFrequency.Contains("Half yearly"))
                {

                    Contribution = 0;
                    AnnualPremium = Contribution * 2;
                    
                    LifeCoverValue = AnnualPremium * 5;
                }
                PaymentFrequencyLabel = PaymentFrequency + "  " + "Premium";
                TotalPremium = AnnualPremium * SelectedPolicyDuration;
                


            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteFetchCommand()
        {
            IsBusy = true;
            IsVisible = false;
            try
            {
                if (Contribution == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Input contribution", "Ok");
                    IsBusy = false;

                }
                else if (SelectedPolicyDuration == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Please select policy duration", "Ok");
                    IsBusy = false;
                }
                else
                {
                    logical = new Logical();
                    getMaxBenefitRequest getMaxBenefit = new getMaxBenefitRequest();
                    EPPprojectionsheetRequest req = new EPPprojectionsheetRequest();
                    getMaxBenefit.CustomerAge = AgeBeginPolicy;
                    getMaxBenefit.PolTerm = SelectedPolicyDuration;
                    getMaxBenefit.SumAssured = Convert.ToDouble(LifeCoverValue);
                    getMaxBenefit.annualPremium = Convert.ToDouble(AnnualPremium);
                    getMaxBenefit.invOption = 1;

                    var getMaxBenefitResponse = await logical.GetBenefitResponseAsync(getMaxBenefit);



                    if (getMaxBenefitResponse.MaturityAcctBalanceHigherField != 0.0 || getMaxBenefitResponse.MaturityAcctBalanceLowerField != 0.0)
                    {
                        IsBusy = false;
                        IsVisible = true;
                        MaxMaturityValue = getMaxBenefitResponse.MaturityAcctBalanceHigherField;
                        MinMaturityValue = getMaxBenefitResponse.MaturityAcctBalanceLowerField;
                    }
                    else
                    {
                        {
                            IsBusy = false;
                            IsVisible = false;
                            await _pageDialogService.DisplayAlertAsync("Error", "Error fetching booking details,Please try again", "Ok");
                        }
                    }

                }
                PolicyEndDate = DateTime.Now.AddYears(SelectedPolicyDuration).ToString("MM/dd/yyyy");
                AgeEndPolicy = AgeBeginPolicy + SelectedPolicyDuration;
                TotalPremium = AnnualPremium * SelectedPolicyDuration;

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                IsBusy = false;
                await _pageDialogService.DisplayAlertAsync("Error", "Error fetching booking details,Please try again", "Ok");
            }

        }

        private  void ExecuteResetCommand()
        {
            IsBusy = false;
            IsVisible = false;
            Contribution = 0;
            LifeCoverValue = 0;
            SelectedPolicyDuration = 0;
        }

        private async void ExecutePickFileCommand()
        {
            try
            {
                
                bool choice = await _pageDialogService.DisplayAlertAsync("Confirm", "Please select how you wish to upload a document", "Gallery", "Camera");
                if (choice)
                {
                    if (Device.RuntimePlatform == Device.Android)
                    {
                        FileTypes = new string[] { "image/png", "image/jpeg", "application/pdf" };
                    }

                    await PickedFiles(FileTypes);

                    if (FileLabel != null || Contents != null)
                    {
                        if (Contents.Length > 2097152)
                        {
                            FileLabel = null;
                            Contents = null;
                            await _pageDialogService.DisplayAlertAsync("Error", "File size too large. Please upload a document not larger than 2MB in size", "Cancel");
                        }
                        else
                            
                            await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");
                    }

                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Unsuccessful", "Document failed to upload. Please try again.", "Ok");
                    }
                }
                else
                {
                    if (_deviceManager.CameraAvailable)
                    {
                        var newPhoto = await _deviceManager.TakePhotoAsync();

                        if (newPhoto != null)
                        {

                            FileLabel = "Photo For Drivers License";
                            NewSignaturePicture = newPhoto.FileContent;
                           
                            UploadFile motorFile = new UploadFile
                            {
                                FileLabel = FileLabel,

                                Content = newPhoto.FileContent
                            };

                            await _pageDialogService.DisplayAlertAsync("File Uploaded", "Photo successfully captured", "Okay");

                        }
                        else
                        {

                            await _pageDialogService.DisplayAlertAsync("Oooops!!!", "File too large, recapture the document or upload another document", "Cancel");
                        }
                    }

                }
                var convertedImage = converter.Convert(NewSignaturePicture, null, null, null) as ImageSource;

                SignaturePicture = convertedImage ?? ImageSource.FromResource(ResourceNamespace + "add_photo.png");
            }
            catch (Exception ex)

            {
                ex.Message.ToString();
            }
        }

        public async Task PickedFiles(string[] fileTypes)
        {
            try
            {
                
                var pickedFile = await CrossFilePicker.Current.PickFile(fileTypes);

                if (pickedFile != null)
                {
                    FileLabel = pickedFile.FileName;
                    FileLabelPath = pickedFile.FilePath;
                    NewSignaturePicture = pickedFile.DataArray;

                    if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase))
                    {
                        Contents = System.Text.Encoding.UTF8.GetString(pickedFile.DataArray, 0, pickedFile.DataArray.Length);
                    }

                    FileSize = FileSizeFormatter.FormatSize(Contents.Length);
                    UploadFile motorFile = new UploadFile
                    {
                        FileLabel = FileLabel,
                        DocumentCategory = FileLabelPath,
                        Content = pickedFile.DataArray
                    };

                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public static class FileSizeFormatter
        {
            static readonly string[] suffixes = { "Bytes", "KB", "MB", "GB", "TB", "PB" };

            public static string FormatSize(long bytes)
            {
                int counter = 0;
                decimal number = (decimal)bytes;
                while (Math.Round(number / 1024) >= 1)
                {
                    number = number / 1024;
                    counter++;
                }
                return string.Format("{0:n1}{1}", number, suffixes[counter]);
            }
        }

        private async void ExecuteFileDeleteCommand()
        {
            try
            {
                if (FileLabel != null || Contents != null)
                {
                    FileLabel = null;
                    Contents = null;
                    SignaturePicture = null;
                    await _pageDialogService.DisplayAlertAsync("Done", "Uploaded file deleted successfully", "Ok");
                }
                else
                    await _pageDialogService.DisplayAlertAsync("Notice", "There is no document to be deleted", "Ok");
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteProceed()
        {
            IsBusy = true;
            try
            {
           
                if (Contribution == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please Enter a Contribution", "Ok");
                }
                else if (SelectedPolicyDuration == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a policy duration", "Ok");
                }
                else if (string.IsNullOrEmpty(SelectedBranch))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a branch", "Ok");
                }
                else if (string.IsNullOrEmpty(BankName))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a bank", "Ok");
                }
                else if (string.IsNullOrEmpty(AccountNumber))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Kindly enter bank account number", "Ok");
                }
                else if (AccountNumber.Length != 10)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Account number must be 10 digits", "Ok");
                }
                else if (!Regex.IsMatch(AccountNumber, AccountNumberRegex))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Account number must be in a correct format", "Ok");
                }
                else
                {
                    if (!(string.IsNullOrEmpty(SelectedDSA)))
                    {
                        DSA = DSAs.Where(x => x.FullName == SelectedDSA).FirstOrDefault();                      
                    }
                    if (!(string.IsNullOrEmpty(SelectedBranch)))
                    {
                        var v = await _branchesRepository.GetBranchCodeByBranch(SelectedBranch);
                        BranchCode = v.BranchCode;
                    }

                    BookOnline = new BookOnline
                    {
                        Id = Guid.NewGuid(),
                        ProductPlanId = ProductPlan.Id,
                        AgentName = LoggedAgent.FullName,
                        AgeBeginPolicy = Convert.ToInt32(AgeBeginPolicy),
                        AgeEndPolicy = Convert.ToInt32(AgeEndPolicy),
                        AgentCode = LoggedAgent.AgentCode,
                        AnnualPremium = Convert.ToDecimal(AnnualPremium),
                        Assurer = LoggedAgent.FullName,
                        CustomerNo = Prospect.CustomerNumber,
                        DateCreated = DateTime.Now,
                        EmailAddress = Prospect.Email,
                        IntiationDate = DateTime.Now.ToString("MM/dd/yyyy"),
                        SumAssured = Convert.ToDecimal(LifeCoverValue),
                        TransactionType = "New",
                        SBU = LoggedAgent.SBU,
                        DSA = SelectedDSA,
                        DSACode = DSA?.AgentCode,
                        TotalPremium = Convert.ToDecimal(TotalPremium),
                        Amount = Contribution,
                        PolicyTerm = SelectedPolicyDuration,
                        LifeCoverValue = Convert.ToDecimal(LifeCoverValue),
                        PolicyStartDate = PolicyStartDate,
                        PolicyEndDate = PolicyEndDate,
                        PaymentFrequency = PaymentFrequency,
                        Contribution = Contribution,
                        PolicyClass = PolicyClass,
                        MaxMaturityValue =Convert.ToDouble( MaxMaturityValue),
                        MinMaturityValue =Convert.ToDouble( MinMaturityValue),                      
                        BranchCode = BranchCode,
                        BankAccountNumber = AccountNumber,
                        BankName = BankName
                    };
                    logical = new Logical();
                    getMaxBenefitRequest getMaxBenefit = new getMaxBenefitRequest();
                    EPPprojectionsheetRequest req = new EPPprojectionsheetRequest();
                    getMaxBenefit.CustomerAge = AgeBeginPolicy;
                    getMaxBenefit.PolTerm = SelectedPolicyDuration;
                    getMaxBenefit.SumAssured = Convert.ToDouble(LifeCoverValue);
                    getMaxBenefit.annualPremium = Convert.ToDouble(AnnualPremium);
                    getMaxBenefit.invOption = 1;

                    var getMaxBenefitResponse = await logical.GetBenefitResponseAsync(getMaxBenefit);

                    #region eppprojectionsheet

                    ProjectionsField[] res = new ProjectionsField[28];

                    res = getMaxBenefitResponse.ProjectionsField;

                    #region variable declaration
                    req.Year_1 = string.Empty;
                    req.Contribution_1 = string.Empty;
                    req.Lower_Sum_Assured_1 = string.Empty;
                    req.Lower_Policy_Value_1 = string.Empty;
                    req.Lower_Surrender_Value_1 = string.Empty;
                    req.Higher_Sum_Assured_1 = string.Empty;
                    req.Higher_Policy_Value_1 = string.Empty;
                    req.Higher_Surrender_Value_1 = string.Empty;

                    req.Year_2 = string.Empty;
                    req.Contribution_2 = string.Empty;
                    req.Lower_Sum_Assured_2 = string.Empty;
                    req.Lower_Policy_Value_2 = string.Empty;
                    req.Lower_Surrender_Value_2 = string.Empty;
                    req.Higher_Sum_Assured_2 = string.Empty;
                    req.Higher_Policy_Value_2 = string.Empty;
                    req.Higher_Surrender_Value_2 = string.Empty;

                    req.Year_3 = string.Empty;
                    req.Contribution_3 = string.Empty;
                    req.Lower_Sum_Assured_3 = string.Empty;
                    req.Lower_Policy_Value_3 = string.Empty;
                    req.Lower_Surrender_Value_3 = string.Empty;
                    req.Higher_Sum_Assured_3 = string.Empty;
                    req.Higher_Policy_Value_3 = string.Empty;
                    req.Higher_Surrender_Value_3 = string.Empty;


                    req.Year_4 = string.Empty;
                    req.Contribution_4 = string.Empty;
                    req.Lower_Sum_Assured_4 = string.Empty;
                    req.Lower_Policy_Value_4 = string.Empty;
                    req.Lower_Surrender_Value_4 = string.Empty;
                    req.Higher_Sum_Assured_4 = string.Empty;
                    req.Higher_Policy_Value_4 = string.Empty;
                    req.Higher_Surrender_Value_4 = string.Empty;

                    req.Year_5 = string.Empty;
                    req.Contribution_5 = string.Empty;
                    req.Lower_Sum_Assured_5 = string.Empty;
                    req.Lower_Policy_Value_5 = string.Empty;
                    req.Lower_Surrender_Value_5 = string.Empty;
                    req.Higher_Sum_Assured_5 = string.Empty;
                    req.Higher_Policy_Value_5 = string.Empty;
                    req.Higher_Surrender_Value_5 = string.Empty;

                    req.Year_6 = string.Empty;
                    req.Contribution_6 = string.Empty;
                    req.Lower_Sum_Assured_6 = string.Empty;
                    req.Lower_Policy_Value_6 = string.Empty;
                    req.Lower_Surrender_Value_6 = string.Empty;
                    req.Higher_Sum_Assured_6 = string.Empty;
                    req.Higher_Policy_Value_6 = string.Empty;
                    req.Higher_Surrender_Value_6 = string.Empty;

                    req.Year_7 = string.Empty;
                    req.Contribution_7 = string.Empty;
                    req.Lower_Sum_Assured_7 = string.Empty;
                    req.Lower_Policy_Value_7 = string.Empty;
                    req.Lower_Surrender_Value_7 = string.Empty;
                    req.Higher_Sum_Assured_7 = string.Empty;
                    req.Higher_Policy_Value_7 = string.Empty;
                    req.Higher_Surrender_Value_7 = string.Empty;

                    req.Year_8 = string.Empty;
                    req.Contribution_8 = string.Empty;
                    req.Lower_Sum_Assured_8 = string.Empty;
                    req.Lower_Policy_Value_8 = string.Empty;
                    req.Lower_Surrender_Value_8 = string.Empty;
                    req.Higher_Sum_Assured_8 = string.Empty;
                    req.Higher_Policy_Value_8 = string.Empty;
                    req.Higher_Surrender_Value_8 = string.Empty;

                    req.Year_9 = string.Empty;
                    req.Contribution_9 = string.Empty;
                    req.Lower_Sum_Assured_9 = string.Empty;
                    req.Lower_Policy_Value_9 = string.Empty;
                    req.Lower_Surrender_Value_9 = string.Empty;
                    req.Higher_Sum_Assured_9 = string.Empty;
                    req.Higher_Policy_Value_9 = string.Empty;
                    req.Higher_Surrender_Value_9 = string.Empty;

                    req.Year_10 = string.Empty;
                    req.Contribution_10 = string.Empty;
                    req.Lower_Sum_Assured_10 = string.Empty;
                    req.Lower_Policy_Value_10 = string.Empty;
                    req.Lower_Surrender_Value_10 = string.Empty;
                    req.Higher_Sum_Assured_10 = string.Empty;
                    req.Higher_Policy_Value_10 = string.Empty;
                    req.Higher_Surrender_Value_10 = string.Empty;

                    req.Year_11 = string.Empty;
                    req.Contribution_11 = string.Empty;
                    req.Lower_Sum_Assured_11 = string.Empty;
                    req.Lower_Policy_Value_11 = string.Empty;
                    req.Lower_Surrender_Value_11 = string.Empty;
                    req.Higher_Sum_Assured_11 = string.Empty;
                    req.Higher_Policy_Value_11 = string.Empty;
                    req.Higher_Surrender_Value_11 = string.Empty;

                    req.Year_12 = string.Empty;
                    req.Contribution_12 = string.Empty;
                    req.Lower_Sum_Assured_12 = string.Empty;
                    req.Lower_Policy_Value_12 = string.Empty;
                    req.Lower_Surrender_Value_12 = string.Empty;
                    req.Higher_Sum_Assured_12 = string.Empty;
                    req.Higher_Policy_Value_12 = string.Empty;
                    req.Higher_Surrender_Value_12 = string.Empty;

                    req.Year_13 = string.Empty;
                    req.Contribution_13 = string.Empty;
                    req.Lower_Sum_Assured_13 = string.Empty;
                    req.Lower_Policy_Value_13 = string.Empty;
                    req.Lower_Surrender_Value_13 = string.Empty;
                    req.Higher_Sum_Assured_13 = string.Empty;
                    req.Higher_Policy_Value_13 = string.Empty;
                    req.Higher_Surrender_Value_13 = string.Empty;

                    req.Year_14 = string.Empty;
                    req.Contribution_14 = string.Empty;
                    req.Lower_Sum_Assured_14 = string.Empty;
                    req.Lower_Policy_Value_14 = string.Empty;
                    req.Lower_Surrender_Value_14 = string.Empty;
                    req.Higher_Sum_Assured_14 = string.Empty;
                    req.Higher_Policy_Value_14 = string.Empty;
                    req.Higher_Surrender_Value_14 = string.Empty;

                    req.Year_15 = string.Empty;
                    req.Contribution_15 = string.Empty;
                    req.Lower_Sum_Assured_15 = string.Empty;
                    req.Lower_Policy_Value_15 = string.Empty;
                    req.Lower_Surrender_Value_15 = string.Empty;
                    req.Higher_Sum_Assured_15 = string.Empty;
                    req.Higher_Policy_Value_15 = string.Empty;
                    req.Higher_Surrender_Value_15 = string.Empty;

                    req.Year_16 = string.Empty;
                    req.Contribution_16 = string.Empty;
                    req.Lower_Sum_Assured_16 = string.Empty;
                    req.Lower_Policy_Value_16 = string.Empty;
                    req.Lower_Surrender_Value_16 = string.Empty;
                    req.Higher_Sum_Assured_16 = string.Empty;
                    req.Higher_Policy_Value_16 = string.Empty;
                    req.Higher_Surrender_Value_16 = string.Empty;

                    req.Year_17 = string.Empty;
                    req.Contribution_17 = string.Empty;
                    req.Lower_Sum_Assured_17 = string.Empty;
                    req.Lower_Policy_Value_17 = string.Empty;
                    req.Lower_Surrender_Value_17 = string.Empty;
                    req.Higher_Sum_Assured_17 = string.Empty;
                    req.Higher_Policy_Value_17 = string.Empty;
                    req.Higher_Surrender_Value_17 = string.Empty;

                    req.Year_18 = string.Empty;
                    req.Contribution_18 = string.Empty;
                    req.Lower_Sum_Assured_18 = string.Empty;
                    req.Lower_Policy_Value_18 = string.Empty;
                    req.Lower_Surrender_Value_18 = string.Empty;
                    req.Higher_Sum_Assured_18 = string.Empty;
                    req.Higher_Policy_Value_18 = string.Empty;
                    req.Higher_Surrender_Value_18 = string.Empty;

                    req.Year_19 = string.Empty;
                    req.Contribution_19 = string.Empty;
                    req.Lower_Sum_Assured_19 = string.Empty;
                    req.Lower_Policy_Value_19 = string.Empty;
                    req.Lower_Surrender_Value_19 = string.Empty;
                    req.Higher_Sum_Assured_19 = string.Empty;
                    req.Higher_Policy_Value_19 = string.Empty;
                    req.Higher_Surrender_Value_19 = string.Empty;

                    req.Year_20 = string.Empty;
                    req.Contribution_20 = string.Empty;
                    req.Lower_Sum_Assured_20 = string.Empty;
                    req.Lower_Policy_Value_20 = string.Empty;
                    req.Lower_Surrender_Value_20 = string.Empty;
                    req.Higher_Sum_Assured_20 = string.Empty;
                    req.Higher_Policy_Value_20 = string.Empty;
                    req.Higher_Surrender_Value_20 = string.Empty;

                    req.Year_21 = string.Empty;
                    req.Contribution_21 = string.Empty;
                    req.Lower_Sum_Assured_21 = string.Empty;
                    req.Lower_Policy_Value_21 = string.Empty;
                    req.Lower_Surrender_Value_21 = string.Empty;
                    req.Higher_Sum_Assured_21 = string.Empty;
                    req.Higher_Policy_Value_21 = string.Empty;
                    req.Higher_Surrender_Value_21 = string.Empty;

                    req.Year_22 = string.Empty;
                    req.Contribution_22 = string.Empty;
                    req.Lower_Sum_Assured_22 = string.Empty;
                    req.Lower_Policy_Value_22 = string.Empty;
                    req.Lower_Surrender_Value_22 = string.Empty;
                    req.Higher_Sum_Assured_22 = string.Empty;
                    req.Higher_Policy_Value_22 = string.Empty;
                    req.Higher_Surrender_Value_22 = string.Empty;

                    req.Year_23 = string.Empty;
                    req.Contribution_23 = string.Empty;
                    req.Lower_Sum_Assured_23 = string.Empty;
                    req.Lower_Policy_Value_23 = string.Empty;
                    req.Lower_Surrender_Value_23 = string.Empty;
                    req.Higher_Sum_Assured_23 = string.Empty;
                    req.Higher_Policy_Value_23 = string.Empty;
                    req.Higher_Surrender_Value_23 = string.Empty;

                    req.Year_24 = string.Empty;
                    req.Contribution_24 = string.Empty;
                    req.Lower_Sum_Assured_24 = string.Empty;
                    req.Lower_Policy_Value_24 = string.Empty;
                    req.Lower_Surrender_Value_24 = string.Empty;
                    req.Higher_Sum_Assured_24 = string.Empty;
                    req.Higher_Policy_Value_24 = string.Empty;
                    req.Higher_Surrender_Value_24 = string.Empty;

                    req.Year_25 = string.Empty;
                    req.Contribution_25 = string.Empty;
                    req.Lower_Sum_Assured_25 = string.Empty;
                    req.Lower_Policy_Value_25 = string.Empty;
                    req.Lower_Surrender_Value_25 = string.Empty;
                    req.Higher_Sum_Assured_25 = string.Empty;
                    req.Higher_Policy_Value_25 = string.Empty;
                    req.Higher_Surrender_Value_25 = string.Empty;

                    req.Year_26 = string.Empty;
                    req.Contribution_26 = string.Empty;
                    req.Lower_Sum_Assured_26 = string.Empty;
                    req.Lower_Policy_Value_26 = string.Empty;
                    req.Lower_Surrender_Value_26 = string.Empty;
                    req.Higher_Sum_Assured_26 = string.Empty;
                    req.Higher_Policy_Value_26 = string.Empty;
                    req.Higher_Surrender_Value_26 = string.Empty;

                    req.Year_27 = string.Empty;
                    req.Contribution_27 = string.Empty;
                    req.Lower_Sum_Assured_27 = string.Empty;
                    req.Lower_Policy_Value_27 = string.Empty;
                    req.Lower_Surrender_Value_27 = string.Empty;
                    req.Higher_Sum_Assured_27 = string.Empty;
                    req.Higher_Policy_Value_27 = string.Empty;
                    req.Higher_Surrender_Value_27 = string.Empty;

                    req.Year_28 = string.Empty;
                    req.Contribution_28 = string.Empty;
                    req.Lower_Sum_Assured_28 = string.Empty;
                    req.Lower_Policy_Value_28 = string.Empty;
                    req.Lower_Surrender_Value_28 = string.Empty;
                    req.Higher_Sum_Assured_28 = string.Empty;
                    req.Higher_Policy_Value_28 = string.Empty;
                    req.Higher_Surrender_Value_28 = string.Empty;
                    #endregion

                    if (res.Length >= 1 && res[0] != null)
                    {

                        req.Year_1 = (Prospect.Age + res[0].PolYearField).ToString();
                        req.Contribution_1 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_1 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_1 = res[0].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_1 = res[0].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_1 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_1 = res[0].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_1 = res[0].SurrValHigherField.ToString("N0");

                    }

                    if (res.Length >= 2 && res[1] != null)
                    {

                        req.Year_2 = (Prospect.Age + res[1].PolYearField).ToString();
                        req.Contribution_2 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_2 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_2 = res[1].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_2 = res[1].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_2 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_2 = res[1].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_2 = res[1].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 3 && res[2] != null)
                    {

                        req.Year_3 = (Prospect.Age + res[2].PolYearField).ToString();
                        req.Contribution_3 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_3 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_3 = res[2].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_3 = res[2].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_3 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_3 = res[2].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_3 = res[2].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 4 && res[3] != null)
                    {

                        req.Year_4 = (Prospect.Age + res[3].PolYearField).ToString();
                        req.Contribution_4 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_4 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_4 = res[3].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_4 = res[3].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_4 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_4 = res[3].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_4 = res[3].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 5 && res[4] != null)
                    {

                        req.Year_5 = (Prospect.Age + res[4].PolYearField).ToString();
                        req.Contribution_5 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_5 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_5 = res[4].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_5 = res[4].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_5 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_5 = res[4].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_5 = res[4].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 6 && res[5] != null)
                    {

                        req.Year_6 = (Prospect.Age + res[5].PolYearField).ToString();
                        req.Contribution_6 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_6 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_6 = res[5].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_6 = res[5].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_6 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_6 = res[5].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_6 = res[5].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 7 && res[6] != null)
                    {

                        req.Year_7 = (Prospect.Age + res[6].PolYearField).ToString();
                        req.Contribution_7 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_7 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_7 = res[6].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_7 = res[6].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_7 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_7 = res[6].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_7 = res[6].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 8 && res[7] != null)
                    {

                        req.Year_8 = (Prospect.Age + res[7].PolYearField).ToString();
                        req.Contribution_8 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_8 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_8 = res[7].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_8 = res[7].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_8 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_8 = res[7].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_8 = res[7].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 9 && res[8] != null)
                    {

                        req.Year_9 = (Prospect.Age + res[8].PolYearField).ToString();
                        req.Contribution_9 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_9 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_9 = res[8].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_9 = res[8].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_9 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_9 = res[8].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_9 = res[8].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 10 && res[9] != null)
                    {

                        req.Year_10 = (Prospect.Age + res[9].PolYearField).ToString();
                        req.Contribution_10 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_10 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_10 = res[9].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_10 = res[9].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_10 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_10 = res[9].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_10 = res[9].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 11 && res[10] != null)
                    {

                        req.Year_11 = (Prospect.Age + res[10].PolYearField).ToString();
                        req.Contribution_11 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_11 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_11 = res[10].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_11 = res[10].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_11 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_11 = res[10].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_11 = res[10].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 12 && res[11] != null)
                    {

                        req.Year_12 = (Prospect.Age + res[11].PolYearField).ToString();
                        req.Contribution_12 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_12 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_12 = res[11].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_12 = res[11].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_12 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_12 = res[11].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_12 = res[11].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 13 && res[12] != null)
                    {

                        req.Year_13 = (Prospect.Age + res[12].PolYearField).ToString();
                        req.Contribution_13 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_13 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_13 = res[12].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_13 = res[12].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_13 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_13 = res[12].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_13 = res[12].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 14 && res[13] != null)
                    {

                        req.Year_14 = (Prospect.Age + res[13].PolYearField).ToString();
                        req.Contribution_14 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_14 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_14 = res[13].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_14 = res[13].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_14 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_14 = res[13].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_14 = res[13].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 15 && res[14] != null)
                    {

                        req.Year_15 = (Prospect.Age + res[14].PolYearField).ToString();
                        req.Contribution_15 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_15 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_15 = res[14].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_15 = res[14].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_15 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_15 = res[14].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_15 = res[14].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 16 && res[15] != null)
                    {

                        req.Year_16 = (Prospect.Age + res[15].PolYearField).ToString();
                        req.Contribution_16 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_16 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_16 = res[15].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_16 = res[15].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_16 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_16 = res[15].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_16 = res[15].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 17 && res[16] != null)
                    {

                        req.Year_17 = (Prospect.Age + res[16].PolYearField).ToString();
                        req.Contribution_17 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_17 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_17 = res[16].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_17 = res[16].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_17 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_17 = res[16].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_17 = res[16].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 18 && res[17] != null)
                    {

                        req.Year_18 = (Prospect.Age + res[17].PolYearField).ToString();
                        req.Contribution_18 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_18 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_18 = res[17].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_18 = res[17].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_18 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_18 = res[17].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_18 = res[17].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 19 && res[18] != null)
                    {

                        req.Year_19 = (Prospect.Age + res[18].PolYearField).ToString();
                        req.Contribution_19 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_19 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_19 = res[18].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_19 = res[18].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_19 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_19 = res[18].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_19 = res[18].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 20 && res[19] != null)
                    {

                        req.Year_20 = (Prospect.Age + res[19].PolYearField).ToString();
                        req.Contribution_20 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_20 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_20 = res[19].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_20 = res[19].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_20 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_20 = res[19].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_20 = res[19].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 21 && res[20] != null)
                    {

                        req.Year_21 = (Prospect.Age + res[20].PolYearField).ToString();
                        req.Contribution_21 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_21 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_21 = res[20].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_21 = res[20].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_21 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_21 = res[20].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_21 = res[20].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 22 && res[21] != null)
                    {

                        req.Year_22 = (Prospect.Age + res[21].PolYearField).ToString();
                        req.Contribution_22 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_22 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_22 = res[21].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_22 = res[21].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_22 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_22 = res[21].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_22 = res[21].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 23 && res[22] != null)
                    {

                        req.Year_23 = (Prospect.Age + res[22].PolYearField).ToString();
                        req.Contribution_23 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_23 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_23 = res[22].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_23 = res[22].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_23 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_23 = res[22].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_23 = res[22].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 24 && res[23] != null)
                    {

                        req.Year_24 = (Prospect.Age + res[23].PolYearField).ToString();
                        req.Contribution_24 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_24 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_24 = res[23].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_24 = res[23].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_24 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_24 = res[23].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_24 = res[23].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 25 && res[24] != null)
                    {

                        req.Year_25 = (Prospect.Age + res[24].PolYearField).ToString();
                        req.Contribution_25 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_25 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_25 = res[24].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_25 = res[24].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_25 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_25 = res[24].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_25 = res[24].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 26 && res[25] != null)
                    {

                        req.Year_26 = (Prospect.Age + res[25].PolYearField).ToString();
                        req.Contribution_26 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_26 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_26 = res[25].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_26 = res[25].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_26 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_26 = res[25].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_26 = res[25].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 27 && res[26] != null)
                    {

                        req.Year_27 = (Prospect.Age + res[26].PolYearField).ToString();
                        req.Contribution_27 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_27 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_27 = res[26].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_27 = res[26].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_27 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_27 = res[26].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_27 = res[26].SurrValHigherField.ToString("N0");

                    };

                    if (res.Length >= 28 && res[27] != null)
                    {

                        req.Year_28 = (Prospect.Age + res[27].PolYearField).ToString();
                        req.Contribution_28 = Contribution.ToString("N0");
                        req.Lower_Sum_Assured_28 = LifeCoverValue.ToString("N0");
                        req.Lower_Policy_Value_28 = res[27].YrlyProjLowerField.ToString("N0");
                        req.Lower_Surrender_Value_28 = res[27].SurrValLowerField.ToString("N0");
                        req.Higher_Sum_Assured_28 = LifeCoverValue.ToString("N0");
                        req.Higher_Policy_Value_28 = res[27].YrlyProjHigherField.ToString("N0");
                        req.Higher_Surrender_Value_28 = res[27].SurrValHigherField.ToString("N0");

                    };

                    req.Agent_Name = LoggedAgent.FullName;
                    //req.AgentEmail = "raphael.ariguzor@axamansard.com";
                    req.AgentEmail = LoggedAgent.EmailAddress;
                    req.Issue_Date = DateTime.Now.ToString("dd-MM-yyyy");
                    req.Customer_Name = Prospect.FullName;
                    req.Phone_Number = Prospect.MobileNumber;
                    //req.Email = "rafaelchisom@gmail.com";
                    req.Email = Prospect.Email;
                    req.Address = Prospect.Address;
                    req.Total_Premium = (AnnualPremium * SelectedPolicyDuration).ToString("N0");
                    req.Premium_Frequency = PaymentFrequency;
                    req.Policy_Term = Convert.ToString(SelectedPolicyDuration) + " Years";
                    req.Customer_Signature = Prospect.FullName;
                    req.Lower_Maturity_Value = getMaxBenefitResponse.MaturityAcctBalanceLowerField.ToString("N0");
                    req.Higher_Maturity_Value = getMaxBenefitResponse.MaturityAcctBalanceHigherField.ToString("N0");
                    req.Product = ProductPlan.PlanCategory;

                    var response = await logical.GenerateEppProjectionSheet(req);
                    if (response.IsSuccess == true)
                    {
                        BookOnline.ProjectionSheetDocument = response.DocumentString;
                        IsBusy = false;
                        await _pageDialogService.DisplayAlertAsync("Successful", "projection sheet sent", "Ok");
                    }
                    else
                    {
                        IsBusy = false;
                        await _pageDialogService.DisplayAlertAsync("Unsuccessful", "projection sheet not sent", "Ok");

                    }
                    #endregion

                    //int saved = await _bookOnlineRepository.SaveBooking(BookOnline);

                    var parameters = new NavigationParameters();
                    parameters.Add("ProspectId", Prospect.Id);
                    parameters.Add("ProductPlanId", ProductPlan.Id);
                    parameters.Add("AgentId", LoggedAgent.Id);
                    parameters.Add("BookOnlineId", BookOnline);

                    await _navigationService.NavigateAsync("AddBeneficiaryPage", parameters);
                }
            }
            catch (Exception ex)
            {

            }
            IsBusy = false;
        }
    }
}
