﻿using Prism.Commands;
using Prism.AppModel;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;
using Prism.Navigation;
using Prism.Services;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using System.Threading.Tasks;
using AxaSolLite.Models;
using Newtonsoft.Json;

namespace AxaSolLite.ViewModels
{
    public class LeadAccountPageViewModel : BindableBase, INavigationAware
    {
        private readonly IPageDialogService _pageDialogService;
        private readonly INavigationService _navigationService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly EncryptUtils _encryptUtils;

        private Logical _logical;

        #region Fields
        public bool _isBusy;
        private string _firstName;
        private string _lastName;
        private string _emailAddress;
        private string _dateOfBirth;
        private string _phoneNumber;
        private string _residentialAddress;
        public bool _isYes;
        public bool _isNo;
        private string _customerNumber;
        private Guid _prospectId;
        #endregion
        #region Properties
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public bool IsYes
        {
            get { return _isYes; }
            set { SetProperty(ref _isYes, value); }
        }
        public bool IsNo
        {
            get { return _isNo; }
            set { SetProperty(ref _isNo, value); }
        }
        public string CustomerNumber
        {
            get { return _customerNumber; }
            set { SetProperty(ref _customerNumber, value); }
        }
        public string FirstName
        {
            get { return _firstName; }
            set { SetProperty(ref _firstName, value); }
        }
        public string LastName
        {
            get { return _lastName; }
            set { SetProperty(ref _lastName, value); }
        }
        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }
        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { SetProperty(ref _phoneNumber, value); }
        }
        public string Address
        {
            get { return _residentialAddress; }
            set { SetProperty(ref _residentialAddress, value); }
        }
        public string DateOfBirth
        {
            get { return _dateOfBirth; }
            set { SetProperty(ref _dateOfBirth, value); }
        }
        public Prospect SelectedProspect { get; private set; }
        public Agent LoggedAgent { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }
        #endregion
        #region Commands
        private DelegateCommand _proceedCommand;
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProceed));
        #endregion
        public LeadAccountPageViewModel(IPageDialogService pageDialogService, INavigationService navigationService, IProspectRepository prospectRepository, Logical logical, IAgentRepository agentRepository,
            EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _prospectRepository = prospectRepository;
             _logical = logical;
            _agentRepository = agentRepository;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
          
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    //Guid prospectId;
                    //if (Guid.TryParse(parameters["ProspectId"].ToString(), out prospectId))
                    //{
                    //    SelectedProspect = await _prospectRepository.GetById(prospectId);
                    //}
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }

                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }

                await InitializeDefaultValues();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

        }

        private async Task InitializeDefaultValues()
        {
            try
            {
                FirstName = SelectedProspect.FirstName;
                LastName = SelectedProspect.LastName;
                DateOfBirth = SelectedProspect.Birthdate.ToString("yyyy-MM-dd");
                PhoneNumber = SelectedProspect.MobileNumber;
                Address = SelectedProspect.Address;
                EmailAddress = SelectedProspect.Email;
                

            }
            catch(Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteProceed()
        {
            IsBusy = true;
            var parameters = new NavigationParameters();
            try
            {
                if (IsYes == false && IsNo == false)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Agent cannot proceed without selecting an option YES or NO ", "Ok");
                } 
                else if (IsYes == true && IsNo == true)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Agent cannot proceed with selecting both option YES and NO ", "Ok");

                }
                else
                {
                    if(IsNo)
                    {
                        LeadGeneratorRequest req = new LeadGeneratorRequest
                        {
                            FirstName = FirstName,
                            LastName = LastName,
                            DateOfBirth = DateOfBirth,
                            ResidenceAddress = Address,
                            EmailAddress = EmailAddress,
                            PhoneNumber = PhoneNumber,
                            Title = SelectedProspect.TitleId.ToString(),
                            Gender = SelectedProspect.Gender == 0 ? "2" : "1"
                        };
                        var Response = await _logical.GenerateLeadAccount(req);
                        if(Response.IsSuccessful == true)
                        {
                            CustomerNumber = Response.Result.CustomerNumber;
                            LeadAccountMailRequest request = new LeadAccountMailRequest
                            {
                                CustomerNumber = CustomerNumber,
                                FullName = SelectedProspect.FullName,
                                EmailAddress = SelectedProspect.Email,
                                AgentEmail = LoggedAgent.EmailAddress
                            };
                            var res = await _logical.SendLeadAccountMail(request);


                            ProspectToUpdate prospectToUpdate = new ProspectToUpdate
                            {
                                CustomerNumber = CustomerNumber,
                                EmailAddress = EmailAddress,
                                DateOfBirth = Convert.ToDateTime(DateOfBirth),
                                FirstName = FirstName,
                                LastName = LastName,
                                PhoneNumber = PhoneNumber
                            };

                            bool updated = await _logical.UpdateProspectDetails(prospectToUpdate);
                           
                            await _pageDialogService.DisplayAlertAsync( "Welcome mail has been sent to the customer successfully", "Customer ID:"+ CustomerNumber, "Ok");
                            SelectedProspect.IsLeadAccount = true;
                            var Ischoice =  await _pageDialogService.DisplayAlertAsync("", "Complete customer onboarding Now", "YES", "NO");
                            if(Ischoice)
                            {
                                bool useNIN = await _pageDialogService.DisplayAlertAsync("", "Confirm how to complete onboarding", "Use NIN", "Use Manual");
                                if (useNIN)
                                {
                                    SelectedProspect.CustomerNumber = CustomerNumber;
                                    //await _prospectRepository.UpdateAsync(SelectedProspect);
                                    parameters.Add("ProspectId", SelectedProspect.Id);
                                    parameters.Add("AgentId", LoggedAgent.Id);

                                    string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                                    EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                                    int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                                    //int x = await _prospectRepository.UpdateAsync(SelectedProspect);
                                    await _navigationService.NavigateAsync("NINOnboardingPage", parameters, null, false);
                                }
                                else
                                {
                                    SelectedProspect.CustomerNumber = CustomerNumber;
                                    //await _prospectRepository.UpdateAsync(SelectedProspect);
                                    parameters.Add("ProspectId", SelectedProspect.Id);
                                    parameters.Add("AgentId", LoggedAgent.Id);

                                    string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                                    EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                                    int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                                    //int x = await _prospectRepository.UpdateAsync(SelectedProspect);
                                    await _navigationService.NavigateAsync("CustomerOnboardingPage", parameters, null, false);
                                }
                            }
                            else
                            {
                                SelectedProspect.IsEkycStatus = true;
                                SelectedProspect.CustomerNumber = CustomerNumber;

                                string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                                EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                                int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                                //await _prospectRepository.UpdateAsync(SelectedProspect);
                                parameters.Add("ProspectId", SelectedProspect.Id);
                                parameters.Add("AgentId", LoggedAgent.Id);
                                await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", parameters, null, false);
                            }
                        }
                        else
                        {
                            await _pageDialogService.DisplayAlertAsync("Oooops!", "Customer Lead Account Generation Failed. Please check your network connection and try again.", "Cancel");

                        }                        
                    }
                    else if(IsYes)
                    {
                        SelectedProspect.CustomerNumber = CustomerNumber;
                        //await _prospectRepository.UpdateAsync(SelectedProspect);
                        parameters.Add("ProspectId", SelectedProspect.Id);
                        parameters.Add("AgentId", LoggedAgent.Id);

                        string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                        EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                        int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                        //int x = await _prospectRepository.UpdateAsync(SelectedProspect);
                        await _navigationService.NavigateAsync("CustomerOnboardingPage", parameters, null, false);


                    }                    
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                await _pageDialogService.DisplayAlertAsync("Oooops!!!", "Customer Lead Account Generation Failed. Please check your network connection and try again.", "Cancel");
            }
            IsBusy = false;
        }
    }
}
