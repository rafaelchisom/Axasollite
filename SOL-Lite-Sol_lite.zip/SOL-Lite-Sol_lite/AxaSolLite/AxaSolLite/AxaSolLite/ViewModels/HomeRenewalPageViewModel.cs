﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Xamarin.Forms;

namespace AxaSolLite.ViewModels
{
    public class HomeRenewalPageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IAgentRepository _agentRepository;
        private string _title;
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public Agent LoggedAgent { get; set; }

        private DelegateCommand _bookNowCommand;
        private DelegateCommand _renewNowCommand;
        public DelegateCommand BookNowCommand => _bookNowCommand ?? (_bookNowCommand = new DelegateCommand(ExecuteBookNowCommand));       
        public DelegateCommand RenewNowCommand => _renewNowCommand ?? (_renewNowCommand = new DelegateCommand(ExecuteRenewNowCommand));

        public HomeRenewalPageViewModel(INavigationService navigationService, IAgentRepository agentRepository)
        {
            _navigationService = navigationService;
            _agentRepository = agentRepository;

        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
           
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            try
            {
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }
                
            }
            catch (Exception)
            {

            }

        }

        private async void ExecuteBookNowCommand()
        {
            try
            {
                var navigationParameter = new NavigationParameters();
                navigationParameter.Add("AgentId", LoggedAgent.Id);
                await _navigationService.NavigateAsync("ProspectRegistrationPage", navigationParameter);
            }
            catch (Exception)
            {

            }
        }

        private async void ExecuteRenewNowCommand()
        {
            try
            {
                var navigationParameter = new NavigationParameters();
                navigationParameter.Add("AgentId", LoggedAgent.Id);
                await _navigationService.NavigateAsync("RenewalSearchPage", navigationParameter);
            }
            catch (Exception)
            {

            }
        }
    }
}
