﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace AxaSolLite.ViewModels
{
	public class LifePlusBookingPageViewModel : BindableBase, INavigationAware
	{
        private const string AccountNumberRegex = @"^[0-9]+$";

        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly IBranchesRepository _branchesRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;
        private readonly CalculatorService _calculatorService;

        private bool _isBusy;
        private string _agentName;
        private string _sbuName;
        private string _selectedDSA;
        private List<string> _myDSAs;
        private bool _isExternalAgent;
        private Prospect _selectedProspect;
        private Agent _loggedAgent;
        private string _title;
        private List<string> _premiumList;
        private string _paymentFrequency;
        private double _sumAssured;
        private int _policyDuration;
        private DateTime _policyStartDate;
        private string _premium;
        private string _age;
        private int _ageAtNextBirthday;
        private string _customerNumber;
        private double _totalPremium;
        private List<DSAUnderPSS> _dSAs;
        private DSAUnderPSS _dSA;
        private List<string> _branchList;
        private string _selectedbranch;
        private SyncDataSample _branches;
        private Branches _branch;
        private int _branchCode;
        private List<Branches> _branchToSave = new List<Branches>();
        private string _agentCode;
        private string _emailAddress;
        private string _sbuCode;
        private string _initiationDate;
        private List<string> _policyDurations = new List<string>();
        private int _ageAtEndOfPolicy;
        private string _selectedPolicyDuration;
        private bool _paymentFreqAndContribMatch;
        private bool _sumAssuredValid;
        private double _contribution;
        private double _annualPremium;
        private Guid _prospectId;
        private string _accountNumber;
        private List<string> _bankList = new List<string>();
        private string _bankName;
        public string BankName
        {
            get { return _bankName; }
            set { SetProperty(ref _bankName, value); }
        }
        public List<string> BankList
        {
            get { return _bankList; }
            set { SetProperty(ref _bankList, value); }
        }
        public string AccountNumber
        {
            get { return _accountNumber; }
            set { SetProperty(ref _accountNumber, value); }
        }
        public double AnnualPremium
        {
            get { return _annualPremium; }
            set { SetProperty(ref _annualPremium, value); }
        }
        public double Contribution
        {
            get { return _contribution; }
            set { SetProperty(ref _contribution, value); }
        }
        public List<Branches> BranchToSave
        {
            get { return _branchToSave; }
            set { SetProperty(ref _branchToSave, value); }
        }
        public bool PaymentFreqAndContribMatch
        {
            get { return _paymentFreqAndContribMatch; }
            set { SetProperty(ref _paymentFreqAndContribMatch, value); }
        }
        public bool SumAssuredValid
        {
            get { return _sumAssuredValid; }
            set { SetProperty(ref _sumAssuredValid, value); }
        }
        public string SelectedPolicyDuration
        {
            get { return _selectedPolicyDuration; }
            set { SetProperty(ref _selectedPolicyDuration, value); }
        }
        public int AgeAtEndOfPolicy
        {
            get { return _ageAtEndOfPolicy; }
            set { SetProperty(ref _ageAtEndOfPolicy, value); }
        }
        public List<string> PolicyDurations
        {
            get { return _policyDurations; }
            set { SetProperty(ref _policyDurations, value); }
        }
        public string InitiationDate
        {
            get { return _initiationDate; }
            set { SetProperty(ref _initiationDate, value); }
        }
        public string SbuCode
        {
            get { return _sbuCode; }
            set { SetProperty(ref _sbuCode, value); }
        }
        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }
        public string AgentCode
        {
            get { return _agentCode; }
            set { SetProperty(ref _agentCode, value); }
        }
        public int BranchCode
        {
            get { return _branchCode; }
            set { SetProperty(ref _branchCode, value); }
        }
        public SyncDataSample Branches
        {
            get { return _branches; }
            set { SetProperty(ref _branches, value); }
        }
        public DSAUnderPSS DSA
        {
            get { return _dSA; }
            set { SetProperty(ref _dSA, value); }
        }
        public List<DSAUnderPSS> DSAs
        {
            get { return _dSAs; }
            set { SetProperty(ref _dSAs, value); }
        }
        public Branches Branch
        {
            get { return _branch; }
            set { SetProperty(ref _branch, value); }
        }
        public double TotalPremium
        {
            get { return _totalPremium; }
            set { SetProperty(ref _totalPremium, value); }
        }
        public List<string> BranchList
        {
            get { return _branchList; }
            set { SetProperty(ref _branchList, value); }
        }
        public string SelectedBranch
        {
            get { return _selectedbranch; }
            set { SetProperty(ref _selectedbranch, value); }
        }
        public string CustomerNumber
        {
            get { return _customerNumber; }
            set { SetProperty(ref _customerNumber, value); }
        }
        public int AgeAtNextBirthday
        {
            get { return _ageAtNextBirthday; }
            set { SetProperty(ref _ageAtNextBirthday, value); }
        }
        public string Age
        {
            get { return _age; }
            set { SetProperty(ref _age, value); }
        }
        public string Premium
        {
            get { return _premium; }
            set { SetProperty(ref _premium, value); }
        }
        public DateTime PolicyStartDate
        {
            get { return _policyStartDate; }
            set { SetProperty(ref _policyStartDate, value); }
        }
        public int PolicyDuration
        {
            get { return _policyDuration; }
            set { SetProperty(ref _policyDuration, value); }
        }
        public double SumAssured
        {
            get { return _sumAssured; }
            set { SetProperty(ref _sumAssured, value); }
        }
        public string PaymentFrequency
        {
            get { return _paymentFrequency; }
            set { SetProperty(ref _paymentFrequency, value); }
        }
        public List<string> PremiumList
        {
            get { return _premiumList; }
            set { SetProperty(ref _premiumList, value); }
        }
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public Agent LoggedAgent
        {
            get { return _loggedAgent; }
            set { SetProperty(ref _loggedAgent, value); }
        }
        public Prospect SelectedProspect
        {
            get { return _selectedProspect; }
            set { SetProperty(ref _selectedProspect, value); }
        }
        public bool IsExternalAgent
        {
            get { return _isExternalAgent; }
            set { SetProperty(ref _isExternalAgent, value); }
        }
        public List<string> MyDSAs
        {
            get { return _myDSAs; }
            set { SetProperty(ref _myDSAs, value); }
        }
        public string SelectedDSA
        {
            get { return _selectedDSA; }
            set { SetProperty(ref _selectedDSA, value); }
        }
        public string SbuName
        {
            get { return _sbuName; }
            set { SetProperty(ref _sbuName, value); }
        }
        public string AgentName
        {
            get { return _agentName; }
            set { SetProperty(ref _agentName, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public ProductPlan ProductPlan { get; set; }
        public BookOnline BookOnline { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }

        private DelegateCommand _resetCommand;
        private DelegateCommand _proceedCommand;
        private DelegateCommand _changePolicyDuration;

        public DelegateCommand ResetCommand => _resetCommand ?? (_resetCommand = new DelegateCommand(ExecuteResetCommand));
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProceed));
        public DelegateCommand ChangePolicyDuration => _changePolicyDuration ?? (_changePolicyDuration = new DelegateCommand(ExecuteChangePolicyDuration));

        public LifePlusBookingPageViewModel(INavigationService navigationService, IPageDialogService pageDialogService, IProspectRepository prospectRepository,
            IProductPlansRepository productPlansRepository, IAgentRepository agentRepository, Logical logical, IBranchesRepository branchesRepository, EncryptUtils encryptUtils, CalculatorService calculatorService)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _prospectRepository = prospectRepository;
            _agentRepository = agentRepository;
            _productPlansRepository = productPlansRepository;
            _branchesRepository = branchesRepository;
            _logical = logical;
            _encryptUtils = encryptUtils;
            _calculatorService = calculatorService;
        }

        public async void OnNavigatedFrom(INavigationParameters parameters)
        {
            IsBusy = true;

            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    Guid prospectId;
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }

                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }

                if (parameters.ContainsKey("ProductPlanId"))
                {
                    Guid _productPlanId;
                    if (Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId))
                    {
                        ProductPlan = await _productPlansRepository.GetProductPlanByProductPlanId(_productPlanId);
                    }
                }

                InitializeDefaultValues();
            }
            catch (Exception ex)
            {

            }
            IsBusy = false;
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;

            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    //Guid prospectId;
                    //if (Guid.TryParse(parameters["ProspectId"].ToString(), out prospectId))
                    //{
                    //    SelectedProspect = await _prospectRepository.GetById(prospectId);
                    //}
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }

                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }

                if (parameters.ContainsKey("ProductPlanId"))
                {
                    Guid _productPlanId;
                    if (Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId))
                    {
                        ProductPlan = await _productPlansRepository.GetProductPlanByProductPlanId(_productPlanId);
                    }
                }

                InitializeDefaultValues();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async void InitializeDefaultValues()
        {
            try
            {
                List<BankDTO> MyBanks = await _logical.GetBankList();
                foreach (BankDTO item in MyBanks)
                {
                    string bankName = string.Empty;
                    bankName = item.NameField;
                    BankList.Add(bankName);
                }
                BankList = BankList.Where(x => x != "-- Select One--").ToList();

                Title = "Life Plus Booking Page";
                AgentName = LoggedAgent.FullName;
                if (LoggedAgent.IsAdvisor)
                {
                    AgentCode = LoggedAgent.SubAgentCode;
                }
                else
                {
                    AgentCode = LoggedAgent.AgentCode;
                }
                EmailAddress = LoggedAgent.EmailAddress;
                SbuName = LoggedAgent.SbuName;
                SbuCode = LoggedAgent.SBU;
                PolicyStartDate = DateTime.Today;
                InitiationDate = DateTime.Today.ToString("MM-dd-yyyy");
                Age = SelectedProspect.Age.ToString();
                AgeAtNextBirthday = _calculatorService.GetAgeAtNextBirthday(SelectedProspect.Birthdate); //(SelectedProspect.Age + 1);
                CustomerNumber = SelectedProspect.CustomerNumber;
                var Branches = await _branchesRepository.GetBranches();
                BranchList = Branches.Select(x => x.Branch).ToList();
                BranchList = BranchList.Where(x => x != "BRANCHES").ToList();

                List<string> Numbers = new List<string>();
                for (int i = 3; i < 31; i++)
                {
                    Numbers.Add(i.ToString());
                }
                PolicyDurations = Numbers;

                if (!LoggedAgent.IsAdvisor && !LoggedAgent.IsTeamManager)
                {
                    IsExternalAgent = false;

                    DSAs = await _logical.GetDSAsUnderPss(LoggedAgent.AgentCode);

                    if (DSAs.Count > 0 && DSAs.First().PSSCode != null)
                    {
                        MyDSAs = DSAs.Select(x => x.FullName).ToList();
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        private async void ExecuteChangePolicyDuration()
        {
            IsBusy = true;
            try
            {
                AgeAtEndOfPolicy = AgeAtNextBirthday + Convert.ToInt32(SelectedPolicyDuration);
                if(AgeAtEndOfPolicy > 60)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Maximum age exceeded", "Ok");
                }
              
                TotalPremium = AnnualPremium * Convert.ToInt32(SelectedPolicyDuration);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private void ExecuteResetCommand()
        {
            try
            {
                IsBusy = false;
                SumAssuredValid = false;
                PaymentFreqAndContribMatch = false;
                Contribution = 0;
                AnnualPremium = 0;
                SumAssured = 0;
                SelectedPolicyDuration = string.Empty;
                AgeAtEndOfPolicy = 0;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public async void ComputePaymentPlan()
        {
            if (!string.IsNullOrEmpty(PaymentFrequency) && Contribution != 0)
            {
                if(PaymentFrequency == "Annual")
                {
                    if(Contribution < 60000)
                    {
                        PaymentFreqAndContribMatch = false;
                        await _pageDialogService.DisplayAlertAsync("Error", "The minimum amount for contribution on an annual payment plan is 60,000 Naira", "Ok");
                    }
                    else
                    {
                        AnnualPremium = Contribution;
                        PaymentFreqAndContribMatch = true;
                    }
                }
                else if(PaymentFrequency == "Monthly")
                {
                    if (Contribution < 5000)
                    {
                        PaymentFreqAndContribMatch = false;
                        await _pageDialogService.DisplayAlertAsync("Error", "The minimum amount for contribution on a monthly payment plan is 5,000 Naira", "Ok");
                    }
                    else
                    {
                        PaymentFreqAndContribMatch = true;
                        AnnualPremium = Contribution * 12;
                    }
                }
                else if (PaymentFrequency == "Quarterly")
                {
                    if (Contribution < 15000)
                    {
                        PaymentFreqAndContribMatch = false;
                        await _pageDialogService.DisplayAlertAsync("Error", "The minimum amount for contribution on a quarterly payment plan is 15,000 Naira", "Ok");
                    }
                    else
                    {
                        AnnualPremium = Contribution * 4;
                        PaymentFreqAndContribMatch = true;
                    }
                }
                else if (PaymentFrequency == "Half yearly")
                {
                    if (Contribution < 30000)
                    {
                        PaymentFreqAndContribMatch = false;
                        await _pageDialogService.DisplayAlertAsync("Error", "The minimum amount for contribution on a half yearly payment plan is 30,000 Naira", "Ok");
                    }
                    else
                    {
                        AnnualPremium = Contribution * 2;
                        PaymentFreqAndContribMatch = true;
                    }
                }
                if (!string.IsNullOrEmpty(SelectedPolicyDuration))
                {
                    TotalPremium = AnnualPremium * Convert.ToInt32(SelectedPolicyDuration);
                }
            }
        }

        private async void ExecuteProceed()
        {
            IsBusy = true;
            try
            {               
                if (string.IsNullOrEmpty(SelectedBranch))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Please select agent branch", "Ok");
                }
                else if (string.IsNullOrEmpty(PaymentFrequency))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Please select payment frequency", "Ok");
                }
                else if (string.IsNullOrEmpty(SelectedPolicyDuration))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Please select policy duration", "Ok");
                }
                else if (Contribution == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Please enter preferred contribution value", "Ok");
                }
                else if (SumAssured == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Please enter preferred sum assured value", "Ok");
                }
                else if(AgeAtEndOfPolicy > 60)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Maximum age exceeded", "Ok");
                }
                else if (string.IsNullOrEmpty(BankName))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a bank", "Ok");
                }
                else if (string.IsNullOrEmpty(AccountNumber))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Kindly enter bank account number", "Ok");
                }
                else if (AccountNumber.Length != 10)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Account number must be 10 digits", "Ok");
                }
                else if (!Regex.IsMatch(AccountNumber, AccountNumberRegex))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Account number must be in a correct format", "Ok");
                }
                else
                {
                    if (SumAssuredValid && PaymentFreqAndContribMatch)
                    {
                        var v = await _branchesRepository.GetBranchCodeByBranch(SelectedBranch);
                        if (v != null)
                        {
                            BranchCode = v.BranchCode;
                        }

                        if (!(string.IsNullOrEmpty(SelectedDSA)))
                        {
                            DSA = DSAs.Where(x => x.FullName == SelectedDSA).FirstOrDefault();
                        }
                        BookOnline = new BookOnline
                        {
                            Id = Guid.NewGuid(),
                            ProductPlanId = ProductPlan.Id,
                            AgentName = LoggedAgent.FullName,
                            AgeBeginPolicy = Convert.ToInt32(Age),
                            AgeEndPolicy = AgeAtEndOfPolicy,
                            AgentCode = LoggedAgent.AgentCode,
                            AnnualPremium = Convert.ToDecimal(AnnualPremium),
                            Assurer = LoggedAgent.FullName,
                            CustomerNo = SelectedProspect.CustomerNumber,
                            DateCreated = DateTime.Now,
                            EmailAddress = SelectedProspect.Email,
                            IntiationDate = DateTime.Now.ToString("MM/dd/yyyy"),
                            SumAssured = Convert.ToDecimal(SumAssured),
                            TransactionType = "New",
                            Amount = Convert.ToDecimal(Contribution),
                            SBU = LoggedAgent.SBU,
                            TotalPremium = Convert.ToDecimal(TotalPremium),
                            PolicyTerm = Convert.ToInt32(SelectedPolicyDuration),
                            Contribution = Convert.ToDecimal(Contribution),
                            LifeCoverValue = Convert.ToDecimal(SumAssured),
                            PolicyStartDate = DateTime.Today.ToString("MM/dd/yyyy"),
                            PolicyEndDate = PolicyStartDate.AddYears(Convert.ToInt32(SelectedPolicyDuration)).ToString("MM/dd/yyyy"),
                            PaymentFrequency = PaymentFrequency,
                            DSA = DSA?.FullName,
                            DSACode = DSA?.AgentCode,
                            BranchCode = BranchCode,
                            BankAccountNumber = AccountNumber,
                            BankName = BankName
                        };

                        LifePlusProjectionSheetRequest lifePlusProjectionSheetRequest = new LifePlusProjectionSheetRequest
                        {
                            Address = SelectedProspect.Address,
                            AgeAtNextBirthday = _calculatorService.GetAgeAtNextBirthday(SelectedProspect.Birthdate).ToString(), //(SelectedProspect.Age + 1).ToString(),
                            AgentEmail = LoggedAgent.EmailAddress,
                            AgentName = LoggedAgent.FullName,
                            AnnualContribution = AnnualPremium,
                            EmailAddress = SelectedProspect.Email,
                            SumAssured = SumAssured,
                            CustomerSignature = SelectedProspect.FullName,
                            ContentType = string.Empty,
                            CustomerName = SelectedProspect.FullName,
                            DateOfBirth = SelectedProspect.Birthdate.ToString("dd/MM/yyyy"),
                            DOB = SelectedProspect.Birthdate,
                            Duration = Convert.ToInt32(SelectedPolicyDuration),
                            IssueDate = Guid.NewGuid().ToString(),
                            PhoneNumber = SelectedProspect.MobileNumber,
                        };

                        GeneralBizPdfCertResponse lifePlusProjectionSheetResponse = await _logical.GenerateLifePlusProjectionSheet(lifePlusProjectionSheetRequest);

                        if(lifePlusProjectionSheetResponse != null && lifePlusProjectionSheetResponse.IsSuccess)
                        {
                            BookOnline.ProjectionSheetDocument = lifePlusProjectionSheetResponse.DocumentString;
                            await _pageDialogService.DisplayAlertAsync("", "A projection sheet has been sent to the customer's email address", "Ok");
                            var parameters = new NavigationParameters();
                            parameters.Add("ProspectId", SelectedProspect.Id);
                            parameters.Add("ProductPlanId", ProductPlan.Id);
                            parameters.Add("AgentId", LoggedAgent.Id);
                            parameters.Add("BookOnlineId", BookOnline);

                            await _navigationService.NavigateAsync("AddBeneficiaryPage", parameters);
                        }
                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Please check to confirm that payment frequency and contribution amount match. Also ensure that the value for sum assured is not less than 100,000 and not greater than 10,000,000 Naira", "Ok");
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }
    }
}
