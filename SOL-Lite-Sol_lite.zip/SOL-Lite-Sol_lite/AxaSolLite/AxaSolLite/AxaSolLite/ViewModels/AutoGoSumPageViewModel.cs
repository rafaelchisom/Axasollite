﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AxaSolLite.ViewModels
{
    public class AutoGoSumPageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IMotorProductRepository _motorProductRepository;
        private readonly IProductPlansRepository _productPlanRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly IPageDialogService _pageDialogService;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        #region Fields
        private string _dateofBirth;
        private string _startDate;
        private string _firstname;
        private string _lastname;
        private string _othername;
        private string _gender;
        private string _phonenumber;
        private string _email;
        private string _address;
        private string _fileLabel;
        private string _state;
        private bool _isBusy;
        private string _registrationnumber;
        private string _enginenumber;
        private string _chassisnumber;
        private string _vehiclemodel;
        private string _vehiclemake;
        private string _vehicleyear;
        private string _selectedVehicleMake;
        private string _SelectedVehicleModel;
        private int _SelectedVehicleYear;
        private string _effectiveCoverDate;
        private int _amount;
        private string _paymentOption;
        private int _selectedBranch;
        private Prospect _prospect;
        private Guid _productPlanId;
        private ProductPlan _productPlan;
        private MakeList _motorMake;
        private ModelList _motorModel;
        private Guid _prospectId;
        private PolicyNumberDetailsResponse _policyDetailsResponse;

        #endregion

        #region Properties
        public string DateofBirth
        {
            get { return _dateofBirth; }
            set { SetProperty(ref _dateofBirth, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public string FirstName
        {
            get { return _firstname; }
            set { SetProperty(ref _firstname, value); }
        }
        public string StartDate
        {
            get { return _startDate; }
            set { SetProperty(ref _startDate, value); }
        }
        public string FileLabel
        {
            get { return _fileLabel; }
            set { SetProperty(ref _fileLabel, value); }
        }
        public string LastName
        {
            get { return _lastname; }
            set { SetProperty(ref _lastname, value); }
        }

        public string OtherName
        {
            get { return _othername; }
            set { SetProperty(ref _othername, value); }
        }

        public string Gender
        {
            get { return _gender; }
            set { SetProperty(ref _gender, value); }
        }

        public string PhoneNumber
        {
            get { return _phonenumber; }
            set { SetProperty(ref _phonenumber, value); }
        }

        public string Email
        {
            get { return _email; }
            set { SetProperty(ref _email, value); }
        }
        public string PaymentOption
        {
            get { return _paymentOption; }
            set { SetProperty(ref _paymentOption, value); }
        }

        public string Address
        {
            get { return _address; }
            set { SetProperty(ref _address, value); }
        }

        public string State
        {
            get { return _state; }
            set { SetProperty(ref _state, value); }
        }

        public string RegistrationNumber
        {
            get { return _registrationnumber; }
            set { SetProperty(ref _registrationnumber, value); }
        }

        public string EngineNumber
        {
            get { return _enginenumber; }
            set { SetProperty(ref _enginenumber, value); }
        }

        public string ChassisNumber
        {
            get { return _chassisnumber; }
            set { SetProperty(ref _chassisnumber, value); }
        }

        public string VehicleModel
        {
            get { return _vehiclemodel; }
            set { SetProperty(ref _vehiclemodel, value); }
        }

        public string VehicleMake
        {
            get { return _vehiclemake; }
            set { SetProperty(ref _vehiclemake, value); }
        }

        public string VehicleYear
        {
            get { return _vehicleyear; }
            set { SetProperty(ref _vehicleyear, value); }
        }
        public int SelectedYear
        {
            get { return _SelectedVehicleYear; }
            set { SetProperty(ref _SelectedVehicleYear, value); }
        }

        public string SelectedVehicleMake
        {
            get { return _selectedVehicleMake; }
            set { SetProperty(ref _selectedVehicleMake, value); }
        }

        public string SelectedVehicleModel
        {
            get { return _SelectedVehicleModel; }
            set { SetProperty(ref _SelectedVehicleModel, value); }
        }

        public int Amount
        {
            get { return _amount; }
            set { SetProperty(ref _amount, value); }
        }
        public Prospect Prospect
        {
            get { return _prospect = _prospect ?? (_prospect = new Prospect()); }
            set { SetProperty(ref _prospect, value); }
        }
        public ProductPlan ProductPlan
        {
            get { return _productPlan = _productPlan ?? (_productPlan = new ProductPlan()); }
            set { SetProperty(ref _productPlan, value); }
        }
        public string EffectiveCoverDate
        {
            get { return _effectiveCoverDate; }
            set { SetProperty(ref _effectiveCoverDate, value); }
        }
        public ModelList MotorModel
        {
            get { return _motorModel; }
            set { SetProperty(ref _motorModel, value); }
        }
        public MakeList MotorMake
        {
            get { return _motorMake; }
            set { SetProperty(ref _motorMake, value); }
        }
        public int SelectedBranch
        {
            get { return _selectedBranch; }
            set { SetProperty(ref _selectedBranch, value); }
        }
        public PolicyNumberDetailsResponse PolicyDetailsResponse
        {
            get { return _policyDetailsResponse; }
            set { SetProperty(ref _policyDetailsResponse, value); }
        }


        public Agent LoggedAgent { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }
        private DelegateCommand<string> _autoGoPayLaterCommand;
        private DelegateCommand _autoGoPayNowCommand;

        #endregion

        #region Commands
        public DelegateCommand<string> PayLaterCommand => _autoGoPayLaterCommand ?? (_autoGoPayLaterCommand = new DelegateCommand<string>(ExecutePayLaterCommand));
        public DelegateCommand PayNowCommand => _autoGoPayNowCommand ?? (_autoGoPayNowCommand = new DelegateCommand(ExecutePayNowCommand));
        #endregion

        public AutoGoSumPageViewModel(INavigationService navigationService,
             IProspectRepository prospectRepository,
             IMotorProductRepository motorProductRepository,
             IProductPlansRepository productPlanRepository,
              IPageDialogService pageDialogService,
               IProductPlansRepository productPlansRepository,
               Logical logical,
             IAgentRepository agentRepository, EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _prospectRepository = prospectRepository;
            _pageDialogService = pageDialogService;
            _productPlanRepository = productPlanRepository;
            _motorProductRepository = motorProductRepository;
            _agentRepository = agentRepository;
            _productPlansRepository = productPlansRepository;
            _logical = logical;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            if (parameters.ContainsKey("ProspectId"))
            {
                //Guid prospectId;
                //if (Guid.TryParse(parameters["ProspectId"].ToString(), out prospectId))
                //{
                //    Prospect = await _prospectRepository.GetById(prospectId);
                //}

                Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                Prospect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
            }
            if (parameters.ContainsKey("ProductPlanId"))
            {
                Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId);
                ProductPlan = await _productPlanRepository.GetProductPlanByProductPlanId(_productPlanId);
            }
            if (parameters.ContainsKey("AgentId"))
            {
                Guid agentId;
                if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                {
                    LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                }
            }
            if (parameters.ContainsKey("PolicyDetails"))
            {
                PolicyDetailsResponse = parameters.GetValue<PolicyNumberDetailsResponse>("PolicyDetails");              
            }

            FirstName = parameters.GetValue<string>("FirstName");
            OtherName = parameters.GetValue<string>("OtherName");
            LastName = parameters.GetValue<string>("LastName");
            Gender = parameters.GetValue<string>("Gender");
            PhoneNumber = parameters.GetValue<string>("PhoneNumber");
            Email = parameters.GetValue<string>("Email");
            Address = parameters.GetValue<string>("Address");
            State = parameters.GetValue<string>("State");
            SelectedBranch = parameters.GetValue<int>("Branch");
            #region state
            {
                if (Convert.ToInt16(State) == 0)
                {
                    State = "Abia";
                }
                else if (Convert.ToInt16(State) == 1)
                {
                    State = "Abuja";
                }
                else if (Convert.ToInt16(State) == 2)
                {
                    State = "Adamawa";
                }
                else if (Convert.ToInt16(State) == 3)
                {
                    State = "Akwa ibom";
                }
                else if (Convert.ToInt16(State) == 4)
                {
                    State = "Anambra";
                }
                else if (Convert.ToInt16(State) == 5)
                {
                    State = "Bauchi";
                }
                else if (Convert.ToInt16(State) == 6)
                {
                    State = "Bayelsa";
                }
                else if (Convert.ToInt16(State) == 7)
                {
                    State = "Benue";
                }
                else if (Convert.ToInt16(State) == 8)
                {
                    State = "Borno";
                }
                else if (Convert.ToInt16(State) == 9)
                {
                    State = "Cross River";
                }
                else if (Convert.ToInt16(State) == 10)
                {
                    State = "Delta";
                }
                else if (Convert.ToInt16(State) == 11)
                {
                    State = "Ebonyi";
                }
                else if (Convert.ToInt16(State) == 12)
                {
                    State = "Enugu";
                }
                else if (Convert.ToInt16(State) == 13)
                {
                    State = "Edo";
                }
                else if (Convert.ToInt16(State) == 14)
                {
                    State = "Ekiti";
                }
                else if (Convert.ToInt16(State) == 15)
                {
                    State = "Gombo";
                }
                else if (Convert.ToInt16(State) == 16)
                {
                    State = "Imo";
                }
                else if (Convert.ToInt16(State) == 17)
                {
                    State = "Jigawa";
                }
                else if (Convert.ToInt16(State) == 18)
                {
                    State = "Kaduna";
                }
                else if (Convert.ToInt16(State) == 19)
                {
                    State = "Kano";
                }
                else if (Convert.ToInt16(State) == 20)
                {
                    State = "Kastina";
                }
                else if (Convert.ToInt16(State) == 21)
                {
                    State = "Kebbi";
                }
                else if (Convert.ToInt16(State) == 22)
                {
                    State = "Kogi";
                }
                else if (Convert.ToInt16(State) == 23)
                {
                    State = "Kwara";
                }
                else if (Convert.ToInt16(State) == 24)
                {
                    State = "Lagos";
                }
                else if (Convert.ToInt16(State) == 25)
                {
                    State = "Nasarawa";
                }
                else if (Convert.ToInt16(State) == 26)
                {
                    State = "Niger";
                }
                else if (Convert.ToInt16(State) == 27)
                {
                    State = "Ogun";
                }
                else if (Convert.ToInt16(State) == 28)
                {
                    State = "Ondo";
                }
                else if (Convert.ToInt16(State) == 29)
                {
                    State = "Osun";
                }
                else if (Convert.ToInt16(State) == 30)
                {
                    State = "Oyo";
                }
                else if (Convert.ToInt16(State) == 31)
                {
                    State = "Plateau";
                }
                else if (Convert.ToInt16(State) == 32)
                {
                    State = "Rivers";
                }
                else if (Convert.ToInt16(State) == 33)
                {
                    State = "Sokoto";
                }
                else if (Convert.ToInt16(State) == 34)
                {
                    State = "Taraba";
                }
                else if (Convert.ToInt16(State) == 35)
                {
                    State = "Yobe";
                }
                else if (Convert.ToInt16(State) == 36)
                {
                    State = "Zamfara";
                }
            }

            #endregion state

            RegistrationNumber = parameters.GetValue<string>("RegistrationNumber");
            EngineNumber = parameters.GetValue<string>("EngineNumber");
            ChassisNumber = parameters.GetValue<string>("ChassisNumber");
            VehicleModel = parameters.GetValue<string>("SelectedVehicleModel");
            VehicleMake = parameters.GetValue<string>("SelectedVehicleMake");
            VehicleYear = parameters.GetValue<string>("SelectedYear");
           
            DateofBirth = parameters.GetValue<string>("DateofBirth");
            StartDate = parameters.GetValue<string>("StartDate");
            MotorMake = parameters.GetValue<MakeList>("MotorMakes");
            MotorModel = parameters.GetValue<ModelList>("MotorModels");
            Amount = 5000;
            EffectiveCoverDate = DateTime.Today.ToString("MM/dd/yyyy") + " till " + DateTime.Today.AddYears(1).AddDays(-1).ToString("MM/dd/yyyy");
        }

        public async void ExecutePayLaterCommand(string parameter)
        {
            try
            {
                var motorproduct = new MotorProduct
                {
                    Id = Guid.NewGuid(),
                    ProductPlanId = ProductPlan.Id,
                    RegistrationNumber = RegistrationNumber,
                    EngineNumber = EngineNumber,
                    ChassisNumber = ChassisNumber,
                    VehicleModel = VehicleModel,
                    VehicleMake = VehicleMake,
                    VehicleYear = VehicleYear,
                    MotorMakeId = Convert.ToString( MotorMake.Id),
                    MotorModelId =Convert.ToString( MotorModel.Id),
                    StartDate = StartDate,
                    Branch = SelectedBranch,
                    Premium = Amount,
                };

                var y = await _motorProductRepository.SaveAsync(motorproduct);

                if (y == 1)
                {
                    var navigationParameter = new NavigationParameters();

                    navigationParameter.Add("ProspectId", Prospect.Id);
                    navigationParameter.Add("ProductPlanId", _productPlanId);
                    navigationParameter.Add("MotorProductId", motorproduct.Id);
                    navigationParameter.Add("AgentId", LoggedAgent.Id);

                    await _navigationService.NavigateAsync("PayLaterPage", navigationParameter);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        //public async void ExecutePayNowCommand()
        //{
        //    try
        //    {
        //        var motorproduct = new MotorProduct
        //        {
        //            Id = Guid.NewGuid(),
        //            ProductPlanId = ProductPlan.Id,
        //            RegistrationNumber = RegistrationNumber,
        //            EngineNumber = EngineNumber,
        //            ChassisNumber = ChassisNumber,
        //            VehicleModel = VehicleModel,
        //            VehicleMake = VehicleMake,
        //            VehicleYear = VehicleYear,
        //            MotorMakeId = Convert.ToString(MotorMake.Id),
        //            MotorModelId = Convert.ToString(MotorModel.Id),
        //            StartDate = StartDate,
        //            Branch = SelectedBranch,
        //            Premium = Amount,
        //        };

        //        var y = await _motorProductRepository.SaveAsync(motorproduct);

        //        if (y == 1)
        //        {
        //            var navigationParameter = new NavigationParameters();

        //            navigationParameter.Add("ProspectId", Prospect.Id);
        //            navigationParameter.Add("ProductPlanId", _productPlanId);
        //            navigationParameter.Add("MotorProductId", motorproduct.Id);
        //            navigationParameter.Add("AgentId", LoggedAgent.Id);

        //            await _navigationService.NavigateAsync("PayNowPage", navigationParameter);
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //}

        private async void ExecutePayNowCommand()
        {
            IsBusy = true;
            try
            {
                if (string.IsNullOrEmpty(PaymentOption))
                {
                    await _pageDialogService.DisplayAlertAsync("Kindly select a payment method", "", "Okay");
                    return;
                }
                if (PaymentOption.Contains("Pay with Paystack"))
                {
                    ProductPlan.IsAccountBalance = false;
                    int updated = await _productPlanRepository.UpdateAsync(ProductPlan);
                    var motorproduct = new MotorProduct
                    {
                        Id = Guid.NewGuid(),
                        ProductPlanId = ProductPlan.Id,
                        RegistrationNumber = RegistrationNumber,
                        EngineNumber = EngineNumber,
                        ChassisNumber = ChassisNumber,
                        VehicleModel = VehicleModel,
                        VehicleMake = VehicleMake,
                        VehicleYear = VehicleYear,
                        MotorMakeId = Convert.ToString(MotorMake.Id),
                        MotorModelId = Convert.ToString(MotorModel.Id),
                        StartDate = StartDate,
                        Branch = SelectedBranch,
                        Premium = Amount,

                        //CarColorCode = PolicyDetailsResponse.VehColorCode == null ? 0 : PolicyDetailsResponse.VehColorCode,
                        CarColorCode = 0,
                    };

                    var y = await _motorProductRepository.SaveAsync(motorproduct);

                    if (y == 1)
                    {
                        var navigationParameter = new NavigationParameters();

                        navigationParameter.Add("ProspectId", Prospect.Id);
                        navigationParameter.Add("ProductPlanId", _productPlanId);
                        navigationParameter.Add("MotorProductId", motorproduct.Id);
                        navigationParameter.Add("AgentId", LoggedAgent.Id);
                        navigationParameter.Add("IsRenewal", ProductPlan.IsRenewal);

                        await _navigationService.NavigateAsync("PayNowPage", navigationParameter);

                    }
                }
                else if (PaymentOption.Contains("Pay with QuoteID"))
                {
                    ProductPlan.IsAccountBalance = false;
                    int updated = await _productPlanRepository.UpdateAsync(ProductPlan);
                    var motorproduct = new MotorProduct
                    {
                        Id = Guid.NewGuid(),
                        ProductPlanId = ProductPlan.Id,
                        RegistrationNumber = RegistrationNumber,
                        EngineNumber = EngineNumber,
                        ChassisNumber = ChassisNumber,
                        VehicleModel = VehicleModel,
                        VehicleMake = VehicleMake,
                        VehicleYear = VehicleYear,
                        MotorMakeId = Convert.ToString(MotorMake.Id),
                        MotorModelId = Convert.ToString(MotorModel.Id),
                        StartDate = StartDate,
                        Branch = SelectedBranch,
                        Premium = Amount,

                        //CarColorCode = Poli? 0 : PolicyDetailsResponse.VehColorCode,
                        CarColorCode = 0,
                    };

                    var y = await _motorProductRepository.SaveAsync(motorproduct);

                    if (y == 1)
                    {
                        var navigationParameter = new NavigationParameters
                        {
                            { "ProspectId", Prospect.Id },
                            { "ProductPlanId", _productPlanId },
                            { "MotorProductId", motorproduct.Id },
                            { "AgentId", LoggedAgent.Id },
                            { "IsRenewal", ProductPlan.IsRenewal }
                        };
                        await _navigationService.NavigateAsync("PayLaterPage", navigationParameter);
                    }
                }
                else if (PaymentOption.Contains("Pay with Customer Account Balance"))
                {
                    var response = await _logical.GetCustomerAccountBalance(Prospect.CustomerNumber);
                    //Balance accountBalanceResponse = new Balance()
                    //{
                    //    availBalance = 500000
                    //};
                    //response.balances = accountBalanceResponse;
                    await _pageDialogService.DisplayAlertAsync("Account Balance", "Customer account balance:" + response.balances.availBalance, "Ok");
                    if (Convert.ToDouble(Amount) <= response.balances.availBalance)
                    {
                        ProductPlan.IsAccountBalance = true;
                        int updated = await _productPlanRepository.UpdateAsync(ProductPlan);
                        Prospect.LifeAimsBalance = response.balances.lifeBalance.ToString();
                        Prospect.NonLifeAimsBalance = response.balances.nonLifeBalance.ToString();
                        Prospect.TotalAimsBalance = response.balances.availBalance.ToString();

                        string serializedProspect = JsonConvert.SerializeObject(Prospect);
                        EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                        int update = await _prospectRepository.UpdateAsync(EncryptedProspect);

                        var motorproduct = new MotorProduct
                        {
                            Id = Guid.NewGuid(),
                            ProductPlanId = ProductPlan.Id,
                            RegistrationNumber = RegistrationNumber,
                            EngineNumber = EngineNumber,
                            ChassisNumber = ChassisNumber,
                            VehicleModel = VehicleModel,
                            VehicleMake = VehicleMake,
                            VehicleYear = VehicleYear,
                            MotorMakeId = Convert.ToString(MotorMake.Id),
                            MotorModelId = Convert.ToString(MotorModel.Id),
                            StartDate = StartDate,
                            Branch = SelectedBranch,
                            Premium = Amount,

                            //CarColorCode = PolicyDetailsResponse.VehColorCode == null ? 0 : PolicyDetailsResponse.VehColorCode,
                            CarColorCode = 0,

                        };

                        var y = await _motorProductRepository.SaveAsync(motorproduct);

                        if (y == 1)
                        {
                            var navigationParameter = new NavigationParameters();

                            navigationParameter.Add("ProspectId", Prospect.Id);
                            navigationParameter.Add("ProductPlanId", _productPlanId);
                            navigationParameter.Add("MotorProductId", motorproduct.Id);
                            navigationParameter.Add("AgentId", LoggedAgent.Id);
                            navigationParameter.Add("IsRenewal", ProductPlan.IsRenewal);

                            await _navigationService.NavigateAsync("PayNowPage", navigationParameter);

                        }

                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Insufficent Fund", "Kindly inform the customer to credit account or use a different payment option", "Ok");

                    }
                }
                else
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a payment option", "Ok");
                }



            }
            catch (Exception ex)
            {
                await _pageDialogService.DisplayAlertAsync("Error", ex.Message.ToString(), "Ok");


            }
            IsBusy = false;
        }
    }
}
