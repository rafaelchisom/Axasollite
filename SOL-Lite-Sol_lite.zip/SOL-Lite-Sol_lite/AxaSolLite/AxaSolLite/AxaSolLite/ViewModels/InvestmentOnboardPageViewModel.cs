﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AxaSolLite.ViewModels
{
    public class InvestmentOnboardPageViewModel : BindableBase, INavigationAware
    {
        private readonly IPageDialogService _pageDialogService;
        private readonly INavigationService _navigationService;
        private readonly IAgentRepository _agentRepository;
        private readonly Logical _logical;

        #region Fields
        public bool _isBusy;
        public bool _status;
        private string _firstName;
        private string _lastName;
        private string _emailAddress;
        private string _accountNumber;
        private string _phoneNumber;
        private string _bvn;
        private string _accountName;
        private string _selectedFundType;
        private List<string> _bankList = new List<string>();
        private PaystackBankListResponse _myBanks; //= new List<PaystackBankListResponse>();
        private string _bankName;
        private double _amountInvest;
        #endregion

        #region Properties
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public bool Status
        {
            get { return _status; }
            set { SetProperty(ref _status, value); }
        }
        public double AmountInvest
        {
            get { return _amountInvest; }
            set { SetProperty(ref _amountInvest, value); }
        }
        public string AccountNumber
        {
            get { return _accountNumber; }
            set { SetProperty(ref _accountNumber, value); }
        }
        public string FirstName
        {
            get { return _firstName; }
            set { SetProperty(ref _firstName, value); }
        }
        public string LastName
        {
            get { return _lastName; }
            set { SetProperty(ref _lastName, value); }
        }
        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }
        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { SetProperty(ref _phoneNumber, value); }
        }
        public string BVN
        {
            get { return _bvn; }
            set { SetProperty(ref _bvn, value); }
        }
        public string AccountName
        {
            get { return _accountName; }
            set { SetProperty(ref _accountName, value); }
        }
        public string SelectedFundType
        {
            get { return _selectedFundType; }
            set { SetProperty(ref _selectedFundType, value); }
        }
        public string BankName
        {
            get { return _bankName; }
            set { SetProperty(ref _bankName, value); }
        }
        public List<string> BankList
        {
            get { return _bankList; }
            set { SetProperty(ref _bankList, value); }
        }
        public PaystackBankListResponse MyBanks
        {
            get { return _myBanks; }
            set { SetProperty(ref _myBanks, value); }
        }
        public Agent LoggedAgent { get; set; }


        private DelegateCommand _proceedCommand;
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProccedCommand));
        #endregion
        public InvestmentOnboardPageViewModel(IPageDialogService pageDialogService, INavigationService navigationService,
            IAgentRepository agentRepository, Logical logical)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _agentRepository = agentRepository;
            _logical = logical;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            try
            {
                if (parameters.ContainsKey("AgentId"))
                {
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out Guid agentId))
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                }
                await InitializeDefaultValues();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async Task InitializeDefaultValues()
        {
            try
            {
                MyBanks = await _logical.GetPaystackBanks();
                if (MyBanks.Status)
                {
                    foreach (Datum item in MyBanks.Data)
                    {
                        string bankName = string.Empty;
                        bankName = item.Name;
                        BankList.Add(bankName);
                    }
                    BankList = BankList.ToList();
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public async Task VerifyBVN()
        {
            IsBusy = true;
            try
            {
                var bank = MyBanks.Data.Where(x => x.Name == BankName).FirstOrDefault();
                if (bank != null)
                {
                    InvestmentConfirmBvnRequest request = new InvestmentConfirmBvnRequest
                    {
                        AccountNumber = AccountNumber,
                        Bvn = BVN,
                        BankId = bank.Id
                    };

                    var response = await _logical.BVNVerify(request);
                    if (response != null)
                    {
                        if(response.ReturnedObject != null)
                        {
                            if (response.ReturnedObject.IsMatched)
                            {
                                Status = true;
                                IsBusy = false;
                            }
                            else
                            {
                                Status = false;
                                IsBusy = false;
                            }
                        }
                        else
                        {
                            Status = false;
                            IsBusy = false;
                        }
                    }
                    else
                    {
                        Status = false;
                        IsBusy = false;
                    }
                }
                else
                    await _pageDialogService.DisplayAlertAsync("Error", "Unable to retrieve bank details. Please try again", "Ok");
            }
            catch (Exception ex)
            {
                IsBusy = false;
                Status = true;
            }
            IsBusy = false;
        }

        public async void ExecuteProccedCommand()
        {
            IsBusy = true;
            try
            {
                if (string.IsNullOrEmpty(FirstName))
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "FirstName", "Ok");
                }
                else if (string.IsNullOrEmpty(LastName))
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "LastName", "Ok");
                }
                else if (string.IsNullOrEmpty(EmailAddress))
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "EmailAddress", "Ok");
                }
                else if (string.IsNullOrEmpty(PhoneNumber))
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "EmailAddress", "Ok");
                }
                else if (string.IsNullOrEmpty(BankName))
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "BankName", "Ok");
                }
                else if (string.IsNullOrEmpty(AccountNumber))
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "AccountNumber", "Ok");
                }
                else if (string.IsNullOrEmpty(BVN))
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "BVN", "Ok");
                }
                else
                {
                    int bankId;
                    var Bank = MyBanks.Data.Where(x => x.Name == BankName).FirstOrDefault();

                    if (Bank == null)
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Unable to retrieve bank detais", "Ok");
                        IsBusy = false;
                        return;
                    }
                    else
                        bankId = Bank.Id;
                    InvestmentCreateClientRequest req = new InvestmentCreateClientRequest();
                    List<BankAccount> lsit = new List<BankAccount>();
                    BankAccount bankact = new BankAccount();
                    bankact.BankId = Convert.ToInt32(bankId);
                    bankact.AccountNo = AccountNumber;
                    bankact.AccountName = AccountName;
                    bankact.SortCode = null;
                    bankact.IsActive = true;
                    bankact.ClientBankId = 0;
                    bankact.BankName = BankName;
                    lsit.Add(bankact);
                    req.AgentCode = LoggedAgent.AgentCode;
                    req.Id = 0;
                    req.Uuid = null;
                    req.AccountType = 1;
                    req.TitleId = 1;
                    req.Surname = LastName;
                    req.Firstname = FirstName;
                    req.MiddleName = null;
                    req.MothersMaidenName = "N-A";
                    req.Gender = 1;
                    req.Nationality = 128;
                    req.Dob = DateTime.Now.AddYears(-30);
                    req.CountryOfBirth = 128;
                    req.DualCitizenship = null;
                    req.Occupation = 395;
                    req.ResidentPermitNo = null;
                    req.Country = 128;
                    req.StateId = 1;
                    req.ResidentialAddress = "N/A";
                    req.ZipCode = null;
                    req.MobileNo = PhoneNumber;
                    req.HomePhone = null;
                    req.Fax = null;
                    req.OfficeAddress = null;
                    req.OfficePhone = null;
                    req.EmailAddress = EmailAddress;
                    req.NokName = FirstName + LastName;
                    req.NokAddress = "N-A";
                    req.NokPhone = PhoneNumber;
                    req.NokEmail = EmailAddress;
                    req.NokRelationship = 5;
                    req.NokOtherRelationship = null;
                    req.Bvn = BVN;
                    req.BvnVerified = false;
                    req.CorrespondenceAddress = null;
                    req.ForeignMailingAddress = null;
                    req.ForeignPhoneNo = null;
                    req.Tin = null;
                    req.IsStandingInstruction = null;
                    req.IdType = null;
                    req.DriversLicenseOrPassportNo = null;
                    req.AccountPurposeId = 1;
                    req.AccountPurpose = "";
                    req.WealthSourceId = 1;
                    req.WealthSource = "";
                    req.IncomeClass = null;
                    req.IsPartOnboarding = true;
                    req.FundsOrigin = null;
                    req.PoliticalExposure = "No";
                    req.DiscoveryCode = 6;
                    req.ConfirmationCode = null;
                    req.SecurityQuestion = "N/A";
                    req.SecurityAnswer = "N/A";
                    req.InviteCode = null;
                    req.Source = 8;
                    req.PartnerId = 0;
                    req.PayoutDividend = false;
                    req.DisableLiquidation = false;
                    req.ReferralCode = null;
                    req.HasPin = false;
                    req.HasFd = false;
                    req.HasRiskAssessmentProfile = false;
                    req.AccruedInterest = 0.0;
                    req.CurrentBalance = 0.0;
                    req.BookBalance = 0.0;
                    req.RiskProfile = null;
                    req.JointClient = null;
                    req.BankAccounts = lsit;

                    var res = JsonConvert.SerializeObject(req);

                    var sent = await _logical.InvestmentClientOnboard(req);
                    if (sent.Success)
                    {
                        await _pageDialogService.DisplayAlertAsync("Successful", "Client Onboarded", "Ok");
                        NavigationParameters parameters = new NavigationParameters
                        {
                            { "AgentId", LoggedAgent.Id }
                        };
                        await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/HomeRenewalPage", parameters);
                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Unsucessful", sent.Message, "Ok");
                    }
                }
                IsBusy = false;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                IsBusy = false;
                await _pageDialogService.DisplayAlertAsync("Unsuceesful", "Try Again", "Ok");
            }
        }
    }
}
