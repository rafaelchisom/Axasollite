﻿using AxaSolLite.Models;
using AxaSolLite.Models.CustomerOnboardingCreateCase;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Plugin.FilePicker;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AxaSolLite.ViewModels
{
    public class HealthBookingPageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly IMediaManager _deviceManager;
        private readonly IProductPlansRepository _productPlanRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        private bool _isBusy;
        private bool _isHealthCondition;
        private bool _isBeneficiaryHealthCondition;
        private string _planType;
        private bool _isMyself;
        private bool _isSomeoneElse;
        private bool _isGroup;
        private string _firstName;
        private string _middleName;
        private string _lastName;
        private string _gender;
        private string _dateOfBirth;
        private string _genotype;
        private string _value;
        private string _phoneNumber;
        private string _address;
        private string _emailAddress;
        private string _stateOfResidence;
        private string _beneficiaryStateOfResidence;
        private string _selectedHospitalLocation;
        private string _selectedBeneficiaryHospitalLocation;
        private string _selectedHospital;
        private string _selectedBeneficiaryHospital;
        private string _town;
        private List<string> _states = new List<string>();
        private List<HealthStates> _myStates = new List<HealthStates>();
        private List<string> _myGenotypes = new List<string>();
        private List<Genotypes> _genotypes = new List<Genotypes>();
        private List<string> _preExistingCondition = new List<string>();
        private List<HealthPreExistingConditions> _myPreExistingConditions = new List<HealthPreExistingConditions>();
        private Hospitals _hospitals;
        private List<string> _myHospitals = new List<string>();
        private List<string> _myBeneficiaryHospitals = new List<string>();
        private List<Plans> _plans = new List<Plans>();
        private List<Towns> _towns = new List<Towns>();
        private List<string> _myTowns = new List<string>();
        private byte[] _contents;
        private string _meansOfIdentification;
        private string[] _fileTypes;
        private ObservableCollection<FileVariable> _fileNameList = new ObservableCollection<FileVariable>();
        private string _fileLabel;
        private string _contentType;
        private string _fileLabelPath;
        private string _passportPhotograph;
        private DateTime _beneficiaryDateOfBirth;
        private string _beneficiaryFirstName;
        private string _beneficiaryLastName;
        private string beneficiaryMiddleName;
        private string _beneficiaryGenotype;
        private string _beneficiaryGender;
        private string _beneficiaryEmailAddress;
        private string _beneficiaryTelephone;
        private string _beneficiaryTown;
        private bool _isConditionOne;
        private bool _isConditionTwo;
        private bool _isConditionThree;
        private bool _isConditionFour;
        private bool _isConditionFive;
        private bool _isConditionSix;
        private bool _isConditionSeven;
        private bool _isConditionEight;
        private bool _isConditionNine;
        private bool _isConditionTen;
        private bool _isConditionEleven;
        private bool _isConditionTwelve;
        private bool _isConditionThirteen;
        private bool _isConditionForteen;
        private bool _isConditionFifteen;
        private bool _isConditionSixteen;
        private List<bool> _myQuestions = new List<bool>();
        private List<bool> _myBeneficiaryQuestions = new List<bool>();
        private bool _addBenButtonClicked;
        private int _addBenButtonClickedCount;
        private ObservableCollection<HealthBeneficiary> _healthBeneficiaries = new ObservableCollection<HealthBeneficiary>();
        private string _beneficiarySelectedHospitalLocation;
        private string _beneficiarySelectedHospital;
        private List<HealthPreExistingConditions> _myBeneficiaryPreExistingConditions = new List<HealthPreExistingConditions>();
        private List<string> _beneficiaryPreExistingCondition = new List<string>();
        private bool _addBenButtonActive;
        private List<string> _myBeneficiaryTowns = new List<string>();
        private HealthProduct _healthProduct;
        private string _singleCost;
        private int _noOfPersons;
        private string _beneficiaryAddress;
        private Guid _prospectId;
        private string _maritalStatus;
        private string _bloodGroup;
        private string _occupation;
        private string _beneficiaryMaritalStatus;
        private string _beneficiaryBloodGroup;
        private string _beneficiaryOccupation;
        private SyncDataSample _occupations;
        private List<string> _myoccupations = new List<string>();
        private bool _isFromHospitalList;
        private string _selectedHospitalBindable;
        private string _beneficiaryHospitalBindable;

        public string BeneficiaryHospitalBindable
        {
            get { return _beneficiaryHospitalBindable; }
            set { SetProperty(ref _beneficiaryHospitalBindable, value); }
        }
        public string SelectedHospitalBindable
        {
            get { return _selectedHospitalBindable; }
            set { SetProperty(ref _selectedHospitalBindable, value); }
        }
        public bool IsFromHospitalList
        {
            get { return _isFromHospitalList; }
            set { SetProperty(ref _isFromHospitalList, value); }
        }
        public SyncDataSample Occupations
        {
            get { return _occupations; }
            set { SetProperty(ref _occupations, value); }
        }
        public List<string> MyOccupations
        {
            get { return _myoccupations; }
            set { SetProperty(ref _myoccupations, value); }
        }
        public string BeneficiaryOccupation
        {
            get { return _beneficiaryOccupation; }
            set { SetProperty(ref _beneficiaryOccupation, value); }
        }
        public string BeneficiaryBloodGroup
        {
            get { return _beneficiaryBloodGroup; }
            set { SetProperty(ref _beneficiaryBloodGroup, value); }
        }
        public string BeneficiaryMaritalStatus
        {
            get { return _beneficiaryMaritalStatus; }
            set { SetProperty(ref _beneficiaryMaritalStatus, value); }
        }
        public string Occupation
        {
            get { return _occupation; }
            set { SetProperty(ref _occupation, value); }
        }
        public string BloodGroup
        {
            get { return _bloodGroup; }
            set { SetProperty(ref _bloodGroup, value); }
        }
        public string MaritalStatus
        {
            get { return _maritalStatus; }
            set { SetProperty(ref _maritalStatus, value); }
        }
        public string BeneficiaryAddress
        {
            get { return _beneficiaryAddress; }
            set { SetProperty(ref _beneficiaryAddress, value); }
        }
        public int NoOfPersons
        {
            get { return _noOfPersons; }
            set { SetProperty(ref _noOfPersons, value); }
        }
        public string SingleCost
        {
            get { return _singleCost; }
            set { SetProperty(ref _singleCost, value); }
        }
        public HealthProduct HealthProduct
        {
            get { return _healthProduct; }
            set { SetProperty(ref _healthProduct, value); }
        }
        public List<HealthPreExistingConditions> MyBeneficiaryPreExistingConditions
        {
            get { return _myBeneficiaryPreExistingConditions; }
            set { SetProperty(ref _myBeneficiaryPreExistingConditions, value); }
        }
        public List<string> BeneficiaryPreExistingConditions
        {
            get { return _beneficiaryPreExistingCondition; }
            set { SetProperty(ref _beneficiaryPreExistingCondition, value); }
        }
        public string BeneficiarySelectedHospitalLocation
        {
            get { return _beneficiarySelectedHospitalLocation; }
            set { SetProperty(ref _beneficiarySelectedHospitalLocation, value); }
        }
        public string BeneficiarySelectedHospital
        {
            get { return _beneficiarySelectedHospital; }
            set { SetProperty(ref _beneficiarySelectedHospital, value); }
        }
        public ObservableCollection<HealthBeneficiary> HealthBeneficiaries
        {
            get { return _healthBeneficiaries; }
            set { SetProperty(ref _healthBeneficiaries, value); }
        }
        public int AddBenButtonClickedCount
        {
            get { return _addBenButtonClickedCount; }
            set { SetProperty(ref _addBenButtonClickedCount, value); }
        }
        public bool AddBenButtonClicked
        {
            get { return _addBenButtonClicked; }
            set { SetProperty(ref _addBenButtonClicked, value); }
        }
        public List<bool> MyQuestions
        {
            get { return _myQuestions; }
            set { SetProperty(ref _myQuestions, value); }
        }
        public List<bool> MyBeneficiaryQuestions
        {
            get { return _myBeneficiaryQuestions; }
            set { SetProperty(ref _myBeneficiaryQuestions, value); }
        }
        public bool IsConditionOne
        {
            get { return _isConditionOne; }
            set { SetProperty(ref _isConditionOne, value); }
        }
        public bool IsConditionTwo
        {
            get { return _isConditionTwo; }
            set { SetProperty(ref _isConditionTwo, value); }
        }
        public bool IsConditionThree
        {
            get { return _isConditionThree; }
            set { SetProperty(ref _isConditionThree, value); }
        }
        public bool IsConditionFour
        {
            get { return _isConditionFour; }
            set { SetProperty(ref _isConditionFour, value); }
        }
        public bool IsConditionFive
        {
            get { return _isConditionFive; }
            set { SetProperty(ref _isConditionFive, value); }
        }
        public bool IsConditionSix
        {
            get { return _isConditionSix; }
            set { SetProperty(ref _isConditionSix, value); }
        }
        public bool IsConditionSeven
        {
            get { return _isConditionSeven; }
            set { SetProperty(ref _isConditionSeven, value); }
        }
        public bool IsConditionEight
        {
            get { return _isConditionEight; }
            set { SetProperty(ref _isConditionEight, value); }
        }
        public bool IsConditionNine
        {
            get { return _isConditionNine; }
            set { SetProperty(ref _isConditionNine, value); }
        }
        public bool IsConditionTen
        {
            get { return _isConditionTen; }
            set { SetProperty(ref _isConditionTen, value); }
        }
        public bool IsConditionEleven
        {
            get { return _isConditionEleven; }
            set { SetProperty(ref _isConditionEleven, value); }
        }
        public bool IsConditionTwelve
        {
            get { return _isConditionTwelve; }
            set { SetProperty(ref _isConditionTwelve, value); }
        }
        public bool IsConditionThirteen
        {
            get { return _isConditionThirteen; }
            set { SetProperty(ref _isConditionThirteen, value); }
        }
        public bool IsConditionForteen
        {
            get { return _isConditionForteen; }
            set { SetProperty(ref _isConditionForteen, value); }
        }
        public bool IsConditionFifteen
        {
            get { return _isConditionFifteen; }
            set { SetProperty(ref _isConditionFifteen, value); }
        }
        public bool IsConditionSixteen
        {
            get { return _isConditionSixteen; }
            set { SetProperty(ref _isConditionSixteen, value); }
        }
        public string BeneficiaryTown
        {
            get { return _beneficiaryTown; }
            set { SetProperty(ref _beneficiaryTown, value); }
        }
        public string BeneficiaryStateOfResidence
        {
            get { return _beneficiaryStateOfResidence; }
            set { SetProperty(ref _beneficiaryStateOfResidence, value); }
        }
        public string BeneficiaryTelephone
        {
            get { return _beneficiaryTelephone; }
            set { SetProperty(ref _beneficiaryTelephone, value); }
        }
        public string BeneficiaryEmailAddress
        {
            get { return _beneficiaryEmailAddress; }
            set { SetProperty(ref _beneficiaryEmailAddress, value); }
        }
        public string BeneficiaryGender
        {
            get { return _beneficiaryGender; }
            set { SetProperty(ref _beneficiaryGender, value); }
        }
        public string BeneficiaryGenotype
        {
            get { return _beneficiaryGenotype; }
            set { SetProperty(ref _beneficiaryGenotype, value); }
        }
        public string BeneficiaryMiddleName
        {
            get { return beneficiaryMiddleName; }
            set { SetProperty(ref beneficiaryMiddleName, value); }
        }
        public string BeneficiaryLastName
        {
            get { return _beneficiaryLastName; }
            set { SetProperty(ref _beneficiaryLastName, value); }
        }
        public string BeneficiaryFirstName
        {
            get { return _beneficiaryFirstName; }
            set { SetProperty(ref _beneficiaryFirstName, value); }
        }
        public DateTime BeneficiaryDateOfBirth
        {
            get { return _beneficiaryDateOfBirth; }
            set { SetProperty(ref _beneficiaryDateOfBirth, value); }
        }
        public string PassportPhotograph
        {
            get { return _passportPhotograph; }
            set { SetProperty(ref _passportPhotograph, value); }
        }
        public string FileLabelPath
        {
            get { return _fileLabelPath; }
            set { SetProperty(ref _fileLabelPath, value); }
        }
        public string[] FileTypes
        {
            get { return _fileTypes; }
            set { SetProperty(ref _fileTypes, value); }
        }
        public string ContentType
        {
            get { return _contentType; }
            set { SetProperty(ref _contentType, value); }
        }
        public ObservableCollection<FileVariable> FileNameList
        {
            get { return _fileNameList; }
            set { SetProperty(ref _fileNameList, value); }
        }
        public string FileLabel
        {
            get { return _fileLabel; }
            set { SetProperty(ref _fileLabel, value); }
        }
        public string MeansOfIdentification
        {
            get { return _meansOfIdentification; }
            set { SetProperty(ref _meansOfIdentification, value); }
        }
        public byte[] Contents
        {
            get { return _contents; }
            set { SetProperty(ref _contents, value); }
        }
        public List<string> MyTowns
        {
            get { return _myTowns; }
            set { SetProperty(ref _myTowns, value); }
        }
        public List<string> MyBeneficiaryTowns
        {
            get { return _myBeneficiaryTowns; }
            set { SetProperty(ref _myBeneficiaryTowns, value); }
        }
        public List<Towns> Towns
        {
            get { return _towns; }
            set { SetProperty(ref _towns, value); }
        }
        public List<Plans> Plans
        {
            get { return _plans; }
            set { SetProperty(ref _plans, value); }
        }
        public List<string> MyHospitals
        {
            get { return _myHospitals; }
            set { SetProperty(ref _myHospitals, value); }
        }
        public List<string> MyBeneficiaryHospitals 
        {
            get { return _myBeneficiaryHospitals; }
            set { SetProperty(ref _myBeneficiaryHospitals, value); }
        }
        public Hospitals Hospitals
        {
            get { return _hospitals; }
            set { SetProperty(ref _hospitals, value); }
        }
        public string SelectedHospitalLocation
        {
            get { return _selectedHospitalLocation; }
            set { SetProperty(ref _selectedHospitalLocation, value); }
        }
        public string SelectedBeneficiaryHospitalLocation
        {
            get { return _selectedBeneficiaryHospitalLocation; }
            set { SetProperty(ref _selectedBeneficiaryHospitalLocation, value); }
        }
        public string SelectedBeneficiaryHospital
        {
            get { return _selectedBeneficiaryHospital; }
            set { SetProperty(ref _selectedBeneficiaryHospital, value); }
        }
        public string SelectedHospital
        {
            get { return _selectedHospital; }
            set { SetProperty(ref _selectedHospital, value); }
        }
        public List<HealthPreExistingConditions> MyPreExistingConditions
        {
            get { return _myPreExistingConditions; }
            set { SetProperty(ref _myPreExistingConditions, value); }
        }
        public List<string> PreExistingConditions
        {
            get { return _preExistingCondition; }
            set { SetProperty(ref _preExistingCondition, value); }
        }
        public List<Genotypes> Genotypes
        {
            get { return _genotypes; }
            set { SetProperty(ref _genotypes, value); }
        }
        public List<string> MyGenotypes
        {
            get { return _myGenotypes; }
            set { SetProperty(ref _myGenotypes, value); }
        }
        public List<HealthStates> MyStates
        {
            get { return _myStates; }
            set { SetProperty(ref _myStates, value); }
        }
        public List<string> States
        {
            get { return _states; }
            set { SetProperty(ref _states, value); }
        }
        public string StateOfResidence
        {
            get { return _stateOfResidence; }
            set { SetProperty(ref _stateOfResidence, value); }
        }
        public string Town
        {
            get { return _town; }
            set { SetProperty(ref _town, value); }
        }
        public string Value
        {
            get { return _value; }
            set { SetProperty(ref _value, value); }
        }
        public string FirstName
        {
            get { return _firstName; }
            set { SetProperty(ref _firstName, value); }
        }
        public string MiddleName
        {
            get { return _middleName; }
            set { SetProperty(ref _middleName, value); }
        }
        public string LastName
        {
            get { return _lastName; }
            set { SetProperty(ref _lastName, value); }
        }
        public string Gender
        {
            get { return _gender; }
            set { SetProperty(ref _gender, value); }
        }
        public string DateOfBirth
        {
            get { return _dateOfBirth; }
            set { SetProperty(ref _dateOfBirth, value); }
        }
        public string Genotype
        {
            get { return _genotype; }
            set { SetProperty(ref _genotype, value); }
        }
        public bool IsMyself
        {
            get { return _isMyself; }
            set { SetProperty(ref _isMyself, value); }
        }
        public bool IsSomeoneElse
        {
            get { return _isSomeoneElse; }
            set { SetProperty(ref _isSomeoneElse, value); }
        }
        public bool IsGroup
        {
            get { return _isGroup; }
            set { SetProperty(ref _isGroup, value); }
        }
        public bool ActiveAddBenButton
        {
            get { return _addBenButtonActive; }
            set { SetProperty(ref _addBenButtonActive, value); }
        }
        public string PlanType
        {
            get { return _planType; }
            set { SetProperty(ref _planType, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public bool IsBeneficiaryHealthCondition
        {
            get { return _isBeneficiaryHealthCondition; }
            set { SetProperty(ref _isBeneficiaryHealthCondition, value); }
        }
        public bool IsHealthCondition
        {
            get { return _isHealthCondition; }
            set { SetProperty(ref _isHealthCondition, value); }
        }
        public string Address
        {
            get { return _address; }
            set { SetProperty(ref _address, value); }
        }
        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { SetProperty(ref _phoneNumber, value); }
        }
        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }
        public Agent LoggedAgent { get; set; }
        public Prospect SelectedProspect { get; set; }
        public ProductPlan ProductPlan { get; set; }
        public HealthAPICredentials HealthAPICredentials { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }

        private DelegateCommand _isMyselfToggledCommand;
        private DelegateCommand _isSomeoneElseCommand;
        private DelegateCommand _isGroupCommand;
        private DelegateCommand _isHealthConditionCommand;
        private DelegateCommand _isBeneficiaryHealthConditionCommand;
        private DelegateCommand _changeStateCommand;
        private DelegateCommand _changeBeneficiaryStateCommand;
        private DelegateCommand _changeHospitalLocationCommand;
        private DelegateCommand _changeBeneficiaryHospitalLocationCommand;
        private DelegateCommand _pickMeansOfIdentificatioinCommand;
        private DelegateCommand _pickPassportCommand;
        private DelegateCommand _proceedCommand;
        private DelegateCommand _addBeneficiaryCommand;
        private DelegateCommand _pickHospitalCommand;
        private DelegateCommand _pickGroupHospitalCommand;



        public DelegateCommand IsMyselfToggledCommand => _isMyselfToggledCommand ?? (_isMyselfToggledCommand = new DelegateCommand(ExecuteMyselfToggledCommand));
        public DelegateCommand IsSomeoneElseCommand => _isSomeoneElseCommand ?? (_isSomeoneElseCommand = new DelegateCommand(ExecuteSomeoneElseToggledCommand));
        public DelegateCommand IsGroupCommand => _isGroupCommand ?? (_isGroupCommand = new DelegateCommand(ExecuteGroupToggledCommand));
        public DelegateCommand IsHealthConditionCommand => _isHealthConditionCommand ?? (_isHealthConditionCommand = new DelegateCommand(ExecuteHealthConditionCommand));
        public DelegateCommand IsBeneficiaryHealthConditionCommand => _isBeneficiaryHealthConditionCommand ?? (_isBeneficiaryHealthConditionCommand = new DelegateCommand(ExecuteBeneficiaryHealthConditionCommand));
        public DelegateCommand ChangeStateCommand => _changeStateCommand ?? (_changeStateCommand = new DelegateCommand(ExecuteChangeStateCommand));
        public DelegateCommand ChangeBeneficiaryStateCommand => _changeBeneficiaryStateCommand ?? (_changeBeneficiaryStateCommand = new DelegateCommand(ExecuteChangeBeneficiaryStateCommand));
        public DelegateCommand ChangeHospitalLocationCommand => _changeHospitalLocationCommand ?? (_changeHospitalLocationCommand = new DelegateCommand(ExecuteChangeHospitalLocationCommand));
        public DelegateCommand ChangeBeneficiaryHospitalLocationCommand => _changeBeneficiaryHospitalLocationCommand ?? (_changeBeneficiaryHospitalLocationCommand = new DelegateCommand(ExecuteChangeBeneficiaryHospitalLocationCommand));
        public DelegateCommand PickMeansOfIdentificationCommand => _pickMeansOfIdentificatioinCommand ?? (_pickMeansOfIdentificatioinCommand = new DelegateCommand(ExecutePickMeansOfIdenticationCommand));
        public DelegateCommand PickPassportCommand => _pickPassportCommand ?? (_pickPassportCommand = new DelegateCommand(ExecutePickPassportCommand));
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProceedCommand));
        public DelegateCommand AddBeneficiaryCommand => _addBeneficiaryCommand ?? (_addBeneficiaryCommand = new DelegateCommand(ExecuteAddBeneficiaryCommand));
        public DelegateCommand PickGroupHospitalCommand => _pickGroupHospitalCommand ?? (_pickGroupHospitalCommand = new DelegateCommand(ExecutePickGroupHospitalCommand));
        public DelegateCommand PickHospitalCommand => _pickHospitalCommand ?? (_pickHospitalCommand = new DelegateCommand(ExecutePickHospitalCommand));

        public HealthBookingPageViewModel(INavigationService navigationService, IPageDialogService pageDialogService, IProspectRepository prospectRepository, IMediaManager mediaManager,
            IAgentRepository agentRepository, IProductPlansRepository productPlansRepository, Logical logical, EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _prospectRepository = prospectRepository;
            _agentRepository = agentRepository;
            _productPlanRepository = productPlansRepository;
            _deviceManager = mediaManager;
            _logical = logical;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }

                if (parameters.ContainsKey("AgentId"))
                {
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out Guid agentId))
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                }

                if (parameters.ContainsKey("ProductPlanId"))
                {
                    if (Guid.TryParse(parameters["ProductPlanId"].ToString(), out Guid _productPlanId))
                        ProductPlan = await _productPlanRepository.GetProductPlanByProductPlanId(_productPlanId);
                }

                if (parameters.ContainsKey("IsGroup"))
                {
                    IsGroup = parameters.GetValue<bool>("IsGroup");
                    if (IsGroup)
                    {
                        BeneficiarySelectedHospital = parameters.GetValue<string>("SelectedHospital");
                        BeneficiaryHospitalBindable = BeneficiarySelectedHospital;
                    }
                    else
                    {
                        SelectedHospital = parameters.GetValue<string>("SelectedHospital");
                        SelectedHospitalBindable = SelectedHospital;
                    }
                    IsBusy = false;
                    return;
                }

                //if (!parameters.ContainsKey("fromHospitalLists"))
                //{
                    await InitializeDefaultValues();
                //}
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async Task InitializeDefaultValues()
        {
            IsBusy = true;
            try
            {
                HealthBeneficiaries.Clear();
                MyTowns.Clear();
                MyBeneficiaryHospitals.Clear();
                MyBeneficiaryTowns.Clear();

                Town = SelectedHospital = string.Empty;

                BeneficiaryDateOfBirth = DateTime.Parse("1/1/1980 12:00:00 PM");
                IsMyself = true;
                PlanType = ProductPlan.PlanCategory;
                FirstName = SelectedProspect.FirstName;
                LastName = SelectedProspect.LastName;
                MiddleName = SelectedProspect.MiddleName != string.Empty ? SelectedProspect.MiddleName : "N/A";
                Gender = SelectedProspect.Gender == 0 ? "Female" : "Male";
                DateOfBirth = SelectedProspect.Birthdate.ToString("dd/MM/yyyy");
                Address = SelectedProspect.Address;
                PhoneNumber = SelectedProspect.MobileNumber;
                EmailAddress = SelectedProspect.Email;

                Occupations = await _logical.GetOccupationList();
                MyOccupations = Occupations.Result.Select(x => x.NAME).ToList();
                MyOccupations = MyOccupations.Where(x => x != "Occupation").ToList();

                #region Sync in Health API dropdown Values
                HealthAPICredentials = await _logical.GetHealthAPICredentials();
                Genotypes = await _logical.GetGenotypes(HealthAPICredentials.URL, HealthAPICredentials.APIKey);
                if (Genotypes != null && Genotypes.Count > 0)
                {
                    foreach (Genotypes item in Genotypes)
                    {
                        string genotype = string.Empty;
                        genotype = item.Genotype1;
                        MyGenotypes.Add(genotype);
                    }
                    MyGenotypes = MyGenotypes.ToList();
                }

                MyStates = await _logical.GetHealthStates(HealthAPICredentials.URL, HealthAPICredentials.APIKey);
                if(MyStates != null && MyStates.Count > 0)
                {
                    foreach(HealthStates item in MyStates)
                    {
                        string state = string.Empty;
                        state = item.State;
                        if(!States.Contains(state))
                            States.Add(state);
                    }
                    States = States.ToList();
                }
                Plans = await _logical.GetHealthPlanCost(HealthAPICredentials.URL, HealthAPICredentials.APIKey);
                SingleCost = Plans.Where(x => x.Name.ToLower() == PlanType.ToLower()).FirstOrDefault().Value.ToString();
                Value = "Value: N" + SingleCost;
                NoOfPersons = 1;
                #endregion
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private void RemoveMyself()
        {
            IsMyself = false;
        }

        private void RemoveSomeoneElse()
        {
            IsSomeoneElse = false;
        }

        private void RemoveGroup()
        {
            IsGroup = false;
        }

        private void ExecuteMyselfToggledCommand()
        {
            IsBusy = true;
            try
            {
                RemoveSomeoneElse();
                RemoveGroup();
                IsMyself = true;
                ActiveAddBenButton = false;
                AddBenButtonClicked = false;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private void ExecuteSomeoneElseToggledCommand()
        {
            IsBusy = true;
            try
            {
                RemoveMyself();
                RemoveGroup();
                IsSomeoneElse = true;
                ActiveAddBenButton = false;
                AddBenButtonClicked = false;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private void ExecuteGroupToggledCommand()
        {
            IsBusy = true;
            try
            {
                RemoveMyself();
                RemoveSomeoneElse();
                IsGroup = true;
                ActiveAddBenButton = true;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async void ExecuteHealthConditionCommand()
        {

            IsBusy = true;
            try
            {
                await _pageDialogService.DisplayAlertAsync("Ooops!", "This booking cannot be completed on AXA Sol Lite due to the stated pre-existing conditions. Kindly use the Referral link to refer the customer to the website to buy policy", "Okay");
                //PreExistingConditions.Clear();
                //MyPreExistingConditions = await _logical.GetPreExistingConditions(HealthAPICredentials.URL, HealthAPICredentials.APIKey);
                //if (MyPreExistingConditions != null && MyPreExistingConditions.Count > 0)
                //{
                //    foreach (HealthPreExistingConditions item in MyPreExistingConditions)
                //    {
                //        string condition = string.Empty;
                //        condition = item.PreexistingCondition1;
                //        PreExistingConditions.Add(condition);
                //    }
                //}
                await _navigationService.GoBackAsync();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async void ExecuteBeneficiaryHealthConditionCommand()
        {
            IsBusy = true;
            try
            {
                await _pageDialogService.DisplayAlertAsync("Ooops!", "This booking cannot be completed on AXA Sol Lite due to the stated pre-existing conditions. Kindly use the Referral link to refer the customer to the website to buy policy", "Okay");
                //BeneficiaryPreExistingConditions.Clear();
                //MyBeneficiaryPreExistingConditions.Clear();
                //MyBeneficiaryPreExistingConditions = await _logical.GetPreExistingConditions(HealthAPICredentials.URL, HealthAPICredentials.APIKey);
                //if (MyBeneficiaryPreExistingConditions != null && MyBeneficiaryPreExistingConditions.Count > 0)
                //{
                //    foreach (HealthPreExistingConditions item in MyBeneficiaryPreExistingConditions)
                //    {
                //        string condition = string.Empty;
                //        condition = item.PreexistingCondition1;
                //        BeneficiaryPreExistingConditions.Add(condition);
                //    }
                //}
                await _navigationService.GoBackAsync();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async void ExecuteChangeBeneficiaryStateCommand()
        {
            IsBusy = true;
            try
            {
                MyBeneficiaryTowns.Clear();
                Towns.Clear();
                if (!string.IsNullOrEmpty(BeneficiaryStateOfResidence))
                {
                    Towns = await _logical.GetHealthTowns(HealthAPICredentials.URL, HealthAPICredentials.APIKey, BeneficiaryStateOfResidence);
                    if (Towns != null && Towns.Count > 0)
                    {
                        foreach (Towns item in Towns)
                        {
                            string town = string.Empty;
                            town = item.TownName;
                            MyBeneficiaryTowns.Add(town);
                        }
                        MyBeneficiaryTowns = MyBeneficiaryTowns.ToList();
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async void ExecuteChangeStateCommand()
        {
            IsBusy = true;
            try
            {
                MyTowns.Clear();
                if (!string.IsNullOrEmpty(StateOfResidence))
                {
                    Towns = await _logical.GetHealthTowns(HealthAPICredentials.URL, HealthAPICredentials.APIKey, StateOfResidence);
                    if(Towns != null && Towns.Count > 0)
                    {
                        foreach(Towns item in Towns)
                        {
                            string town = string.Empty;
                            town = item.TownName;
                            MyTowns.Add(town);
                        }
                        MyTowns = MyTowns.ToList();
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async void ExecuteChangeHospitalLocationCommand()
        {
            IsBusy = true;
            try
            {
                MyHospitals.Clear();
                if (!string.IsNullOrEmpty(SelectedHospitalLocation))
                {
                    string plan = Plans.Where(x => x.Name.ToLower() == PlanType.ToLower()).FirstOrDefault().Code.ToString();
                    Hospitals = await _logical.GetHospitals(HealthAPICredentials.URL, HealthAPICredentials.APIKey, plan, SelectedHospitalLocation);
                    if(Hospitals != null && Hospitals.ReturnedObject != null && Hospitals.ReturnedObject.Count > 0)
                    {
                        foreach(ReturnedObject item in Hospitals.ReturnedObject)
                        {
                            string hospital = string.Empty;
                            hospital = item.HospitalDetails;
                            MyHospitals.Add(hospital);
                        }
                    }
                    MyHospitals = MyHospitals.ToList();
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async void ExecuteChangeBeneficiaryHospitalLocationCommand()
        {
            IsBusy = true;
            try
            {
                MyBeneficiaryHospitals.Clear();
                Hospitals = null;
                if (!string.IsNullOrEmpty(SelectedBeneficiaryHospitalLocation))
                {
                    string plan = Plans.Where(x => x.Name.ToLower() == PlanType.ToLower()).FirstOrDefault().Code.ToString();
                    Hospitals = await _logical.GetHospitals(HealthAPICredentials.URL, HealthAPICredentials.APIKey, plan, SelectedBeneficiaryHospitalLocation);
                    if (Hospitals != null && Hospitals.ReturnedObject != null && Hospitals.ReturnedObject.Count > 0)
                    {
                        foreach (ReturnedObject item in Hospitals.ReturnedObject)
                        {
                            string hospital = string.Empty;
                            hospital = item.HospitalDetails;
                            MyBeneficiaryHospitals.Add(hospital);
                        }
                    }
                    MyBeneficiaryHospitals = MyBeneficiaryHospitals.ToList();
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async void ExecutePickMeansOfIdenticationCommand()
        {
            try
            {
                bool choice = await _pageDialogService.DisplayAlertAsync("Confirm", "Please select how you wish to upload a document", "Camera", "Gallery");

                if (choice)
                {
                    if (_deviceManager.CameraAvailable)
                    {
                        var newPhoto = await _deviceManager.TakePhotoAsync();

                        if (newPhoto != null && newPhoto.FileContent.Length <= 4194304)
                        {
                            Contents = newPhoto.FileContent;
                            FileVariable CameraTaken = new FileVariable
                            {
                                FileName = newPhoto.FileName,
                                FileContent = Convert.ToBase64String(Contents),
                                FieldName = "Means Of Identification",
                                ContentType = "image/jpg",
                                Extension = "jpg"
                            };
                            MeansOfIdentification = newPhoto.FileName;
                            FileNameList.Add(CameraTaken);
                            await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");
                        }
                        else
                        {
                            await _pageDialogService.DisplayAlertAsync("Unsuccessful", "Document failed to upload. Picture is most likely too large. Please try the gallery option instead.", "Ok");
                        }
                    }
                }
                else
                {
                    if (Device.RuntimePlatform == Device.Android)
                    {
                        FileTypes = new string[] { "image/png", "image/jpeg", "application/pdf" };
                    }

                    await PickedFiles(FileTypes);
                    MeansOfIdentification = FileLabel;
                    FileVariable customerFile = new FileVariable
                    {
                        FileName = MeansOfIdentification,
                        FileContent = Convert.ToBase64String(Contents),
                        FieldName = "Means Of Identification",
                        ContentType = ContentType,
                        Extension = !ContentType.ToLower().Contains("jpeg") ? ContentType.Substring((ContentType.Length - 3), 3) : ContentType.Substring((ContentType.Length - 4), 4)
                    };
                    FileNameList.Add(customerFile);
                    if (MeansOfIdentification != null && Contents != null)
                    {
                        if (Contents.Length > 3145728)
                        {
                            MeansOfIdentification = null;
                            Contents = null;
                            await _pageDialogService.DisplayAlertAsync("Error", "File size too large. Please upload a document not larger than 3MB in size", "Cancel");
                        }
                        else
                        {
                            await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");
                        }
                    }
                    else
                        await _pageDialogService.DisplayAlertAsync("Unsuccessful", "Document failed to upload. Please try again.", "Ok");
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecutePickPassportCommand()
        {
            try
            {
                bool choice = await _pageDialogService.DisplayAlertAsync("Confirm", "Please select how you wish to upload a document", "Camera", "Gallery");

                if (choice)
                {
                    if (_deviceManager.CameraAvailable)
                    {
                        var newPhoto = await _deviceManager.TakePhotoAsync();

                        if (newPhoto != null && newPhoto.FileContent.Length <= 4194304)
                        {
                            Contents = newPhoto.FileContent;
                            FileVariable CameraTaken = new FileVariable
                            {
                                FileName = newPhoto.FileName,
                                FileContent = Convert.ToBase64String(Contents),
                                FieldName = "Passport Photogragh",
                                ContentType = "image/jpg",
                                Extension = "jpg"
                            };
                            PassportPhotograph = newPhoto.FileName;
                            FileNameList.Add(CameraTaken);
                            await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");
                        }
                    }
                }
                else
                {
                    if (Device.RuntimePlatform == Device.Android)
                    {
                        FileTypes = new string[] { "image/png", "image/jpeg", "application/pdf" };
                    }

                    await PickedFiles(FileTypes);
                    PassportPhotograph = FileLabel;
                    FileVariable customerFile = new FileVariable
                    {
                        FileName = PassportPhotograph,
                        FileContent = Convert.ToBase64String(Contents),
                        FieldName = "Passport Photograph",
                        ContentType = ContentType,
                        Extension = !ContentType.ToLower().Contains("jpeg") ? ContentType.Substring((ContentType.Length - 3), 3) : ContentType.Substring((ContentType.Length - 4), 4)
                    };

                    FileNameList.Add(customerFile);

                    if (PassportPhotograph != null && Contents != null)
                    {
                        if (Contents.Length > 3145728)
                        {
                            PassportPhotograph = null;
                            Contents = null;
                            await _pageDialogService.DisplayAlertAsync("Error", "File size too large. Please upload a document not larger than 3MB in size", "Cancel");
                        }
                        else
                            await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");
                    }
                    else
                        await _pageDialogService.DisplayAlertAsync("Unsuccessful", "Document failed to upload. Please try again.", "Ok");
                }
            }

            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public async Task PickedFiles(string[] fileTypes)
        {
            try
            {
                var pickedFile = await CrossFilePicker.Current.PickFile(fileTypes);
                if (pickedFile != null)
                {
                    FileLabel = pickedFile.FileName;
                    FileLabelPath = pickedFile.FilePath;

                    if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("jpeg", StringComparison.OrdinalIgnoreCase))
                    {
                        Contents = pickedFile.DataArray;

                        if (pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "application/pdf";
                        }
                        else if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "image" + "/jpg";
                        }
                        else if (pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "image" + "/png";
                        }
                        else
                            ContentType = "image" + "/jpeg";
                    }
                    else
                        await _pageDialogService.DisplayAlertAsync("Error", "Only .pdf, .png and .jpg files can be uploaded", "Ok");
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteProceedCommand()
        {
            IsBusy = true;
            int BeneficiaryAge = 0;
            bool AllConditionsMet = false;
            try
            {
                MyQuestions.Clear();

                if (IsMyself)
                {
                    if (IsHealthCondition)
                    {
                        await _pageDialogService.DisplayAlertAsync("Ooops!", "This booking cannot be completed on AXA Sol Lite due to the stated pre-existing conditions. Kindly use the Referral link to refer the customer to the website to buy policy", "Okay");
                        //foreach (var item in MyPreExistingConditions)
                        //{
                        //    bool isToggled = false;
                        //    isToggled = item.IsToggled;
                        //    MyQuestions.Add(isToggled);
                        //}
                        //MyQuestions = MyQuestions.ToList();
                        //var res = MyQuestions.FindAll(
                        //   delegate (bool exist)
                        //   {
                        //       return exist == true;
                        //   });
                        //if (res.Count == 0)
                        //{
                        //    await _pageDialogService.DisplayAlertAsync("Invalid Action", "Kindly specify a medical condition or untoggle the pre-existing medical condition clause", "Ok");
                        IsBusy = false;
                        return;
                        //}
                    }

                    //if (string.IsNullOrEmpty(Genotype))
                    //{
                    //    await _pageDialogService.DisplayAlertAsync("Error", "Kindly select genotype", "Ok");
                    //}
                    else if (string.IsNullOrEmpty(StateOfResidence))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly select state", "Ok");
                    }
                    else if (string.IsNullOrEmpty(Town))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly select town", "Ok");
                    }
                    else if (string.IsNullOrEmpty(SelectedHospitalLocation))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly select preferred hospital location", "Ok");
                    }
                    else if (string.IsNullOrEmpty(SelectedHospitals.SelectedHospitalName/*SelectedHospital*/))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly select preferred hospital", "Ok");
                    }
                    else if (string.IsNullOrEmpty(PassportPhotograph))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly upload passport photograph", "Ok");
                    }
                    else if (string.IsNullOrEmpty(MeansOfIdentification))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly upload ID", "Ok");
                    }
                    else
                    {
                        HealthProduct healthProduct = new HealthProduct
                        {
                            Gender = Gender,
                            Plan = PlanType,
                            Genotype = Genotype,
                            PreferredHospital = SelectedHospitals.SelectedHospitalName, //SelectedHospital,
                            PreferredHospitalLocation = SelectedHospitalLocation,
                            State = StateOfResidence,
                            Town = Town,
                            Value = (Convert.ToDouble(SingleCost) * NoOfPersons),
                            Beneficiaries = HealthBeneficiaries.ToList(),
                            PreExistingConditions = MyPreExistingConditions,
                            Occupation = Occupation,
                            MaritalStatus = MaritalStatus,
                            BloodGroup = BloodGroup,
                            APIKey = HealthAPICredentials.APIKey,
                            Salt = HealthAPICredentials.Salt,
                            UploadedDocuments = FileNameList.ToList(),
                            token = HealthAPICredentials.APIKey,
                            URL = HealthAPICredentials.URL,
                            OwnershipType = 1
                        };

                        healthProduct.UploadedDocuments = FileNameList.ToList();

                        HealthProduct = healthProduct;

                        ProductPlan.AmountPaid = healthProduct.Value.ToString();
                        int updated = await _productPlanRepository.UpdateAsync(ProductPlan);
                        AllConditionsMet = true;
                    }
                }
                else if (IsSomeoneElse)
                {
                    if (IsHealthCondition)
                    {
                        await _pageDialogService.DisplayAlertAsync("Ooops!", "This booking cannot be completed on AXA Sol Lite due to the stated pre-existing conditions. Kindly use the Referral link to refer the customer to the website to buy policy", "Okay");
                        //foreach (var item in MyPreExistingConditions)
                        //{
                        //    bool isToggled = false;
                        //    isToggled = item.IsToggled;
                        //    MyQuestions.Add(isToggled);
                        //}
                        //MyQuestions = MyQuestions.ToList();
                        //var res = MyQuestions.FindAll(
                        //   delegate (bool exist)
                        //   {
                        //       return exist == true;
                        //   });
                        //if (res.Count == 0)
                        //{
                        //    await _pageDialogService.DisplayAlertAsync("Invalid Action", "Kindly specify a medical condition or untoggle the pre-existing medical condition clause", "Ok");
                        IsBusy = false;
                           return;
                        //}
                    }

                    BeneficiaryAge = (DateTime.Now.Year) - (BeneficiaryDateOfBirth.Year);

                    if (string.IsNullOrEmpty(BeneficiaryFirstName))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly enter beneficiary first name", "Ok");
                    }
                    else if (string.IsNullOrEmpty(BeneficiaryLastName))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly enter beneficiary last name", "Ok");
                    }
                    else if (string.IsNullOrEmpty(BeneficiaryGender))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly select beneficiary gender", "Ok");
                    }
                    else if ((BeneficiaryAge < 18 || BeneficiaryAge > 65))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Beneficiary age has to be within 18 and 65", "Ok");
                    }
                    //else if (string.IsNullOrEmpty(BeneficiaryGenotype))
                    //{
                    //    await _pageDialogService.DisplayAlertAsync("Error", "Kindly select beneficiary genotype", "Ok");
                    //}
                    else if (string.IsNullOrEmpty(StateOfResidence))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly select state", "Ok");
                    }
                    else if (string.IsNullOrEmpty(Town))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly select town", "Ok");
                    }
                    else if (string.IsNullOrEmpty(BeneficiaryEmailAddress))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly enter beneficiary email address", "Ok");
                    }
                    else if (string.IsNullOrEmpty(BeneficiaryTelephone))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly enter beneficiary telephone", "Ok");
                    }
                    else if (string.IsNullOrEmpty(SelectedHospitalLocation))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly select preferred hospital location", "Ok");
                    }
                    else if (string.IsNullOrEmpty(SelectedHospitals.SelectedHospitalName /*SelectedHospital*/))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly select preferred hospital", "Ok");
                    }
                    else if (string.IsNullOrEmpty(BeneficiaryAddress))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly enter beneficiary address", "Ok");
                    }
                    else if (string.IsNullOrEmpty(PassportPhotograph))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly upload passport photograph", "Ok");
                    }
                    else if (string.IsNullOrEmpty(MeansOfIdentification))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly upload ID", "Ok");
                    }
                    else
                    {
                        HealthBeneficiary healthBeneficiary = new HealthBeneficiary
                        {
                            EmailAddress = BeneficiaryEmailAddress,
                            DateOfBirth = BeneficiaryDateOfBirth,
                            FirstName = BeneficiaryFirstName,
                            Gender = BeneficiaryGender,
                            Genotype = BeneficiaryGenotype,
                            LastName = BeneficiaryLastName,
                            MiddleName = BeneficiaryMiddleName,
                            PhoneNumber = BeneficiaryTelephone,
                            Occupation = BeneficiaryOccupation,
                            MaritalStatus = BeneficiaryMaritalStatus,
                            BloodGroup = BeneficiaryBloodGroup,
                            PreferredHospital = SelectedHospitals.SelectedHospitalName, //SelectedHospital,
                            PreferredHospitalLocation = SelectedHospitalLocation,
                            State = StateOfResidence,
                            Town = Town,
                            Address = BeneficiaryAddress,
                            IsVisible = true,
                            PreExistingConditions = MyBeneficiaryPreExistingConditions
                        };

                        HealthBeneficiaries.Add(healthBeneficiary);

                        HealthProduct healthProduct = new HealthProduct
                        {
                            Gender = Gender,
                            Genotype = BeneficiaryGenotype,
                            Plan = PlanType,
                            APIKey = HealthAPICredentials.APIKey,
                            Salt = HealthAPICredentials.Salt,
                            PreferredHospital = SelectedHospitals.SelectedHospitalName,
                            PreferredHospitalLocation = SelectedHospitalLocation,
                            State = StateOfResidence,
                            Town = Town,
                            Value = (Convert.ToDouble(SingleCost) * NoOfPersons),
                            Beneficiaries = HealthBeneficiaries.ToList(),
                            PreExistingConditions = MyPreExistingConditions,
                            UploadedDocuments = FileNameList.ToList(),
                            token = HealthAPICredentials.APIKey,
                            URL = HealthAPICredentials.URL,
                            OwnershipType = 2
                        };

                        healthProduct.UploadedDocuments = FileNameList.ToList();

                        HealthProduct = healthProduct;

                        ProductPlan.AmountPaid = healthProduct.Value.ToString();
                        int updated = await _productPlanRepository.UpdateAsync(ProductPlan);
                        AllConditionsMet = true;
                    }
                    
                }
                else if (IsGroup)
                {
                    if (IsHealthCondition)
                    {
                        await _pageDialogService.DisplayAlertAsync("Ooops!", "This booking cannot be completed on AXA Sol Lite due to the stated pre-existing conditions. Kindly use the Referral link to refer the customer to the website to buy policy", "Okay");
                        //foreach (var item in MyPreExistingConditions)
                        //{
                        //    bool isToggled = false;
                        //    isToggled = item.IsToggled;
                        //    MyQuestions.Add(isToggled);
                        //}
                        //MyQuestions = MyQuestions.ToList();
                        //var res = MyQuestions.FindAll(
                        //   delegate (bool exist)
                        //   {
                        //       return exist == true;
                        //   });
                        //if (res.Count == 0)
                        //{
                        //    await _pageDialogService.DisplayAlertAsync("Invalid Action", "Kindly specify a medical condition or untoggle the pre-existing medical condition clause", "Ok");
                        //    IsBusy = false;
                        return;
                        //}
                    }
                    if (!AddBenButtonClicked)
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly add a beneficiary", "Ok");
                        IsBusy = false;
                        return;
                    }                   
                    if (string.IsNullOrEmpty(StateOfResidence))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly select principal state", "Ok");
                        IsBusy = false;
                        return;
                    }
                    else if (string.IsNullOrEmpty(Town))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly select principal town", "Ok");
                        IsBusy = false;
                        return;
                    }
                    else if (string.IsNullOrEmpty(SelectedHospitalLocation))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly select principal preferred hospital location", "Ok");
                        IsBusy = false;
                        return;
                    }
                    else if (string.IsNullOrEmpty(SelectedHospitals.SelectedHospitalName/*SelectedHospital*/))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly select principal preferred hospital", "Ok");
                        IsBusy = false;
                        return;
                    }
                    //else if (string.IsNullOrEmpty(Genotype))
                    //{
                    //    await _pageDialogService.DisplayAlertAsync("Error", "Kindly select principal genotype", "Ok");
                    //    IsBusy = false;
                    //    return;
                    //}
                    else if (string.IsNullOrEmpty(PassportPhotograph))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly upload passport photograph", "Ok");
                    }
                    else if (string.IsNullOrEmpty(MeansOfIdentification))
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Kindly upload ID", "Ok");
                    }
                    else if (ActiveAddBenButton || HealthBeneficiaries.Count > 0)
                    {
                        if (string.IsNullOrEmpty(BeneficiaryFirstName))
                        {
                            await _pageDialogService.DisplayAlertAsync("Warning", "Kindly enter beneficiary first name", "Ok");
                        }
                        else if (string.IsNullOrEmpty(BeneficiaryLastName))
                        {
                            await _pageDialogService.DisplayAlertAsync("Warning", "Kindly enter beneficiary Last name", "Ok");
                        }
                        else if (string.IsNullOrEmpty(BeneficiaryGender))
                        {
                            await _pageDialogService.DisplayAlertAsync("Warning", "Kindly select beneficiary gender", "Ok");
                        }
                        //else if (string.IsNullOrEmpty(BeneficiaryGenotype))
                        //{
                        //    await _pageDialogService.DisplayAlertAsync("Warning", "Kindly select beneficiary genotype", "Ok");
                        //}
                        else if (string.IsNullOrEmpty(BeneficiaryTown))
                        {
                            await _pageDialogService.DisplayAlertAsync("Warning", "Kindly select beneficiary town", "Ok");
                        }
                        else if (string.IsNullOrEmpty(BeneficiaryFirstName))
                        {
                            await _pageDialogService.DisplayAlertAsync("Warning", "Kindly enter beneficiary email address", "Ok");
                        }
                        else if (string.IsNullOrEmpty(BeneficiaryTelephone))
                        {
                            await _pageDialogService.DisplayAlertAsync("Warning", "Kindly enter beneficiary phone number", "Ok");
                        }
                        else if (string.IsNullOrEmpty(SelectedHospitals.HospitalName[(SelectedHospitals.HospitalName.Count - 1)] /*BeneficiarySelectedHospital*/))
                        {
                            await _pageDialogService.DisplayAlertAsync("Warning", "Kindly select preferred hospital for beneficiary", "Ok");
                        }
                        else if (string.IsNullOrEmpty(BeneficiaryAddress))
                        {
                            await _pageDialogService.DisplayAlertAsync("Warning", "Kindly enter beneficiary address", "Ok");
                        }
                        else if ((DateTime.Now.Year - BeneficiaryDateOfBirth.Year) > 65 || (DateTime.Now.Year - BeneficiaryDateOfBirth.Year < 18))
                        {
                            await _pageDialogService.DisplayAlertAsync("Error", "Beneficiary age has to be within 18 and 65", "Ok");
                        }
                        else
                        {
                            NoOfPersons += 1;
                            Value = "Value: N" + (Convert.ToDouble(SingleCost) * NoOfPersons).ToString("N0");

                            if (IsBeneficiaryHealthCondition)
                            {
                                await _pageDialogService.DisplayAlertAsync("Ooops!", "This booking cannot be completed on AXA Sol Lite due to the stated pre-existing conditions. Kindly use the Referral link to refer the customer to the website to buy policy", "Okay");
                                //foreach (var item in MyBeneficiaryPreExistingConditions)
                                //{
                                //    bool isToggled = false;
                                //    isToggled = item.IsToggled;
                                //    MyBeneficiaryQuestions.Add(isToggled);
                                //}
                                //MyBeneficiaryQuestions = MyBeneficiaryQuestions.ToList();
                                //var res = MyBeneficiaryQuestions.FindAll(
                                //   delegate (bool exist)
                                //   {
                                //       return exist == true;
                                //   });
                                //if (res.Count == 0)
                                //{
                                //    await _pageDialogService.DisplayAlertAsync("Invalid Action", "Kindly specify a medical condition or untoggle the pre-existing medical condition clause for this beneficiary", "Ok");
                                //    IsBusy = false;
                                return;
                                //}
                            }

                            HealthBeneficiary healthBeneficiary = new HealthBeneficiary
                            {
                                EmailAddress = BeneficiaryEmailAddress,
                                DateOfBirth = BeneficiaryDateOfBirth,
                                FirstName = BeneficiaryFirstName,
                                Gender = BeneficiaryGender,
                                Genotype = BeneficiaryGenotype,
                                LastName = BeneficiaryLastName,
                                MiddleName = BeneficiaryMiddleName,
                                PhoneNumber = BeneficiaryTelephone,
                                Occupation = BeneficiaryOccupation,
                                MaritalStatus = BeneficiaryMaritalStatus,
                                BloodGroup = BeneficiaryBloodGroup,
                                PreferredHospital = SelectedHospitals.HospitalName[(SelectedHospitals.HospitalName.Count - 1)], /*BeneficiarySelectedHospital*/
                                PreferredHospitalLocation = SelectedBeneficiaryHospitalLocation,
                                State = BeneficiaryStateOfResidence,
                                Town = BeneficiaryTown,
                                Address = BeneficiaryAddress,
                                IsVisible = true
                            };

                            healthBeneficiary.PreExistingConditions = MyBeneficiaryPreExistingConditions;

                            if (HealthBeneficiaries.Count == 10)
                            {
                                HealthBeneficiaries.Remove(HealthBeneficiaries.LastOrDefault());
                            }
                            HealthBeneficiaries.Add(healthBeneficiary);

                            BeneficiaryFirstName = BeneficiaryLastName = BeneficiaryEmailAddress = BeneficiaryMiddleName = BeneficiaryTelephone = BeneficiaryGender = BeneficiaryGenotype =
                            BeneficiarySelectedHospital = SelectedBeneficiaryHospitalLocation = BeneficiaryStateOfResidence = BeneficiaryTown = BeneficiaryAddress = string.Empty;

                            HealthProduct healthProduct = new HealthProduct
                            {
                                Gender = Gender,
                                Genotype = Genotype,
                                Plan = PlanType,
                                APIKey = HealthAPICredentials.APIKey,
                                Salt = HealthAPICredentials.Salt,
                                PreferredHospital = SelectedHospitals.SelectedHospitalName, /*SelectedHospital*/
                                PreferredHospitalLocation = SelectedHospitalLocation,
                                State = StateOfResidence,
                                Town = Town,
                                Occupation = Occupation,
                                MaritalStatus = MaritalStatus,
                                BloodGroup = BloodGroup,
                                Value = (Convert.ToDouble(SingleCost) * NoOfPersons),
                                Beneficiaries = HealthBeneficiaries.ToList(),
                                PreExistingConditions = MyPreExistingConditions,
                                UploadedDocuments = FileNameList.ToList(),
                                token = HealthAPICredentials.APIKey,
                                URL = HealthAPICredentials.URL,
                                OwnershipType = 3
                            };

                            healthProduct.UploadedDocuments = FileNameList.ToList();

                            HealthProduct = healthProduct;

                            ProductPlan.AmountPaid = healthProduct.Value.ToString();
                            int updated = await _productPlanRepository.UpdateAsync(ProductPlan);
                            AllConditionsMet = true;
                        }
                    }
                }

                if (AllConditionsMet)
                {
                    NavigationParameters parameters = new NavigationParameters();
                    parameters.Add("ProspectId", SelectedProspect.Id);
                    parameters.Add("AgentId", LoggedAgent.Id);
                    parameters.Add("ProductPlanId", ProductPlan.Id);
                    parameters.Add("HealthProduct", HealthProduct);
                    parameters.Add("Beneficiaries", HealthBeneficiaries.ToList());
                    //await _navigationService.NavigateAsync("HealthSummaryPage", parameters);
                    await _navigationService.NavigateAsync("HealthProposalQuestionnaire", parameters);
                }
            }
            catch (Exception e) 
            {
                e.Message.ToString();
            }
            IsBusy = false;
        }

        private async void ExecuteAddBeneficiaryCommand()
        {
            IsBusy = true;
            try
            {
                AddBenButtonClicked = true;

                if (string.IsNullOrEmpty(BeneficiaryFirstName))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Kindly enter beneficiary first name", "Ok");
                }
                else if (string.IsNullOrEmpty(BeneficiaryLastName))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Kindly enter beneficiary Last name", "Ok");
                }
                else if (string.IsNullOrEmpty(BeneficiaryGender))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Kindly select beneficiary gender", "Ok");
                }
                //else if (string.IsNullOrEmpty(BeneficiaryGenotype))
                //{
                //    await _pageDialogService.DisplayAlertAsync("Warning", "Kindly select beneficiary genotype", "Ok");
                //}
                else if (string.IsNullOrEmpty(BeneficiaryTown))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Kindly select beneficiary town", "Ok");
                }
                else if (string.IsNullOrEmpty(EmailAddress))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Kindly enter beneficiary email address", "Ok");
                }
                else if (string.IsNullOrEmpty(PhoneNumber))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Kindly enter beneficiary phone number", "Ok");
                }
                else if (string.IsNullOrEmpty(SelectedHospitals.HospitalName[(SelectedHospitals.HospitalName.Count - 1)]  /*BeneficiarySelectedHospital*/))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Kindly select preferred hospital for beneficiary", "Ok");
                }
                else if (string.IsNullOrEmpty(BeneficiaryAddress))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Kindly enter beneficiary address", "Ok");
                }
                else if ((DateTime.Now.Year - BeneficiaryDateOfBirth.Year) > 65 || (DateTime.Now.Year - BeneficiaryDateOfBirth.Year < 18))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Beneficiary age has to be within 18 and 65", "Ok");
                }
                else
                {
                    NoOfPersons += 1;
                    Value = "Value: N" + (Convert.ToDouble(SingleCost) * NoOfPersons).ToString("N0");
                    if (IsBeneficiaryHealthCondition)
                    {
                        await _pageDialogService.DisplayAlertAsync("Ooops!", "This booking cannot be completed on AXA Sol Lite due to the stated pre-existing conditions. Kindly use the Referral link to refer the customer to the website to buy policy", "Okay");
                        //foreach (var item in MyBeneficiaryPreExistingConditions)
                        //{
                        //    bool isToggled = false;
                        //    isToggled = item.IsToggled;
                        //    MyBeneficiaryQuestions.Add(isToggled);
                        //}
                        //MyBeneficiaryQuestions = MyBeneficiaryQuestions.ToList();
                        //var res = MyBeneficiaryQuestions.FindAll(
                        //   delegate (bool exist)
                        //   {
                        //       return exist == true;
                        //   });
                        //if (res.Count == 0)
                        //{
                        //    await _pageDialogService.DisplayAlertAsync("Invalid Action", "Kindly specify a medical condition or untoggle the pre-existing medical condition clause for this beneficiary", "Ok");
                        //    IsBusy = false;
                        return;
                        //}
                    }
                    HealthBeneficiary healthBeneficiary = new HealthBeneficiary
                    {
                        EmailAddress = BeneficiaryEmailAddress,
                        DateOfBirth = BeneficiaryDateOfBirth,
                        FirstName = BeneficiaryFirstName,
                        Gender = BeneficiaryGender,
                        Genotype = BeneficiaryGenotype,
                        LastName = BeneficiaryLastName,
                        MiddleName = BeneficiaryMiddleName,
                        PhoneNumber = BeneficiaryTelephone,
                        Occupation = BeneficiaryOccupation,
                        MaritalStatus = BeneficiaryMaritalStatus,
                        BloodGroup = BeneficiaryBloodGroup,
                        PreferredHospital = SelectedHospitals.HospitalName[(SelectedHospitals.HospitalName.Count - 1)] /*BeneficiarySelectedHospital*/,
                        PreferredHospitalLocation = SelectedBeneficiaryHospitalLocation,
                        State = BeneficiaryStateOfResidence,
                        Town = BeneficiaryTown,
                        Address = BeneficiaryAddress,
                        IsVisible = true
                    };
                    healthBeneficiary.PreExistingConditions = MyBeneficiaryPreExistingConditions;

                    HealthBeneficiaries.Add(healthBeneficiary);

                    if(HealthBeneficiaries.Count < 9)
                    {
                        BeneficiaryFirstName = BeneficiaryLastName = BeneficiaryEmailAddress = BeneficiaryMiddleName = BeneficiaryTelephone = BeneficiaryGender = BeneficiaryGenotype =
                        BeneficiarySelectedHospital = SelectedBeneficiaryHospitalLocation = BeneficiaryStateOfResidence = BeneficiaryTown = BeneficiaryAddress = BeneficiaryHospitalBindable = string.Empty;
                        IsBeneficiaryHealthCondition = false;
                        BeneficiaryDateOfBirth = DateTime.Parse("1/1/1980 12:00:00 PM");
                        MyBeneficiaryHospitals.Clear();
                    }
                    else
                    {
                        BeneficiaryFirstName = BeneficiaryLastName = BeneficiaryEmailAddress = BeneficiaryMiddleName = BeneficiaryTelephone = BeneficiaryGender = BeneficiaryGenotype =
                        BeneficiarySelectedHospital = SelectedBeneficiaryHospitalLocation = BeneficiaryStateOfResidence = BeneficiaryTown = BeneficiaryAddress = BeneficiaryHospitalBindable = string.Empty;
                        BeneficiaryDateOfBirth = DateTime.Parse("1/1/1980 12:00:00 PM");
                        IsBeneficiaryHealthCondition = false;
                        ActiveAddBenButton = false;
                        MyBeneficiaryHospitals.Clear();
                    }
                }
            }
            catch (Exception e)
            {
                e.Message.ToString();
            }
            IsBusy = false;
        }

        private async void ExecutePickGroupHospitalCommand()
        {
            try
            {
                if (string.IsNullOrEmpty(SelectedBeneficiaryHospitalLocation))
                {
                    await _pageDialogService.DisplayAlertAsync("", "Kindly select a location", "Ok");
                    return;
                }
                NavigationParameters parameters = new NavigationParameters();
                parameters.Add("ProspectId", SelectedProspect.Id);
                parameters.Add("AgentId", LoggedAgent.Id);
                parameters.Add("ProductPlanId", ProductPlan.Id);
                parameters.Add("HospitalObject", Hospitals);
                parameters.Add("HospitalList", MyBeneficiaryHospitals);
                //parameters.Add("GroupMemberIdentifier", Guid.NewGuid().ToString());
                parameters.Add("IsGroup", true);

                await _navigationService.NavigateAsync("HealthHospitals", parameters, true, true);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecutePickHospitalCommand()
        {
            try
            {
                if (string.IsNullOrEmpty(SelectedHospitalLocation))
                {
                    await _pageDialogService.DisplayAlertAsync("", "Kindly select a location", "Ok");
                    return;
                }
                NavigationParameters parameters = new NavigationParameters();
                parameters.Add("ProspectId", SelectedProspect.Id);
                parameters.Add("AgentId", LoggedAgent.Id);
                parameters.Add("ProductPlanId", ProductPlan.Id);
                parameters.Add("HospitalObject", Hospitals);
                parameters.Add("HospitalList", MyHospitals);
                parameters.Add("IsGroup", false);

                await _navigationService.NavigateAsync("HealthHospitals", parameters, true, true);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
    }
}
