﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AxaSolLite.ViewModels
{
    public class HealthProposalQuestionnaireViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IPageDialogService _pageDialogService;
        private readonly IAgentRepository _agentRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly IHealthPayloadRepository _healthPayloadRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        private Guid _prospectId;
        private bool _isBusy;
        private string _questionOne;
        private string _questionTwo;
        private string _questionThree;
        private string _questionFour;
        private string _questionFive;
        private string _questionSix;
        private string _questionSeven;
        private string _questionEight;
        private string _questionNine;
        private string _questionTen;
        private string _questionEleven;
        private string _questionTwelve;
        private string _questionThirteen;
        private string _questionForteen;
        private string _questionFifteen;
        private string _questionSixteen;
        private string _questionSeventeen;
        private string _questionEighteen;

        private bool _isQuestionOne;
        private bool _isQuestionTwo;
        private bool _isQuestionThree;
        private bool _isQuestionFour;
        private bool _isQuestionFive;
        private bool _isQuestionSix;
        private bool _isQuestionSeven;
        private bool _isQuestionEight;
        private bool _isQuestionNine;
        private bool _isQuestionTen;
        private bool _isQuestionEleven;
        private bool _isQuestionTwelve;
        private bool _isQuestionThirteen;
        private bool _isQuestionForteen;
        private bool _isQuestionFifteen;
        private bool _isQuestionSixteen;
        private bool _isQuestionSeventeen;
        private bool _isQuestionEighteen;
        private List<HealthBeneficiary> _healthBeneficiaries = new List<HealthBeneficiary>();
        private List<bool> _myQuestions = new List<bool>();
        private List<HealthProposalQuestion> _healthProposalQuestions = new List<HealthProposalQuestion>();
        private string _otherConditions;

        public string OtherConditions
        {
            get { return _otherConditions; }
            set { SetProperty(ref _otherConditions, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public string QuestionOne
        {
            get { return _questionOne; }
            set { SetProperty(ref _questionOne, value); }
        }
        public string QuestionTwo
        {
            get { return _questionTwo; }
            set { SetProperty(ref _questionTwo, value); }
        }
        public string QuestionThree
        {
            get { return _questionThree; }
            set { SetProperty(ref _questionThree, value); }
        }
        public string QuestionFour
        {
            get { return _questionFour; }
            set { SetProperty(ref _questionFour, value); }
        }
        public string QuestionFive
        {
            get { return _questionFive; }
            set { SetProperty(ref _questionFive, value); }
        }
        public string QuestionSix
        {
            get { return _questionSix; }
            set { SetProperty(ref _questionSix, value); }
        }
        public string QuestionSeven
        {
            get { return _questionSeven; }
            set { SetProperty(ref _questionSeven, value); }
        }
        public string QuestionEight
        {
            get { return _questionEight; }
            set { SetProperty(ref _questionEight, value); }
        }
        public string QuestionNine
        {
            get { return _questionNine; }
            set { SetProperty(ref _questionNine, value); }
        }
        public string QuestionTen
        {
            get { return _questionTen; }
            set { SetProperty(ref _questionTen, value); }
        }
        public string QuestionEleven
        {
            get { return _questionEleven; }
            set { SetProperty(ref _questionEleven, value); }
        }
        public string QuestionTwelve
        {
            get { return _questionTwelve; }
            set { SetProperty(ref _questionTwelve, value); }
        }
        public string QuestionThirteen
        {
            get { return _questionThirteen; }
            set { SetProperty(ref _questionThirteen, value); }
        }
        public string QuestionForteen
        {
            get { return _questionForteen; }
            set { SetProperty(ref _questionForteen, value); }
        }
        public string QuestionFifteen
        {
            get { return _questionFifteen; }
            set { SetProperty(ref _questionFifteen, value); }
        }
        public string QuestionSixteen
        {
            get { return _questionSixteen; }
            set { SetProperty(ref _questionSixteen, value); }
        }
        public string QuestionSeventeen
        {
            get { return _questionSeventeen; }
            set { SetProperty(ref _questionSeventeen, value); }
        }
        public string QuestionEighteen
        {
            get { return _questionEighteen; }
            set { SetProperty(ref _questionEighteen, value); }
        }

        public bool IsQuestionOne
        {
            get { return _isQuestionOne; }
            set { SetProperty(ref _isQuestionOne, value); }
        }
        public bool IsQuestionTwo
        {
            get { return _isQuestionTwo; }
            set { SetProperty(ref _isQuestionTwo, value); }
        }
        public bool IsQuestionThree
        {
            get { return _isQuestionThree; }
            set { SetProperty(ref _isQuestionThree, value); }
        }
        public bool IsQuestionFour
        {
            get { return _isQuestionFour; }
            set { SetProperty(ref _isQuestionFour, value); }
        }
        public bool IsQuestionFive
        {
            get { return _isQuestionFive; }
            set { SetProperty(ref _isQuestionFive, value); }
        }
        public bool IsQuestionSix
        {
            get { return _isQuestionSix; }
            set { SetProperty(ref _isQuestionSix, value); }
        }
        public bool IsQuestionSeven
        {
            get { return _isQuestionSeven; }
            set { SetProperty(ref _isQuestionSeven, value); }
        }
        public bool IsQuestionEight
        {
            get { return _isQuestionEight; }
            set { SetProperty(ref _isQuestionEight, value); }
        }
        public bool IsQuestionNine
        {
            get { return _isQuestionNine; }
            set { SetProperty(ref _isQuestionNine, value); }
        }
        public bool IsQuestionTen
        {
            get { return _isQuestionTen; }
            set { SetProperty(ref _isQuestionTen, value); }
        }
        public bool IsQuestionEleven
        {
            get { return _isQuestionEleven; }
            set { SetProperty(ref _isQuestionEleven, value); }
        }
        public bool IsQuestionTwelve
        {
            get { return _isQuestionTwelve; }
            set { SetProperty(ref _isQuestionTwelve, value); }
        }
        public bool IsQuestionThirteen
        {
            get { return _isQuestionThirteen; }
            set { SetProperty(ref _isQuestionThirteen, value); }
        }
        public bool IsQuestionForteen
        {
            get { return _isQuestionForteen; }
            set { SetProperty(ref _isQuestionForteen, value); }
        }
        public bool IsQuestionFifteen
        {
            get { return _isQuestionFifteen; }
            set { SetProperty(ref _isQuestionFifteen, value); }
        }
        public bool IsQuestionSixteen
        {
            get { return _isQuestionSixteen; }
            set { SetProperty(ref _isQuestionSixteen, value); }
        }
        public bool IsQuestionSeventeen
        {
            get { return _isQuestionSeventeen; }
            set { SetProperty(ref _isQuestionSeventeen, value); }
        }
        public bool IsQuestionEighteen
        {
            get { return _isQuestionEighteen; }
            set { SetProperty(ref _isQuestionEighteen, value); }
        }
        public List<bool> MyQuestions
        {
            get { return _myQuestions; }
            set { SetProperty(ref _myQuestions, value); }
        }
        public Prospect SelectedProspect { get; set; }
        public Agent LoggedAgent { get; set; }
        public ProductPlan ProductPlan { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }
        public HealthProduct HealthProduct { get; set; }
        public List<HealthBeneficiary> HealthBeneficiaries
        {
            get { return _healthBeneficiaries; }
            set { SetProperty(ref _healthBeneficiaries, value); }
        }
        public List<HealthProposalQuestion> HealthProposalQuestions
        {
            get { return _healthProposalQuestions; }
            set { SetProperty(ref _healthProposalQuestions, value); }
        }

        private DelegateCommand _proceedCommand;
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProceedCommand));

        public HealthProposalQuestionnaireViewModel(INavigationService navigationService,
            IPageDialogService pageDialogService,
            IProspectRepository prospectRepository,
            IAgentRepository agentRepository, Logical logical, IHealthPayloadRepository healthPayloadRepository,
            IProductPlansRepository productPlansRepository, EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _prospectRepository = prospectRepository;
            _agentRepository = agentRepository;
            _productPlansRepository = productPlansRepository;
            _healthPayloadRepository = healthPayloadRepository;
            _logical = logical;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;
            try
            {
                Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);

                Guid agentId = parameters.GetValue<Guid>("AgentId");
                LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);

                Guid _productPlanId = parameters.GetValue<Guid>("ProductPlanId");
                ProductPlan = await _productPlansRepository.GetProductPlanByProductPlanId(_productPlanId);

                HealthProduct = parameters.GetValue<HealthProduct>("HealthProduct");

                HealthBeneficiaries = parameters.GetValue<List<HealthBeneficiary>>("Beneficiaries");

                await InitializeDefaultValues();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async Task InitializeDefaultValues()
        {
            try
            {
                var Questions = await _logical.SyncHealthProposalQuestions();
                if (Questions == null || !Questions.Any())
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Unable to sync in proposal questions. Please ensure your internet is connected and active.", "Okay");
                    return;
                }

                foreach (var item in Questions)
                {
                    HealthProposalQuestion healthProposalQuestion = new HealthProposalQuestion()
                    {
                        Question = item.Value
                    };
                    HealthProposalQuestions.Add(healthProposalQuestion);
                }
                HealthProposalQuestions = HealthProposalQuestions.ToList();

            }
            catch (Exception ex)
            {
                await _pageDialogService.DisplayAlertAsync("Error", "Unable to sync in proposal questions", "Okay");
                ex.Message.ToString();
            }
        }

        private async void ExecuteProceedCommand()
        {
            IsBusy = true;
            var selected = HealthProposalQuestions.FindAll(x => x.IsToggled);
            if (selected != null && selected.Any())
            {
                List<string> selectedQuestions = new List<string>();
                foreach (HealthProposalQuestion healthProposalQuestion in selected)
                {
                    string question = "";
                    question = healthProposalQuestion.Question;
                    selectedQuestions.Add(question);
                }
                if (!string.IsNullOrEmpty(OtherConditions))
                    selectedQuestions.Add(OtherConditions);
                string positivelyAnsweredQuestions = string.Join(", ", selectedQuestions);
                HealthProduct.AnsweredQuestions = positivelyAnsweredQuestions;
            }
            if (!string.IsNullOrEmpty(OtherConditions))
                HealthProduct.AnsweredQuestions = OtherConditions;

            HealthBookingRequest healthBookingRequest = new HealthBookingRequest
            {
                ProductId = ProductPlan.Id,
                RequestBody = JsonConvert.SerializeObject(HealthProduct)
            };

            int updated = await _healthPayloadRepository.SaveAsync(healthBookingRequest);
            NavigationParameters parameters = new NavigationParameters
            {
                { "ProspectId", SelectedProspect.Id },
                { "AgentId", LoggedAgent.Id },
                { "ProductPlanId", ProductPlan.Id },
                { "HealthProduct", HealthProduct },
                { "Beneficiaries", HealthBeneficiaries.ToList() }
            };
            await _navigationService.NavigateAsync("HealthSummaryPage", parameters);
            IsBusy = false;
        }
    }
}
