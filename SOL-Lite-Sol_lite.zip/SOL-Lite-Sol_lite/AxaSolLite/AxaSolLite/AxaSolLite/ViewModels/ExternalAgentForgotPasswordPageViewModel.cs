﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AxaSolLite.ViewModels
{
	public class ExternalAgentForgotPasswordPageViewModel : BindableBase, INavigationAware
    {
        private readonly IRepositoryManager _repositoryManager;
        private readonly IUserManager _userService;
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;

        #region FIELDS
        private string _agentCode;
        private string _generatedCode;
        private string _newPassword;
        private string _confirmPassword;
        private bool _isBusy;
        #endregion
        #region PROPERTIES
        public string AgentCode
        {
            get { { return _agentCode; } }
            set { SetProperty(ref _agentCode, value); }
        }
        public string GeneratedCode
        {
            get { { return _generatedCode; } }
            set { SetProperty(ref _generatedCode, value); }
        }
        public string NewPassword
        {
            get { { return _newPassword; } }
            set { SetProperty(ref _newPassword, value); }
        }
        public string ConfirmPassword
        {
            get { { return _confirmPassword; } }
            set { SetProperty(ref _confirmPassword, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        #endregion

        #region COMMANDS
        private DelegateCommand _getOTPCommand;
        private DelegateCommand _changePassword;

        public DelegateCommand GetOTPCommand => _getOTPCommand ?? (_getOTPCommand = new DelegateCommand(ExecuteGetOTP));
        public DelegateCommand ChangePasswordCommand => _changePassword ?? (_changePassword = new DelegateCommand(ExecuteChangePassword));
        #endregion

        Logical logical = null;
        public ExternalAgentForgotPasswordPageViewModel(IUserManager userService,
            INavigationService navigationService,
            IPageDialogService pageDialogService,
            IRepositoryManager repositoryManager)
        {
            _userService = userService;
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _repositoryManager = repositoryManager;

        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            
        }
        private async void ExecuteGetOTP()
        {
            try
            {
                IsBusy = true;

                if (!String.IsNullOrEmpty(this.AgentCode))
                {
                    this.AgentCode = this.AgentCode.Trim();
                }
                logical = new Logical();
                GetOTPRequest request = new GetOTPRequest();
                request.Username = AgentCode;
                var getOTPResponse = await logical.GetOTPResponseAsync(request);

                if (getOTPResponse.Message.ToLower().Contains("mail sent"))
                {
                    await _pageDialogService.DisplayAlertAsync("Done", "A mail has been sent to you", "Ok");
                }
                else if (getOTPResponse.Message.ToLower().Contains("username does not exist"))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Username does not exist", "Ok");
                }
                else
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Mail not sent", "Ok");
                }
                IsBusy = false;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
        private async void ExecuteChangePassword()
        {
            try
            {
                IsBusy = true;
                if (!String.IsNullOrEmpty(this.NewPassword) && !String.IsNullOrEmpty(this.ConfirmPassword))
                {
                    if (NewPassword == ConfirmPassword)
                    {
                        logical = new Logical();
                        ForgotPasswordRequest request = new ForgotPasswordRequest();
                        request.OTP = GeneratedCode;
                        request.Username = AgentCode;
                        request.Password = ConfirmPassword;

                        var changePassword = await logical.ChangePasswordAsync(request);

                        if (changePassword.Message.ToLower().Contains("password update successful"))
                        {
                            await _pageDialogService.DisplayAlertAsync("Done", "Your Password has been updated", "Ok");
                            await _navigationService.NavigateAsync("ExternalAgentLoginPage", null, null, false);
                        }
                        else if (changePassword.Message.ToLower().Contains("password should contain at least one upper case and lower case letter, a number, at least 8 characters long and at least a special character"))
                        {
                            await _pageDialogService.DisplayAlertAsync("Error", "Password should be at least 8 characters long and should contain at least one upper case, one lower case letter, a number, and at least a special character", "Ok");
                        }
                        else if (changePassword.Message.ToLower().Contains("password update not successful"))
                        {
                            await _pageDialogService.DisplayAlertAsync("Error", "Password not updated successfully", "Ok");
                        }
                        else
                        {
                            await _pageDialogService.DisplayAlertAsync("Error", "Action Failed, please retry", "Ok");
                        }
                    }
                    else
                        await _pageDialogService.DisplayAlertAsync("Password Mismatch", "Please input matching entries into password fields", "Ok");
                }
                IsBusy = false;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
    }
}
