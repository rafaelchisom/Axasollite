﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace AxaSolLite.ViewModels
{
    public class InstantPlanBookingPageViewModel : BindableBase, INavigationAware
    {
        private const string AccountNumberRegex = @"^[0-9]+$";

        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly IBookOnlineRepository _bookOnlineRepository;
        private readonly IBranchesRepository _branchesRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        private bool _isBusy;
        private string _agentName;
        private string _sbuName;
        private string _selectedDSA;
        private List<string> _myDSAs;
        private bool _isExternalAgent;
        private Prospect _selectedProspect;
        private Agent _loggedAgent;
        private string _title;
        private List<string> _premiumList;
        private string _paymentFrequency;
        private string _sumAssured;
        private string _policyDuration;
        private DateTime _policyStartDate;
        private string _premium;
        private string _age;
        private string _ageAtNextBirthday;
        private string _customerNumber;
        private string _totalPremium;
        private List<DSAUnderPSS> _dSAs;
        private DSAUnderPSS _dSA;
        private List<string> _branchList;
        private string _selectedbranch;
        private SyncDataSample _branches;
        private Branches _branch;
        private int _branchCode;
        private Guid _prospectId;
        private List<Branches> _branchToSave = new List<Branches>();
        private string _accountNumber;
        private List<string> _bankList = new List<string>();
        private string _bankName;
        public string BankName
        {
            get { return _bankName; }
            set { SetProperty(ref _bankName, value); }
        }
        public List<string> BankList
        {
            get { return _bankList; }
            set { SetProperty(ref _bankList, value); }
        }
        public string AccountNumber
        {
            get { return _accountNumber; }
            set { SetProperty(ref _accountNumber, value); }
        }
        public List<Branches> BranchToSave
        {
            get { return _branchToSave; }
            set { SetProperty(ref _branchToSave, value); }
        }
        public int BranchCode
        {
            get { return _branchCode; }
            set { SetProperty(ref _branchCode, value); }
        }
        public SyncDataSample Branches
        {
            get { return _branches; }
            set { SetProperty(ref _branches, value); }
        }
        public DSAUnderPSS DSA
        {
            get { return _dSA; }
            set { SetProperty(ref _dSA, value); }
        }
        public List<DSAUnderPSS> DSAs
        {
            get { return _dSAs; }
            set { SetProperty(ref _dSAs, value); }
        }
        public Branches Branch
        {
            get { return _branch; }
            set { SetProperty(ref _branch, value); }
        }
        public string TotalPremium
        {
            get { return _totalPremium; }
            set { SetProperty(ref _totalPremium, value); }
        }

        private List<InstantPlanQuoteReq> _instantPlanQuotes = new List<InstantPlanQuoteReq>();
        public List<InstantPlanQuoteReq> InstantPlanQuotes
        {
            get { return _instantPlanQuotes; }
            set { SetProperty(ref _instantPlanQuotes, value); }
        }

        public List<string> BranchList
        {
            get { return _branchList; }
            set { SetProperty(ref _branchList, value); }
        }
        public string SelectedBranch
        {
            get { return _selectedbranch; }
            set { SetProperty(ref _selectedbranch, value); }
        }
        public string CustomerNumber
        {
            get { return _customerNumber; }
            set { SetProperty(ref _customerNumber, value); }
        }
        public string AgeAtNextBirthday
        {
            get { return _ageAtNextBirthday; }
            set { SetProperty(ref _ageAtNextBirthday, value); }
        }
        public string Age
        {
            get { return _age; }
            set { SetProperty(ref _age, value); }
        }
        public string Premium
        {
            get { return _premium; }
            set { SetProperty(ref _premium, value); }
        }
        public DateTime PolicyStartDate
        {
            get { return _policyStartDate; }
            set { SetProperty(ref _policyStartDate, value); }
        }
        public string PolicyDuration
        {
            get { return _policyDuration; }
            set { SetProperty(ref _policyDuration, value); }
        }
        public string SumAssured
        {
            get { return _sumAssured; }
            set { SetProperty(ref _sumAssured, value); }
        }
        public string PaymentFrequency
        {
            get { return _paymentFrequency; }
            set { SetProperty(ref _paymentFrequency, value); }
        }
        public List<string> PremiumList
        {
            get { return _premiumList; }
            set { SetProperty(ref _premiumList, value); }
        }
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public Agent LoggedAgent
        {
            get { return _loggedAgent; }
            set { SetProperty(ref _loggedAgent, value); }
        }
        public Prospect SelectedProspect
        {
            get { return _selectedProspect; }
            set { SetProperty(ref _selectedProspect, value); }
        }
        public bool IsExternalAgent
        {
            get { return _isExternalAgent; }
            set { SetProperty(ref _isExternalAgent, value); }
        }
        public List<string> MyDSAs
        {
            get { return _myDSAs; }
            set { SetProperty(ref _myDSAs, value); }
        }
        public string SelectedDSA
        {
            get { return _selectedDSA; }
            set { SetProperty(ref _selectedDSA, value); }
        }
        public string SbuName
        {
            get { return _sbuName; }
            set { SetProperty(ref _sbuName, value); }
        }
        public string AgentName
        {
            get { return _agentName; }
            set { SetProperty(ref _agentName, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public ProductPlan ProductPlan { get; set; }
        public BookOnline BookOnline { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }

        private DelegateCommand _proceedCommand;
        private DelegateCommand _changePremiumCommand;
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProceed));
        public DelegateCommand ChangePremiumCommand => _changePremiumCommand ?? (_changePremiumCommand = new DelegateCommand(ExecuteChangePremium));

        public InstantPlanBookingPageViewModel(INavigationService navigationService, IPageDialogService pageDialogService, IProspectRepository prospectRepository,
            IProductPlansRepository productPlansRepository, IAgentRepository agentRepository, Logical logical, IBookOnlineRepository bookOnlineRepository, IBranchesRepository branchesRepository,
            EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _prospectRepository = prospectRepository;
            _agentRepository = agentRepository;
            _productPlansRepository = productPlansRepository;
            _bookOnlineRepository = bookOnlineRepository;
            _branchesRepository = branchesRepository;
            _logical = logical;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;

            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }

                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }

                if (parameters.ContainsKey("ProductPlanId"))
                {
                    Guid _productPlanId;
                    if (Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId))
                    {
                        ProductPlan = await _productPlansRepository.GetProductPlanByProductPlanId(_productPlanId);
                    }
                }

                InitializeDefaultValues();
            }
            catch (Exception ex)
            {

            }
            IsBusy = false;
        }

        private async void InitializeDefaultValues()
        {
            try
            {
                List<BankDTO> MyBanks = await _logical.GetBankList();
                foreach (BankDTO item in MyBanks)
                {
                    string bankName = string.Empty;
                    bankName = item.NameField;
                    BankList.Add(bankName);
                }
                BankList = BankList.Where(x => x != "-- Select One--").ToList();

                Title = "Instant Plan Booking Page";
                AgentName = LoggedAgent.FullName;
                SbuName = LoggedAgent.SbuName;
                PaymentFrequency = "Annual";
                PolicyDuration = "1 year";
                PolicyStartDate = DateTime.Today;
                Age = SelectedProspect.Age.ToString();
                AgeAtNextBirthday = (SelectedProspect.Age + 1).ToString();
                CustomerNumber = SelectedProspect.CustomerNumber;
                var Branches = await _branchesRepository.GetBranches();
                BranchList = Branches.Select(x => x.Branch).ToList();
                BranchList = BranchList.Where(x => x != "BRANCHES").ToList();

                if (LoggedAgent.IsAdvisor || LoggedAgent.IsTeamManager)
                {
                    IsExternalAgent = true;
                }
                else
                {
                    IsExternalAgent = false;



                    DSAs = await _logical.GetDSAsUnderPss(LoggedAgent.AgentCode);



                    if (DSAs.Count > 0 && DSAs.First().PSSCode != null)
                    {
                        MyDSAs = DSAs.Select(x => x.FullName).ToList();
                    }
                }
                //TokenRequest tokenRequest = await _logical.GetInstantPlanTokenCredentials();
                //var instantPlanApi_token = await _logical.GetAxamansardAPIToken();
                var instantPlanQuotes = await _logical.GetAllInstantPlanQuotes();
                InstantPlanQuotes = instantPlanQuotes;
                PremiumList = InstantPlanQuotes.Select(x => x.Premium.ToString()).ToList();
            }
            catch (Exception ex)
            {

            }
        }

        private void ExecuteChangePremium()
        {
            IsBusy = true;
            try
            {
                var sumAssureds = InstantPlanQuotes.Where(e => e.Premium == Premium).FirstOrDefault();
                SumAssured = "NGN" + (Convert.ToDouble(sumAssureds.SumAssured)).ToString("N0");
                TotalPremium = "NGN" + Convert.ToInt64(Premium).ToString("N0");
            }
            catch (Exception ex)
            {
            }
            IsBusy = false;
        }

        private async void ExecuteProceed()
        {
            IsBusy = true;
            try
            {
                TotalPremium = Premium;
                if (string.IsNullOrEmpty(Premium))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please choose preferred premium amount", "Ok");
                }
                else if (PolicyStartDate < DateTime.Today)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Policy start date cannot be earlier than today", "Ok");
                }
                else if (string.IsNullOrEmpty(SelectedBranch))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a branch", "Ok");
                }
                else if (string.IsNullOrEmpty(BankName))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a bank", "Ok");
                }
                else if (string.IsNullOrEmpty(AccountNumber))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Kindly enter bank account number", "Ok");
                }
                else if (AccountNumber.Length != 10)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Account number must be 10 digits", "Ok");
                }
                else if (!Regex.IsMatch(AccountNumber, AccountNumberRegex))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Account number must be in a correct format", "Ok");
                }
                else
                {
                    if (!(string.IsNullOrEmpty(SelectedDSA)))
                    {
                        DSA = DSAs.Where(x => x.FullName == SelectedDSA).FirstOrDefault();
                    }
                    if (!(string.IsNullOrEmpty(SelectedBranch)))
                    {

                        var v = await _branchesRepository.GetBranchCodeByBranch(SelectedBranch);
                        BranchCode = v.BranchCode;

                    }

                    BookOnline = new BookOnline
                    {
                        Id = Guid.NewGuid(),
                        ProductPlanId = ProductPlan.Id,
                        AgentName = LoggedAgent.FullName,
                        AgeBeginPolicy = Convert.ToInt32(Age),
                        AgeEndPolicy = Convert.ToInt32(AgeAtNextBirthday),
                        AgentCode = LoggedAgent.AgentCode,
                        AnnualPremium = Convert.ToDecimal(Premium),
                        Assurer = LoggedAgent.FullName,
                        CustomerNo = SelectedProspect.CustomerNumber,
                        DateCreated = DateTime.Now,
                        EmailAddress = SelectedProspect.Email,
                        IntiationDate = DateTime.Now.ToString("MM/dd/yyyy"),
                        SumAssured = Convert.ToDecimal(InstantPlanQuotes.Where(e => e.Premium == Premium).FirstOrDefault().SumAssured),
                        TransactionType = "New",
                        Amount = Convert.ToDecimal(Premium),
                        SBU = LoggedAgent.SBU,
                        TotalPremium = Convert.ToDecimal(Premium),
                        PolicyTerm = 1,
                        Contribution = Convert.ToDecimal(Premium),
                        LifeCoverValue = Convert.ToDecimal(InstantPlanQuotes.Where(e => e.Premium == Premium).FirstOrDefault().SumAssured),
                        PolicyStartDate = PolicyStartDate.ToString("MM/dd/yyyy"),
                        PolicyEndDate = PolicyStartDate.AddYears(1).ToString("MM/dd/yyyy"),
                        PaymentFrequency = "Annual",
                        DSA = DSA?.FullName,
                        DSACode = DSA?.AgentCode,
                        BranchCode = BranchCode,
                        BankAccountNumber = AccountNumber,
                        BankName = BankName
                    };

                    //int saved = await _bookOnlineRepository.SaveBooking(BookOnline);

                    var parameters = new NavigationParameters();
                    parameters.Add("ProspectId", SelectedProspect.Id);
                    parameters.Add("ProductPlanId", ProductPlan.Id);
                    parameters.Add("AgentId", LoggedAgent.Id);
                    parameters.Add("BookOnlineId", BookOnline);

                    await _navigationService.NavigateAsync("AddBeneficiaryPage", parameters);
                    //await _navigationService.NavigateAsync("NonMedicalQuestionairePage", parameters);
                }
            }
            catch (Exception ex)
            {

            }
            IsBusy = false;
        }
    }
}