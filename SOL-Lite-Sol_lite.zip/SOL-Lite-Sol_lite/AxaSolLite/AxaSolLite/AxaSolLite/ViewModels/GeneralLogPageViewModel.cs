﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AxaSolLite.ViewModels
{
	public class GeneralLogPageViewModel : BindableBase, INavigationAware
	{
        private readonly IPageDialogService _pageDialogService;
        private readonly INavigationService _navigationService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IUserManager _userManager;
        private readonly IUserRepository _userRepository;
        private readonly ITitlesRepository _titlesRepository;
        private readonly IStatesRepository _statesRepository;
        private readonly ICountryRepository _countryRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private Logical _logical;

        private bool _isBusy;
        private bool _itemExists;
        private string _title;
        private List<BookingDetails> _generalLogList = new List<BookingDetails>();

        public bool ItemExists
        {
            get { return _itemExists; }
            set { SetProperty(ref _itemExists, value); }
        }
        public List<BookingDetails> GeneralLogList
        {
            get { return _generalLogList; }
            set { SetProperty(ref _generalLogList, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public Agent Agent { get; set; }

        public GeneralLogPageViewModel(IPageDialogService pageDialogService, INavigationService navigationService,
             IProspectRepository prospectRepository, IUserManager userManager, IUserRepository userRepository, ITitlesRepository titlesRepository, Logical logical,
             IStatesRepository statesRepository, ICountryRepository countryRepository, IAgentRepository agentRepository, IProductPlansRepository productPlansRepository)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _prospectRepository = prospectRepository;
            _countryRepository = countryRepository;
            _statesRepository = statesRepository;
            _titlesRepository = titlesRepository;
            _userManager = userManager;
            _logical = logical;
            _userRepository = userRepository;
            _agentRepository = agentRepository;
            _productPlansRepository = productPlansRepository;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;
            ItemExists = false;
            try
            {
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        Agent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }

                Title = "My Log";

                if (Agent.IsAdvisor)
                {
                    GeneralLogList = await _logical.GetBookingsByAgentCode(Agent.SubAgentCode);
                }
                else
                {
                    GeneralLogList = await _logical.GetBookingsByAgentCode(Agent.AgentCode);
                    //await Task.Delay(3000);
                }
                GeneralLogList = GeneralLogList.ToList();
                //GeneralLogList = GeneralLogList.OrderByDescending(x => x.CreatedDate).ToList();
                if (GeneralLogList != null && GeneralLogList.Count > 0)
                {
                    ItemExists = true;
                    IsBusy = false;
                }
                else
                {
                    await _pageDialogService.DisplayAlertAsync("No booking record found", "", "Ok");
                    IsBusy = false;
                }
            }
            catch (Exception ex)
            {
                
            }            
        }
    }
}
