﻿using AxaSolLite.Extensions;
using AxaSolLite.Models;
using AxaSolLite.Models.CustomerOnboardingCreateCase;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Plugin.FilePicker;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AxaSolLite.ViewModels
{
    public class AddBeneficiaryPageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IPageDialogService _pageDialogService;
        private readonly IAgentRepository _agentRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly IBookOnlineRepository _bookOnlineRepository;
        private readonly ITitlesRepository _titlesRepository;
        private readonly IMediaManager _deviceManager;
        private readonly EncryptUtils _encryptUtils;

        #region Fields
        private string _firstName;
        private string _lastName;
        private string _otherName;

        private DateTime _dateOfBirth;
        private bool _isBusy;
        private bool _isLimit;
        private bool _isEnabled;
        private bool _isVisible;
        private bool _isAdd;
        private string _title;
        private string _selectedTitle;
        private string _phoneNumber;
        private int _gender;
        private string _address;
        private SyncDataSample _titles;
        private List<string> _myTitles = new List<string>();
        private List<BeneficiaryDetails> _beneficiaryList = new List<BeneficiaryDetails>();
        private int _titleId;
        private string _selectedType;
        private string _selectedRelationship;
        private string _selectedMaritalStatus;
        private string _occupation;
        private Prospect _prospect;
        private Guid _prospectId;
        private Guid _productPlanId;
        private ProductPlan _productPlan;
        private ImageSource _signaturePicture;
        private byte[] _newSignaturePicture;
        private string _fileLabel;
        private string _fileLabelPath;
        private string[] _fileTypes;
        private string _fileSize;
        private Image _fileImagePreview;
        private List<string> _fileNameList;
        private Dictionary<string, object> _fileByteList;
        private string _contents;
        private string _contentType;
        private FileVariable _files;
        private UploadFile _uploadFile;
        private SyncDataSample _occupations;
        private List<string> _myoccupations = new List<string>();
        private bool _isExistinggPolicy;
        private string _existingPolicyDetail;
        private string _existingPolicyLifeAssuranceValue;
        private string _assurer;
        private bool _isProposalDeclined;
        private string _declinedProposalDetail;
        private bool _isNonScheduledFlight;
        private bool _isArmedForces;
        private string _medicalGrade;
        private bool _isAdditionalFacts;
        private string _additionalFact;
        private bool _isResideOutsideNigeria;
        private string _indicatedCountry;
        private bool _hasExistingLifeAssurance;
        private const string ResourceNamespace = "AxaSolLite.Resources.Assets.";
        Logical logical = new Logical();
        ArrayToImageConverter converter = new ArrayToImageConverter();
        private DelegateCommand _fileDeleteCommand;
        private DelegateCommand _pickfileCommand;
        private DelegateCommand _addBeneficiaryCommand;
        private DelegateCommand _saveBeneficiaryCommand;
        private DelegateCommand<string> _deleteBeneficiaryCommand;
        private DelegateCommand _proceedCommand;
        #endregion

        #region Properties
        public bool HasExistingLifeAssurance
        {
            get { return _hasExistingLifeAssurance; }
            set { SetProperty(ref _hasExistingLifeAssurance, value); }
        }
        public string IndicatedCountry
        {
            get { return _indicatedCountry; }
            set { SetProperty(ref _indicatedCountry, value); }
        }
        public bool IsResideOutsideNigeria
        {
            get { return _isResideOutsideNigeria; }
            set { SetProperty(ref _isResideOutsideNigeria, value); }
        }
        public string AdditionalFact
        {
            get { return _additionalFact; }
            set { SetProperty(ref _additionalFact, value); }
        }
        public bool IsAdditionalFacts
        {
            get { return _isAdditionalFacts; }
            set { SetProperty(ref _isAdditionalFacts, value); }
        }
        public string MedicalGrade
        {
            get { return _medicalGrade; }
            set { SetProperty(ref _medicalGrade, value); }
        }
        public bool IsArmedForces
        {
            get { return _isArmedForces; }
            set { SetProperty(ref _isArmedForces, value); }
        }
        public bool IsNonScheduledFlight
        {
            get { return _isNonScheduledFlight; }
            set { SetProperty(ref _isNonScheduledFlight, value); }
        }
        public string DeclinedProposalDetail
        {
            get { return _declinedProposalDetail; }
            set { SetProperty(ref _declinedProposalDetail, value); }
        }
        public bool IsProposalDeclined
        {
            get { return _isProposalDeclined; }
            set { SetProperty(ref _isProposalDeclined, value); }
        }
        public string Assurer
        {
            get { return _assurer; }
            set { SetProperty(ref _assurer, value); }
        }
        public string ExistingPolicyLifeAssuranceValue
        {
            get { return _existingPolicyLifeAssuranceValue; }
            set { SetProperty(ref _existingPolicyLifeAssuranceValue, value); }
        }
        public string ExistingPolicyDetail
        {
            get { return _existingPolicyDetail; }
            set { SetProperty(ref _existingPolicyDetail, value); }
        }
        public bool IsExistingPolicy
        {
            get { return _isExistinggPolicy; }
            set { SetProperty(ref _isExistinggPolicy, value); }
        }
        public string FirstName
        {
            get { return _firstName; }
            set { SetProperty(ref _firstName, value); }
        }
        public string LastName
        {
            get { return _lastName; }
            set { SetProperty(ref _lastName, value); }
        }
        public string OtherName
        {
            get { return _otherName; }
            set { SetProperty(ref _otherName, value); }
        }        
        public DateTime DateOfBirth
        {
            get { return _dateOfBirth; }
            set { SetProperty(ref _dateOfBirth, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public bool IsLimit
        {
            get { return _isLimit; }
            set { SetProperty(ref _isLimit, value); }
        }
        public bool IsEnabled
        {
            get { return _isEnabled; }
            set { SetProperty(ref _isEnabled, value); }
        }
        public bool IsVisible
        {
            get { return _isVisible; }
            set { SetProperty(ref _isVisible, value); }
        }
        public bool IsAdd
        {
            get { return _isAdd; }
            set { SetProperty(ref _isAdd, value); }
        }
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public string SelectedTitle
        {
            get { return _selectedTitle; }
            set { SetProperty(ref _selectedTitle, value); }
        }
        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { SetProperty(ref _phoneNumber, value); }
        }
        public int Gender
        {
            get { return _gender; }
            set { SetProperty(ref _gender, value); }
        }
        public string Address
        {
            get { return _address; }
            set { SetProperty(ref _address, value); }
        }
        public SyncDataSample Titles
        {
            get { return _titles; }
            set { SetProperty(ref _titles, value); }
        }
        public int TitleId
        {
            get { return _titleId; }
            set { SetProperty(ref _titleId, value); }
        }
        public List<string> MyTitles
        {
            get { return _myTitles; }
            set { SetProperty(ref _myTitles, value); }
        }
        public List<BeneficiaryDetails> BeneficiaryList
        {
            get { return _beneficiaryList; }
            set { SetProperty(ref _beneficiaryList, value); }
        }
        public string SelectedType
        {
            get { return _selectedType; }
            set { SetProperty(ref _selectedType, value); }
        }
        public string SelectedRelationship
        {
            get { return _selectedRelationship; }
            set { SetProperty(ref _selectedRelationship, value); }
        }
        public string SelectedMaritalStatus
        {
            get { return _selectedMaritalStatus; }
            set { SetProperty(ref _selectedMaritalStatus, value); }
        }
        public string Occupation
        {
            get { return _occupation; }
            set { SetProperty(ref _occupation, value); }
        }
        public ImageSource SignaturePicture
        {
            get { return _signaturePicture; }
            set { SetProperty(ref _signaturePicture, value); }
        }
        public byte[] NewSignaturePicture
        {
            get { return _newSignaturePicture; }
            set { SetProperty(ref _newSignaturePicture, value); }
        }
        public List<string> FileNameList
        {
            get { return _fileNameList; }
            set { SetProperty(ref _fileNameList, value); }
        }
        public Dictionary<string, object> FileByteList
        {
            get { return _fileByteList; }
            set { SetProperty(ref _fileByteList, value); }
        }
        public string Contents
        {
            get { return _contents; }
            set { SetProperty(ref _contents, value); }
        }
        public string FileLabel
        {
            get { return _fileLabel; }
            set { SetProperty(ref _fileLabel, value); }
        }
        public string FileLabelPath
        {
            get { return _fileLabelPath; }
            set { SetProperty(ref _fileLabelPath, value); }
        }
        public string FileSize
        {
            get { return _fileSize; }
            set { SetProperty(ref _fileSize, value); }
        }
        public string[] FileTypes
        {
            get { return _fileTypes; }
            set { SetProperty(ref _fileTypes, value); }
        }
        public Image FileImagePreview
        {
            get { return _fileImagePreview; }
            set { SetProperty(ref _fileImagePreview, value); }
        }
        public Prospect Prospect
        {
            get { return _prospect = _prospect ?? (_prospect = new Prospect()); }
            set { SetProperty(ref _prospect, value); }
        }
        public ProductPlan ProductPlan
        {
            get { return _productPlan = _productPlan ?? (_productPlan = new ProductPlan()); }
            set { SetProperty(ref _productPlan, value); }
        }
        public UploadFile UploadFile
        {
            get { return _uploadFile = _uploadFile ?? (_uploadFile = new UploadFile()); }
            set { SetProperty(ref _uploadFile, value); }
        }
        public string ContentType
        {
            get { return _contentType; }
            set { SetProperty(ref _contentType, value); }
        }
        public FileVariable Files
        {
            get { return _files; }
            set { SetProperty(ref _files, value); }
        }
        public SyncDataSample Occupations
        {
            get { return _occupations; }
            set { SetProperty(ref _occupations, value); }
        }
        public List<string> MyOccupations
        {
            get { return _myoccupations; }
            set { SetProperty(ref _myoccupations, value); }
        }
        public Agent LoggedAgent { get; set; }
        public BookOnline BookOnline { get; set; }
        #endregion

        #region Commands
        public DelegateCommand PickFileCommand => _pickfileCommand ?? (_pickfileCommand = new DelegateCommand(ExecutePickFileCommand));
        public DelegateCommand FileDeleteCommand => _fileDeleteCommand ?? (_fileDeleteCommand = new DelegateCommand(ExecuteFileDeleteCommand));
        public DelegateCommand AddBeneficiaryCommand => _addBeneficiaryCommand ?? (_addBeneficiaryCommand = new DelegateCommand(ExecuteAddBeneficiaryCommand));
        public DelegateCommand SaveBeneficiaryCommand => _saveBeneficiaryCommand ?? (_saveBeneficiaryCommand = new DelegateCommand(ExecuteSaveBeneficiaryCommand));
        public DelegateCommand<string> DeleteBeneficiaryCommand => _deleteBeneficiaryCommand ?? (_deleteBeneficiaryCommand = new DelegateCommand<string>(ExecuteDeleteBeneficiaryCommand));
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProceedCommand));
        #endregion

        public AddBeneficiaryPageViewModel(INavigationService navigationService,
            IPageDialogService pageDialogService,
            IProspectRepository prospectRepository,
            IAgentRepository agentRepository,
            ITitlesRepository titlesRepository,
            IMediaManager mediaManager,
            IProductPlansRepository productPlansRepository, IBookOnlineRepository bookOnlineRepository, EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _prospectRepository = prospectRepository;
            _agentRepository = agentRepository;
            _titlesRepository = titlesRepository;
            _deviceManager = mediaManager;
            _productPlansRepository = productPlansRepository;
            _bookOnlineRepository = bookOnlineRepository;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsVisible = true;
            IsBusy = true;
            IsLimit = true;
            IsEnabled = true;
            IsAdd = false;
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect encryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(encryptedProspect.Prospect);
                    Prospect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }
                if (parameters.ContainsKey("ProductPlanId"))
                {
                    Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId);
                    ProductPlan = await _productPlansRepository.GetProductPlanByProductPlanId(_productPlanId);
                }
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }
                if (parameters.ContainsKey("BookOnlineId"))
                {
                    BookOnline = parameters.GetValue<BookOnline>("BookOnlineId");
                }

                DateOfBirth = DateTime.Parse("1/1/1980 12:00:00 PM");
                SignaturePicture = "add_photo.png";
                var TitleList = await _titlesRepository.GetTitles();
                MyTitles = TitleList.Select(x => x.Title).ToList();
                MyTitles = MyTitles.Where(x => x != "Titles").ToList();
                Occupations = await logical.GetOccupationList();
                MyOccupations = Occupations.Result.Select(x => x.NAME).ToList();
                MyOccupations = MyOccupations.Where(x => x != "Occupation").ToList();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }            
        }

        private async void ExecutePickFileCommand()
        {
            try
            {

                bool choice = await _pageDialogService.DisplayAlertAsync("Confirm", "Please select how you wish to upload a document", "Gallery", "Camera");
                if (choice)
                {
                    if (Device.RuntimePlatform == Device.Android)
                    {
                        FileTypes = new string[] { "image/png", "image/jpeg", "application/pdf" };
                    }

                    await PickedFiles(FileTypes);
                    FileVariable signatureFile = new FileVariable
                    {
                        FileName = FileLabel,
                        FieldName = "Captured Signature",
                        FileContent = Convert.ToBase64String(NewSignaturePicture),
                        ContentType = ContentType,
                        Extension = !ContentType.ToLower().Contains("jpeg") ? ContentType.Substring((ContentType.Length - 3), 3) : ContentType.Substring((ContentType.Length - 4), 4)
                    };
                    Files = signatureFile;

                    if (FileLabel != null || Contents != null)
                    {
                        if (Contents.Length > 2097152)
                        {
                            FileLabel = null;
                            Contents = null;
                            await _pageDialogService.DisplayAlertAsync("Error", "File size too large. Please upload a document not larger than 2MB in size", "Cancel");
                        }
                        else

                            await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");
                    }

                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Unsuccessful", "Document failed to upload. Please try again.", "Ok");
                    }
                }
                else
                {
                    if (_deviceManager.CameraAvailable)
                    {
                        var newPhoto = await _deviceManager.TakePhotoAsync();

                        if (newPhoto != null)
                        {
                            NewSignaturePicture = newPhoto.FileContent;

                            FileVariable CameraTaken = new FileVariable
                            {
                                FileName = newPhoto.FileName,
                                FileContent = Convert.ToBase64String(NewSignaturePicture),
                                FieldName = "Captured Signature",
                                ContentType = "image/jpg",
                                Extension = "jpg"
                            };
                            Files = CameraTaken;
                            await _pageDialogService.DisplayAlertAsync("File Uploaded", "Photo successfully captured", "Okay");
                        }
                        else
                        {

                            await _pageDialogService.DisplayAlertAsync("Oooops!!!", "File too large, recapture the document or upload another document", "Cancel");
                        }
                    }

                }
                var convertedImage = converter.Convert(NewSignaturePicture, null, null, null) as ImageSource;

                SignaturePicture = convertedImage ?? ImageSource.FromResource(ResourceNamespace + "add_photo.png");

                
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public async Task PickedFiles(string[] fileTypes)
        {
            try
            {

                var pickedFile = await CrossFilePicker.Current.PickFile(fileTypes);

                if (pickedFile != null)
                {
                    FileLabel = pickedFile.FileName;
                    FileLabelPath = pickedFile.FilePath;
                    //NewSignaturePicture = pickedFile.DataArray;

                    if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase))
                    {
                        Contents = System.Text.Encoding.UTF8.GetString(pickedFile.DataArray, 0, pickedFile.DataArray.Length);
                        NewSignaturePicture = pickedFile.DataArray;

                        if (pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "application/pdf";
                        }
                        else if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "image" + "/jpg";
                        }
                        else if (pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "image" + "/png";
                        }
                        else
                            ContentType = "image" + "/jpeg";
                    }

                    // FileSize = FileSizeFormatter.FormatSize(Contents.Length);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public static class FileSizeFormatter
        {
            static readonly string[] suffixes = { "Bytes", "KB", "MB", "GB", "TB", "PB" };

            public static string FormatSize(long bytes)
            {
                int counter = 0;
                decimal number = (decimal)bytes;
                while (Math.Round(number / 1024) >= 1)
                {
                    number = number / 1024;
                    counter++;
                }
                return string.Format("{0:n1}{1}", number, suffixes[counter]);
            }
        }

        private async void ExecuteFileDeleteCommand()
        {
            try
            {
                if (FileLabel != null || Contents != null)
                {
                    FileLabel = null;
                    Contents = null;
                    SignaturePicture = null;
                    await _pageDialogService.DisplayAlertAsync("Done", "Uploaded file deleted successfully", "Ok");
                }
                else
                    await _pageDialogService.DisplayAlertAsync("Notice", "There is no document to be deleted", "Ok");
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteAddBeneficiaryCommand()
        {
            IsLimit = true;
            IsVisible = true;
            try
            {
                FirstName = null;
                LastName = null;
                SelectedType = null;
                SelectedRelationship = null;
                Occupation = null;
                Address = null;
                SelectedMaritalStatus = null;
                PhoneNumber = "";
                DateOfBirth = DateTime.Parse("1/1/1980 12:00:00 PM");

                SelectedTitle = null;
                OtherName = null;
                if (BeneficiaryList.Count == 2)
                {
                    if (SignaturePicture == null)
                    {
                        await _pageDialogService.DisplayAlertAsync("Beneficiary limit reached", "Proceed to upload signature", "Ok");
                        IsLimit = false;
                        IsVisible = false;
                        IsBusy = false;
                        IsAdd = true;
                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Beneficiary limit reached", "Click on proceed button", "Ok");
                        IsLimit = false;
                        IsVisible = false;
                        IsBusy = false;
                        IsAdd = true;
                    }
                }
                else
                {
                    if (BeneficiaryList.Count == 1)
                    {
                        foreach (var rs in BeneficiaryList)
                        {
                            if (rs.Type.Contains("Primary"))
                            {
                                SelectedType = "Contingent";
                                IsEnabled = false;
                                IsAdd = false;
                            }
                            else
                            {
                                SelectedType = "Primary";
                                IsEnabled = false;
                                IsAdd = false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteSaveBeneficiaryCommand()
        {
            try
            {
                var title = await _titlesRepository.GetTitleCodeByTitle(SelectedTitle);
                var occupationcode = Occupations.Result.Where(x => x.NAME == Occupation).FirstOrDefault().CODE;
                if (FirstName == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please enter a first name", "Ok");
                }
                else if (LastName == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please enter a last name", "Ok");
                }
                else if (SelectedTitle == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please Select a Title", "Ok");
                }
                else if (Occupation == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please enter an occupation", "Ok");
                }
                else if (PhoneNumber == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please enter a phone number", "Ok");
                }
                else if (Gender == -1)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please Select a gender", "Ok");
                }
                else if (SelectedType == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please Select a beneficiary type", "Ok");
                }
                else if (SelectedRelationship == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please Select a relationship", "Ok");
                }
                else if (SelectedMaritalStatus == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please Select a marital status", "Ok");
                }
                else if (Address == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please enter an address", "Ok");
                }
                else
                {
                    var item = new BeneficiaryDetails
                    {
                        
                        TitleCode = title.TitleCode,
                        FirstName = FirstName,
                        LastName = LastName,
                        Type = SelectedType,
                        Relationship = SelectedRelationship,
                        Occupation = occupationcode,
                        Address = Address,
                        MaritalStatus = SelectedMaritalStatus,
                        PhoneNumber = PhoneNumber,
                        DateOfBirth = DateOfBirth,
                        Gender = Gender,
                        IsVisible = true,
                        OccupationName = Occupations.Result.Where(x => x.CODE == occupationcode).FirstOrDefault().NAME
                    };

                    #region codes
                    if (SelectedType.Contains("Primary"))
                    {
                        item.TypeCode = 2;
                    }
                    else if (SelectedType.Contains("Contingent"))
                    {
                        item.TypeCode = 3;
                    }
                    if (SelectedMaritalStatus.Contains("Single"))
                    {
                        item.MaritalStatusCode = 1;
                    }
                    else if (SelectedMaritalStatus.Contains("Married"))
                    {
                        item.MaritalStatusCode = 2;
                    }
                    else if (SelectedMaritalStatus.Contains("Widowed"))
                    {
                        item.MaritalStatusCode = 3;
                    }
                    else if (SelectedMaritalStatus.Contains("Divorced"))
                    {
                        item.MaritalStatusCode = 4;
                    }
                    if (SelectedRelationship.Contains("Brother"))
                    {
                        item.RelationshipCode = 13;
                    }
                    else if (SelectedRelationship.Contains("Sister"))
                    {
                        item.RelationshipCode = 14;
                    }
                    else if (SelectedRelationship.Contains("Child"))
                    {
                        item.RelationshipCode = 15;
                    }
                    else if (SelectedRelationship.Contains("Son"))
                    {
                        item.RelationshipCode = 2;
                    }
                    else if (SelectedRelationship.Contains("Daughter"))
                    {
                        item.RelationshipCode = 4;
                    }
                    else if (SelectedRelationship.Contains("Father"))
                    {
                        item.RelationshipCode = 3;
                    }
                    else if (SelectedRelationship.Contains("Mother"))
                    {
                        item.RelationshipCode = 5;
                    }
                    else if (SelectedRelationship.Contains("Nephew"))
                    {
                        item.RelationshipCode = 10;
                    }
                    else if (SelectedRelationship.Contains("Niece"))
                    {
                        item.RelationshipCode = 9;
                    }
                    else if (SelectedRelationship.Contains("Spouse"))
                    {
                        item.RelationshipCode = 7;
                    }
                    else if (SelectedRelationship.Contains("Others"))
                    {
                        item.RelationshipCode = 8;
                    }
                    #endregion
                    BeneficiaryList.Add(item);
                    BeneficiaryList = BeneficiaryList.ToList();
                    await _pageDialogService.DisplayAlertAsync("Saved", "Your" + " " + SelectedType + " " + "beneficiary details saved", "Ok");
                    IsVisible = false;
                    IsAdd = true;
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

        }

        private async void ExecuteDeleteBeneficiaryCommand(string fullname)
        {
            var item = BeneficiaryList.Where(x => x.FullName == fullname).FirstOrDefault();
            BeneficiaryList.Remove(item);
            BeneficiaryList = BeneficiaryList;
            await _pageDialogService.DisplayAlertAsync("Removed", "Beneficiary details removed", "Ok");
            if (item.FullName != null)
            {
                item.IsVisible = false;
                item.FirstName = null;
                item.LastName = null;
                IsVisible = true;
                IsAdd = false;
                FirstName = null;
                LastName = null;
                SelectedType = null;
                SelectedRelationship = null;
                Occupation = null;
                Address = null;
                SelectedMaritalStatus = null;
                PhoneNumber = "";
                DateOfBirth = DateTime.Parse("1/1/1980 12:00:00 PM");

                SelectedTitle = null;
                OtherName = null;
            }            
        }

        private async void ExecuteProceedCommand()
        {

            try
            {
                if (BeneficiaryList.Count < 1)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Please save your beneficiary details", "Ok");
                }
                else
                {
                    if (NewSignaturePicture == null)
                    {
                        await _pageDialogService.DisplayAlertAsync("Notice", "Please upload your e-signature", "Ok");
                    }
                    else if (IsExistingPolicy && string.IsNullOrEmpty(ExistingPolicyDetail))
                    {
                        await _pageDialogService.DisplayAlertAsync("Notice", "Please give details about your existing policy or untoggle the option above", "Ok");
                    }
                    else if (IsProposalDeclined && string.IsNullOrEmpty(DeclinedProposalDetail))
                    {
                        await _pageDialogService.DisplayAlertAsync("Notice", "Please give details about the declined proposal or untoggle the option above", "Ok");
                    }
                    else if (IsArmedForces && string.IsNullOrEmpty(MedicalGrade))
                    {
                        await _pageDialogService.DisplayAlertAsync("Notice", "Please enter your medical grade or untoggle the option above", "Ok");
                    }
                    else if (IsAdditionalFacts && string.IsNullOrEmpty(AdditionalFact))
                    {
                        await _pageDialogService.DisplayAlertAsync("Notice", "Please provide additional facts affecting the risk of assurance on your life", "Ok");
                    }
                    else if (IsResideOutsideNigeria && string.IsNullOrEmpty(IndicatedCountry))
                    {
                        await _pageDialogService.DisplayAlertAsync("Notice", "Please indicate the country you intend to reside in or untoggle the option above", "Ok");
                    }
                    else
                    {
                        BookOnline.BeneficiaryList = BeneficiaryList;
                        BookOnline.NewSignaturePicture = NewSignaturePicture;

                        ProposalQuestionnaire proposalQuestionnaire = new ProposalQuestionnaire
                        {
                            IsExistingPolicy = IsExistingPolicy,
                            IsAdditionalFacts = IsAdditionalFacts,
                            IsArmedForces = IsArmedForces,
                            IsProposalDeclined = IsProposalDeclined,
                            IsNonScheduledFlight = IsNonScheduledFlight,
                            AdditionalFacts = AdditionalFact,
                            Assurer = !HasExistingLifeAssurance ? string.Empty : Assurer,
                            ExistingPolicyLifeAssuranceValue = !HasExistingLifeAssurance ? string.Empty : ExistingPolicyLifeAssuranceValue,
                            DeclinedProposalDetail = DeclinedProposalDetail,
                            ExistingPolicyDetails = ExistingPolicyDetail,
                            MedicalGrade = MedicalGrade,
                            IsResideOutsideNigeria = IsResideOutsideNigeria,
                            IndicatedCountry = IndicatedCountry
                        };

                        var parameters = new NavigationParameters
                        {
                            { "ProductPlanId", ProductPlan.Id },
                            { "AgentId", LoggedAgent.Id },
                            { "ProspectId", Prospect.Id },
                            { "BookOnline", BookOnline },
                            { "UploadFile", Files },
                            { "ProposalQuestionnaire", proposalQuestionnaire }
                        };
                        await _navigationService.NavigateAsync("NonMedicalQuestionairePage", parameters);
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

        }

    }
}
