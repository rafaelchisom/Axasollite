﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AxaSolLite.ViewModels
{
    public class EFormsPageNewViewModel : BindableBase, INavigationAware
    {
        private readonly IAgentRepository _agentRepository;
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly Logical _logical;

        #region fields
        private bool _isBusy;
        private string _urlLink;
        private string _firstName;
        private string _lastName;
        private string _emailAddress;
        private string _selectedProduct;
        private List<string> _selectedProductClass = new List<string>();
        private SyncDataSample _formType;
        private List<Products> _productClasses = new List<Products>();
        private List<EForms> _myEForms = new List<EForms>();
        private List<string> _eForms = new List<string>();
        private string _selectedEForm;
        #endregion

        #region properties
        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }
        public SyncDataSample FormType
        {
            get { return _formType; }
            set { SetProperty(ref _formType, value); }
        }
        public string LastName
        {
            get { return _lastName; }
            set { SetProperty(ref _lastName, value); }
        }
        public string SelectedProduct
        {
            get { return _selectedProduct; }
            set { SetProperty(ref _selectedProduct, value); }
        }
        public string FirstName
        {
            get { return _firstName; }
            set { SetProperty(ref _firstName, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public string UrlLink
        {
            get { return _urlLink; }
            set { SetProperty(ref _urlLink, value); }
        }

        public Agent Agent { get; set; }
        public List<string> SelectedProductClass
        {
            get { return _selectedProductClass; }
            set { SetProperty(ref _selectedProductClass, value); }
        }

        public string SelectedEForm
        {
            get { return _selectedEForm; }
            set { SetProperty(ref _selectedEForm, value); }
        }
        public List<string> EForms
        {
            get { return _eForms; }
            set { SetProperty(ref _eForms, value); }
        }
        public List<EForms> MyEforms
        {
            get { return _myEForms; }
            set { SetProperty(ref _myEForms, value); }
        }
        public List<Products> ProductClasses
        {
            get { return _productClasses; }
            set { SetProperty(ref _productClasses, value); }
        }
        #endregion

        private DelegateCommand _sendCommand;
        private DelegateCommand _productSelectCommand;
        private object logical;

        public DelegateCommand SendCommand => _sendCommand ?? (_sendCommand = new DelegateCommand(ExecuteSendCommand));
        public DelegateCommand SelectProductCommand => _productSelectCommand ?? (_productSelectCommand = new DelegateCommand(ExecuteProductSelectCommand));



        public EFormsPageNewViewModel(INavigationService navigationService, IPageDialogService pageDialogService, IAgentRepository agentRepository, Logical logical)
        {

            _agentRepository = agentRepository;
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _logical = logical;


        }


        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            try
            {
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        Agent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }
                await InitializeDefaultValues();

            }
            catch (Exception ex)
            {

            }

        }

        private async Task InitializeDefaultValues()
        {
            try
            {
                ProductClasses = await _logical.GetEformsProducts();
                if (ProductClasses != null && ProductClasses.Count > 0)
                {
                    foreach (Products item in ProductClasses)
                    {
                        string product = string.Empty;
                        product = item.Product;
                        SelectedProductClass.Add(product);

                    }
                    SelectedProductClass = SelectedProductClass.ToList();
                }
            }
            catch (Exception ex)
            {

                ex.Message.ToString();
            }
        }

        private async void ExecuteProductSelectCommand()
        {
            try
            {
                Products MySelectedProduct = ProductClasses.Where(x => x.Product == SelectedProduct).FirstOrDefault();

                logical = new Logical();
                var res = await _logical.GetEformsBaseUrl();
                var baseUrl = res.BaseUrl;

                //baseUrl = "https://www.axamansard.com/insurance/forms/Index";
                //string FullName = Agent.FullName.ToLower();
                string FullName = Agent.Firstname + "%20" + Agent.Surname;
                var Value = MySelectedProduct.Id + "/" + Agent.AgentCode + "/" + FullName.ToLower() + "/" + Agent.EmailAddress + "/" + "axa-sol" + "/";
                var EncryptString = await _logical.GetEncryptValue(Value);
                UrlLink = baseUrl + EncryptString.ToString();


                //UrlLink = baseUrl + "/" + MySelectedProduct.Id + "/" + Agent.AgentCode + "/"  + FullName.ToLower() + "/" + Agent.EmailAddress + "/";
            }
            catch (Exception ex)
            {

                ex.Message.ToString();
            }

        }

        private async void ExecuteSendCommand()
        {
            IsBusy = true;
            try
            {


                if (string.IsNullOrEmpty(EmailAddress))
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Email Address", "Ok");

                }
                else if (string.IsNullOrEmpty(SelectedProduct))
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "select a Form", "Ok");

                }
                else if (string.IsNullOrEmpty(FirstName))
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "First Name", "Ok");

                }
                else if (string.IsNullOrEmpty(LastName))
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Last Name", "Ok");

                }


                else
                {
                    EformRequest req = new EformRequest();
                    req.FullName = FirstName + " " + LastName;
                    req.EmailAddress = EmailAddress;
                    req.AgentEmail = Agent.EmailAddress;
                    req.Plan = SelectedProduct;
                    req.EformLink = UrlLink;
                    req.AgentEmail = Agent.EmailAddress;

                    var sent = await _logical.SendEformLinkMail(req);
                    if (sent)
                    {
                        await _pageDialogService.DisplayAlertAsync("Mail Sent", "The e-form link has been sent to your customer's mail", "Ok");
                        AxaSolLiteReferralRate liteReferralRate = new AxaSolLiteReferralRate //assigning value to the object
                        {
                            AgentCode = Agent.AgentCode,
                            AgentFullName = Agent.FullName,
                            CustomerFullName = FirstName + " " + LastName,
                            ReferralLink = UrlLink,
                            PolicyName = SelectedProduct,
                            Sbu = Agent.SBU,
                            SbuName = Agent.SbuName
                        };
                        bool inserted = await _logical.InsertCustomerReferralRate(liteReferralRate);
                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Mail Not Sent", "Try Again", "Ok");

                    }
                }
                IsBusy = false;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                await _pageDialogService.DisplayAlertAsync("Mail Not Sent", "Try Again", "Ok");
                IsBusy = false;
            }



        }
    }
}
