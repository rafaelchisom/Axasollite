﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AxaSolLite.ViewModels
{
    public class BuyVehicleViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IMotorBoughtRepository _motorBoughtRepository;
        private readonly Logical _logical;

        private string _vahicleName;
        private int _yearOfManufacture;
        private string _title;

        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public int YearOfManufacture
        {
            get { return _yearOfManufacture; }
            set { SetProperty(ref _yearOfManufacture, value); }
        }
        public string VehicleName
        {
            get { return _vahicleName; }
            set { SetProperty(ref _vahicleName, value); }
        }

        private DelegateCommand _buyVehicleCommand;
        public DelegateCommand BuyVehicleCommand => _buyVehicleCommand ?? (_buyVehicleCommand = new DelegateCommand(ExecuteBuyVehicleCommand));

        public BuyVehicleViewModel(INavigationService navigationService, IPageDialogService pageDialogService, IMotorBoughtRepository motorBoughtRepository, Logical logical)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _motorBoughtRepository = motorBoughtRepository;
            _logical = logical;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            Title = "Buy Vehicle Page";
            var id = parameters.GetValue<int>("MotorId");
            var vehicleName = parameters.GetValue<string>("VahicleName");
            var motor = _motorBoughtRepository.GetById(id);
        }

        private async void ExecuteBuyVehicleCommand()
        {
            if (string.IsNullOrEmpty(VehicleName))
            {
                await _pageDialogService.DisplayAlertAsync("Warning", "Please enter vehicle name", "Ok");
                return;
            }
            else if(YearOfManufacture == 0)
            {
                await _pageDialogService.DisplayAlertAsync("Warning", "Please select year of manufacture", "Ok");
                return;
            }
            MotorBought motorBought = new MotorBought()
            {
                Id = 2,
                VehicleName = VehicleName,
                YearOfManufacture = YearOfManufacture
            };

            bool response = await _logical.GetMyName("Jesus");

            int saved = await _motorBoughtRepository.SaveAsync(motorBought);
            if(saved <= 0)
                await _pageDialogService.DisplayAlertAsync("Warning", "Unable to save record", "Ok");
            NavigationParameters parameters = new NavigationParameters
            {
                { "VahicleName", VehicleName },
                { "year", YearOfManufacture },
                { "myClass", motorBought },
                {"MotorId", motorBought.Id }
            };
            await _navigationService.NavigateAsync("BuyVehicleBeneficary", parameters);
        }
    }
}
