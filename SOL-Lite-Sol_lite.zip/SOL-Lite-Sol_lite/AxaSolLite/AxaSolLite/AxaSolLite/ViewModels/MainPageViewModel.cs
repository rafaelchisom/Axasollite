﻿//using AxaSolLite.Services.Contracts;
using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.ViewModels
{
    public class MainPageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IRepositoryManager _repositoryManager;
        private readonly IStatesRepository _statesRepository;
        private readonly ICountryRepository _countryRepository;

        private string _title;
        private string _username;
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public string UserName
        {
            get { { return _username; } }
            set { SetProperty(ref _username, value); }
        }
        private SyncDataSample _titles;
        private string _myTitles;
        private SyncDataSample _myStates;
        public SyncDataSample MyStates
        {
            get { return _myStates; }
            set { SetProperty(ref _myStates, value); }
        }
        private SyncDataSample _myCountries;
        public SyncDataSample MyCountries
        {
            get { return _myCountries; }
            set { SetProperty(ref _myCountries, value); }
        }
        private List<States> _states = new List<States>();
        public List<States> States
        {
            get { return _states; }
            set { SetProperty(ref _states, value); }
        }
        private List<Countries> _countries = new List<Countries>();
        public List<Countries> Countries
        {
            get { return _countries; }
            set { SetProperty(ref _countries, value); }
        }
        public string MyTitles
        {
            get { return _myTitles; }
            set { SetProperty(ref _myTitles, value); }
        }
        public SyncDataSample Titles
        {
            get { return _titles; }
            set { SetProperty(ref _titles, value); }
        }

        private DelegateCommand _loginCommand;
        public DelegateCommand LoginCommand => _loginCommand ?? (_loginCommand = new DelegateCommand(ExecuteLoginCommand));

        public MainPageViewModel(INavigationService navigationService, IRepositoryManager repositoryManager, IStatesRepository statesRepository, ICountryRepository countryRepository)
        {
            _navigationService = navigationService;
            _repositoryManager = repositoryManager;
            _statesRepository = statesRepository;
            _countryRepository = countryRepository;
        }
        private async void ExecuteLoginCommand()
        {
            var navigationParameter = new NavigationParameters();
            navigationParameter.Add("Username", this.UserName.Trim());
            await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/AgentWelcomePage", navigationParameter);
        }

        public async Task InitializeApplication()
        {
            Title = "AXA SOLUTIONS";
            Logical logical = new Logical();
            try     
            {
                await _repositoryManager.Initialize();


                MyCountries = await logical.GetCountryList();
                MyStates = await logical.GetStates(1);

                foreach (var item in MyCountries.Result)
                {
                    Countries countryToSave = new Countries();
                    countryToSave.Country = item.NAME;
                    countryToSave.CountryCode = item.CODE;
                    Countries.Add(countryToSave);
                }
                Countries = Countries.Where(x => x.Country != "Countries").ToList();

                foreach(var item in MyStates.Result)
                {
                    States statesToSave = new States();
                    statesToSave.State = item.NAME;
                    statesToSave.StateCode = item.CODE;
                    States.Add(statesToSave);
                }
                States = States.Where(x => x.State != "STATES").ToList();

                if(Countries != null && Countries.Count > 0)
                {
                    int x = await _countryRepository.SaveAllAsync(Countries);
                }

                if(States != null && States.Count > 0)
                {
                    int x = await _statesRepository.SaveAll(States);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            UserName = parameters.GetValue<string>("Username");
            await InitializeApplication();
        }
    }
}
