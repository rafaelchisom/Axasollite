﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AxaSolLite.ViewModels
{
	public class MyProfilePageViewModel : BindableBase, INavigationAware
	{
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IAgentRepository _agentRepository;
        private readonly Logical _logical;

        private bool _isBusy;
        private string _fullName;
        private string _emailAddress;
        private string _agentCode;
        private string _sbuCode;
        private string _sbuName;
        private string _phoneNumber;
        private string _subAgentCode;
        private bool _isAdvisor;
        private int _gender;
        private byte[] _profilePicture;

        public byte[] ProfilePicture
        {
            get { return _profilePicture; }
            set { SetProperty(ref _profilePicture, value); }
        }
        public int Gender
        {
            get { return _gender; }
            set { SetProperty(ref _gender, value); }
        }
        public bool IsAdvisor
        {
            get { return _isAdvisor; }
            set { SetProperty(ref _isAdvisor, value); }
        }
        public string SubAgentCode
        {
            get { return _subAgentCode; }
            set { SetProperty(ref _subAgentCode, value); }
        }
        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { SetProperty(ref _phoneNumber, value); }
        }
        public string SbuName
        {
            get { return _sbuName; }
            set { SetProperty(ref _sbuName, value); }
        }
        public string SbuCode
        {
            get { return _sbuCode; }
            set { SetProperty(ref _sbuCode, value); }
        }
        public string AgentCode
        {
            get { return _agentCode; }
            set { SetProperty(ref _agentCode, value); }
        }
        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }
        public string FullName
        {
            get { return _fullName; }
            set { SetProperty(ref _fullName, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public Agent LoggedAgent { get; set; }

        public MyProfilePageViewModel(INavigationService navigationService, IPageDialogService pageDialogService, IAgentRepository agentRepository,
            Logical logical)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _agentRepository = agentRepository;
            _logical = logical;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;
            try
            {
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }

                if (LoggedAgent.IsAdvisor)
                {
                    IsAdvisor = true;
                    SubAgentCode = LoggedAgent.SubAgentCode;
                }
                ProfilePicture = LoggedAgent.ProfilePicture;
                FullName = LoggedAgent.FullName;
                EmailAddress = LoggedAgent.EmailAddress;
                AgentCode = LoggedAgent.AgentCode;
                SbuCode = LoggedAgent.SBU;
                SbuName = LoggedAgent.SbuName;
                PhoneNumber = LoggedAgent.MobileNo;
                Gender = (!LoggedAgent.IsAdvisor && !LoggedAgent.IsTeamManager) ? (LoggedAgent.Gender.Contains("M") ? 1 : 0) : 1;
                
            }
            catch (Exception ex)
            {
                
            }
            IsBusy = false;
        }
    }
}
