﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace AxaSolLite.ViewModels
{
	public class AgentReferralLinkViewModel : BindableBase, INavigationAware
	{
        private readonly IAgentRepository _agentRepository;
        private readonly IProspectRepository _prospectRepository;
        private readonly IPageDialogService _pageDialogService;
        private readonly IGenBizBranchRepository _genBizBranchRepository;
        private readonly IBranchesRepository _branchesRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly INavigationService _navigationService;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        private bool _isBusy;
        private string _urlLink;
        private bool _isLife;
        private string _selectedBranch;
        private int _branch;
        private string _productCode;
        private Prospect _prospect;
        private Guid _prospectId;
        private Guid _productPlanId;
        private ProductPlan _productPlan;
        private ObservableCollection<string> _branches = new ObservableCollection<string>();
        private List<GenBizBranch> _myBranches = new List<GenBizBranch>();
        private List<Branches> _lifeBranches = new List<Branches>();

        public bool IsLife
        {
            get { return _isLife; }
            set { SetProperty(ref _isLife, value); }
        }
        public string UrlLink
        {
            get { return _urlLink; }
            set { SetProperty(ref _urlLink, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public string SelectedBranch
        {
            get { return _selectedBranch; }
            set { SetProperty(ref _selectedBranch, value); }
        }
        public int Branch
        {
            get { return _branch; }
            set { SetProperty(ref _branch, value); }
        }
        public string ProductCode
        {
            get { return _productCode; }
            set { SetProperty(ref _productCode, value); }
        }
        public ObservableCollection<string> Branches
        {
            get { return _branches; }
            set { SetProperty(ref _branches, value); }
        }
        public List<Branches> LifeBranches
        {
            get { return _lifeBranches; }
            set { SetProperty(ref _lifeBranches, value); }
        }
        public List<GenBizBranch> MyBranches
        {
            get { return _myBranches; }
            set { SetProperty(ref _myBranches, value); }
        }
        public Prospect Prospect
        {
            get { return _prospect = _prospect ?? (_prospect = new Prospect()); }
            set { SetProperty(ref _prospect, value); }
        }
        public ProductPlan ProductPlan
        {
            get { return _productPlan = _productPlan ?? (_productPlan = new ProductPlan()); }
            set { SetProperty(ref _productPlan, value); }
        }
        public Agent Agent { get; set; }
        private Logical logical = null;

        private DelegateCommand _sendLinkCommand;
        private DelegateCommand _selectBranchCommand;
        private DelegateCommand _backCommand;
        public DelegateCommand SendLinkCommand => _sendLinkCommand ?? (_sendLinkCommand = new DelegateCommand(ExecuteSendLinkCommand));
        public DelegateCommand SelectBranchCommand => _selectBranchCommand ?? (_selectBranchCommand = new DelegateCommand(ExecuteSelectBranchCommand));
        public DelegateCommand BackCommand => _backCommand ?? (_backCommand = new DelegateCommand(ExecuteBackCommand));

        public AgentReferralLinkViewModel(INavigationService navigationService, IAgentRepository agentRepository, IProspectRepository prospectRepository,
            IGenBizBranchRepository genBizBranchRepository, IBranchesRepository branchesRepository,
             IPageDialogService pageDialogService,
            IProductPlansRepository productPlansRepository, EncryptUtils encryptUtils)
        {
            _agentRepository = agentRepository;
            _navigationService = navigationService;
            _prospectRepository = prospectRepository;
            _pageDialogService = pageDialogService;
            _branchesRepository = branchesRepository;
            _genBizBranchRepository = genBizBranchRepository;
            _productPlansRepository = productPlansRepository;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            try
            {
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        Agent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                    if (parameters.ContainsKey("ProspectId"))
                    {
                        //Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                        //Prospect = await _prospectRepository.GetById(_prospectId);

                        Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                        EncryptedProspect encryptedProspect = await _prospectRepository.GetById(_prospectId);
                        string serializedProspect = _encryptUtils.aesDecrypt(encryptedProspect.Prospect);
                        Prospect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                    }
                    if (parameters.ContainsKey("ProductPlanId"))
                    {
                        Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId);
                        ProductPlan = await _productPlansRepository.GetProductPlanByProductPlanId(_productPlanId);
                    }
                }
                #region ProductCode
                if (ProductPlan.PlanCategory == "Auto Go")
                {
                    ProductCode = "29";
                }
                else if (ProductPlan.PlanCategory == "Auto Classic")
                {
                    ProductCode = "48";
                }
                else if (ProductPlan.PlanCategory == "Auto Plus")
                {
                    ProductCode = "7";
                }
                else if (ProductPlan.PlanCategory == "Instant Plan")
                {
                    ProductCode = "131";
                }
                else if (ProductPlan.PlanCategory == "Education Plan Plus")
                {
                    ProductCode = "456";
                }
                else if (ProductPlan.PlanCategory == "Life Savings")
                {
                    ProductCode = "118";
                }
                #endregion
                IsLife = ProductPlan.IsLife;
                if (IsLife)
                {
                    LifeBranches = await _branchesRepository.GetBranches();
                    foreach (Branches item in LifeBranches)
                    {
                        string branch = string.Empty;
                        branch = item.Branch;
                        Branches.Add(branch);
                    }
                }
                else
                {
                    MyBranches = await _genBizBranchRepository.GetGenBizBranches();
                    foreach (GenBizBranch item in MyBranches)
                    {
                        string branch = string.Empty;
                        branch = item.BranchName;
                        Branches.Add(branch);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private async void ExecuteSelectBranchCommand()
        {
            try
            {
                logical = new Logical();
                var res = await logical.GetReferralLinkBaseUrl();
                var baseUrl = res.BaseUrl;
                if (IsLife)
                {
                    Branch = LifeBranches.Where(branch => branch.Branch == SelectedBranch).FirstOrDefault().BranchCode;
                }
                else
                {
                    Branch = MyBranches.Where(branch => branch.BranchName == SelectedBranch).FirstOrDefault().BranchCode;
                }
                if(Prospect.CustomerNumber != null)
                {
                    UrlLink = baseUrl + Agent.AgentCode + "/" + Agent.SBU + "/144/" + Branch + "/" + ProductCode + "/" + Prospect.CustomerNumber + "/";
                }
                else
                {
                    UrlLink = baseUrl + Agent.AgentCode + "/" + Agent.SBU + "/144/" + Branch + "/" + ProductCode;
                }

                
            }
            catch (Exception ex)
            {

            }
        }

        private async void ExecuteSendLinkCommand()
        {
            IsBusy = true;
            try
            {
                if (string.IsNullOrEmpty(SelectedBranch))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a branch", "Ok");
                }
                else
                {
                    logical = new Logical();
                    ReferralLinkRequest req = new ReferralLinkRequest();
                    req.FullName = Prospect.FullName;
                    req.CustomerNumber = Prospect.CustomerNumber;
                    req.EmailAddress = Prospect.Email;
                    req.Plan = ProductPlan.PlanCategory;
                    req.ReferralLink = UrlLink;
                    var sent = await logical.SendReferralLinkMail(req);
                    if (sent)
                    {
                        await _pageDialogService.DisplayAlertAsync("Mail sent", "Referral link sent", "ok");
                        await _navigationService.GoBackAsync();
                        


                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Mail Not Sent", "Unable to send Referral Link", "ok");
                        await _navigationService.GoBackAsync();
                    }
                }


            }
            catch (Exception ex)
            {

            }
            IsBusy = false;



        }

        private  void ExecuteBackCommand()
        {
            
        }
    }
}
