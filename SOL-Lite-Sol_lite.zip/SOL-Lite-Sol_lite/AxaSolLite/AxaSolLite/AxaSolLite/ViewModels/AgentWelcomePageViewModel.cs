﻿using AxaSolLite.Extensions;
using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Plugin.FilePicker;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AxaSolLite.ViewModels
{
    public class AgentWelcomePageViewModel : BindableBase, INavigationAware
    {
        private const string ResourceNamespace = "AxaSolLite.Resources.Assets.";
        SecureString secureString = new SecureString();

        private readonly IRepositoryManager _repositoryManager;
        private readonly IUserManager _userService;
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IMediaManager _deviceManager;
        private readonly IAgentRepository _agentRepository;
        private readonly IMotorProductRepository _productPlanRepository;
        private readonly ISyncDateRecordRepository _loginDateRecordRepository;
        private readonly ITitlesRepository _titlesRepository;
        private readonly IStatesRepository _statesRepository;
        private readonly ICountryRepository _countryRepository;
        private readonly ISyncDateRecordRepository _syncDateRecordRepository;
        private readonly IBranchesRepository _branchesRepository;
        private readonly IGenBizBranchRepository _genBizBranchRepository;
        private readonly IDevice _device;
        private readonly Logical _logical;

        private bool _isBusy;
        private string _text;
        private string _email;
        private string _username;
        private string _authToken;
        private string _encryptedString;
        private string _firstName;
        private string _lastName;
        private string _agentCode;
        private string _middleName;
        private string _location;
        private string _emailAddress;
        private string _contactNumber;
        private string _branch;
        private bool _isExternal;
        private Agent _agent;
        private ImageSource _signaturePicture;
        private byte[] _newSignaturePicture;
        private string[] _fileTypes;
        private string _contents;
        private SyncDataSample _titles;
        private int _titleId;
        private List<Titles> _titlesToSave = new List<Titles>();
        private SyncDataSample _myStates;
        private SyncDataSample _myCountries;
        private SyncDataSample _myBranches;
        private SyncDataSample _myGenBizBranches;
        private List<States> _states = new List<States>();
        private List<Countries> _countries = new List<Countries>();
        private List<Branches> _branches = new List<Branches>();
        private List<GenBizBranch> _genBizBranches = new List<GenBizBranch>();

        public SyncDataSample MyStates
        {
            get { return _myStates; }
            set { SetProperty(ref _myStates, value); }
        }
        public SyncDataSample MyCountries
        {
            get { return _myCountries; }
            set { SetProperty(ref _myCountries, value); }
        }
        public SyncDataSample MyBranches
        {
            get { return _myBranches; }
            set { SetProperty(ref _myBranches, value); }
        }
        public SyncDataSample MyGenBizBranches
        {
            get { return _myGenBizBranches; }
            set { SetProperty(ref _myGenBizBranches, value); }
        }
        public List<GenBizBranch> GenBizBranches
        {
            get { return _genBizBranches; }
            set { SetProperty(ref _genBizBranches, value); }
        }
        public List<States> States
        {
            get { return _states; }
            set { SetProperty(ref _states, value); }
        }
        public List<Countries> Countries
        {
            get { return _countries; }
            set { SetProperty(ref _countries, value); }
        }
        public List<Branches> Branches
        {
            get { return _branches; }
            set { SetProperty(ref _branches, value); }
        }
        public List<Titles> TitlesToSave
        {
            get { return _titlesToSave; }
            set { SetProperty(ref _titlesToSave, value); }
        }
        public int TitleId
        {
            get { return _titleId; }
            set { SetProperty(ref _titleId, value); }
        }
        public SyncDataSample Titles
        {
            get { return _titles; }
            set { SetProperty(ref _titles, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public string UserName
        {
            get { { return _username; } }
            set { SetProperty(ref _username, value); }
        }
        public string Email
        {
            get { { return _email; } }
            set { SetProperty(ref _email, value); }
        }

        public string AuthToken
        {
            get { { return _authToken; } }
            set { SetProperty(ref _authToken, value); }
        }
        public string EncryptedString
        {
            get { { return _encryptedString; } }
            set { SetProperty(ref _encryptedString, value); }
        }
        public string FirstName
        {
            get { return _firstName; }
            set { SetProperty(ref _firstName, value); }
        }
        public string LastName
        {
            get { return _lastName; }
            set { SetProperty(ref _lastName, value); }
        }
        public string AgentCode
        {
            get { return _agentCode; }
            set { SetProperty(ref _agentCode, value); }
        }
        public string MiddleName
        {
            get { return _middleName; }
            set { SetProperty(ref _middleName, value); }
        }
        public string Location
        {
            get { return _location; }
            set { SetProperty(ref _location, value); }
        }
        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }
        public string ContactNumber
        {
            get { return _contactNumber; }
            set { SetProperty(ref _contactNumber, value); }
        }
        public string Branch
        {
            get { return _branch; }
            set { SetProperty(ref _branch, value); }
        }
        public string Text
        {
            get { return _text; }
            set { SetProperty(ref _text, value); }
        }
        public bool IsExternal
        {
            get { return _isExternal; }
            set { SetProperty(ref _isExternal, value); }
        }
        public ImageSource SignaturePicture
        {
            get { return _signaturePicture; }
            set { SetProperty(ref _signaturePicture, value); }
        }
        public byte[] NewSignaturePicture
        {
            get { return _newSignaturePicture; }
            set { SetProperty(ref _newSignaturePicture, value); }
        }
        public string[] FileTypes
        {
            get { return _fileTypes; }
            set { SetProperty(ref _fileTypes, value); }
        }
        public string Contents
        {
            get { return _contents; }
            set { SetProperty(ref _contents, value); }
        }
        public Agent Agent
        {
            get { return _agent = _agent ?? (_agent = new Agent()); }
            set { SetProperty(ref _agent, value); }
        }

        ArrayToImageConverter converter = new ArrayToImageConverter();

        private DelegateCommand _proceedCommand;
        private DelegateCommand _changePictureCommand;

        public DelegateCommand ChangePictureCommand => _changePictureCommand ?? (_changePictureCommand = new DelegateCommand(ExecuteChangePictureCommand));
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProceed));


        public AgentWelcomePageViewModel(IUserManager userService,
            INavigationService navigationService,
            IPageDialogService pageDialogService,
            IRepositoryManager repositoryServices,
            IMediaManager deviceManager, ITitlesRepository titlesRepository,
            IAgentRepository agentRepository, ISyncDateRecordRepository loginDateRecordRepository,
            IMotorProductRepository productPlanRepository, Logical logical,
            IStatesRepository statesRepository, ICountryRepository countryRepository,
            IBranchesRepository branchesRepository, IGenBizBranchRepository genBizBranchRepository, ISyncDateRecordRepository syncDateRecordRepository, IDevice device)
        {
            _userService = userService;
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _repositoryManager = repositoryServices;
            _deviceManager = deviceManager;
            _agentRepository = agentRepository;
            _productPlanRepository = productPlanRepository;
            _logical = logical;
            _loginDateRecordRepository = loginDateRecordRepository;
            _titlesRepository = titlesRepository;
            _statesRepository = statesRepository;
            _countryRepository = countryRepository;
            _branchesRepository = branchesRepository;
            _genBizBranchRepository = genBizBranchRepository;
            _syncDateRecordRepository = syncDateRecordRepository;
            _device = device;
        }

        public async void ExecuteChangePictureCommand()
            {
            try
            {
                bool choice = await _pageDialogService.DisplayAlertAsync("Confirm", "Please select how you wish to upload a document", "Gallery", "Camera");
                if (choice)
                {
                    if (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS)
                    {
                        FileTypes = new string[] { "image/png", "image/jpeg", "application/pdf" };
                    }
                    await PickedFiles(FileTypes);
                }
                else
                {
                    if (_deviceManager.CameraAvailable)
                    {
                        var newDisplayProfilePicture = await _deviceManager.TakePhotoAsync();
                        if (newDisplayProfilePicture != null)
                        {
                            NewSignaturePicture = newDisplayProfilePicture.FileContent;
                            Agent.ProfilePicture = newDisplayProfilePicture.FileContent;
                            int updated = await _agentRepository.UpdateAsync(Agent);
                            //RefreshProspectProfilePicture();
                        }
                    }
                }

                SignaturePicture = converter.Convert(NewSignaturePicture, null, null, null) as ImageSource;
            }
            catch (Exception ex)
            {
            }
        }

        public async Task PickedFiles(string[] fileTypes)
        {
            try
            {
                var pickedFile = await CrossFilePicker.Current.PickFile(fileTypes);

                if (pickedFile != null)
                {
                    if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase))
                    {
                        Contents = System.Text.Encoding.UTF8.GetString(pickedFile.DataArray, 0, pickedFile.DataArray.Length);
                        NewSignaturePicture = pickedFile.DataArray;

                        Agent.ProfilePicture = NewSignaturePicture;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public void RefreshProspectProfilePicture()
        {
            try
            {
                ArrayToImageConverter converter = new ArrayToImageConverter();
                var convertedImage = converter.Convert(NewSignaturePicture, null, null, null) as ImageSource;

                SignaturePicture = convertedImage ?? "";
            }
            catch (Exception ex)
            {
            }
        }

        public async void ExecuteProceed()
        {
            IsBusy = true;
            try
            {
                List<char> MyList = new List<char>();
                var States = await _logical.GetStates(1);
                int IndexToPick = 0;

                if(States != null && States.IsSuccessful)
                {
                    for (int i = 1; i < 8; i++)
                    {
                        char charToUse = States.Result[i].NAME.ElementAt(IndexToPick);
                        MyList.Add(charToUse);
                        IndexToPick++;
                        if (IndexToPick == 3)
                        {
                            IndexToPick = 1;
                        }
                    }

                    var lastState = States.Result.LastOrDefault().NAME.ToList().Where(x => States.Result.LastOrDefault().NAME.ToList().IndexOf(x) % 2 == 0);
                    foreach (char item in lastState)
                    {
                        MyList.Add(item);
                    }
                    var MyLastState = string.Join("", MyList);

                    foreach (char item in MyLastState)
                    {
                        secureString.AppendChar(item);
                    }
                }

                Application.Current.Properties["Usage"] = secureString;

                var navigationParameter = new NavigationParameters();
                navigationParameter.Add("AgentId", Agent.Id);

                await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/HomeRenewalPage", navigationParameter);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;
            try
            {
                RefreshProspectProfilePicture();
                await InitializeDefaultValues();
                UserName = parameters.GetValue<string>("Username");

                AgentCode = parameters.GetValue<string>("AgentCode");
                //Email = parameters.GetValue<string>("Email");
                Email = "leesi.monokpo@axamansard.com";
                //AgentCode = "3432300943";
                EncryptedString = parameters.GetValue<string>("EncryptedString");


                IsExternal = parameters.GetValue<bool>("IsExternal");
                if (IsExternal == true)
                {
                    
                    var response = await _logical.GetAdvisorsDetailsByAgentcode(AgentCode);
                    if (response.Count == 1)
                    {
                        foreach (var item in response)
                        {
                            if (item.Email.ToLower() == Email)
                            {
                                var PolicyProcessingRegion = await _logical.GetPolicyProcessingDetailsBySBU(Convert.ToInt16(item.SbuCode));
                                PolicyProcessingDetails[] policyProcessingDetails = PolicyProcessingRegion.ToArray();

                                FirstName = item.AgentName;
                                AgentCode = "Code: " + item.SubAgentCode;
                                Location = "SBU: " + item.SbuName;
                                EmailAddress = "Email: " + item.Email;
                             
                                ContactNumber = "Tel: " + item.PhoneNumber;
                                Branch = "Branch: " + item.PolicyRegion;
                                Text = "Welcome " + FirstName;
                                var agent = new Agent
                                {
                                    Id = Guid.NewGuid(),
                                    Firstname = item.AgentName,
                                    MobileNo = item.PhoneNumber,
                                    //EmailAddress = item.Email,
                                    EmailAddress = "Oluwapemi.Siyanbola@axamansard.com",
                                    SubAgentCode = item.SubAgentCode,
                                    SbuName = item.SbuName,
                                    SBU = Convert.ToString(item.SbuCode),
                                    Office = item.PolicyRegion,
                                    PolicyProcessingRegion = policyProcessingDetails[0].PolicyRegion,
                                    PolicyProcessingRegionID = policyProcessingDetails[0].PolicyRegionID,
                                    AgentCode = item.AgentCode,
                                    IsAdvisor = true,
                                    AgentAuthToken = AuthToken,
                                    TokenEncrypt = EncryptedString,
                                    IsExternalAgent = true,
                                    IsTeamManager = false
                                };
                                var y = await _agentRepository.SaveAsync(agent);
                                Agent = agent;
                            }
                            else
                            {
                                await _pageDialogService.DisplayAlertAsync("No record", "No record found", "Ok");
                                await _navigationService.NavigateAsync("LoginPage");
                            }
                        }
                    }
                    else
                    {
                        var res = await _logical.GetTeamManagersDetailsByAgentcode(AgentCode);
                        if (res.Count == 1)
                        {
                            foreach (var item in res)
                            {

                                if (item.Email.ToLower() == Email)
                                {
                                    var PolicyProcessingRegion = await _logical.GetPolicyProcessingDetailsBySBU(Convert.ToInt16(item.SbuCode));
                                    PolicyProcessingDetails[] policyProcessingDetails = PolicyProcessingRegion.ToArray();

                                    FirstName = item.AgentName;
                                    AgentCode = "Code: " + item.AgentCode;
                                    Location = "SBU: " + item.SbuName;
                                    EmailAddress = "Email: " + item.Email;
                                    ContactNumber = "Tel: " + item.PhoneNumber;
                                    Branch = "Branch: " + item.PolicyRegion;
                                    Text = "Welcome " + FirstName;
                                    var agent = new Agent
                                    {
                                        Id = Guid.NewGuid(),
                                        Firstname = item.AgentName,
                                        MobileNo = item.PhoneNumber,
                                        EmailAddress = item.Email,
                                        SbuName = item.SbuName,
                                        SBU = Convert.ToString(item.SbuCode),
                                        Office = item.PolicyRegion,
                                        PolicyProcessingRegion = policyProcessingDetails[0].PolicyRegion,
                                        PolicyProcessingRegionID = policyProcessingDetails[0].PolicyRegionID,
                                        AgentCode = item.AgentCode,
                                        IsTeamManager = true,
                                        AgentAuthToken = AuthToken,
                                        TokenEncrypt = EncryptedString,
                                        IsExternalAgent = true,
                                        IsAdvisor = false
                                    };
                                    var y = await _agentRepository.SaveAsync(agent);
                                    Agent = agent;
                                }
                                else
                                {
                                    await _pageDialogService.DisplayAlertAsync("No record", "No record found", "Ok");
                                    await _navigationService.NavigateAsync("LoginPage");
                                }

                            }


                        }
                        else
                        {
                            await _pageDialogService.DisplayAlertAsync("No record", "No record found", "Ok");
                            await _navigationService.NavigateAsync("LoginPage");
                        }
                    }
                }
                else
                {
                    GetAgentDetailsRequest AgentdetailsReq = new GetAgentDetailsRequest();
                    //AgentdetailsReq.Pssusername = UserName;
                   AgentdetailsReq.Pssusername = "khassan";

                  
                    var getPssDetailsResponse = await _logical.GetAgentDetailsResponseAsync(AgentdetailsReq);
                    var PolicyProcessingRegion = await _logical.GetPolicyProcessingDetailsBySBU(Convert.ToInt16(getPssDetailsResponse.SBU));
                    PolicyProcessingDetails[] policyProcessingDetails = PolicyProcessingRegion.ToArray();
                    var SBUDetails = await _logical.GetSBUDetails();
                    string SBUName = SBUDetails.Where(x => x.SBU_Code == getPssDetailsResponse.SBU).FirstOrDefault().SBU_Desc;

                    FirstName = getPssDetailsResponse.FullName;
                    LastName = getPssDetailsResponse.Surname;
                    AgentCode = "Code: " + getPssDetailsResponse.AgentCode;
                    MiddleName = getPssDetailsResponse.OtherName;
                    Location = "SBU: " + SBUName;
                    EmailAddress = "Email: " + getPssDetailsResponse.EmailAddress;
                    ContactNumber = "Tel: " + getPssDetailsResponse.MobileNo;
                    Branch = "Branch: " + policyProcessingDetails[0].PolicyRegion;
                    Text = "Welcome " + FirstName;

                    var agent = new Agent
                    {
                        Id = Guid.NewGuid(),
                        AgentCode = getPssDetailsResponse.AgentCode,
                        Staffno = getPssDetailsResponse.Staffno,
                        Surname = getPssDetailsResponse.Surname,
                        Firstname = getPssDetailsResponse.Firstname,
                        OtherName = getPssDetailsResponse.OtherName,
                        Gender = getPssDetailsResponse.Gender,
                        CurrentLevel = getPssDetailsResponse.CurrentLevel,
                        Confirmationstatus = getPssDetailsResponse.Confirmationstatus,
                        Recruitmentagency = getPssDetailsResponse.Recruitmentagency,
                        Status = getPssDetailsResponse.Status,
                        ResignationDate = getPssDetailsResponse.ResignationDate,
                        DateOfEntry = getPssDetailsResponse.DateOfEntry,
                        MobileNo = getPssDetailsResponse.MobileNo,
                        SbuName = SBUName,
                        //EmailAddress = getPssDetailsResponse.EmailAddress,
                        EmailAddress = "Oluwapemi.Siyanbola@axamansard.com",
                        PssUsername = UserName,
                        SsType = getPssDetailsResponse.SsType,
                        Office = getPssDetailsResponse.Office,
                        Branch = getPssDetailsResponse.Branch,
                        BmUsername = getPssDetailsResponse.BmUsername,
                        BankCode = getPssDetailsResponse.BankCode,
                        BankAccountName = getPssDetailsResponse.BankAccountName,
                        EchannelCode = getPssDetailsResponse.EchannelCode,
                        BankAccountNumber = getPssDetailsResponse.BankAccountNumber,
                        PssHouse = getPssDetailsResponse.PssHouse,
                        MailingList = getPssDetailsResponse.MailingList,
                        SortCode = getPssDetailsResponse.SortCode,
                        Bvn = getPssDetailsResponse.Bvn,
                        LastPromotionDate = getPssDetailsResponse.LastPromotionDate,
                        //MeansOfIdentification = getPssDetailsResponse.MeansOfIdentification,
                        BankName = getPssDetailsResponse.BankName,
                        SBU = getPssDetailsResponse.SBU,
                        ActionMessage = getPssDetailsResponse.ActionMessage,
                        //Photo = getPssDetailsResponse.Photo,
                        SubAgentCode = getPssDetailsResponse.SubAgentCode,
                        PolicyProcessingRegion = policyProcessingDetails[0].PolicyRegion,
                        PolicyProcessingRegionID = policyProcessingDetails[0].PolicyRegionID,
                        IsAdvisor = false,
                        IsTeamManager = false,
                        IsExternalAgent = false,
                        AgentAuthToken = AuthToken,
                        TokenEncrypt = EncryptedString,
                    };
                    var y = await _agentRepository.SaveAsync(agent);
                    Agent = agent;

                    var deviceId = _device.GetIdentifier();

                    LoginAuditTrailRequest request = new LoginAuditTrailRequest();
                    request.UserName = UserName;
                    request.AgentCode = agent.AgentCode;
                    request.AgentName = agent.FullName;
                    request.SbuCode = agent.SBU;
                    request.SbuName = agent.SbuName;
                    request.Grp = Convert.ToString( agent.Group);
                    request.AgentType = "PSS";
                    request.DeviceId = deviceId;


                    var insert = await _logical.SaveLoginAuditTrailToDb(request);
                    int checkExistingUser = await _logical.CheckNewUserSignIn(UserName, deviceId);
                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                await _pageDialogService.DisplayAlertAsync("No record", "No record found", "Ok");
                await _navigationService.NavigateAsync("LoginPage");
            }
            IsBusy = false;
        }

        private async Task InitializeDefaultValues()
        {
            try
            {
                bool RequiresSync = false;
                SyncDate LastSyncDate = new SyncDate();
                int NoOfDaysSinceLastSync = 0;

                List<SyncDate> AllSyncDates = await _syncDateRecordRepository.GetSyncDates();

                if (AllSyncDates != null && AllSyncDates.Count > 0)
                {
                    LastSyncDate = AllSyncDates.Last();
                    NoOfDaysSinceLastSync = Convert.ToInt32((DateTime.Now - LastSyncDate.LastSyncDate).TotalDays);
                    if (NoOfDaysSinceLastSync > 15)
                    {
                        RequiresSync = true;
                    }
                }
                else
                    RequiresSync = true;

                if (RequiresSync)
                {
                    Titles = await _logical.GetProspectTitles();
                    foreach (var item in Titles.Result)
                    {
                        Titles TitleToSave = new Titles();
                        TitleId = item.CODE;
                        TitleToSave.Title = item.NAME;
                        TitleToSave.TitleCode = item.CODE;
                        TitlesToSave.Add(TitleToSave);
                    }

                    MyCountries = await _logical.GetCountryList();
                    MyStates = await _logical.GetStates(1);
                    MyBranches = await _logical.GetBranches(2);
                    MyGenBizBranches = await _logical.GetBranches(1);
                    foreach (var item in MyCountries.Result)
                    {
                        Countries countryToSave = new Countries
                        {
                            Country = item.NAME,
                            CountryCode = item.CODE
                        };
                        Countries.Add(countryToSave);
                    }
                    Countries = Countries.Where(x => x.Country != "Countries").ToList();

                    foreach (var item in MyStates.Result)
                    {
                        States statesToSave = new States
                        {
                            State = item.NAME,
                            StateCode = item.CODE
                        };
                        States.Add(statesToSave);
                    }
                    States = States.Where(x => x.State != "STATES").ToList();

                    foreach (var item in MyBranches.Result)
                    {
                        Branches BranchToSave = new Branches
                        {
                            Branch = item.NAME,
                            BranchCode = item.CODE
                        };
                        Branches.Add(BranchToSave);
                    }
                    Branches = Branches.Where(x => x.Branch != "BRANCHES").ToList();

                    foreach (var item in MyGenBizBranches.Result)
                    {
                        GenBizBranch BranchToSave = new GenBizBranch
                        {
                            BranchName = item.NAME,
                            BranchCode = item.CODE
                        };
                        GenBizBranches.Add(BranchToSave);
                    }
                    GenBizBranches = GenBizBranches.Where(x => x.BranchName != "BRANCHES").ToList();


                    if (TitlesToSave != null && TitlesToSave.Count > 0)
                    {
                        int x = await _titlesRepository.SaveAll(TitlesToSave);
                    }
                    if (Countries != null && Countries.Count > 0)
                    {
                        int x = await _countryRepository.SaveAllAsync(Countries);
                    }
                    if (Branches != null && Branches.Count > 0)
                    {
                        int x = await _branchesRepository.SaveAll(Branches);
                    }
                    if (GenBizBranches != null && GenBizBranches.Count > 0)
                    {
                        int x = await _genBizBranchRepository.SaveAllAsync(GenBizBranches);
                    }
                    if (States != null && States.Count > 0)
                    {
                        int x = await _statesRepository.SaveAll(States);
                        SyncDate CurrentSyncDate = new SyncDate
                        {
                            LastSyncDate = DateTime.Now
                        };
                        int syncDateSaved = await _syncDateRecordRepository.SaveSyncDate(CurrentSyncDate);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}
