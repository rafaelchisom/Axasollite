﻿using AxaSolLite.Models;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AxaSolLite.ViewModels
{
    public class MyPopupViewModel : BindableBase, INavigationAware
    {
        private string _name;
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public Action<PopupOptions> CallBack { get; set; }

        private DelegateCommand goBackCommand;
        public DelegateCommand GoBackCommand => goBackCommand ?? (goBackCommand = new DelegateCommand(ExecuteGoBack));

        public MyPopupViewModel(string name, Action<PopupOptions> callBack)
        {
            CallBack = callBack;
        }

        private void ExecuteGoBack()
        {
            PopupOptions dd = new PopupOptions
            {
                Name = " Idemudia",
                Color = "blue",
                Size = "20px"
            };

            CallBack(dd);
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            
        }
    }
}
