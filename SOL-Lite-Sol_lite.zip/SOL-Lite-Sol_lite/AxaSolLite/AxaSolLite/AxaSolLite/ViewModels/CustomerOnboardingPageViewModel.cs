﻿using AxaSolLite.Models;
using AxaSolLite.Models.CustomerOnboardingCreateCase;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Plugin.FilePicker;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace AxaSolLite.ViewModels
{
    public class CustomerOnboardingPageViewModel : BindableBase, INavigationAware
    {
        private readonly IPageDialogService _pageDialogService;
        private readonly INavigationService _navigationService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IUserManager _userManager;
        private readonly IMediaManager _deviceManager;
        private readonly IUserRepository _userRepository;
        private readonly ITitlesRepository _titlesRepository;
        private readonly IStatesRepository _statesRepository;
        private readonly ICountryRepository _countryRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        #region Fields
        public bool _isBusy;
        private string _customerNumber;
        private string _title;
        private bool _nationalIdToggled;
        private bool _driversLicenseToggled;
        private bool _votersCardToggled;
        private bool _internationalPassportToggled;
        private string _firstName;
        private string _lastName;
        private string _middleName;
        private string _emailAddress;
        private string _gender;
        private DateTime _dateOfBirth;
        private string _customerTitle;
        private string _phoneNumber;
        private string _occupation;
        private string _nationality;
        private string _stateOfOrigin;
        private string _city;
        private string _residentialAddress;
        private string _countryOfResidence;
        private string _town;
        private string _bVN;
        private long _bVNConverted;
        private string _residencePermitNo;
        private string _meansOfIdentification;
        private string _capturedSignature;
        private string _fileLabel;
        private string _fileLabelPath;
        private string _religion;
        private string[] _fileTypes;
        private string _extension;
        private string _contentType;
        private AccountOpeningFormResponse _accountOpeningForm = new AccountOpeningFormResponse();
        private bool _isNigerian;
        private bool _isForeigner;
        private bool _middleNameExists;
        private bool _middleNameNotExist;
        private ObservableCollection<FileVariable> _fileNameList = new ObservableCollection<FileVariable>();
        private Dictionary<object, object> _fileByteList = new Dictionary<object, object>();
        private string _documentCategory;
        private byte[] _contents;
        private List<string> _countries = new List<string>();
        private List<string> _states = new List<string>();
        private bool _conditionsMet;
        private bool _idCardSelected;
        private bool _isPoliticallyExposed;
        private string _stateOfResidence;
        private string _maidenName;
        private DateTime _expiryDate;
        private string _maritalStatus;
        private string _selectedIDType;
        private List<ResultSample> _myCities = new List<ResultSample>();
        private List<string> _cities = new List<string>();
        private States _selectedState;
        private States _selectedStateOfResidence;
        private string _utilityBill;
        private bool _isDeferall;
        private NINResponse _ninResponse;
        private SyncDataSample _occupations;
        private List<string> _myoccupations = new List<string>();
        private Guid _prospectId;
        #endregion

        #region Properties
        public bool InternationalPassportToggled
        {
            get { return _internationalPassportToggled; }
            set { SetProperty(ref _internationalPassportToggled, value); }
        }
        public NINResponse NINResponse
        {
            get { return _ninResponse; }
            set { SetProperty(ref _ninResponse, value); }
        }
        public States SelectedStateOfResidence
        {
            get { return _selectedStateOfResidence; }
            set { SetProperty(ref _selectedStateOfResidence, value); }
        }
        public States SelectedState
        {
            get { return _selectedState; }
            set { SetProperty(ref _selectedState, value); }
        }
        public List<string> Cities
        {
            get { return _cities; }
            set { SetProperty(ref _cities, value); }
        }
        public List<ResultSample> MyCities
        {
            get { return _myCities; }
            set { SetProperty(ref _myCities, value); }
        }
        public string SelectedIDType
        {
            get { return _selectedIDType; }
            set { SetProperty(ref _selectedIDType, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public string CustomerNumber
        {
            get { return _customerNumber; }
            set { SetProperty(ref _customerNumber, value); }
        }
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public string FirstName
        {
            get { return _firstName; }
            set { SetProperty(ref _firstName, value); }
        }
        public string LastName
        {
            get { return _lastName; }
            set { SetProperty(ref _lastName, value); }
        }
        public string MiddleName
        {
            get { return _middleName; }
            set { SetProperty(ref _middleName, value); }
        }
        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }
        public string Gender
        {
            get { return _gender; }
            set { SetProperty(ref _gender, value); }
        }
        public string CustomerTitle
        {
            get { return _customerTitle; }
            set { SetProperty(ref _customerTitle, value); }
        }
        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { SetProperty(ref _phoneNumber, value); }
        }
        public string Occupation
        {
            get { return _occupation; }
            set { SetProperty(ref _occupation, value); }
        }
        public string Nationality
        {
            get { return _nationality; }
            set { SetProperty(ref _nationality, value); }
        }
        public string StateOfOrigin
        {
            get { return _stateOfOrigin; }
            set { SetProperty(ref _stateOfOrigin, value); }
        }
        public string City
        {
            get { return _city; }
            set { SetProperty(ref _city, value); }
        }
        public string ResidentialAddress
        {
            get { return _residentialAddress; }
            set { SetProperty(ref _residentialAddress, value); }
        }
        public string CountryOfResidence
        {
            get { return _countryOfResidence; }
            set { SetProperty(ref _countryOfResidence, value); }
        }
        public string Town
        {
            get { return _town; }
            set { SetProperty(ref _town, value); }
        }
        public string BVN
        {
            get { return _bVN; }
            set { SetProperty(ref _bVN, value); }
        }
        public long BVNConverted
        {
            get { return _bVNConverted; }
            set { SetProperty(ref _bVNConverted, value); }
        }
        public string Religion
        {
            get { return _religion; }
            set { SetProperty(ref _religion, value); }
        }
        public string ResidencePermitNo
        {
            get { return _residencePermitNo; }
            set { SetProperty(ref _residencePermitNo, value); }
        }
        public bool NationalIdToggled
        {
            get { return _nationalIdToggled; }
            set { SetProperty(ref _nationalIdToggled, value); }
        }
        public bool DriversLicenseToggled
        {
            get { return _driversLicenseToggled; }
            set { SetProperty(ref _driversLicenseToggled, value); }
        }
        public bool VotersCardToggled
        {
            get { return _votersCardToggled; }
            set { SetProperty(ref _votersCardToggled, value); }
        }
        public DateTime DateOfBirth
        {
            get { return _dateOfBirth; }
            set { SetProperty(ref _dateOfBirth, value); }
        }
        public Prospect SelectedProspect { get; private set; }
        public Agent LoggedAgent { get; set; }
        public bool IsPoliticallyExposed
        {
            get { return _isPoliticallyExposed; }
            set { SetProperty(ref _isPoliticallyExposed, value); }
        }
        public string MeansOfIdentification
        {
            get { return _meansOfIdentification; }
            set { SetProperty(ref _meansOfIdentification, value); }
        }
        public string CapturedSignature
        {
            get { return _capturedSignature; }
            set { SetProperty(ref _capturedSignature, value); }
        }
        public string UtilityBill
        {
            get { return _utilityBill; }
            set { SetProperty(ref _utilityBill, value); }
        }
        public string FileLabel
        {
            get { return _fileLabel; }
            set { SetProperty(ref _fileLabel, value); }
        }
        public string FileLabelPath
        {
            get { return _fileLabelPath; }
            set { SetProperty(ref _fileLabelPath, value); }
        }
        public string Extension
        {
            get { return _extension; }
            set { SetProperty(ref _extension, value); }
        }
        public string ContentType
        {
            get { return _contentType; }
            set { SetProperty(ref _contentType, value); }
        }
        public AccountOpeningFormResponse AccountOpeningForm
        {
            get { return _accountOpeningForm; }
            set { SetProperty(ref _accountOpeningForm, value); }
        }
        public string[] FileTypes
        {
            get { return _fileTypes; }
            set { SetProperty(ref _fileTypes, value); }
        }
        public ObservableCollection<FileVariable> FileNameList
        {
            get { return _fileNameList; }
            set { SetProperty(ref _fileNameList, value); }
        }
        public Dictionary<object, object> FileByteList
        {
            get { return _fileByteList; }
            set { SetProperty(ref _fileByteList, value); }
        }
        public string DocumentCategory
        {
            get { return _documentCategory; }
            set { SetProperty(ref _documentCategory, value); }
        }
        public byte[] Contents
        {
            get { return _contents; }
            set { SetProperty(ref _contents, value); }
        }
        public List<string> Countries
        {
            get { return _countries; }
            set { SetProperty(ref _countries, value); }
        }
        public List<string> States
        {
            get { return _states; }
            set { SetProperty(ref _states, value); }
        }
        public bool IsNigerian
        {
            get { return _isNigerian; }
            set { SetProperty(ref _isNigerian, value); }
        }
        public bool IsForeigner
        {
            get { return _isForeigner; }
            set { SetProperty(ref _isForeigner, value); }
        }
        public bool MiddleNameExists
        {
            get { return _middleNameExists; }
            set { SetProperty(ref _middleNameExists, value); }
        }
        public bool MiddleNameNotExist
        {
            get { return _middleNameNotExist; }
            set { SetProperty(ref _middleNameNotExist, value); }
        }
        public bool ConditionsMet
        {
            get { return _conditionsMet; }
            set { SetProperty(ref _conditionsMet, value); }
        }
        public string MaritalStatus
        {
            get { return _maritalStatus; }
            set { SetProperty(ref _maritalStatus, value); }
        }
        public DateTime ExpiryDate
        {
            get { return _expiryDate; }
            set { SetProperty(ref _expiryDate, value); }
        }
        public string MaidenName
        {
            get { return _maidenName; }
            set { SetProperty(ref _maidenName, value); }
        }
        public string StateOfResidence
        {
            get { return _stateOfResidence; }
            set { SetProperty(ref _stateOfResidence, value); }
        }
        public bool IdCardSelected
        {
            get { return _idCardSelected; }
            set { SetProperty(ref _idCardSelected, value); }
        }
        public bool IsDeferall
        {
            get { return _isDeferall; }
            set { SetProperty(ref _isDeferall, value); }
        }
        public SyncDataSample Occupations
        {
            get { return _occupations; }
            set { SetProperty(ref _occupations, value); }
        }
        public List<string> MyOccupations
        {
            get { return _myoccupations; }
            set { SetProperty(ref _myoccupations, value); }
        }

        private ObservableCollection<string> _myCountries = new ObservableCollection<string>();
        public ObservableCollection<string> BindableCountries
        {
            get { return _myCountries; }
            set { SetProperty(ref _myCountries, value); }
        }
        public EncryptedProspect EncryptedProspect { get; set; }
        #endregion

        #region Commands
        private DelegateCommand _nationalID;
        private DelegateCommand _votersCard;
        private DelegateCommand _driversLicense;
        private DelegateCommand _internationalPassport;
        private DelegateCommand _pickMeansOfIdentificatioinCommand;
        private DelegateCommand _pickCapturedSignatureCommand;
        private DelegateCommand _pickUtilityBillCommand;
        private DelegateCommand<string> _fileDeleteCommand;
        private DelegateCommand _registerUserCommand;
        private DelegateCommand _changeNationality;
        private DelegateCommand _getCitiesCommand;

        public DelegateCommand NationalID => _nationalID ?? (_nationalID = new DelegateCommand(ExecuteSelectNationalID));
        public DelegateCommand VotersCard => _votersCard ?? (_votersCard = new DelegateCommand(ExecuteSelectVotersCard));
        public DelegateCommand DriversLicense => _driversLicense ?? (_driversLicense = new DelegateCommand(ExecuteSelectDriversLicense));
        public DelegateCommand InternaionalPassport => _internationalPassport ?? (_internationalPassport = new DelegateCommand(ExecuteSelectInternationalPassport));
        public DelegateCommand PickMeansOfIdentificationCommand => _pickMeansOfIdentificatioinCommand ?? (_pickMeansOfIdentificatioinCommand = new DelegateCommand(ExecutePickMeansOfIdenticationCommand));
        public DelegateCommand PickCapturedSignatureCommand => _pickCapturedSignatureCommand ?? (_pickCapturedSignatureCommand = new DelegateCommand(ExecutePickCapturedSignatureCommand));
        public DelegateCommand PickUtilityBillCommand => _pickUtilityBillCommand ?? (_pickUtilityBillCommand = new DelegateCommand(ExecutePickUtilityBillCommand));
        public DelegateCommand<string> FileDeleteCommand => _fileDeleteCommand ?? (_fileDeleteCommand = new DelegateCommand<string>(ExecuteFileDeleteCommand));
        public DelegateCommand RegisterUserCommand => _registerUserCommand ?? (_registerUserCommand = new DelegateCommand(ExecuteRegisterUserCommand));
        public DelegateCommand ChangeNationalityCommand => _changeNationality ?? (_changeNationality = new DelegateCommand(ExecuteChangeNationalityCommand));
        public DelegateCommand GetCitiesCommand => _getCitiesCommand ?? (_getCitiesCommand = new DelegateCommand(ExecuteGetCitiesCommand));
        #endregion

        public CustomerOnboardingPageViewModel(IPageDialogService pageDialogService, INavigationService navigationService, IMediaManager mediaManager,
            IProspectRepository prospectRepository, IUserManager userManager, IUserRepository userRepository, ITitlesRepository titlesRepository, Logical logical,
             IStatesRepository statesRepository, ICountryRepository countryRepository, IAgentRepository agentRepository, IProductPlansRepository productPlansRepository, EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _deviceManager = mediaManager;
            _prospectRepository = prospectRepository;
            _countryRepository = countryRepository;
            _statesRepository = statesRepository;
            _titlesRepository = titlesRepository;
            _userManager = userManager;
            _logical = logical;
            _userRepository = userRepository;
            _agentRepository = agentRepository;
            _productPlansRepository = productPlansRepository;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    //Guid prospectId;
                    //if (Guid.TryParse(parameters["ProspectId"].ToString(), out prospectId))
                    //{
                    //    SelectedProspect = await _prospectRepository.GetById(prospectId);
                    //}
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }

                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }

                if (parameters.ContainsKey("NINResponse"))
                {
                    NINResponse = parameters.GetValue<NINResponse>("NINResponse");
                }

                await InitializeDefaultValues();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async Task InitializeDefaultValues()
        {
            try
            {
                IsNigerian = false;
                IsForeigner = false;
                Title = "Customer Onboarding Page";
                FirstName = SelectedProspect.FirstName;
                LastName = SelectedProspect.LastName;
                MiddleName = SelectedProspect.MiddleName;
                if (MiddleName == "" || MiddleName == null)
                {
                    MiddleNameExists = false;
                    MiddleNameNotExist = true;
                }
                else
                {
                    MiddleNameExists = true;
                    MiddleNameNotExist = false;
                }
                PhoneNumber = SelectedProspect.MobileNumber;
                DateOfBirth = SelectedProspect.Birthdate;
                EmailAddress = SelectedProspect.Email;
                Gender = SelectedProspect.Gender == 1 ? "Male" : "Female";
                CustomerNumber = SelectedProspect.CustomerNumber;

                var title = await _titlesRepository.GetTitleByTitleCode(SelectedProspect.TitleId.GetValueOrDefault());
                if (title != null)
                {
                    CustomerTitle = title.Title;
                }

                var MyStates = await _statesRepository.GetAllStates();
                var MyCountries = await _countryRepository.GetCountries();

                if (MyStates != null)
                {
                    foreach (var item in MyStates)
                    {
                        States.Add(item.State);
                    }
                    States = States.Where(x => x != "STATES").Distinct().ToList();
                }

                if (MyCountries != null)
                {
                    foreach (var item in MyCountries)
                    {
                        Countries.Add(item.Country);
                    }
                    Countries = Countries.Where(x => x != null && x != "Countries").Distinct().ToList();
                }

                foreach (var item in Countries)
                {
                    BindableCountries.Add(item);
                }
                ExpiryDate = DateTime.Now;

                Occupations = await _logical.GetOccupationList();
                MyOccupations = Occupations.Result.Select(x => x.NAME).ToList();
                MyOccupations = MyOccupations.Where(x => x != "Occupation").ToList();

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public void ExecuteChangeNationalityCommand()
        {
            if (Nationality == "Nigeria")
            {
                IsNigerian = true;
                IsForeigner = false;
                ResidencePermitNo = null;
            }
            else
            {
                StateOfOrigin = null;
                IsNigerian = false;
                IsForeigner = true;
            }
        }

        private async void ExecutePickMeansOfIdenticationCommand()
        {
            try
            {
                bool choice = await _pageDialogService.DisplayAlertAsync("Confirm", "Please select how you wish to upload a document", "Camera", "Gallery");

                if (choice)
                {
                    if (_deviceManager.CameraAvailable)
                    {
                        var newPhoto = await _deviceManager.TakePhotoAsync();

                        if (newPhoto != null && newPhoto.FileContent.Length <= 4194304)
                        {
                            Contents = newPhoto.FileContent;
                            FileVariable CameraTaken = new FileVariable
                            {
                                FileName = newPhoto.FileName,
                                FileContent = Convert.ToBase64String(Contents),
                                FieldName = "Means Of Identification",
                                ContentType = "image/jpg",
                                Extension = "jpg"
                            };
                            MeansOfIdentification = newPhoto.FileName;
                            FileNameList.Add(CameraTaken);
                            IdCardSelected = true;
                            await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");
                        }
                        else
                        {
                            await _pageDialogService.DisplayAlertAsync("Unsuccessful", "Document failed to upload. Picture is most likely too large. Please try the gallery option instead.", "Ok");
                        }
                    }
                }
                else
                {
                    if (Device.RuntimePlatform == Device.Android)
                    {
                        FileTypes = new string[] { "image/png", "image/jpeg", "application/pdf" };
                    }

                    await PickedFiles(FileTypes);
                    MeansOfIdentification = FileLabel;
                    FileVariable customerFile = new FileVariable
                    {
                        FileName = MeansOfIdentification,
                        FileContent = Convert.ToBase64String(Contents),
                        FieldName = "Means Of Identification",
                        ContentType = ContentType,
                        Extension = !ContentType.ToLower().Contains("jpeg") ? ContentType.Substring((ContentType.Length - 3), 3) : ContentType.Substring((ContentType.Length - 4), 4)
                    };
                    FileNameList.Add(customerFile);
                    if (MeansOfIdentification != null && Contents != null)
                    {
                        if (Contents.Length > 3145728)
                        {
                            MeansOfIdentification = null;
                            Contents = null;
                            await _pageDialogService.DisplayAlertAsync("Error", "File size too large. Please upload a document not larger than 3MB in size", "Cancel");
                        }
                        else
                        {
                            IdCardSelected = true;
                            await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");
                        }
                    }
                    else
                        await _pageDialogService.DisplayAlertAsync("Unsuccessful", "Document failed to upload. Please try again.", "Ok");
                }
            }

            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecutePickCapturedSignatureCommand()
        {
            try
            {
                bool choice = await _pageDialogService.DisplayAlertAsync("Confirm", "Please select how you wish to upload a document", "Camera", "Gallery");

                if (choice)
                {
                    if (_deviceManager.CameraAvailable)
                    {
                        var newPhoto = await _deviceManager.TakePhotoAsync();

                        if (newPhoto != null && newPhoto.FileContent.Length <= 4194304)
                        {
                            Contents = newPhoto.FileContent;
                            FileVariable CameraTaken = new FileVariable
                            {
                                FileName = newPhoto.FileName,
                                FileContent = Convert.ToBase64String(Contents),
                                FieldName = "CapturedSignature",
                                ContentType = "image/jpg",
                                Extension = "jpg"
                            };
                            CapturedSignature = newPhoto.FileName;
                            FileNameList.Add(CameraTaken);
                            await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");
                        }
                    }
                }
                else
                {
                    if (Device.RuntimePlatform == Device.Android)
                    {
                        FileTypes = new string[] { "image/png", "image/jpeg", "application/pdf" };
                    }

                    await PickedFiles(FileTypes);
                    CapturedSignature = FileLabel;
                    FileVariable customerFile = new FileVariable
                    {
                        FileName = CapturedSignature,
                        FileContent = Convert.ToBase64String(Contents),
                        FieldName = "CapturedSignature",
                        ContentType = ContentType,
                        Extension = !ContentType.ToLower().Contains("jpeg") ? ContentType.Substring((ContentType.Length - 3), 3) : ContentType.Substring((ContentType.Length - 4), 4)
                    };

                    FileNameList.Add(customerFile);

                    if (CapturedSignature != null && Contents != null)
                    {
                        if (Contents.Length > 3145728)
                        {
                            CapturedSignature = null;
                            Contents = null;
                            await _pageDialogService.DisplayAlertAsync("Error", "File size too large. Please upload a document not larger than 3MB in size", "Cancel");
                        }
                        else
                            await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");
                    }
                    else
                        await _pageDialogService.DisplayAlertAsync("Unsuccessful", "Document failed to upload. Please try again.", "Ok");
                }
            }

            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecutePickUtilityBillCommand()
        {
            try
            {
                bool choice = await _pageDialogService.DisplayAlertAsync("Confirm", "Please select how you wish to upload a document", "Camera", "Gallery");

                if (choice)
                {
                    if (_deviceManager.CameraAvailable)
                    {
                        var newPhoto = await _deviceManager.TakePhotoAsync();

                        if (newPhoto != null && newPhoto.FileContent.Length <= 4194304)
                        {
                            Contents = newPhoto.FileContent;
                            FileVariable CameraTaken = new FileVariable
                            {
                                FileName = newPhoto.FileName,
                                FileContent = Convert.ToBase64String(Contents),
                                FieldName = "UtilityBill",
                                ContentType = "image/jpg",
                                Extension = "jpg"
                            };
                            UtilityBill = newPhoto.FileName;
                            FileNameList.Add(CameraTaken);
                            await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");
                        }
                    }
                }
                else
                {
                    if (Device.RuntimePlatform == Device.Android)
                    {
                        FileTypes = new string[] { "image/png", "image/jpeg", "application/pdf" };
                    }

                    await PickedFiles(FileTypes);
                    UtilityBill = FileLabel;
                    FileVariable customerFile = new FileVariable
                    {
                        FileName = UtilityBill,
                        FileContent = Convert.ToBase64String(Contents),
                        FieldName = "UtilityBill",
                        ContentType = ContentType,
                        Extension = !ContentType.ToLower().Contains("jpeg") ? ContentType.Substring((ContentType.Length - 3), 3) : ContentType.Substring((ContentType.Length - 4), 4)
                    };

                    FileNameList.Add(customerFile);

                    if (UtilityBill != null && Contents != null)
                    {
                        if (Contents.Length > 3145728)
                        {
                            UtilityBill = null;
                            Contents = null;
                            await _pageDialogService.DisplayAlertAsync("Error", "File size too large. Please upload a document not larger than 3MB in size", "Cancel");
                        }
                        else
                            await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");
                    }
                    else
                        await _pageDialogService.DisplayAlertAsync("Unsuccessful", "Document failed to upload. Please try again.", "Ok");
                }
            }

            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public async Task PickedFiles(string[] fileTypes)
        {
            try
            {
                var pickedFile = await CrossFilePicker.Current.PickFile(fileTypes);
                if (pickedFile != null)
                {
                    FileLabel = pickedFile.FileName;
                    FileLabelPath = pickedFile.FilePath;

                    if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("jpeg", StringComparison.OrdinalIgnoreCase))
                    {
                        Contents = pickedFile.DataArray;

                        if (pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "application/pdf";
                        }
                        else if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "image" + "/jpg";
                        }
                        else if (pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "image" + "/png";
                        }
                        else
                            ContentType = "image" + "/jpeg";
                    }
                    else
                        await _pageDialogService.DisplayAlertAsync("Error", "Only .pdf, .png and .jpg files can be uploaded", "Ok");
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public static class FileSizeFormatter
        {
            static readonly string[] suffixes = { "Bytes", "KB", "MB", "GB", "TB", "PB" };
            public static string FormatSize(long bytes)
            {
                int counter = 0;
                decimal number = (decimal)bytes;
                while (Math.Round(number / 1024) >= 1)
                {
                    number = number / 1024;
                    counter++;
                }
                return string.Format("{0:n1}{1}", number, suffixes[counter]);
            }
        }

        public void ExecuteFileDeleteCommand(string FileLabel)
        {
            try
            {
                if (MeansOfIdentification != null && MeansOfIdentification == FileLabel)
                {
                    MeansOfIdentification = null;
                    FileVariable uploadFile = FileNameList.Where(x => x.FileName == FileLabel).FirstOrDefault();
                    uploadFile.FileContent = null;
                    uploadFile.FileName = null;
                    uploadFile.Extension = null;
                    uploadFile.FieldName = null;
                    uploadFile.ContentType = null;

                    FileNameList.Remove(uploadFile);
                    IdCardSelected = false;
                }
                if (CapturedSignature != null && CapturedSignature == FileLabel)
                {
                    CapturedSignature = null;
                    FileVariable uploadFile = FileNameList.Where(x => x.FileName == FileLabel).FirstOrDefault();
                    uploadFile.FileContent = null;
                    uploadFile.FileName = null;
                    uploadFile.Extension = null;
                    uploadFile.FieldName = null;
                    uploadFile.ContentType = null;

                    FileNameList.Remove(uploadFile);
                }
                if (UtilityBill != null && UtilityBill == FileLabel)
                {
                    UtilityBill = null;
                    FileVariable uploadFile = FileNameList.Where(x => x.FileName == FileLabel).FirstOrDefault();
                    uploadFile.FileContent = null;
                    uploadFile.FileName = null;
                    uploadFile.Extension = null;
                    uploadFile.FieldName = null;
                    uploadFile.ContentType = null;

                    FileNameList.Remove(uploadFile);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public string GetTransRef()
        {
            Guid guid = Guid.NewGuid();
            var TransRef = Convert.ToBase64String(guid.ToByteArray());
            return TransRef.Replace("=", "");
        }

        private void ExecuteSelectNationalID()
        {
            RemoveDriversLicense();
            RemoveVotersCard();
            RemoveInternationalPassport();
            NationalIdToggled = true;
        }

        private void ExecuteSelectVotersCard()
        {
            RemoveNationalID();
            RemoveDriversLicense();
            RemoveInternationalPassport();
            VotersCardToggled = true;
        }

        private void ExecuteSelectDriversLicense()
        {
            RemoveNationalID();
            RemoveVotersCard();
            RemoveInternationalPassport();
            DriversLicenseToggled = true;
        }

        private void ExecuteSelectInternationalPassport()
        {
            RemoveNationalID();
            RemoveVotersCard();
            RemoveDriversLicense();
            InternationalPassportToggled = true;
        }

        private void RemoveNationalID()
        {
            NationalIdToggled = false;
        }

        private void RemoveVotersCard()
        {
            VotersCardToggled = false;
        }

        private void RemoveDriversLicense()
        {
            DriversLicenseToggled = false;
        }

        private void RemoveInternationalPassport()
        {
            InternationalPassportToggled = false;
        }

        private async Task<User> GetAgentEmail(string AgentUserName)
        {
            User user = await _userRepository.GetByName(AgentUserName.ToLower());

            return user;
        }

        private async void ExecuteGetCitiesCommand()
        {
            IsBusy = true;
            try
            {
                Cities.Clear();
                SelectedStateOfResidence = await _statesRepository.GetStateCodeByState(StateOfResidence);
                MyCities = await _logical.GetCities(SelectedStateOfResidence.StateCode);

                if (MyCities != null)
                {
                    foreach (var item in MyCities)
                    {
                        Cities.Add(item.NAME);
                    }
                    Cities = Cities.ToList();
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async void ExecuteRegisterUserCommand()
        {
            IsBusy = true;
            try
            {
                ConditionsMet = false;
                try
                {
                    if (!string.IsNullOrEmpty(BVN))
                    {
                        BVNConverted = Convert.ToInt64(BVN);
                    }
                }
                catch (Exception ex)
                {
                    await _pageDialogService.DisplayAlertAsync("Error!", "BVN input not correct.", "Ok");
                    ex.Message.ToString();
                }

                CreatePMCaseResponse createPMCaseResponse = new CreatePMCaseResponse();
                if (SelectedIDType == "National ID")
                {
                    NationalIdToggled = true;
                    VotersCardToggled = false;
                    DriversLicenseToggled = false;
                    InternationalPassportToggled = false;
                }
                else if (SelectedIDType == "Voter's Card")
                {
                    VotersCardToggled = true;
                    NationalIdToggled = false;
                    DriversLicenseToggled = false;
                    InternationalPassportToggled = false;
                }
                else if (SelectedIDType == "Driver's License")
                {
                    DriversLicenseToggled = true;
                    NationalIdToggled = false;
                    VotersCardToggled = false;
                    InternationalPassportToggled = false;
                }
                else
                {
                    InternationalPassportToggled = true;
                    NationalIdToggled = false;
                    VotersCardToggled = false;
                    DriversLicenseToggled = false;
                }

                if (ExpiryDate > DateTime.Today)
                {
                    if (!string.IsNullOrEmpty(Occupation) && Nationality != null &&
                                        !string.IsNullOrEmpty(City) && !string.IsNullOrEmpty(ResidentialAddress) &&
                                        !string.IsNullOrEmpty(Town) && FileNameList != null && FileNameList.Count >= 3 && !string.IsNullOrEmpty(MaritalStatus) &&
                                        !string.IsNullOrEmpty(StateOfResidence) && (ExpiryDate > DateTime.Now)) //Check for the other entry fields here too
                    {
                        int _BVNLimit = 11;

                        if (BVN != null && BVN != "" && BVN.Length < _BVNLimit && BVNConverted < 10000000000)
                        {
                            await _pageDialogService.DisplayAlertAsync("Error!", "BVN input cannot be less than 11 digits.", "Ok");
                        }
                        if (IsNigerian == true && StateOfOrigin == null)
                        {
                            await _pageDialogService.DisplayAlertAsync("Notice", "Please select your state of origin", "Ok");
                        }
                        else if (IsForeigner == true && ResidencePermitNo == null || ResidencePermitNo == "")
                        {
                            await _pageDialogService.DisplayAlertAsync("Notice", "Please input your residence permit number", "Ok");
                        }
                        else
                        {
                            var SelectedCountry = await _countryRepository.GetCountryByCountryName(Nationality); //; 

                            Logical logical = new Logical();
                            CustomerOnboardingRequest customer = new CustomerOnboardingRequest();
                            PMRequestParam customerCaseRequest = new PMRequestParam();
                            ProspectToUpdate prospectToUpdate = null;
                            AccountCreationFormModel accountCreationFormModel = new AccountCreationFormModel();
                            AccountOpeningFormResponse AccountOpeningForm = new AccountOpeningFormResponse();
                            CustomerOnboardingMailRequest customerOnboardingMailRequest = new CustomerOnboardingMailRequest();
                            CustomerOnboardingMailResponse customerOnboardingMailResponse = new CustomerOnboardingMailResponse();

                            if (Nationality == "Nigeria")
                            {
                                SelectedState = await _statesRepository.GetStateCodeByState(StateOfOrigin);
                            }
                            SelectedStateOfResidence = await _statesRepository.GetStateCodeByState(StateOfResidence);
                            customer.FirstName = accountCreationFormModel.FirstName = FirstName;
                            customer.LastName = accountCreationFormModel.LastName = LastName;
                            customer.MiddleName = accountCreationFormModel.MiddleName = MiddleName != null ? MiddleName : "";
                            customer.Nationality = SelectedCountry.CountryCode; accountCreationFormModel.Nationality = Nationality;
                            customer.Occupation = accountCreationFormModel.Occupation = Occupation;
                            customer.PhoneNumber = accountCreationFormModel.PhoneNumber = PhoneNumber;
                            customer.EmailAddress = accountCreationFormModel.EmailAddress = EmailAddress;
                            customer.ExceptionExist = 0;
                            if (SelectedProspect.Gender == 0)
                            {
                                customer.Gender = 2;
                                accountCreationFormModel.Gender = "Female";
                            }
                            else
                            {
                                customer.Gender = 1;
                                accountCreationFormModel.Gender = "Male";
                            }
                            //customer.Gender = 1; //SelectedProspect.Gender;
                            customer.ResidenceAddress = accountCreationFormModel.ResidentialAddress = ResidentialAddress;
                            customer.Salary = Convert.ToInt64(SelectedProspect.GrossMonthlyincome);
                            customer.Title = Convert.ToInt64(SelectedProspect.TitleId);
                            customer.AcmProf = 1;
                            customer.BankBranchTrfTo = 1;
                            customer.ChannelCode = "AXASOL";
                            customer.City = accountCreationFormModel.City = MyCities.Where(x => x.NAME == City).FirstOrDefault().CODE.ToString();
                            customer.ClientCode = "AXASOL";
                            customer.Colecter = 0;
                            customer.DateOfBirth = SelectedProspect.Birthdate; accountCreationFormModel.DateOfBirth = SelectedProspect.Birthdate.ToString("dd/MM/yyyy");
                            customer.IbankNo = accountCreationFormModel.BVN = BVN != null ? BVN.ToString() : " ";
                            customer.LastTransDate = DateTime.Now;
                            customer.LastTransTime = 1;
                            customer.Source = 1;
                            customer.Fax = "";
                            customer.Through = Convert.ToInt64(LoggedAgent.SBU);
                            customer.TransRef = GetTransRef();
                            customer.Religion = 5;
                            #region State of Origin

                            if (SelectedState != null)
                            {
                                customer.StateOfOrigin = SelectedState.StateCode;
                                accountCreationFormModel.StateOfOrigin = StateOfOrigin;
                            }
                            else if (SelectedState == null && ResidencePermitNo != null && ResidencePermitNo != "")
                            {
                                accountCreationFormModel.ResidencePermitNo = ResidencePermitNo;
                            }
                            else
                            {
                                customer.StateOfOrigin = 99; //StateCode of 99 represents "not specified" on AIMS database
                                accountCreationFormModel.StateOfOrigin = "Not Specified";
                            }
                            #endregion

                            accountCreationFormModel.CountryOfResidence = "Nigeria";
                            accountCreationFormModel.Town = Town;
                            if (ResidencePermitNo == null)
                            {
                                accountCreationFormModel.ResidencePermitNo = " ";
                            }
                            accountCreationFormModel.CapturedSignature = FileNameList.Where(x => x.FieldName == "CapturedSignature").LastOrDefault().FileContent;
                            accountCreationFormModel.FileContentType = FileNameList.Where(x => x.FieldName == "CapturedSignature").LastOrDefault().ContentType;
                            if (NationalIdToggled || VotersCardToggled || DriversLicenseToggled || InternationalPassportToggled)
                            {
                                if (NationalIdToggled)
                                {
                                    accountCreationFormModel.MeansOfIdentification = "National ID";
                                }
                                else if (VotersCardToggled)
                                {
                                    accountCreationFormModel.MeansOfIdentification = "Voter's Card";
                                }
                                else if (DriversLicenseToggled)
                                {
                                    accountCreationFormModel.MeansOfIdentification = "Driver's License";
                                }
                                else
                                    accountCreationFormModel.MeansOfIdentification = "International Passport";
                                    
                            }
                            else
                                accountCreationFormModel.MeansOfIdentification = "";
                            CustomerOnboardingResponse customerOnboardingResponse = new CustomerOnboardingResponse(); //await logical.CustomerOnboardingResponseAsync(customer);

                            bool CustomerNumberExists = false;
                            //CustomerNumber = customerOnboardingResponse.Customer.CustomerNumber; old commented

                            //if (!string.IsNullOrEmpty(CustomerNumber) || !string.IsNullOrEmpty(SelectedProspect.CustomerNumber))
                            //{
                            //    CustomerNumberExists = true;
                            //}
                            //else
                            //{
                            //    customerOnboardingResponse = await logical.CustomerOnboardingResponseAsync(customer);
                            //}

                            //if (customeronboardingresponse.issuccessful || customernumberexists == true)
                            //{
                            //if (CustomerNumber == null && string.IsNullOrEmpty(SelectedProspect.CustomerNumber))
                            //{
                            //    CustomerNumber = customerOnboardingResponse.Customer.CustomerNumber;

                            //    try
                            //    {
                            //        SelectedProspect.CustomerNumber = CustomerNumber;
                            //        SelectedProspect.StateOfOrigin = StateOfOrigin;
                            //        SelectedProspect.Nationality = Nationality;

                            //        var ProspectProductPlans = await _productPlansRepository.GetProductPlansByProspectId(SelectedProspect.Id);

                            //        foreach (ProductPlan item in ProspectProductPlans)
                            //        {
                            //            item.IsNotPolicyId = true;
                            //            await _productPlansRepository.UpdateAsync(item);
                            //        }

                            //prospectToUpdate = new ProspectToUpdate
                            //{
                            //    CustomerNumber = CustomerNumber,
                            //    EmailAddress = EmailAddress,
                            //    DateOfBirth = DateOfBirth,
                            //    FirstName = FirstName,
                            //    LastName = LastName,
                            //    PhoneNumber = PhoneNumber
                            //};
                            //bool updated = await _logical.UpdateProspectDetails(prospectToUpdate);
                            //        await _prospectRepository.UpdateAsync(SelectedProspect);
                            //    }
                            //    catch (Exception)
                            //    { }
                            //}
                            //else
                            //    CustomerNumber = !string.IsNullOrEmpty(CustomerNumber) ? CustomerNumber : SelectedProspect.CustomerNumber;

                            AccountOpeningForm = await logical.AccountCreationFormAsync(accountCreationFormModel);

                            if (AccountOpeningForm.Document != null)
                            {
                                string[] triggers = new string[] { "6097033315da87e5ba616b4090170703" };
                                customerCaseRequest.pro_uid = "3370441965d9b2dd3dd7040029820172";
                                customerCaseRequest.tas_uid = "9835281815eaab54d423478010874707";

                                ////for pilot, please change after pilot
                                //string[] triggers = new string[3] { "23909338761cdbbb50945b3067313791", "46522975461cdbbb50a3b10016026312", "63008272161cdbbb50a2371007412884" };

                                //customerCaseRequest.pro_uid = "51219727861cdbbb4293890054957005";
                                //customerCaseRequest.tas_uid = "41748816961cdbbb43a9165080579893";
                                //customerCaseRequest.name = LoggedAgent.FullName; //"Oluwatobi Akano";
                                customerCaseRequest.triggers = triggers;

                                var occupationcode = Occupations.Result.Where(x => x.NAME == Occupation).FirstOrDefault().CODE;

                                //var city = MyCities.Where(x => x.NAME == City).FirstOrDefault().NAME.ToString();

                                try
                                {
                                    FileVariable file = new FileVariable();
                                    file.ContentType = "application/pdf";
                                    file.Extension = "pdf";
                                    file.FieldName = "Account Opening Form";
                                    file.FileContent = AccountOpeningForm.Document;
                                    file.FileName = AccountOpeningForm.DocumentPath;

                                    List<FileVariable> File1 = new List<FileVariable>();
                                    File1.Add(file);
                                    FileVariable file2 = FileNameList.Where(x => x.FileName == MeansOfIdentification).LastOrDefault();
                                    List<FileVariable> File2 = new List<FileVariable>();
                                    File2.Add(file2);
                                    FileVariable file3 = FileNameList.Where(x => x.FileName == UtilityBill).LastOrDefault();
                                    List<FileVariable> File3 = new List<FileVariable>();
                                    File3.Add(file3);

                                    CaseVariables variables = new CaseVariables();
                                    List<CaseVariable> caseVariable = new List<CaseVariable>();
                                    List<CaseVariable3> caseVariable3 = new List<CaseVariable3>();

                                    CaseVariable3 caseVariable3A = null;
                                    CaseVariable3 caseVariable3B = null;
                                    CaseVariable3 caseVariable3C = null;

                                    List<FileVariable>[] Image1 = new List<FileVariable>[1];
                                    List<FileVariable>[] Image2 = new List<FileVariable>[1];
                                    List<FileVariable>[] Image3 = new List<FileVariable>[1];

                                    Image1[0] = File1;
                                    Image2[0] = File2;
                                    Image3[0] = File3;

                                    if (Image1.Length > 0)
                                    {
                                        caseVariable3A = new CaseVariable3 { FileVariableName = "customerIdCard" };
                                        caseVariable3A.VariableValues = Image1;
                                    }

                                    if (Image2.Length > 0)
                                    {
                                        caseVariable3B = new CaseVariable3 { FileVariableName = "accountOpeningForm" }; //Put the value
                                        caseVariable3B.VariableValues = Image2;
                                    }

                                    if (Image3.Length > 0)
                                    {
                                        caseVariable3C = new CaseVariable3 { FileVariableName = "utilityBill" };
                                        caseVariable3C.VariableValues = Image3;
                                    }

                                    //caseVariable.Add(new CaseVariable { VariableName = "startedFromPM", VariableValue = "2" });
                                    //caseVariable.Add(new CaseVariable { VariableName = "startedFromPM_label", VariableValue = "2" });

                                    caseVariable.Add(new CaseVariable { VariableName = "dateOfInitiation", VariableValue = DateTime.Now.ToString("yyyy-MM-dd") });
                                    caseVariable.Add(new CaseVariable { VariableName = "dateOfInitiation_label", VariableValue = DateTime.Now.ToString("yyyy-MM-dd") });
                                    caseVariable.Add(new CaseVariable { VariableName = "pssName", VariableValue = LoggedAgent.FullName /*"Oluwatobi Akano" */});
                                    caseVariable.Add(new CaseVariable { VariableName = "pssName_label", VariableValue = LoggedAgent.FullName /*"Oluwatobi Akano" */});

                                    caseVariable.Add(new CaseVariable { VariableName = "pssEmailAddress", VariableValue = LoggedAgent.EmailAddress });
                                    caseVariable.Add(new CaseVariable { VariableName = "pssEmailAddress_label", VariableValue = LoggedAgent.EmailAddress });
                                    caseVariable.Add(new CaseVariable { VariableName = "requester_username", VariableValue = LoggedAgent.FullName /*"oakano" */}); //_userManager.UserName

                                    caseVariable.Add(new CaseVariable { VariableName = "customerTitle2", VariableValue = SelectedProspect.TitleId.ToString() });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerFirstName2", VariableValue = SelectedProspect.FirstName });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerMiddleName1", VariableValue = !string.IsNullOrEmpty(SelectedProspect.MiddleName) ? SelectedProspect.MiddleName : MiddleName });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerLastName2", VariableValue = SelectedProspect.LastName });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerPhoneNumber1", VariableValue = SelectedProspect.MobileNumber });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerEmailAddress1", VariableValue = SelectedProspect.Email });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerDateOfBirth1", VariableValue = SelectedProspect.Birthdate.ToString("yyyy-MM-dd") });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerGender", VariableValue = SelectedProspect.Gender == 0 ? "2" : "1" }); //check this
                                    caseVariable.Add(new CaseVariable { VariableName = "customerGender_label", VariableValue = SelectedProspect.Gender == 0 ? "Female" : "Male" }); //check this
                                    caseVariable.Add(new CaseVariable { VariableName = "customerNationality", VariableValue = SelectedCountry.CountryCode.ToString() });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerNationality_label", VariableValue = SelectedCountry.Country });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerPermitId", VariableValue = ResidencePermitNo });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerStateOfOrigin", VariableValue = SelectedState != null ? SelectedState.StateCode.ToString() : "" });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerStateOfOrigin_label", VariableValue = SelectedState != null ? StateOfOrigin : "" });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerResidentialAddress", VariableValue = ResidentialAddress });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerCityOfResidence", VariableValue = Town });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerCityOfResidence_label", VariableValue = City });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerOccupation", VariableValue = occupationcode.ToString() });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerOccupation_label", VariableValue = Occupation });
                                    caseVariable.Add(new CaseVariable { VariableName = "bvn", VariableValue = BVN });
                                    caseVariable.Add(new CaseVariable { VariableName = "maiden_name", VariableValue = MaidenName });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerStateOfResidence", VariableValue = SelectedStateOfResidence.StateCode.ToString() });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerStateOfResidence_label", VariableValue = StateOfResidence });
                                    caseVariable.Add(new CaseVariable { VariableName = "idCardExpiryDate", VariableValue = ExpiryDate.ToString("yyyy-MM-dd") });
                                    caseVariable.Add(new CaseVariable { VariableName = "fromAxaSol", VariableValue = "1" });
                                    caseVariable.Add(new CaseVariable { VariableName = "case_label", VariableValue = "Customer Onboarding for " + SelectedProspect.FullName + " Initiated by " + LoggedAgent.FullName });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerAccountNumber", VariableValue = CustomerNumber });
                                    caseVariable.Add(new CaseVariable { VariableName = "exempt", VariableValue = IsDeferall ? "yes" : "no" });
                                    caseVariable.Add(new CaseVariable { VariableName = "exempt_label", VariableValue = IsDeferall ? "yes" : "no" });
                                    caseVariable.Add(new CaseVariable { VariableName = "ressett", VariableValue = "0" });
                                    //caseVariable.Add(new CaseVariable { VariableName = "is_approved", VariableValue = "1" });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerAccountNumber", VariableValue = SelectedProspect.CustomerNumber });
                                    caseVariable.Add(new CaseVariable { VariableName = "customerAccountNumber_label", VariableValue = SelectedProspect.CustomerNumber });

                                    if (NationalIdToggled || VotersCardToggled || DriversLicenseToggled)
                                    {
                                        if (NationalIdToggled)
                                        {
                                            caseVariable.Add(new CaseVariable { VariableName = "typeOfIdentity", VariableValue = "NATIONAL" });
                                        }
                                        else if (VotersCardToggled)
                                        {
                                            caseVariable.Add(new CaseVariable { VariableName = "typeOfIdentity", VariableValue = "VOTE" });
                                        }
                                        else
                                            caseVariable.Add(new CaseVariable { VariableName = "typeOfIdentity", VariableValue = "DRIVERS" });
                                    }
                                    if (MaritalStatus.Contains("Single"))
                                    {
                                        caseVariable.Add(new CaseVariable { VariableName = "marital_status", VariableValue = "1" });
                                        caseVariable.Add(new CaseVariable { VariableName = "marital_status_label", VariableValue = "Single" });
                                    }
                                    else if (MaritalStatus.Contains("Married"))
                                    {
                                        caseVariable.Add(new CaseVariable { VariableName = "marital_status", VariableValue = "2" });
                                        caseVariable.Add(new CaseVariable { VariableName = "marital_status_label", VariableValue = "Married" });
                                    }
                                    else if (MaritalStatus.Contains("Widowed"))
                                    {
                                        caseVariable.Add(new CaseVariable { VariableName = "marital_status", VariableValue = "3" });
                                        caseVariable.Add(new CaseVariable { VariableName = "marital_status_label", VariableValue = "Widowed" });
                                    }
                                    else if (MaritalStatus.Contains("Divorced"))
                                    {
                                        caseVariable.Add(new CaseVariable { VariableName = "marital_status", VariableValue = "4" });
                                        caseVariable.Add(new CaseVariable { VariableName = "marital_status_label", VariableValue = "Divorced" });
                                    }

                                    if (IsPoliticallyExposed || SelectedProspect.TitleId == 6 || SelectedProspect.TitleId == 7 || SelectedProspect.TitleId == 11 || SelectedProspect.TitleId == 28 || SelectedProspect.TitleId == 31 || SelectedProspect.TitleId == 36)
                                    {
                                        caseVariable.Add(new CaseVariable { VariableName = "nextTeam", VariableValue = "Compliance Team" });
                                        caseVariable.Add(new CaseVariable { VariableName = "finalApproval", VariableValue = "9312800165e4289199149e9068569609" });
                                        caseVariable.Add(new CaseVariable { VariableName = "customerPEPQuestion", VariableValue = IsPoliticallyExposed ? "Y" : "N" });
                                        caseVariable.Add(new CaseVariable { VariableName = "customerPEPQuestion_label", VariableValue = IsPoliticallyExposed ? "Yes" : "No" });
                                    }
                                    else
                                    {
                                        caseVariable.Add(new CaseVariable { VariableName = "nextTeam", VariableValue = "Final Approval" });
                                        caseVariable.Add(new CaseVariable { VariableName = "finalApproval", VariableValue = "2895496105dfa2934719ea9079592512" });
                                        caseVariable.Add(new CaseVariable { VariableName = "customerPEPQuestion", VariableValue = "N" });
                                        caseVariable.Add(new CaseVariable { VariableName = "customerPEPQuestion_label", VariableValue = "No" });
                                    }


                                    #region NEW ADDITION FOR THE PURPOSE OF E-KYC
                                    if (NINResponse != null)
                                    {
                                        caseVariable.Add(new CaseVariable { VariableName = "clientfistName", VariableValue = NINResponse.Data.Firstname });
                                        caseVariable.Add(new CaseVariable { VariableName = "clientlastname", VariableValue = NINResponse.Data.Lastname });
                                        caseVariable.Add(new CaseVariable { VariableName = "clientmiddlename", VariableValue = NINResponse.Data.Middlename });
                                        caseVariable.Add(new CaseVariable { VariableName = "clientphone", VariableValue = NINResponse.Data.Phone });
                                        caseVariable.Add(new CaseVariable { VariableName = "clientemail", VariableValue = NINResponse.Data.Email });
                                        caseVariable.Add(new CaseVariable { VariableName = "clientdateOfbirth", VariableValue = NINResponse.Data.Birthdate });
                                        caseVariable.Add(new CaseVariable { VariableName = "clientGender", VariableValue = NINResponse.Data.Gender });
                                        caseVariable.Add(new CaseVariable { VariableName = "clientnationality", VariableValue = NINResponse.Data.Nationality });
                                        caseVariable.Add(new CaseVariable { VariableName = "clientmaidenName", VariableValue = "" });
                                        caseVariable.Add(new CaseVariable { VariableName = "clientstateOfOrigin", VariableValue = NINResponse.Data.StateOfOrigin });
                                        caseVariable.Add(new CaseVariable { VariableName = "clientAddress", VariableValue = NINResponse.Data.Address1 });
                                        caseVariable.Add(new CaseVariable { VariableName = "clientstate", VariableValue = NINResponse.Data.State });
                                        caseVariable.Add(new CaseVariable { VariableName = "clientlga", VariableValue = NINResponse.Data.Lga });
                                        caseVariable.Add(new CaseVariable { VariableName = "clientprofession", VariableValue = NINResponse.Data.Profession });
                                    }
                                    caseVariable.Add(new CaseVariable { VariableName = "validationType2", VariableValue = "Manual" });
                                    caseVariable.Add(new CaseVariable { VariableName = "onboardingType2", VariableValue = "Complete KYC Onboarding" });
                                    caseVariable.Add(new CaseVariable { VariableName = "validationType", VariableValue = "2" });
                                    caseVariable.Add(new CaseVariable { VariableName = "onboardingType", VariableValue = "2" });
                                    #endregion

                                    caseVariable.Add(new CaseVariable { VariableName = "caseInitiator", VariableValue = "6583285825a61c681b64ae4015270962" });

                                    caseVariable3.Add(caseVariable3A);
                                    caseVariable3.Add(caseVariable3B);
                                    caseVariable3.Add(caseVariable3C);

                                    variables.caseVariable = caseVariable;
                                    variables.fileVariables = caseVariable3;

                                    customerCaseRequest.caseVariables = variables;

                                }
                                catch (Exception ex)
                                {
                                    await _pageDialogService.DisplayAlertAsync("Oooops!!!", "Customer Onboarding Initiation Failed ", "Cancel");
                                    ex.Message.ToString();
                                }

                                createPMCaseResponse = await logical.CustomerCaseCreateAsync(customerCaseRequest);

                                if (createPMCaseResponse.app_number != null)
                                {
                                    SelectedProspect.IsCaseId = true;
                                    ConditionsMet = true;
                                    SelectedProspect.CaseCreated = true;
                                    SelectedProspect.IsEkycStatus = false;
                                    SelectedProspect.CaseId = createPMCaseResponse.app_number;
                                    SelectedProspect.OnboardingCase_app_uid = createPMCaseResponse.app_uid;
                                    //ProspectCaseCreated prospectCaseCreated = new ProspectCaseCreated
                                    //{
                                    //    CaseCreated = true,
                                    //    CustomerNumber = CustomerNumber
                                    //};

                                    //await _logical.ConfirmOnboardingCaseCreated(prospectCaseCreated);
                                    string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                                    EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                                    int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                                    //await _prospectRepository.UpdateAsync(SelectedProspect);
                                    //await _pageDialogService.DisplayAlertAsync("Successful", "Your customer number is " + CustomerNumber + " and your Case ID is " + createPMCaseResponse.app_number, "Ok");
                                    await _pageDialogService.DisplayAlertAsync("Successful", "Your Case ID is " + createPMCaseResponse.app_number + ". This case has routed to Policy Processing for Approval.", "Ok");

                                    //customerOnboardingMailRequest.AgentName = LoggedAgent.FullName /*"Oluwatobi Akano"*/;
                                    //customerOnboardingMailRequest.AgentEmailAddress = LoggedAgent.EmailAddress;
                                    //customerOnboardingMailRequest.CaseId = createPMCaseResponse.app_number;
                                    //customerOnboardingMailRequest.CustomerEmailAddress = SelectedProspect.Email;
                                    //customerOnboardingMailRequest.CustomerName = SelectedProspect.FullName;
                                    //customerOnboardingMailRequest.CustomerNumber = CustomerNumber;

                                    customerOnboardingMailResponse = await logical.CustomerOnboardingMail(customerOnboardingMailRequest);
                                    //if (customerOnboardingMailResponse.IsSuccessful)
                                    //{
                                    //    await _pageDialogService.DisplayAlertAsync("", "Mail sent", "Okay");
                                    //}
                                    //else
                                    //    await _pageDialogService.DisplayAlertAsync("Oooops!!!", "Mail not sent", "Okay");
                                    if(IsPoliticallyExposed)
                                    {
                                        EkycReportRequest req = new EkycReportRequest();
                                        req.CaseID = Convert.ToInt32( createPMCaseResponse.app_number);
                                        req.DateSent = DateTime.Now;
                                        if (LoggedAgent.IsAdvisor)
                                        {
                                            req.CurrentUser = LoggedAgent.SubAgentCode + "/" + LoggedAgent.FullName;
                                            req.SentBy = LoggedAgent.SubAgentCode + "/" + LoggedAgent.FullName;
                                        }
                                        else
                                        {
                                            req.CurrentUser = LoggedAgent.AgentCode + "/" + LoggedAgent.FullName;
                                            req.SentBy = LoggedAgent.AgentCode + "/" + LoggedAgent.FullName;
                                        }
                                        req.CaseStatus = "IN PROGRESS";
                                        req.PolicyRegion = Convert.ToInt32( LoggedAgent.SBU);
                                        req.ApprovalLevel = "Compliance";
                                        if(SelectedProspect.IsLeadAccount)
                                        {
                                            req.CaseTitle = "Onboarding initiated for Lead Account";

                                        }
                                        else
                                        {
                                            req.CaseTitle = "Onboarding initiated for Manual Account";
                                        }
                                       

                                        var res = await logical.EkycReport(req);
                                       


                                    }
                                    else
                                    {

                                        EkycReportRequest req = new EkycReportRequest();
                                        req.CaseID = Convert.ToInt32(createPMCaseResponse.app_number);
                                        req.DateSent = DateTime.Now;
                                        if (LoggedAgent.IsAdvisor)
                                        {
                                            req.CurrentUser = LoggedAgent.SubAgentCode + "/" + LoggedAgent.FullName;
                                            req.SentBy = LoggedAgent.SubAgentCode + "/" + LoggedAgent.FullName;
                                        }
                                        else
                                        {
                                            req.CurrentUser = LoggedAgent.AgentCode + "/" + LoggedAgent.FullName;
                                            req.SentBy = LoggedAgent.AgentCode + "/" + LoggedAgent.FullName;
                                        }
                                        req.CaseStatus = "IN PROGRESS";
                                        req.PolicyRegion = Convert.ToInt32(LoggedAgent.SBU);
                                        req.ApprovalLevel = "CSA LEVEL";
                                        if (SelectedProspect.IsLeadAccount)
                                        {
                                            req.CaseTitle = "Onboarding initiated for Lead Account";

                                        }
                                        else
                                        {
                                            req.CaseTitle = "Onboarding initiated for Manual Account";
                                        }

                                        var res = await logical.EkycReport(req);

                                    }
                                }
                                else
                                    await _pageDialogService.DisplayAlertAsync("Oooops!!!", "Customer Onboarding Initiation Failed. Please check your network connection and try again. " + createPMCaseResponse.error.message.ToString(), "Cancel");
                            }
                            else
                                await _pageDialogService.DisplayAlertAsync("Oooops!!!", "Customer Onboarding Initiation Failed", "Cancel");
                        }
                    }
                    else
                    {
                        ConditionsMet = false;
                        await _pageDialogService.DisplayAlertAsync("Oooops!!!", "It seems you left some fields blank. Please fill all required fields before proceeding.", "Ok");
                    }

                    if (ConditionsMet)
                    {
                        NavigationParameters parameters = new NavigationParameters();
                        SelectedProspect.CustomerNumber = CustomerNumber;
                        string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                        EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                        int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                        //await _prospectRepository.UpdateAsync(SelectedProspect);
                        parameters.Add("CaseId", createPMCaseResponse.app_number);
                        parameters.Add("ProspectId", SelectedProspect.Id);
                        parameters.Add("AgentId", LoggedAgent.Id);
                        await _pageDialogService.DisplayAlertAsync("Success", "Customer Onboarding Initiated", "Ok");
                        await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", parameters);
                    }
                }
                else
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "ID Card expiry date should be later than current date", "Ok");
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                await _pageDialogService.DisplayAlertAsync("Oooops!!!", "Customer Onboarding Initiation Failed. Please check your network connection and try again.", "Cancel");
            }
            IsBusy = false;
        }
    }
}
