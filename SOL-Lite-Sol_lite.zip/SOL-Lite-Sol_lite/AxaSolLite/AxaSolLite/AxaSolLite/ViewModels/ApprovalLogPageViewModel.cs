﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AxaSolLite.ViewModels
{
    public class ApprovalLogPageViewModel : BindableBase, INavigationAware
    {
        private readonly IPageDialogService _pageDialogService;
        private readonly INavigationService _navigationService;      
        private readonly IAgentRepository _agentRepository;      
        private Logical _logical;


        #region Fields
        private List<Approval_details> _approvalLogList = new List<Approval_details>();
        private bool _isBusy;
        private bool _itemExists;


        #endregion

        #region Properties
        public List<Approval_details> ApprovalLogList
        {
            get { return _approvalLogList; }
            set { SetProperty(ref _approvalLogList, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public bool ItemExists
        {
            get { return _itemExists; }
            set { SetProperty(ref _itemExists, value); }
        }

        public Agent Agent { get; set; }
        #endregion

        #region Commands
        private DelegateCommand<string> _approvalInformationCommand;
        public DelegateCommand<string> ApprovalInformationCommand => _approvalInformationCommand ?? (_approvalInformationCommand = new DelegateCommand<string>(ExecuteApprovalInformation));
        #endregion

        public ApprovalLogPageViewModel(IPageDialogService pageDialogService, INavigationService navigationService,
              IAgentRepository agentRepository, Logical logical)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;            
            _logical = logical;      
            _agentRepository = agentRepository;
            

        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            Policy_details policydetails = new Policy_details();
           
            IsBusy = true;
            try
            {
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        Agent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }
                Agent.AgentCode = "3432300061";
                var response = await _logical.GetApprovalLogByAgentCode(Agent.AgentCode);

                foreach(var item in response)
                {
                    Approval_details approvaldetails = new Approval_details();
                    policydetails = JsonConvert.DeserializeObject<Policy_details>(item.PolicyDetails);

                    
                    approvaldetails.AgentCode = policydetails.AgentCode;
                    approvaldetails.CustomerNumber = policydetails.CustomerNumber;
                    approvaldetails.PaymentType = policydetails.PaymentType;
                    approvaldetails.Premium = policydetails.Premium;
                    approvaldetails.ProductType = policydetails.ProductType;
                    approvaldetails.CaseId = item.CaseId;
                    approvaldetails.IsApproved = item.IsApproved;
                    approvaldetails.IsRejected = item.IsRejected;
                    approvaldetails.DateModified = item.DateModified.ToString("dd/MM/yyyy");
                    approvaldetails.ModifiedBy = item.ModifiedBy;
                    approvaldetails.Comments = item.Comment;
                    approvaldetails.StartDate = Convert.ToDateTime( policydetails.StartDate).ToString("dd/MM/yyyy");
                    approvaldetails.EndDate = Convert.ToDateTime(policydetails.EndDate).ToString("dd/MM/yyyy");
                    approvaldetails.Product = policydetails.Product;
                    approvaldetails.AmountPaid = policydetails.Proposal_details.AmountPaid;
                    approvaldetails.BeneficiaryDateofBirth = policydetails.Proposal_details.BeneficiaryDateofBirth;
                    approvaldetails.BeneficiaryFullName = policydetails.Proposal_details.BeneficiaryFullName;
                    approvaldetails.BeneficiaryPhoneNumber = policydetails.Proposal_details.BeneficiaryPhoneNumber;
                    approvaldetails.CustomerDateofBirth = policydetails.Proposal_details.CustomerDateofBirth;
                    approvaldetails.CustomerFullName = policydetails.Proposal_details.CustomerFullName;
                    approvaldetails.EmailAddress = policydetails.Proposal_details.EmailAddress;
                    approvaldetails.EngNo = policydetails.Proposal_details.EngNo;
                    approvaldetails.MotorModel = policydetails.Proposal_details.MotorModel;
                    approvaldetails.MotorType = policydetails.Proposal_details.MotorType;
                    approvaldetails.PaymentFrequency = policydetails.Proposal_details.PaymentFrequency;
                    approvaldetails.PhoneNumber = policydetails.Proposal_details.PhoneNumber;
                    approvaldetails.PolicyTerm = policydetails.Proposal_details.PolicyTerm;
                    approvaldetails.RegNo = policydetails.Proposal_details.RegNo;
                    approvaldetails.SumAssured = policydetails.Proposal_details.SumAssured;


                    approvaldetails.Id = Guid.NewGuid();
                    if (item.IsApproved)
                    {
                        approvaldetails.ApprovalType = "APPROVED";
                    }
                    else if(item.IsRejected)
                    {
                        approvaldetails.ApprovalType = "REJECTED";

                    }
                    else if(!item.IsApproved && !item.IsRejected)
                    {
                        approvaldetails.ApprovalType = "PENDING";

                    }
                    ApprovalLogList.Add(approvaldetails);
                }
                



                ApprovalLogList = ApprovalLogList.ToList();
                ApprovalLogList = ApprovalLogList.OrderByDescending(x => x.DateCreated).ToList();
                if (ApprovalLogList != null && ApprovalLogList.Count > 0)
                {
                    ItemExists = true;
                    IsBusy = false;

                }
                else
                {
                    IsBusy = false;
                    await _pageDialogService.DisplayAlertAsync("No Approval log found", "", "Ok");
                  
                }
               
            }
            catch (Exception ex)
            {
                await _pageDialogService.DisplayAlertAsync("ERROR", ex.Message.ToString(), "Ok");
                IsBusy = false;

            }

        }

        public async void ExecuteApprovalInformation(string IdString)
        {
            try
            {
                Approval_details approvaldetails = new Approval_details();
                var productLogGuid = new Guid(IdString);
                approvaldetails = ApprovalLogList.Where(x => x.Id == productLogGuid).SingleOrDefault();

                if(approvaldetails != null)
                {
                    NavigationParameters parameters = new NavigationParameters();
                   
                    parameters.Add("AgentId", Agent.Id);
                  
                    parameters.Add("Approvaldetails", approvaldetails);
                    await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ApprovalLogInformationPage", parameters);
                }
               

            }
            catch (Exception ex)
            {

            }
        }
    }
}
