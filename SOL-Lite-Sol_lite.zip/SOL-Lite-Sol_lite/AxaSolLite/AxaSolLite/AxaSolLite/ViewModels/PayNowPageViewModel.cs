﻿using AxaSolLite.Models;
using AxaSolLite.Models.CustomerOnboardingCreateCase;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AxaSolLite.ViewModels
{
	public class PayNowPageViewModel : BindableBase, INavigationAware
    {
        private readonly IRepositoryManager _repositoryManager;
        private readonly IUserManager _userService;
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IMediaManager _deviceManager;
        private readonly IAgentRepository _agentRepository;
        private readonly IProspectRepository _prospectRepository;
        private readonly IProductPlansRepository _productPlanRepository;
        private readonly IMotorProductRepository _motorProductRepository;
        private readonly IMotorRidersRepository _motorRidersRepository;
        private readonly IMotorDocumentRepository _motorDocumentRepository;
        private readonly ICountryRepository _countryRepository;
        private readonly ISaveLifeBookingDetails _saveLifeBookingDetails;
        private readonly ITravelProductRepository _travelProductRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        #region Fields 
        private string _urlLink;
        private string _prodType;
        private string _email;
        private int _amount;
        private string _payReference;
        private string _reference;
        private string _certificateNo;
        private Prospect _prospect;
        private Guid _prospectId;
        private Guid _productPlanId;
        private ProductPlan _productPlan;
        private Guid _motorProductId;
        private MotorProduct _motorProduct;
        private List<ExtraTravellers> _extraTravellers = new List<ExtraTravellers>();
        private DelegateCommand _bookingCommand;
        private DelegateCommand _verifyPaymentCommand;
        private AccountOpeningFormResponse _generatedMotorSummaryPdf;
        private bool _caseCreated;
        private bool _isBusy;
        private bool _isVisible;
        private bool _isPaymentRefOld;
        private string _payRef;
        private bool _isRenewal;

        public bool IsPaymentRefOld
        {
            get { return _isPaymentRefOld; }
            set { SetProperty(ref _isPaymentRefOld, value); }
        }
        public string PayRef
        {
            get { return _payRef; }
            set { SetProperty(ref _payRef, value); }
        }

      
        
        #endregion

        #region Properties 
        public bool IsRenewal
        {
            get { return _isRenewal; }
            set { SetProperty(ref _isRenewal, value); }
        }
        public bool CaseCreated
        {
            get { return _caseCreated; }
            set { SetProperty(ref _caseCreated, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public bool IsVisible
        {
            get { return _isVisible; }
            set { SetProperty(ref _isVisible, value); }
        }
        public string UrlLink
        {
            get { return _urlLink; }
            set { SetProperty(ref _urlLink, value); }
        }
        public string ProdType
        {
            get { return _prodType; }
            set { SetProperty(ref _prodType, value); }
        }
        public int Amount
        {
            get { return _amount; }
            set { SetProperty(ref _amount, value); }
        }
        public string PaymentReference
        {
            get { return _payReference; }
            set { SetProperty(ref _payReference, value); }
        }
        public string Reference
        {
            get { return _reference; }
            set { SetProperty(ref _reference, value); }
        }
        public string CertificateNo
        {
            get { return _certificateNo; }
            set { SetProperty(ref _certificateNo, value); }
        }
        public string Email
        {
            get { return _email; }
            set { SetProperty(ref _email, value); }
        }
        public Prospect Prospect
        {
            get { return _prospect = _prospect ?? (_prospect = new Prospect()); }
            set { SetProperty(ref _prospect, value); }
        }
        public ProductPlan ProductPlan
        {
            get { return _productPlan = _productPlan ?? (_productPlan = new ProductPlan()); }
            set { SetProperty(ref _productPlan, value); }
        }
        public MotorProduct MotorProduct
        {
            get { return _motorProduct = _motorProduct ?? (_motorProduct = new MotorProduct()); }
            set { SetProperty(ref _motorProduct, value); }
        }
        public TravelProduct TravelProduct { get; set; }
        public List<ExtraTravellers> ExtraTravellers
        {
            get { return _extraTravellers; }
            set { SetProperty(ref _extraTravellers, value); }
        }
        public Agent LoggedAgent { get; set; }
        public MotorRiders Riders { get; set; }
        public List<FileVariable> Documents { get; set; }
        public BookOnline BookOnline { get; set; }
        public AccountOpeningFormResponse GeneratedMotorSummaryPdf
        {
            get { return _generatedMotorSummaryPdf; }
            set { SetProperty(ref _generatedMotorSummaryPdf, value); }
        }
        private List<AccountOpeningFormResponse> _lifeDocumentPdfs = new List<AccountOpeningFormResponse>();
        public List<AccountOpeningFormResponse> LifeDocumentPdfs
        {
            get { return _lifeDocumentPdfs; }
            set { SetProperty(ref _lifeDocumentPdfs, value); }
        }
        public HealthProduct HealthProduct { get; set; }
        public PersonalAccidentProduct MyPersonalAccidentProduct { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }
        #endregion

        private Logical logical = null;
        private VerifyPayStackPaymentRequest verifyPayStackPayment = new VerifyPayStackPaymentRequest();
        private VerifyPayStackPaymentResponse stackPaymentResponse = new VerifyPayStackPaymentResponse();
        public DelegateCommand BookingCommand => _bookingCommand ?? (_bookingCommand = new DelegateCommand(ExecuteBookingCommand));
        public DelegateCommand VerifyPaymentCommand => _verifyPaymentCommand ?? (_verifyPaymentCommand = new DelegateCommand(ExecuteVerifyPayementCommand));

        public PayNowPageViewModel(IUserManager userService,
            INavigationService navigationService,
            IPageDialogService pageDialogService,
            IRepositoryManager repositoryServices, ITravelProductRepository travelProductRepository,
            IMediaManager deviceManager, ISaveLifeBookingDetails saveLifeBookingDetails,
            IAgentRepository agentRepository, ICountryRepository countryRepository,
            IProspectRepository prospectRepository, IMotorDocumentRepository motorDocumentRepository,
            IProductPlansRepository productPlanRepository, Logical logical,
            IMotorProductRepository motorProductRepository, IMotorRidersRepository motorRidersRepository, EncryptUtils encryptUtils)
        {
            _userService = userService;
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _repositoryManager = repositoryServices;
            _deviceManager = deviceManager;
            _agentRepository = agentRepository;
            _prospectRepository = prospectRepository;
            _productPlanRepository = productPlanRepository;
            _motorProductRepository = motorProductRepository;
            _motorRidersRepository = motorRidersRepository;
            _logical = logical;
            _motorDocumentRepository = motorDocumentRepository;
            _countryRepository = countryRepository;
            _saveLifeBookingDetails = saveLifeBookingDetails;
            _travelProductRepository = travelProductRepository;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    Prospect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }
                if (parameters.ContainsKey("ProductPlanId"))
                {
                    Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId);
                    ProductPlan = await _productPlanRepository.GetProductPlanByProductPlanId(_productPlanId);
                }
                if (parameters.ContainsKey("MotorProductId"))
                {
                    Guid.TryParse(parameters["MotorProductId"].ToString(), out _motorProductId);
                    MotorProduct = await _motorProductRepository.GetMotorProductById(_motorProductId);
                    ProductPlan.AmountPaid = Convert.ToString(MotorProduct.Premium);
                    Amount = Convert.ToInt32(MotorProduct.Premium) * 100;
                }
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }
                if (parameters.ContainsKey("MotorProductId"))
                {
                    Riders = await _motorRidersRepository.GetMotorRidersByMotorProductId(MotorProduct.Id);
                }
                if (parameters.ContainsKey("UploadedDocuments"))
                {
                    Documents = parameters.GetValue<List<FileVariable>>("UploadedDocuments");
                }
                if (parameters.ContainsKey("SummaryPdf"))
                {
                    GeneratedMotorSummaryPdf = parameters.GetValue<AccountOpeningFormResponse>("SummaryPdf");
                }
                if (parameters.ContainsKey("BookOnline"))
                {
                    BookOnline = parameters.GetValue<BookOnline>("BookOnline");
                    ProductPlan.AmountPaid = Convert.ToString(BookOnline.Amount);
                    Amount = Convert.ToInt32(BookOnline.Amount) * 100;
                }
                if (parameters.ContainsKey("LifePdfDocuments"))
                {
                    LifeDocumentPdfs = parameters.GetValue<List<AccountOpeningFormResponse>>("LifePdfDocuments");
                }
                if (parameters.ContainsKey("TravelProductId"))
                {
                    if (Guid.TryParse(parameters["TravelProductId"].ToString(), out Guid travelProductId))
                    {
                        TravelProduct = await _travelProductRepository.GetTravelProductById(travelProductId);
                        ProductPlan.AmountPaid = Convert.ToString(TravelProduct.Premium);
                        Amount = Convert.ToInt32(TravelProduct.Premium) * 100;
                    }
                }
                if (parameters.ContainsKey("OtherTravellers"))
                {
                    ExtraTravellers = parameters.GetValue<List<ExtraTravellers>>("OtherTravellers");
                }

                if (!ProductPlan.IsAccountBalance)
                {
                    bool searchType = await _pageDialogService.DisplayAlertAsync("Notice!", "Pay with....", "Old Payment Reference", "New Payment Reference");
                    if (searchType)
                        IsPaymentRefOld = true;
                    else
                        IsPaymentRefOld = false;
                }
                if (!IsPaymentRefOld)
                {
                    if (parameters.ContainsKey("HealthProduct"))
                    {
                        HealthProduct = parameters.GetValue<HealthProduct>("HealthProduct");
                        Amount = Convert.ToInt32(HealthProduct.Value) * 100;
                    }
                    if (parameters.ContainsKey("IsRenewal"))
                    {
                        IsRenewal = parameters.GetValue<bool>("IsRenewal");
                    }
                    if (parameters.ContainsKey("IsFleetRenewal"))
                    {
                        ProductPlan.AmountPaid = Convert.ToString(ProductPlan.BasicPremium);
                        Amount = Convert.ToInt32(ProductPlan.BasicPremium) * 100;
                    }
                    if (parameters.ContainsKey("PersonalAccidentProduct"))
                    {
                        MyPersonalAccidentProduct = parameters.GetValue<PersonalAccidentProduct>("PersonalAccidentProduct");
                        Amount = Convert.ToInt32(MyPersonalAccidentProduct.Premium) * 100;
                    }
                    Random random = new Random();
                    if (ProductPlan.PaymentReference != null)
                    {
                        PaymentReference = ProductPlan.PaymentReference;
                    }
                    else if (ProductPlan.IsAccountBalance == true)
                    {
                        PaymentReference = Prospect.CustomerNumber + " " + "Aims Account Balance";
                        ProductPlan.PaymentReference = PaymentReference;
                    }
                    else
                    {
                        PaymentReference = "GMAG_ref-" + random.Next(00000001, 10000000).ToString() + "-AXASOL";
                    }
                    CertificateNo = random.Next(00000001, 10000000).ToString();
                    Email = Prospect.Email;
                    InitiatePayStackPayment();
                }                
            }
            catch (Exception ex)
            {

            }            
        }

        public async void InitiatePayStackPayment()
        {
            IsBusy = true;
            IsVisible = false;
            
            try
            {               
                logical = new Logical();
                if (ProductPlan.PaymentReference != null || ProductPlan.IsAccountBalance == true)
                {
                    verifyPayStackPayment.Reference = ProductPlan.PaymentReference;
                    ExecuteBookingCommand();
                    
                    ProductPlan.IsMailSent = IsRenewal ? false : true;
                    ProductPlan.IsNotMailSent = false;
                    ProductPlan.IsCaseId = false;
                    ProductPlan.IsNotPolicyId = false;
                    ProductPlan.IsQuoteId = false;
                    ProductPlan.IsPolicyId = false;
                    ProductPlan.IsRetryBooking = false;
                    int x = await _productPlanRepository.UpdateAsync(ProductPlan);

                   
                    var navigationParameter = new NavigationParameters();
                    navigationParameter.Add("ProspectId", _prospectId);
                    navigationParameter.Add("ProductPlanId", ProductPlan.Id);
                    navigationParameter.Add("AgentId", LoggedAgent.Id);
                    navigationParameter.Add("BookOnline", BookOnline);
                    await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", navigationParameter);

                }
                else
                {
                    PayStackPaymentRequest payStackPaymentRequest = new PayStackPaymentRequest
                    {
                        Amount = Amount,
                        Email = Email,
                        Reference = PaymentReference
                    };
                    var customFields = new CustomField();

                    PayStackPaymentResponse paymentResponse = new PayStackPaymentResponse();

                    paymentResponse = await logical.InitiatePayStackPaymentAsync(payStackPaymentRequest);

                    SavePaymentReferenceRequest paymentref = new SavePaymentReferenceRequest();
                    paymentref.PaymentReference = paymentResponse.Data.Reference;
                    paymentref.PaymentPlatform = "paystack";
                    paymentref.QuoteId = "";
                    var insert = await logical.SavePaymentReferenceToDb(paymentref);


                    Task.Delay(2000).Wait();

                    if (paymentResponse.Status)
                    {
                        UrlLink = UrlLink ?? paymentResponse.Data.AuthorizationUrl.ToString();
                        verifyPayStackPayment.Reference = paymentResponse.Data.Reference;
                        EpaymentRequest req = new EpaymentRequest();
                        req.FullName = Prospect.FullName;
                        req.CustomerNumber = Prospect.CustomerNumber;
                        req.EmailAddress = Prospect.Email;
                        req.Plan = ProductPlan.PlanCategory;
                        req.PaymentLink = UrlLink;
                        var sent = await logical.SendEpaymentMail(req);
                        sent = true; ///////Remove later
                        if (sent)
                        {
                            await _pageDialogService.DisplayAlertAsync("Mail sent", "Payment link sent", "ok");
                            ExecuteBookingCommand();
                            ProductPlan.IsMailSent = IsRenewal? false : true;
                            ProductPlan.IsNotMailSent = false;
                            ProductPlan.IsCaseId = false;
                            ProductPlan.IsNotPolicyId = false;
                            ProductPlan.IsQuoteId = false;
                            ProductPlan.IsPolicyId = false;
                            ProductPlan.IsRetryBooking = false;
                            int x = await _productPlanRepository.UpdateAsync(ProductPlan);

                            //ProductLogDataRequest request = new ProductLogDataRequest();
                            //request.TableName = "BookOnline";
                            //request.ProductLogId = "";
                            //request.ParentId = BookOnline.ProductPlanId.ToString();
                            //request.SerializedData = JsonConvert.SerializeObject(BookOnline);

                            //var inserted = await logical.InsertProductLogData(request);
                            var navigationParameter = new NavigationParameters();
                            navigationParameter.Add("ProspectId", _prospectId);
                            navigationParameter.Add("ProductPlanId", ProductPlan.Id);
                            navigationParameter.Add("AgentId", LoggedAgent.Id);
                            navigationParameter.Add("BookOnline", BookOnline);
                            await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", navigationParameter);
                        }
                        else
                        {
                            await _pageDialogService.DisplayAlertAsync("Mail Not Sent", "Unable to send Payment Link", "ok");

                            var navigationParameter = new NavigationParameters();
                            navigationParameter.Add("ProspectId", _prospectId);
                            navigationParameter.Add("ProductPlanId", ProductPlan.Id);
                            navigationParameter.Add("AgentId", LoggedAgent.Id);
                            await _navigationService.GoBackAsync();
                        }
                    }
                    else
                    {
                        var errorRes = await _pageDialogService.DisplayAlertAsync("Payment Error", paymentResponse.Message, "Reload", "Go Back");

                        if (errorRes)
                        {
                            await _pageDialogService.DisplayAlertAsync("Mail sent", "Payment link sent", "ok");
                            ExecuteBookingCommand();
                            ProductPlan.IsMailSent = IsRenewal ? false : true;
                            ProductPlan.IsNotMailSent = false;
                            ProductPlan.IsCaseId = false;
                            ProductPlan.IsNotPolicyId = false;
                            ProductPlan.IsQuoteId = false;
                            ProductPlan.IsPolicyId = false;
                            ProductPlan.IsRetryBooking = false;
                            
                            int x = await _productPlanRepository.UpdateAsync(ProductPlan);

                            ProductLogDataRequest request = new ProductLogDataRequest();
                            request.TableName = "BookOnline";
                            request.ProductLogId = "";
                            request.ParentId = BookOnline.ProductPlanId.ToString();
                            request.SerializedData = JsonConvert.SerializeObject(BookOnline);

                            var inserted = await logical.InsertProductLogData(request);

                            var navigationParameter = new NavigationParameters();
                            navigationParameter.Add("ProspectId", _prospectId);
                            navigationParameter.Add("ProductPlanId", ProductPlan.Id);
                            navigationParameter.Add("AgentId", LoggedAgent.Id);
                            navigationParameter.Add("BookOnline", BookOnline);
                            await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", navigationParameter);

                            //InitiatePayStackPayment();
                        }
                        else
                        {
                            await _navigationService.GoBackAsync();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
               
            }
            IsBusy = false;
            IsVisible = true;
        }

        public string GetTransRef()
        {
            Guid guid = Guid.NewGuid();
            var TransRef = Convert.ToBase64String(guid.ToByteArray());
            return TransRef.Replace("=", "");
        }

        private async Task<VerifyPayStackPaymentResponse> VerifyPaymentStatus(VerifyPayStackPaymentRequest payRefence)
        {
            logical = new Logical();
            

            VerifyPayStackPaymentResponse verifyResponse = await logical.VerifyPayStackPaymentResponseAsync(payRefence);

            return verifyResponse;
        }

        private async void ExecuteBookingCommand()
        {
            IsBusy = true;
            IsVisible = false;
            try
            {
                if (ProductPlan.PlanCategory == "Instant Plan" || ProductPlan.PlanCategory == "Education Plan Plus" || ProductPlan.PlanCategory == "Bonus Life"
                    || ProductPlan.PlanCategory == "Life Savings" || ProductPlan.PlanCategory == "Ambitions" || ProductPlan.PlanCategory == "Life Plus" || ProductPlan.PlanCategory == "CashBack Term Life")
                {
                    LifeBookingResponse lifeBookingResponse = new LifeBookingResponse();

                    BeneficiaryDetails[] MyArray = BookOnline.BeneficiaryList.ToArray();
                    AimsLifeBookingDto aimsLife = new AimsLifeBookingDto
                    {
                        AmountPaid = Convert.ToInt64(BookOnline.Amount),
                        RequestSource = "MYAXASOL",
                        TransRef = GetTransRef(),
                        PaymentSource = ProductPlan.IsAccountBalance ? "AimsAccountBalance" : "PayStack",
                        RequesterUsername = LoggedAgent.IsExternalAgent ? LoggedAgent.FullName : LoggedAgent.PssUsername,
                        CustomerDeliveryAddress = Prospect.Address,
                        XfrInfoAcmAnnSalary = 0,
                        XfrInfoAcmIdType = 0,
                        XfrInfoCustPrevPolicyFlag = 2,
                        XfrInfoDiscountRate = 0,
                        XfrInfoLcpPaymentPeriod = BookOnline.PolicyTerm,
                        XfrInfoLcpPaymentPeriod2 = BookOnline.PolicyTerm,
                        XfrInfoLcpPaymentPeriod3 = BookOnline.PolicyTerm,
                        XfrInfoLcpPaymentPeriod4 = BookOnline.PolicyTerm,
                        XfrInfoLcpRiderType2 = "",
                        XfrInfoLcpRiderType3 = "",
                        XfrInfoLcpRiderType4 = "",
                        //XfrInfoMstEndtSerial = "",
                        //AgentCode = LoggedAgent.IsAdvisor ? LoggedAgent.SubAgentCode : string.Empty,
                        XfrInfoMstAgentNo = LoggedAgent.AgentCode,
                        XfrInfoMstBranch = BookOnline.BranchCode,
                        XfrInfoMstOffice = 587,
                        XfrInfoMstCustNo = Convert.ToInt64(Prospect.CustomerNumber),
                        XfrInfoMstDocType = 0,
                        XfrInfoMstInsStDt = DateTime.Now,
                        XfrInfoMstLongTermFlag = 0,
                        XfrInfoMstPeriod = BookOnline.PolicyTerm,
                        XfrInfoMstRegDt = DateTime.Now,
                        XfrInfoCarBodyType = "",
                        XfrInfoIsapss = "",
                        XfrInfoHasDiscount = false,
                        XfrInfoAnyYesNmq = BookOnline.AnyYesNMQ,
                        XfrInfoIsreferralPolicy = "",
                        XfrInfoIspayNow = true,
                        XfrInfoLbenAddress = MyArray[0].Address,
                        XfrInfoLbenAddress3 = "",
                        XfrInfoLbenAddress4 = "",
                        XfrInfoLbenAddress5 = "",
                        XfrInfoLbenBirthDt = MyArray[0].DateOfBirth,
                        XfrInfoLbenCustRelation = MyArray[0].RelationshipCode,
                        XfrInfoLbenCustRelation3 = "",
                        XfrInfoLbenCustRelation4 = "",
                        XfrInfoLbenCustRelation5 = "",
                        XfrInfoLbenJobClass = 1,
                        XfrInfoLbenJobClass3 = "",
                        XfrInfoLbenJobClass4 = "",
                        XfrInfoLbenJobClass5 = "",
                        XfrInfoLbenMaritalStatus = MyArray[0].MaritalStatusCode,
                        XfrInfoLbenMaritalStatus3 = "",
                        XfrInfoLbenMaritalStatus4 = "",
                        XfrInfoLbenMaritalStatus5 = "",
                        XfrInfoLbenOccupation = MyArray[0].Occupation,
                        XfrInfoLbenMonthlySalary = 0,
                        XfrInfoLbenNationalNo = LoggedAgent.IsAdvisor ? LoggedAgent.SubAgentCode : string.Empty,
                        XfrInfoLbenOccupation3 = "",
                        XfrInfoLbenOccupation4 = "",
                        XfrInfoLbenOccupation5 = "",
                        XfrInfoLbenOtherName = MyArray[0].FirstName,
                        XfrInfoLbenOtherName3 = "",
                        XfrInfoLbenOtherName4 = "",
                        XfrInfoLbenOtherName5 = "",
                        XfrInfoLbenSumAssured = Convert.ToInt64(BookOnline.SumAssured),
                        XfrInfoLbenSurName = MyArray[0].LastName,
                        XfrInfoLbenSurName3 = "",
                        XfrInfoLbenSurName4 = "",
                        XfrInfoLbenSurName5 = "",
                        XfrInfoLbenTel = MyArray[0].PhoneNumber,
                        XfrInfoLbenTel3 = "",
                        XfrInfoLbenTel4 = "",
                        XfrInfoLbenTel5 = "",
                        XfrInfoLbenType1 = MyArray[0].TypeCode.ToString(),
                        Bentitle1 = MyArray[0].TitleCode,
                        XfrInfoLbenType3 = "",
                        XfrInfoLbenType4 = "",
                        XfrInfoLbenType5 = "",
                        XfrInfoLpmLoadedPrem = 0,
                        XfrInfoLinkedDocNo = 705,
                        XfrInfoLpmPeriodType = 0,
                        XfrInfoMstRenPolType = 0,
                        XfrInfoMstThrough = Convert.ToInt64(LoggedAgent.SBU),
                        XfrInfoMstTrnType = 2,
                        XfrInfoPayNowTransRef = verifyPayStackPayment.Reference,
                        XfrInfoMstUwYear = DateTime.Now.Year,
                        

                        XfrInfoNationamlNo = "",
                        XfrInfoPolicyKey = "",
                        XfrInfoQuoteNo = null,
                        XfrInfoReferralCode = "",
                        XfrInfoScanDate = DateTime.Now,
                        XfrInfoScanSerial = 1036879,
                        XfrInfoUseCustomRate = false,
                        XfrInfoPeriodContrib = Convert.ToInt64(BookOnline.Contribution),
                        XFR_INFO_BOOK_FROM_BALANCE = ProductPlan.IsAccountBalance


                        /* XFR_INFO_SOURCE_BUISNESS = 2*/
                    };

                    if (ProductPlan.PlanCategory == "Instant Plan")
                    {
                        aimsLife.XfrInfoMstPolType = 131;
                        aimsLife.XfrInfoLcpRiderType1 = 1;
                    }
                    else if (ProductPlan.PlanCategory == "Life Savings")
                    {
                        aimsLife.XfrInfoMstPolType = 476;
                        aimsLife.XfrInfoLcpRiderType1 = 1048;
                    }
                    else if (ProductPlan.PlanCategory == "Education Plan Plus")
                    {
                        aimsLife.XfrInfoMstPolType = 456;
                        aimsLife.XfrInfoLcpRiderType1 = 826;
                    }
                    else if (ProductPlan.PlanCategory == "Bonus Life")
                    {
                        aimsLife.XfrInfoMstPolType = 150;
                        if (BookOnline.PolicyTerm == 1)
                        {
                            aimsLife.XfrInfoLcpRiderType1 = 729;
                        }
                        else if (BookOnline.PolicyTerm == 5)
                        {
                            aimsLife.XfrInfoLcpRiderType1 = 720;
                        }
                        else if (BookOnline.PolicyTerm == 10)
                        {
                            aimsLife.XfrInfoLcpRiderType1 = 721;
                        }
                        else if (BookOnline.PolicyTerm == 15)
                        {
                            aimsLife.XfrInfoLcpRiderType1 = 722;
                        }
                       
                    }
                    else if (ProductPlan.PlanCategory == "Ambitions")
                    {
                        aimsLife.XfrInfoMstPolType = 466;
                        aimsLife.XfrInfoLcpRiderType1 = 898;
                    }
                    else if (ProductPlan.PlanCategory == "Life Plus")
                    {
                        aimsLife.XfrInfoMstPolType = 114;
                        aimsLife.XfrInfoLcpRiderType1 = 1;
                    }

                    if (MyArray.Count() > 1)
                    {
                        aimsLife.XfrInfoLbenAddress2 = MyArray[1].Address;
                        aimsLife.XfrInfoLbenCustRelation2 = MyArray[1].RelationshipCode;
                        aimsLife.XfrInfoLbenMaritalStatus2 = MyArray[1].MaritalStatusCode;
                        aimsLife.XfrInfoLbenBirthDt2 = MyArray[1].DateOfBirth;
                        aimsLife.XfrInfoLbenJobClass2 = 1;
                        aimsLife.XfrInfoLbenOccupation2 = MyArray[1].Occupation;
                        aimsLife.XfrInfoLbenOtherName2 = MyArray[1].FirstName;
                        aimsLife.XfrInfoLbenSurName2 = MyArray[1].LastName;
                        aimsLife.XfrInfoLbenTel2 = MyArray[1].PhoneNumber;
                        aimsLife.XfrInfoLbenType2 = MyArray[1].TypeCode;
                        aimsLife.Bentitle2 = MyArray[1].TitleCode;
                    }

                    AccountOpeningFormResponse[] DocumentsArray = LifeDocumentPdfs.ToArray();
                    aimsLife.LifeProposalForm = new LifeProposalForm
                    {
                        ContentType = "application/pdf",
                        Extension = "pdf",
                        FieldName = "Life Proposal",
                        FileName = DocumentsArray[0].DocumentPath,
                        FileContent = DocumentsArray[0].Document
                    };
                    aimsLife.NonMedQuestionaire = new LifeProposalForm
                    {
                        ContentType = "application/pdf",
                        Extension = "pdf",
                        FieldName = "Non Medical Questionaire",
                        FileName = DocumentsArray[1].DocumentPath,
                        FileContent = DocumentsArray[1].Document
                    };
                    List<LifeProposalForm> OtherDocuments = new List<LifeProposalForm>();
                    LifeProposalForm projectionSheet = new LifeProposalForm
                    {
                        ContentType = "application/pdf",
                        Extension = "pdf",
                        FieldName = "Projection Sheet",
                        FileName = Prospect.FullName + "'s projection sheet.pdf",
                        FileContent = BookOnline.ProjectionSheetDocument
                    };
                    if(DocumentsArray != null && DocumentsArray.Count() > 2)
                    {
                        for(int i = 2; i < DocumentsArray.Count(); i++)
                        {
                            LifeProposalForm medicalDocument = new LifeProposalForm
                            {
                                ContentType = DocumentsArray[i].ContentType,
                                Extension = DocumentsArray[i].Extension,
                                FieldName = "Medical Supporting Document",
                                FileName = DocumentsArray[i].DocumentPath,
                                FileContent = DocumentsArray[i].Document
                            };
                            OtherDocuments.Add(medicalDocument);
                        }
                    }
                    OtherDocuments.Add(projectionSheet);
                    
                    aimsLife.OtherRequirements = OtherDocuments;
                    if (BookOnline.PaymentFrequency == "Annual")
                    {
                        aimsLife.XfrInfoMstPayType = 4;
                    }
                    else if (BookOnline.PaymentFrequency == "Monthly")
                    {
                        aimsLife.XfrInfoMstPayType = 1;
                    }
                    else if (BookOnline.PaymentFrequency == "Quarterly")
                    {
                        aimsLife.XfrInfoMstPayType = 2;
                    }
                    else if (BookOnline.PaymentFrequency == "Half yearly")
                    {
                        aimsLife.XfrInfoMstPayType = 3;
                    }
                    else if (BookOnline.PaymentFrequency == "Single")
                    {
                        aimsLife.XfrInfoMstPayType = 5;
                    }

                    #region NaicomIdAssignment
                    List<LifeIndividualBeneficiary> lifeIndividualBeneficiaries = new List<LifeIndividualBeneficiary>();
                    CustomerDetailsReponse customerDetailsReponse = await _logical.GetCustomerDetailsByCustomerNumber(Prospect.CustomerNumber);
                    SyncDataSample NationalitiesObj = await _logical.GetNationalities();
                    SyncDataSample PoliciesObj = await _logical.GetPolicyTypes(2);

                    if (customerDetailsReponse.IsSuccessful && customerDetailsReponse.Result != null && !string.IsNullOrEmpty(customerDetailsReponse.Result.CustomerName))
                    {
                        NaicomIdLifeRequest naicomIdRequest = new NaicomIdLifeRequest
                        {
                            AddressLine = customerDetailsReponse.Result.CustomerAddress, //lifeBookingRequest.CustomerDeliveryAddress,
                            CommissionFee = "0",
                            CoverageStartDate = DateTime.Now, //Convert.ToDateTime(policyStartDate),
                            CoverageEndDate = (DateTime.Now.AddYears(Convert.ToInt16(BookOnline.PolicyTerm))).AddDays(-1), //Convert.ToDateTime(BookOnline.PolicyEndDate),
                            BirthDate = customerDetailsReponse.Result.DateOfBirth,
                            CustomerName = customerDetailsReponse.Result.CustomerName,
                            DocNo = 0,
                            Email = customerDetailsReponse.Result.EmailAddress,
                            Gender = customerDetailsReponse.Result.Gender == 1 ? "Male" : "Female",
                            IdNo = "0",
                            InsuredValue = BookOnline.SumAssured.ToString(),
                            PhoneMobile = customerDetailsReponse.Result.PhoneNumber,
                            Premium = BookOnline.Amount.ToString(),
                            CityLga = "Lagos",
                            PhoneWork = "",
                            State = "",
                            Marital = "",
                            Occupation = ""
                        };
                        if (NationalitiesObj != null && NationalitiesObj.Result != null && NationalitiesObj.Result.Count > 0)
                        {
                            naicomIdRequest.Nationality = NationalitiesObj.Result.Where(x => x.CODE == customerDetailsReponse.Result.Nationality).FirstOrDefault().NAME;
                        }
                        if (PoliciesObj != null && PoliciesObj.Result != null && PoliciesObj.Result.Count > 0)
                        {
                            string productName = PoliciesObj.Result.Where(x => x.CODE == aimsLife.XfrInfoMstPolType).FirstOrDefault().NAME;
                            naicomIdRequest.ProductType = naicomIdRequest.ProductName = naicomIdRequest.PolicyDescription = productName;
                        }
                        LifeIndividualBeneficiary beneficiary1 = new LifeIndividualBeneficiary
                        {
                            BeneficiaryName = BookOnline.BeneficiaryList[0].FirstName + " " + BookOnline.BeneficiaryList[0].LastName,
                            BeneficiaryAddress = BookOnline.BeneficiaryList[0].Address,
                            BeneficiaryBirthDate = BookOnline.BeneficiaryList[0].DateOfBirth,
                            BeneficiaryEmail = "", //bookOnline.BeneficiaryList[0],
                            BeneficiaryGender = BookOnline.BeneficiaryList[0].Gender == 1 ? "Male" : "Female",
                            BeneficiaryIdDoc = "0",
                            BeneficiaryIdNo = "0",
                            BeneficiaryPhone = BookOnline.BeneficiaryList[0].PhoneNumber,
                            BeneficiaryNote = "n/a",
                            BeneficiaryRelationship = BookOnline.BeneficiaryList[0].Relationship,
                            InsuredNo = customerDetailsReponse.Result.CustomerNumber,
                            BenefitProportions = "0"
                        };
                        lifeIndividualBeneficiaries.Add(beneficiary1);

                        if (BookOnline.BeneficiaryList.Count > 1)
                        {
                            LifeIndividualBeneficiary beneficiary2 = new LifeIndividualBeneficiary
                            {
                                BeneficiaryName = BookOnline.BeneficiaryList[1].FirstName + " " + BookOnline.BeneficiaryList[0].LastName,
                                BeneficiaryAddress = BookOnline.BeneficiaryList[1].Address,
                                BeneficiaryBirthDate = BookOnline.BeneficiaryList[1].DateOfBirth,
                                BeneficiaryEmail = "",
                                BeneficiaryGender = BookOnline.BeneficiaryList[1].Gender == 1 ? "Male" : "Female",
                                BeneficiaryIdDoc = "0",
                                BeneficiaryIdNo = "0",
                                BeneficiaryPhone = BookOnline.BeneficiaryList[1].PhoneNumber,
                                BeneficiaryNote = "n/a",
                                BeneficiaryRelationship = BookOnline.BeneficiaryList[1].Relationship,
                                InsuredNo = customerDetailsReponse.Result.CustomerNumber,
                                BenefitProportions = "0"
                            };

                            lifeIndividualBeneficiaries.Add(beneficiary2);
                        }
                        naicomIdRequest.LifeIndividualBeneficiaries = lifeIndividualBeneficiaries.ToArray();
                        string naicomIdPayload = JsonConvert.SerializeObject(naicomIdRequest);
                        ProductPlan.NaicomRequestId = naicomIdPayload;
                    }                    
                    
                    #endregion

                    if (ProductPlan.PlanCategory == "Education Plan Plus")
                    {
                        EduPlanPdfCertRequest request = new EduPlanPdfCertRequest();
                        request.CertificateNo = CertificateNo;
                        request.PolicyId = lifeBookingResponse.PolicyID;
                        request.LifeAssured = Prospect.FullName;
                        request.DateOfBirth = Prospect.Birthdate;
                        request.AgeNextBirthday = Convert.ToString(BookOnline.AgeBeginPolicy);
                        request.SumAssured = string.Format("{0:n0}", BookOnline.SumAssured);
                        request.Premium = string.Format("{0:n0}", BookOnline.Amount);
                        request.StartDate = DateTime.Now; ;
                        request.PeriodOfCover = Convert.ToString(BookOnline.PolicyTerm) + " Years";
                        request.EndDate = (DateTime.Now.AddYears(Convert.ToInt16(BookOnline.PolicyTerm))).AddDays(-1);
                        request.PolicyTerm = Convert.ToString(BookOnline.PolicyTerm) + " Years";
                        request.PaymentFrequency = BookOnline.PaymentFrequency;
                        request.BeneficiaryFullName = MyArray[0].FullName;
                        request.IssueDate = DateTime.Now;
                        request.CustEmail = Prospect.Email;
                        request.CustName = Prospect.FullName;
                        request.RefCode = GetTransRef();
                        request.Product = ProductPlan.PlanCategory;
                        //request.AgentEmail = "raphael.ariguzor@axamansard.com";
                        request.AgentEmail = LoggedAgent.EmailAddress;
                        request.CustomerNo = Prospect.CustomerNumber;

                        SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                        {
                            ProductPlanId = ProductPlan.Id,
                            RequestData = JsonConvert.SerializeObject(aimsLife),
                            PaymentReference = verifyPayStackPayment.Reference,
                            CertData = JsonConvert.SerializeObject(request)
                        };
                        int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);
                    }
                    else if (ProductPlan.PlanCategory == "Instant Plan")
                    {
                        InstantPlanPdfCertRequest request = new InstantPlanPdfCertRequest();
                        request.PolicyId = lifeBookingResponse.PolicyID;
                        request.LifeAssured = Prospect.FullName;
                        request.DateOfBirth = Prospect.Birthdate;
                        request.SumAssured = string.Format("{0:n0}", BookOnline.SumAssured);
                        request.Premium = string.Format("{0:n0}", BookOnline.Amount);
                        request.StartDate = DateTime.Now;
                        request.EndDate = (DateTime.Now.AddYears(1)).AddDays(-1);
                        request.BeneficiaryFullName = MyArray[0].FullName;
                        request.IssueDate = DateTime.Now;
                        request.CustEmail = Prospect.Email;
                        request.CustName = Prospect.FullName;
                        request.RefCode = GetTransRef();
                        request.Product = ProductPlan.PlanCategory;
                        //request.AgentEmail = "raphael.ariguzor@axamansard.com";
                        request.AgentEmail = LoggedAgent.EmailAddress;
                        request.CustomerNo = Prospect.CustomerNumber;

                        SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                        {
                            ProductPlanId = ProductPlan.Id,
                            RequestData = JsonConvert.SerializeObject(aimsLife),
                            PaymentReference = verifyPayStackPayment.Reference,
                            CertData = JsonConvert.SerializeObject(request)

                        };
                        int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);
                    }
                    else if (ProductPlan.PlanCategory == "Life Savings")
                    {
                        LifeSavingPdfCertRequest request = new LifeSavingPdfCertRequest();

                        request.PolicyId = lifeBookingResponse.PolicyID;
                        request.LifeAssured = Prospect.FullName;
                        request.DateOfBirth = Prospect.Birthdate.ToString("dd-MM-yyyy");
                        request.AgeNextBirthday = Convert.ToString(BookOnline.AgeBeginPolicy);
                        request.SumAssured = string.Format("{0:n0}", BookOnline.SumAssured);
                        request.Premium = string.Format("{0:n0}", BookOnline.Amount);
                        request.StartDate = BookOnline.PolicyStartDate;
                        request.AnnualContribution = string.Format("{0:n0}", BookOnline.Amount);
                        request.EndDate = BookOnline.PolicyEndDate;
                        request.PaymentFrequency = BookOnline.PaymentFrequency;
                        request.BeneficiaryFullNameOne = MyArray[0].FullName;
                        request.BeneficiaryFullNameTwo = (MyArray.Count() > 1) ? MyArray[1].FullName : string.Empty;
                        request.BeneficiaryFullNameThree = string.Empty;
                        request.CertificateNo = CertificateNo;
                        request.IssueDate =DateTime.Now.ToString("dd-MM-yyyy");
                        request.CustEmail = Prospect.Email;
                        request.CustName = Prospect.FullName;
                        request.RefCode = GetTransRef();
                        request.Product = ProductPlan.PlanCategory;
                        //request.AgentEmail = "raphael.ariguzor@axamansard.com";
                        request.AgentEmail = LoggedAgent.EmailAddress;
                        request.CustomerNo = Prospect.CustomerNumber;
                        SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                        {
                            ProductPlanId = ProductPlan.Id,
                            RequestData = JsonConvert.SerializeObject(aimsLife),
                            PaymentReference = verifyPayStackPayment.Reference,
                            CertData = JsonConvert.SerializeObject(request)

                        };
                        int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);

                    }
                  
                    else if (ProductPlan.PlanCategory == "Bonus Life")
                    {
                        BonusLifeCertRequest bonusLifeCertRequest = new BonusLifeCertRequest
                        {
                            AgentEmail = LoggedAgent.EmailAddress,
                            EmailAddress = Prospect.Email,
                            CustomerName = Prospect.FullName,
                            CustomerNumber = Prospect.CustomerNumber,
                            AgeNextBirthday = BookOnline.AgeBeginPolicy.ToString(),
                            LifeAssured = Prospect.FullName,
                            SumAssured = BookOnline.SumAssured.ToString(),
                            CertificateNumber = CertificateNo,
                            StartDate = BookOnline.PolicyStartDate,
                            IssueDate = BookOnline.PolicyStartDate,
                            PaymentTerm = BookOnline.PolicyTerm.ToString(),
                            PolicyId = lifeBookingResponse.PolicyID, //Big check here o!!!!!!!!!!!!!!
                            DateOfBirth = Prospect.Birthdate.ToString("MM/dd/yyyy"),
                            ProductName = "Bonus Life",
                            Frequency = BookOnline.PaymentFrequency,
                            Premium = BookOnline.AnnualPremium.ToString(),
                            TransactionReference = GetTransRef(),
                            BeneficiaryOne = MyArray[0].FullName,
                            BeneficiaryTwo = (MyArray.Count() > 1) ? MyArray[1].FullName : string.Empty,
                            BeneficiaryThree = string.Empty,
                            FromAxaSol = true
                        };

                        SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                        {
                            ProductPlanId = ProductPlan.Id,
                            RequestData = JsonConvert.SerializeObject(aimsLife),
                            PaymentReference = ProductPlan.PaymentReference,
                            CertData = JsonConvert.SerializeObject(bonusLifeCertRequest)
                        };
                        int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);
                    }
                    else if (ProductPlan.PlanCategory == "Ambitions")
                    {
                        AmbitionsCertificateRequest ambitionsCertificate = new AmbitionsCertificateRequest
                        {
                            AgeNextBirthday = BookOnline.AgeBeginPolicy.ToString(),
                            LifeAssured = Prospect.FullName,
                            SumAssured = BookOnline.SumAssured.ToString("N2"),
                            CertificateNo = CertificateNo,
                            CustomerName = Prospect.FullName,
                            PolicyTerm = BookOnline.PolicyTerm.ToString(),
                            Premium = BookOnline.AnnualPremium.ToString("N2"),
                            PolicyId = lifeBookingResponse.PolicyID,
                            StartDate = BookOnline.PolicyStartDate,
                            EndDate = BookOnline.PolicyEndDate,
                            DateofBirth = Prospect.Birthdate.ToString("MM/dd/yyyy"),
                            Beneficiary = MyArray[0].FullName,
                            Beneficiary2 = (MyArray.Count() > 1) ? MyArray[1].FullName : string.Empty,
                            IssueDate = BookOnline.PolicyStartDate,
                            PeriodofCover = BookOnline.PolicyStartDate + " to " + BookOnline.PolicyEndDate,
                            AgentEmaiil = LoggedAgent.EmailAddress,
                            EmailAddress = Prospect.Email,
                            CustomerNumber = Prospect.CustomerNumber,
                            ProductName = "Ambitions",
                            TransactionReference = ProductPlan.PaymentReference
                        };

                        SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                        {
                            ProductPlanId = ProductPlan.Id,
                            RequestData = JsonConvert.SerializeObject(aimsLife),
                            PaymentReference = ProductPlan.PaymentReference,
                            CertData = JsonConvert.SerializeObject(ambitionsCertificate)
                        };
                        int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);
                    }
                    else if (ProductPlan.PlanCategory == "Bonus Life")
                    {
                        BonusLifeCertRequest bonusLifeCertRequest = new BonusLifeCertRequest
                        {
                            AgentEmail = LoggedAgent.EmailAddress,
                            EmailAddress = Prospect.Email,
                            CustomerName = Prospect.FullName,
                            CustomerNumber = Prospect.CustomerNumber,
                            AgeNextBirthday = BookOnline.AgeBeginPolicy.ToString(),
                            LifeAssured = Prospect.FullName,
                            SumAssured = BookOnline.SumAssured.ToString(),
                            CertificateNumber = CertificateNo,
                            StartDate = BookOnline.PolicyStartDate,
                            IssueDate = BookOnline.PolicyStartDate,
                            PaymentTerm = BookOnline.PolicyTerm.ToString(),
                            PolicyId = lifeBookingResponse.PolicyID, //Big check here o!!!!!!!!!!!!!!
                            DateOfBirth = Prospect.Birthdate.ToString("MM/dd/yyyy"),
                            ProductName = "Bonus Life",
                            Frequency = BookOnline.PaymentFrequency,
                            Premium = BookOnline.AnnualPremium.ToString(),
                            TransactionReference = GetTransRef(),
                            BeneficiaryOne = MyArray[0].FullName,
                            BeneficiaryTwo = (MyArray.Count() > 1) ? MyArray[1].FullName : string.Empty,
                            BeneficiaryThree = string.Empty,
                            FromAxaSol = true
                        };

                        SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                        {
                            ProductPlanId = ProductPlan.Id,
                            RequestData = JsonConvert.SerializeObject(aimsLife),
                            PaymentReference = ProductPlan.PaymentReference,
                            CertData = JsonConvert.SerializeObject(bonusLifeCertRequest)
                        };
                        int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);
                    }                
                   
                    else if (ProductPlan.PlanCategory == "Life Plus")
                    {
                        LifePlusCertificateRequest request = new LifePlusCertificateRequest()
                        {
                            AgeNextBirthday = BookOnline.AgeBeginPolicy.ToString(),
                            LifeAssured = Prospect.FullName,
                            SumAssured = BookOnline.SumAssured.ToString("N2"),
                            CertificateNo = CertificateNo,
                            CustomerName = Prospect.FullName,
                            PolicyId = lifeBookingResponse.PolicyID,
                            StartDate = BookOnline.PolicyStartDate,
                            EndDate = BookOnline.PolicyEndDate,
                            DateofBirth = Prospect.Birthdate.ToString("MM/dd/yyyy"),
                            Beneficiary = MyArray[0].FullName,
                            Beneficiary2 = (MyArray.Count() > 1) ? MyArray[1].FullName : string.Empty,
                            IssueDate = BookOnline.PolicyStartDate,
                            AgentEmaiil = LoggedAgent.EmailAddress,
                            EmailAddress = Prospect.Email,
                            CustomerNumber = Prospect.CustomerNumber,
                            ProductName = "Life Plus",
                            TransactionReference = PaymentReference,
                            PaymentFrequency = BookOnline.PaymentFrequency,
                            AnnualContribution = BookOnline.AnnualPremium.ToString("N2"),
                        };
                        SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                        {
                            ProductPlanId = ProductPlan.Id,
                            RequestData = JsonConvert.SerializeObject(aimsLife),
                            PaymentReference = verifyPayStackPayment.Reference,
                            CertData = JsonConvert.SerializeObject(request)
                        };
                        int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);
                    }
                }
                else
                {
                    SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                    {
                        ProductPlanId = ProductPlan.Id,
                        PaymentReference = verifyPayStackPayment.Reference
                    };
                    int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);
                }

                ProductPlan.PaymentReference = verifyPayStackPayment.Reference;
               
                await _productPlanRepository.UpdateAsync(ProductPlan);
                ProductLogDataRequest req = new ProductLogDataRequest();
                req.TableName = "ProductPlan";
                req.ProductLogId = ProductPlan.IdString;
                req.ParentId = Prospect.ProspectId;
                req.SerializedData = JsonConvert.SerializeObject(ProductPlan);

                var inserted = await logical.InsertProductLogData(req);

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
            IsVisible = true;
        }

        private async void ExecuteVerifyPayementCommand()
        {
            try
            {
                IsBusy = true;
                VerifyPayStackPaymentRequest req = new VerifyPayStackPaymentRequest();

                req.Reference = Reference;
                verifyPayStackPayment.Reference = Reference;
               
                var res = await VerifyPaymentStatus(req);
                if (res.Data.Status.Contains("success"))
                {
                    if (res.Data.Fees.ToString() == ProductPlan.AmountPaid)
                    {
                        await _pageDialogService.DisplayAlertAsync("Payment Success", "Your payment for " + ProductPlan.PlanCategory + " is successful!", "ok");
                        ExecuteBookingCommand();
                        ProductPlan.IsMailSent = true;
                        ProductPlan.IsNotMailSent = false;
                        ProductPlan.IsCaseId = false;
                        ProductPlan.IsNotPolicyId = false;
                        ProductPlan.IsQuoteId = false;
                        ProductPlan.IsPolicyId = false;
                        ProductPlan.IsRetryBooking = false;
                        int x = await _productPlanRepository.UpdateAsync(ProductPlan);

                        ProductLogDataRequest request = new ProductLogDataRequest();
                        request.TableName = "BookOnline";
                        request.ProductLogId = "";
                        request.ParentId = BookOnline.ProductPlanId.ToString();
                        request.SerializedData = JsonConvert.SerializeObject(BookOnline);

                        var inserted = await logical.InsertProductLogData(request);
                        var navigationParameter = new NavigationParameters();
                        navigationParameter.Add("ProspectId", _prospectId);
                        navigationParameter.Add("ProductPlanId", ProductPlan.Id);
                        navigationParameter.Add("AgentId", LoggedAgent.Id);
                        navigationParameter.Add("BookOnline", BookOnline);
                        await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", navigationParameter);
                    }
                    else
                    {
                        IsBusy = false;
                        await _pageDialogService.DisplayAlertAsync("Unable to validate payment, Please check reference number", "check back soon", "ok");
                        await _navigationService.GoBackAsync();
                    }
                }
                else
                {
                    IsBusy = false;
                    await _pageDialogService.DisplayAlertAsync("Unable to validate payment, Please check reference number", "check back soon", "ok");
                    await _navigationService.GoBackAsync();

                }
            }
            catch (Exception e)
            {
                IsBusy = false;
                await _pageDialogService.DisplayAlertAsync("Payment verification Unsuccessful", "check back soon", "ok");
                await _navigationService.GoBackAsync();
            }
        }
    }
}
