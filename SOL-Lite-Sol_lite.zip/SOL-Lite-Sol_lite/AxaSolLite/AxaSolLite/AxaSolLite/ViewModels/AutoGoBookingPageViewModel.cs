﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Plugin.FilePicker;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AxaSolLite.ViewModels
{
    public class AutoGoBookingPageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IValidationService _validationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly ICalculatorService _calculatorService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IProductPlansRepository _productPlanRepository;
        private readonly IMediaManager _deviceManager;
        private readonly IAgentRepository _agentRepository;
        private readonly IGenBizBranchRepository _genBizBranchRepository;
        private readonly EncryptUtils _encryptUtils;

        #region Fields
        private string _dateofBirth;
        private DateTime _startDate;
        private DateTime _date;
        private string _firstname;
        private string _lastname;
        private string _othername;
        private string _gender;
        private string _phonenumber;
        private string _email;
        private string _address;
        private string _state;
        private string _registrationnumber;
        private string _enginenumber;
        private string _chassisnumber;
        private bool _isBusy;
        private List<int> _vehicleYear;
        private MotorDetailSample _myVehicleMakes;
        private MakeModeDetailsSample _myVehicleModels;
        private ObservableCollection<string> _vehicleMakes = new ObservableCollection<string>();
        private ObservableCollection<string> _vehicleModels = new ObservableCollection<string>();
        private ObservableCollection<string> _vehicleReturned = new ObservableCollection<string>();
        private string _selectedVehicleMake;
        private string _SelectedVehicleModel;
        private int _SelectedVehicleYear;
        private string _fileLabel;
        private string _fileLabelPath;
        private string[] _fileTypes;
        private string _fileSize;
        private Image _fileImagePreview;
        private string _text;
        private List<string> _fileNameList;
        private Dictionary<string, object> _fileByteList;
        private string _contents;
        private string _selectedBranch;
        private int _branch;
        private ObservableCollection<string> _branches = new ObservableCollection<string>();
        private List<GenBizBranch> _myBranches = new List<GenBizBranch>();
        private Prospect _prospect;
        private Guid _prospectId;
        private Guid _productPlanId;
        private ProductPlan _productPlan;
        private UploadFile _uploadFile;
        private MakeList _motorMake;
        private ModelList _motorModel;
        private PolicyNumberDetailsResponse _policyDetailsResponse;
        private DelegateCommand _autoGoFormCommand;
        private DelegateCommand _pickfileCommand;
        #endregion

        #region Properties
        public string DateofBirth
        {
            get { return _dateofBirth; }
            set { SetProperty(ref _dateofBirth, value); }
        }
        public string FirstName
        {
            get { return _firstname; }
            set { SetProperty(ref _firstname, value); }
        }
        public DateTime StartDate
        {
            get { return _startDate; }
            set { SetProperty(ref _startDate, value); }
        }
        public DateTime Date
        {
            get { return _date; }
            set { SetProperty(ref _date, value); }
        }
        public string LastName
        {
            get { return _lastname; }
            set { SetProperty(ref _lastname, value); }
        }
        public string OtherName
        {
            get { return _othername; }
            set { SetProperty(ref _othername, value); }
        }
        public string Gender
        {
            get { return _gender; }
            set { SetProperty(ref _gender, value); }
        }
        public string PhoneNumber
        {
            get { return _phonenumber; }
            set { SetProperty(ref _phonenumber, value); }
        }
        public string Email
        {
            get { return _email; }
            set { SetProperty(ref _email, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public string Address
        {
            get { return _address; }
            set { SetProperty(ref _address, value); }
        }
        public string State
        {
            get { return _state; }
            set { SetProperty(ref _state, value); }
        }
        public string RegistrationNumber
        {
            get { return _registrationnumber; }
            set { SetProperty(ref _registrationnumber, value); }
        }
        public string EngineNumber
        {
            get { return _enginenumber; }
            set { SetProperty(ref _enginenumber, value); }
        }
        public string ChassisNumber
        {
            get { return _chassisnumber; }
            set { SetProperty(ref _chassisnumber, value); }
        }
        List<object> vehicleMakes = new List<object>();
        public List<string> FileNameList
        {
            get { return _fileNameList; }
            set { SetProperty(ref _fileNameList, value); }
        }
        public Dictionary<string, object> FileByteList
        {
            get { return _fileByteList; }
            set { SetProperty(ref _fileByteList, value); }
        }
        public string Contents
        {
            get { return _contents; }
            set { SetProperty(ref _contents, value); }
        }
        public string FileLabel
        {
            get { return _fileLabel; }
            set { SetProperty(ref _fileLabel, value); }
        }
        public string FileLabelPath
        {
            get { return _fileLabelPath; }
            set { SetProperty(ref _fileLabelPath, value); }
        }
        public string FileSize
        {
            get { return _fileSize; }
            set { SetProperty(ref _fileSize, value); }
        }
        public string[] FileTypes
        {
            get { return _fileTypes; }
            set { SetProperty(ref _fileTypes, value); }
        }
        public Image FileImagePreview
        {
            get { return _fileImagePreview; }
            set { SetProperty(ref _fileImagePreview, value); }
        }
        public List<int> VehicleYear
        {
            get { return _vehicleYear; }
            set { SetProperty(ref _vehicleYear, value); }
        }
        public int SelectedYear
        {
            get { return _SelectedVehicleYear; }
            set { SetProperty(ref _SelectedVehicleYear, value); }
        }
        public string SelectedVehicleMake
        {
            get { return _selectedVehicleMake; }
            set { SetProperty(ref _selectedVehicleMake, value); }
        }
        public string SelectedVehicleModel
        {
            get { return _SelectedVehicleModel; }
            set { SetProperty(ref _SelectedVehicleModel, value); }
        }
        public MotorDetailSample MyVehicleMakes
        {
            get { return _myVehicleMakes; }
            set { SetProperty(ref _myVehicleMakes, value); }
        }
        public MakeModeDetailsSample MyVehicleModels
        {
            get { return _myVehicleModels; }
            set { SetProperty(ref _myVehicleModels, value); }
        }
        public ObservableCollection<string> VehicleMakes
        {
            get { return _vehicleMakes; }
            set { SetProperty(ref _vehicleMakes, value); }
        }
        public ObservableCollection<string> VehicleModels
        {
            get { return _vehicleModels; }
            set { SetProperty(ref _vehicleModels, value); }
        }
        public ObservableCollection<string> VehicleReturned
        {
            get { return _vehicleReturned; }
            set { SetProperty(ref _vehicleReturned, value); }
        }
        public PolicyNumberDetailsResponse PolicyDetailsResponse
        {
            get { return _policyDetailsResponse; }
            set { SetProperty(ref _policyDetailsResponse, value); }
        }
        public Prospect Prospect
        {
            get { return _prospect = _prospect ?? (_prospect = new Prospect()); }
            set { SetProperty(ref _prospect, value); }
        }
        public ProductPlan ProductPlan
        {
            get { return _productPlan = _productPlan ?? (_productPlan = new ProductPlan()); }
            set { SetProperty(ref _productPlan, value); }
        }
        public UploadFile UploadFile
        {
            get { return _uploadFile = _uploadFile ?? (_uploadFile = new UploadFile()); }
            set { SetProperty(ref _uploadFile, value); }
        }
        public ModelList MotorModel
        {
            get { return _motorModel; }
            set { SetProperty(ref _motorModel, value); }
        }
        public MakeList MotorMake
        {
            get { return _motorMake; }
            set { SetProperty(ref _motorMake, value); }
        }
        public Agent LoggedAgent { get; set; }
        public string SelectedBranch
        {
            get { return _selectedBranch; }
            set { SetProperty(ref _selectedBranch, value); }
        }
        public int Branch
        {
            get { return _branch; }
            set { SetProperty(ref _branch, value); }
        }
        public ObservableCollection<string> Branches
        {
            get { return _branches; }
            set { SetProperty(ref _branches, value); }
        }
        public List<GenBizBranch> MyBranches
        {
            get { return _myBranches; }
            set { SetProperty(ref _myBranches, value); }
        }
        #endregion

        #region Commands
        private DelegateCommand<string> _changeVehicleMakeCommand;
        private DelegateCommand _fileDeleteCommand;
        Logical logical = null;


        public DelegateCommand BuyAutoGoCommand => _autoGoFormCommand ?? (_autoGoFormCommand = new DelegateCommand(ExecuteBuyAutoGoCommand));
        public DelegateCommand PickFileCommand => _pickfileCommand ?? (_pickfileCommand = new DelegateCommand(ExecutePickFileCommand));
        public DelegateCommand<string> ChangeVehicleMakeCommand => _changeVehicleMakeCommand ?? (_changeVehicleMakeCommand = new DelegateCommand<string>(ExecuteChangeVehicleMakeCommand));
        public DelegateCommand FileDeleteCommand => _fileDeleteCommand ?? (_fileDeleteCommand = new DelegateCommand(ExecuteFileDeleteCommand));
        #endregion

        public AutoGoBookingPageViewModel(INavigationService navigationService,
            IValidationService validationService, IPageDialogService pageDialogService,
            ICalculatorService calculatorService,
            IProspectRepository prospectRepository,
            IMediaManager mediaManager,
            IProductPlansRepository productPlanRepository,
            IAgentRepository agentRepository, IGenBizBranchRepository genBizBranchRepository, EncryptUtils encryptUtils
            )
        {
            _navigationService = navigationService;
            _validationService = validationService;
            _pageDialogService = pageDialogService;
            _calculatorService = calculatorService;
            _prospectRepository = prospectRepository;
            _deviceManager = mediaManager;
            _productPlanRepository = productPlanRepository;
            _agentRepository = agentRepository;
            _genBizBranchRepository = genBizBranchRepository;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    //Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    //Prospect = await _prospectRepository.GetById(_prospectId);

                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect encryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(encryptedProspect.Prospect);
                    Prospect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);

                    FirstName = Prospect.FirstName;
                    OtherName = Prospect.MiddleName;
                    LastName = Prospect.LastName;
                    Gender = Prospect.Gender.ToString();
                    if (Prospect.Gender == 1)
                    {
                        Gender = "Male";
                    }
                    if (Prospect.Gender == 0)
                    {
                        Gender = "Female";
                    }
                    DateofBirth = Prospect.Birthdate.ToString("MM/dd/yyyy");
                    PhoneNumber = Prospect.MobileNumber;
                    Email = Prospect.Email;
                    Address = Prospect.Address;

                }
                if (parameters.ContainsKey("ProductPlanId"))
                {
                    Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId);
                    ProductPlan = await _productPlanRepository.GetProductPlanByProductPlanId(_productPlanId);

                }
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }
                if (parameters.ContainsKey("PolicyDetails"))
                {
                    PolicyDetailsResponse = parameters.GetValue<PolicyNumberDetailsResponse>("PolicyDetails");
                    
                    //SelectedVehicleModel = PolicyDetailsResponse.VehModel;
                    //SelectedYear = PolicyDetailsResponse.VehProdYear;
                    RegistrationNumber = PolicyDetailsResponse.VehPlateNo;
                    ChassisNumber = PolicyDetailsResponse.ChasisNo;
                    EngineNumber = PolicyDetailsResponse.EngineNo;
                   

                }
                logical = new Logical();
                var m = await logical.GetMotorMakes();
                MyVehicleMakes = m;
                foreach (var item in m.Result.MakeList)
                {
                    var pre = item.Name;

                    VehicleMakes.Add(pre);

                }
                if (PolicyDetailsResponse != null)
                {

                    SelectedVehicleMake = VehicleMakes.Where(x => x.ToLower() == PolicyDetailsResponse.VehMakeName.ToLower()).FirstOrDefault();
                    var make = SelectedVehicleMake;

                    var res = MyVehicleMakes.Result.MakeList.Where(x => x.Name == make).FirstOrDefault();
                    var models = await logical.GetMotorModels(res.Id);

                    foreach (var item in models.Result.ModelList)
                    {
                        if (item.Name != null)
                        {
                            VehicleModels.Add(item.Name);
                        }
                        else
                        {
                            VehicleModels.Add(string.Empty);
                        }
                    }
                    SelectedVehicleModel = VehicleModels.Where(x => x.ToLower() == PolicyDetailsResponse.VehModel.ToLower()).FirstOrDefault();
                    var startYear = new DateTime(1970, 1, 1).Year;
                    var endYear = DateTime.Now.Year;
                    var yearCount = YearCount(endYear, startYear);
                    var MyList = Enumerable.Range(startYear, yearCount + 1).Reverse().ToList();
                    VehicleYear = MyList;
                    SelectedYear = VehicleYear.Where(x => x == PolicyDetailsResponse.VehProdYear).FirstOrDefault();
                }

                IsBusy = true;

                InitializeDefaultValues();
               

            }
            catch (Exception ex)
            {
                //TODO: add logging service
            }
            IsBusy = false;
        }

        private async void InitializeDefaultValues()
        {
            try
            {
                StartDate = DateTime.Now;
                Date = DateTime.Now;
                var startYear = new DateTime(1970, 1, 1).Year;
                var endYear = DateTime.Now.Year;
                var yearCount = YearCount(endYear, startYear);
                var MyList = Enumerable.Range(startYear, yearCount + 1).Reverse().ToList();
                VehicleYear = MyList;

                MyBranches = await _genBizBranchRepository.GetGenBizBranches();
                foreach (GenBizBranch item in MyBranches)
                {
                    string branch = string.Empty;
                    branch = item.BranchName;
                    Branches.Add(branch);
                }

            }
            catch (Exception ex)
            {

            }
        }

        public int YearCount(int startDate, int endDate)
        {
            return startDate - endDate;
        }

        private async void ExecutePickFileCommand()
        {
            IsBusy = true;
            try
            {
                bool choice = await _pageDialogService.DisplayAlertAsync("Confirm", "Please select how you wish to upload a document", "Gallery", "Camera");
                if (choice)
                {
                    if (Device.RuntimePlatform == Device.Android)
                    {
                        FileTypes = new string[] { "image/png", "image/jpeg", "application/pdf" };
                    }

                    await PickedFiles(FileTypes);

                    if (FileLabel != null || Contents != null)
                    {
                        if (Contents.Length > 2097152)
                        {
                            FileLabel = null;
                            Contents = null;
                            await _pageDialogService.DisplayAlertAsync("Error", "File size too large. Please upload a document not larger than 2MB in size", "Cancel");
                        }
                        else
                            await _pageDialogService.DisplayAlertAsync("Success", "Document Uploaded successfully", "Ok");
                    }

                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Unsuccessful", "Document failed to upload. Please try again.", "Ok");
                    }
                }
                else
                {
                    if (_deviceManager.CameraAvailable)
                    {
                        var newPhoto = await _deviceManager.TakePhotoAsync();

                        if (newPhoto != null)
                        {

                            FileLabel = "Photo For Drivers License";
                            UploadFile motorFile = new UploadFile
                            {
                                FileLabel = FileLabel,

                                Content = newPhoto.FileContent
                                
                            };
                            Contents = System.Text.Encoding.UTF8.GetString(motorFile.Content);


                            await _pageDialogService.DisplayAlertAsync("File Uploaded", "Photo successfully captured", "Okay");

                        }
                        else
                        {

                            await _pageDialogService.DisplayAlertAsync("Oooops!!!", "File too large, recapture the document or upload another document", "Cancel");
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        public async Task PickedFiles(string[] fileTypes)
        {
            try
            {
                var pickedFile = await CrossFilePicker.Current.PickFile(fileTypes);

                if (pickedFile != null)
                {
                    FileLabel = pickedFile.FileName;
                    FileLabelPath = pickedFile.FilePath;

                    if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase))
                    {
                        Contents = System.Text.Encoding.UTF8.GetString(pickedFile.DataArray, 0, pickedFile.DataArray.Length);
                    }

                    FileSize = FileSizeFormatter.FormatSize(Contents.Length);
                    UploadFile motorFile = new UploadFile
                    {
                        FileLabel = FileLabel,
                        DocumentCategory = FileLabelPath,
                        Content = pickedFile.DataArray
                    };

                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public static class FileSizeFormatter
        {
            static readonly string[] suffixes = { "Bytes", "KB", "MB", "GB", "TB", "PB" };

            public static string FormatSize(long bytes)
            {
                int counter = 0;
                decimal number = (decimal)bytes;
                while (Math.Round(number / 1024) >= 1)
                {
                    number = number / 1024;
                    counter++;
                }
                return string.Format("{0:n1}{1}", number, suffixes[counter]);
            }
        }

        private async void ExecuteFileDeleteCommand()
        {
            IsBusy = true;
            try
            {
                if (FileLabel != null || Contents != null)
                {
                    FileLabel = null;
                    Contents = null;
                    await _pageDialogService.DisplayAlertAsync("Done", "Uploaded file deleted successfully", "Ok");
                }
                else
                    await _pageDialogService.DisplayAlertAsync("Notice", "There is no document to be deleted", "Ok");
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        public async void ExecuteChangeVehicleMakeCommand(string make)
        {
            IsBusy = true;
            List<string> motorModels = new List<string>();
            try
            {
                if (Regex.IsMatch(SelectedVehicleMake, @"\d"))
                {
                    VehicleModels.Clear();
                    var models = await logical.GetMotorModels(Convert.ToInt32(SelectedVehicleMake));

                    foreach (var item in models.Result.ModelList)
                    {
                        if (item.Name != null)
                        {
                            VehicleModels.Add(item.Name);
                        }
                        else
                        {
                            VehicleModels.Add(string.Empty);
                        }
                    }
                }
                else if (SelectedVehicleMake != null)
                {
                    VehicleModels.Clear();
                    make = SelectedVehicleMake;

                    var res = MyVehicleMakes.Result.MakeList.Where(x => x.Name == make).FirstOrDefault();
                    var var = await logical.GetMotorModels(Convert.ToInt32(res.Id));

                    MyVehicleModels = var;
                    foreach (var item in var.Result.ModelList)
                    {
                        var pre = item.Name;
                        VehicleModels.Add(pre);
                    }
                }
                else
                {
                    return;
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        public async void ExecuteBuyAutoGoCommand()
        {
            IsBusy = true;
            try
            {
                if (FirstName == "" || FirstName == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "First Name", "Ok");
                }
                else if (LastName == null || LastName == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Last Name", "Ok");
                }
                else if (DateofBirth == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Date of birth", "Ok");
                }
                else if (PhoneNumber == null || PhoneNumber == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Phone Number", "Ok");
                }
                else if (Email == null || Email == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Email", "Ok");
                }
                else if (Address == null || Address == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Address", "Ok");
                }
                else if (State == null || State == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "State", "Ok");
                }
                else if (SelectedVehicleMake == null || SelectedVehicleMake == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Vehicle Make", "Ok");
                }
                else if (SelectedVehicleModel == null || SelectedVehicleModel == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Vehicle Model", "Ok");
                }
                else if (RegistrationNumber == null || RegistrationNumber == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Registration Number", "Ok");
                }
                else if (ChassisNumber == "" || ChassisNumber == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Chassis Number", "Ok");
                }
                else if (EngineNumber == null || EngineNumber == "")
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Engine Number", "Ok");
                }
                else if (SelectedYear == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Vehicle Year", "Ok");
                }
                else if (StartDate < DateTime.Today)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Policy start date cannot be earlier than current date", "Ok");
                }
                else if (string.IsNullOrEmpty(SelectedBranch))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select agent branch", "Ok");
                }
               
                else
                {
                    var makes = SelectedVehicleMake;
                    MotorMake = MyVehicleMakes.Result.MakeList.Where(x => x.Name == makes).FirstOrDefault();
                    var model = SelectedVehicleModel;
                    MotorModel = MyVehicleModels.Result.ModelList.Where(x => x.Name == model).FirstOrDefault();
                    Branch = MyBranches.Where(branch => branch.BranchName == SelectedBranch).FirstOrDefault().BranchCode;
                    FileLabel = "Document";
                    var navigationParameter = new NavigationParameters();
                    navigationParameter.Add("FirstName", FirstName);
                    navigationParameter.Add("OtherName", OtherName);
                    navigationParameter.Add("LastName", LastName);
                    navigationParameter.Add("Gender", Gender);
                    navigationParameter.Add("PhoneNumber", PhoneNumber);
                    navigationParameter.Add("Email", Email);
                    navigationParameter.Add("Address", Address);
                    navigationParameter.Add("State", State);
                    navigationParameter.Add("RegistrationNumber", RegistrationNumber);
                    navigationParameter.Add("EngineNumber", EngineNumber);
                    navigationParameter.Add("ChassisNumber", ChassisNumber);
                    navigationParameter.Add("SelectedVehicleModel", SelectedVehicleModel);
                    navigationParameter.Add("SelectedVehicleMake", SelectedVehicleMake);
                    navigationParameter.Add("MotorMakes", MotorMake);
                    navigationParameter.Add("MotorModels", MotorModel);
                    navigationParameter.Add("SelectedYear", SelectedYear);
                    navigationParameter.Add("DateofBirth", DateofBirth);
                    navigationParameter.Add("StartDate", StartDate.ToString("dd/MM/yyyy"));
                   
                    navigationParameter.Add("ProspectId", Prospect.Id);
                    navigationParameter.Add("ProductPlanId", ProductPlan.Id);
                    navigationParameter.Add("AgentId", LoggedAgent.Id);
                    navigationParameter.Add("Branch", Branch);
                    navigationParameter.Add("PolicyDetails", PolicyDetailsResponse);

                    await _navigationService.NavigateAsync("AutoGoSumPage", navigationParameter);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }
    }
}
