﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AxaSolLite.ViewModels
{
    public class EmarketingPageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly ITitlesRepository _titlesRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly IEmarketingStatusRepository _emarketingStatusRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        private List<string> _myPolicyType = new List<string>();
        private int _numberMessage;
        private string _selectedPolicyType;
        private byte[] _profilePicture;
        private int _gender;
        private bool _isBusy;
        private bool _isVisible;
        private string _fullname;
        private IList<EmarketingStatus> _status;

        public List<string> MyPolicyType
        {
            get { return _myPolicyType; }
            set { SetProperty(ref _myPolicyType, value); }
        }
        public int NumberMessage
        {
            get { return _numberMessage; }
            set { SetProperty(ref _numberMessage, value); }
        }
        public string SelectedPolicyType
        {
            get { return _selectedPolicyType; }
            set { SetProperty(ref _selectedPolicyType, value); }
        }
        public byte[] ProfilePicture
        {
            get { return _profilePicture; }
            set { SetProperty(ref _profilePicture, value); }
        }
        public int Gender
        {
            get { return _gender; }
            set { SetProperty(ref _gender, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public bool IsVisible
        {
            get { return _isVisible; }
            set { SetProperty(ref _isVisible, value); }
        }
        public string FullName
        {
            get { return _fullname; }
            set { SetProperty(ref _fullname, value); }
        }
        public IList<EmarketingStatus> Status
        {
            get { return _status; }
            set { SetProperty(ref _status, value); }
        }
        public Agent LoggedAgent { get; set; }
        public Prospect SelectedProspect { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }

        private DelegateCommand _sendMailCommand;
        public DelegateCommand SendMailCommand => _sendMailCommand ?? (_sendMailCommand = new DelegateCommand(ExecuteSendMailCommand));


        public EmarketingPageViewModel(IPageDialogService pageDialogService, INavigationService navigationService, IProspectRepository prospectRepository,
            IAgentRepository agentRepository, Logical logical, ITitlesRepository titlesRepository, IProductPlansRepository productPlansRepository, IEmarketingStatusRepository emarketingStatusRepository,
            EncryptUtils encryptUtils)
        {
            _pageDialogService = pageDialogService;
            _navigationService = navigationService;
            _prospectRepository = prospectRepository;
            _agentRepository = agentRepository;
            _titlesRepository = titlesRepository;
            _productPlansRepository = productPlansRepository;
            _emarketingStatusRepository = emarketingStatusRepository;
            _logical = logical;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }
        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    Guid prospectId;
                    Guid.TryParse(parameters["ProspectId"].ToString(), out prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                    //SelectedProspect = await _prospectRepository.GetById(prospectId);
                    Status = await _emarketingStatusRepository.GetEmarketingStatusByProductPlanId(prospectId);
                }

                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }

                NumberMessage = Status.Count;

                InitializeDefaultValues();
            }
            catch (Exception ex)
            {

            }

        }
        private  void InitializeDefaultValues()
        {

            try
            {
                IsBusy = false;

                //NumberMessage = 2;
                FullName = SelectedProspect.FullName;
                Gender = SelectedProspect.Gender;
                MyPolicyType.Add("Auto Go");
                MyPolicyType.Add("Auto Classic");
                MyPolicyType.Add("Auto Plus");
                MyPolicyType.Add("General Protection");
                MyPolicyType.Add("Student Protection");
                MyPolicyType.Add("Pilgrimage Protection");
                MyPolicyType.Add("Ambitions");
                MyPolicyType.Add("Bonus Life");
                MyPolicyType.Add("CashBack Term Life");
                MyPolicyType.Add("Education Plan Plus");
                MyPolicyType.Add("Instant Plan");
                MyPolicyType.Add("Life Savings");
                MyPolicyType.Add("Bronze");
                MyPolicyType.Add("Easy Care");
                MyPolicyType.Add("Easy Care (6 months)");
                MyPolicyType.Add("Gold");
                MyPolicyType.Add("Platinum");
                MyPolicyType.Add("Platinum Plus");
                MyPolicyType.Add("Silver");

                MyPolicyType = MyPolicyType.ToList();

            }
            catch (Exception ex)
            {

            }
        }
        private async void ExecuteSendMailCommand()
        {
            IsBusy = true;

            try
            {
                if (SelectedPolicyType == null)
                {
                    await _pageDialogService.DisplayAlertAsync("Input required field ", "Please select a product", "Ok");
                }
                else
                {
                    EmarketingRequest req = new EmarketingRequest();
                    req.ProspectName = SelectedProspect.FullName;
                    req.EmailAddress = SelectedProspect.Email;
                    req.AgentName = LoggedAgent.FullName;
                    req.AgentEmail = LoggedAgent.EmailAddress;
                    //req.AgentEmail = "raphael.ariguzor@axamansard.com";
                    req.AgentPhoneNumber = LoggedAgent.MobileNo;
                    req.DateCreated = SelectedProspect.DateCreated.ToString("dd-MM-yyyy");
                    req.ProductName = SelectedPolicyType;

                    var sent = await _logical.SendEMarketingMail(req);
                    if (sent)
                    {
                        await _pageDialogService.DisplayAlertAsync("Mail Sent", "Follow up mail has been sent", "Ok");
                        var res = new EmarketingStatus
                        {
                            Id = Guid.NewGuid(),
                            Date = DateTime.Now.ToString("dd-MM-yyyy"),
                            Product = SelectedPolicyType,
                            IsSent = true,
                            ProspectId = SelectedProspect.Id
                        };

                        var y = await _emarketingStatusRepository.SaveEmarketingStatus(res);

                        Status = await _emarketingStatusRepository.GetEmarketingStatusByProductPlanId(SelectedProspect.Id);
                        NumberMessage = Status.Count;
                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Mail Not Sent", "Try Again", "Ok");
                    }
                }
                IsBusy = false;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                await _pageDialogService.DisplayAlertAsync("Mail Not Sent", "Try Again", "Ok");
                IsBusy = false;
            }
        }
    }
}
