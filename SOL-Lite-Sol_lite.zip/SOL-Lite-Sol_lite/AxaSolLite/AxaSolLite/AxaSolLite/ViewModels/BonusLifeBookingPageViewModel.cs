﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace AxaSolLite.ViewModels
{
	public class BonusLifeBookingPageViewModel : BindableBase, INavigationAware
	{
        private const string AccountNumberRegex = @"^[0-9]+$";

        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly IBranchesRepository _branchesRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        private bool _isBusy;
        private string _agentName;
        private string _sbuName;
        private string _selectedDSA;
        private List<string> _myDSAs;
        private bool _isExternalAgent;
        private Prospect _selectedProspect;
        private Agent _loggedAgent;
        private string _title;
        private List<string> _premiumList;
        private string _paymentFrequency;
        private double _sumAssured;
        private int _paymentTerm;
        private DateTime _policyStartDate;
        private string _premium;
        private string _age;
        private int _ageAtNextBirthday;
        private string _customerNumber;
        private double _totalPremium;
        private List<DSAUnderPSS> _dSAs;
        private DSAUnderPSS _dSA;
        private List<string> _branchList;
        private string _selectedbranch;
        private SyncDataSample _branches;
        private Branches _branch;
        private int _branchCode;
        private List<Branches> _branchToSave = new List<Branches>();
        private string _agentCode;
        private string _emailAddress;
        private string _sbuCode;
        private string _initiationDate;
        private List<int>_paymentTerms = new List<int>();
        private int _ageAtEndOfPolicy;
        private string _selectedPaymentTerm;
        private bool _isPremium;
        private double _contribution;
        private double _calculatedPremium;
        private double _annualPremium;
        private string _riderCode;
        private Guid _prospectId;
        private string _accountNumber;
        private List<string> _bankList = new List<string>();
        private string _bankName;
        private bool _isSinglePayment;

        public bool IsSinglePayment
        {
            get { return _isSinglePayment; }
            set { SetProperty(ref _isSinglePayment, value); }
        }
        public string BankName
        {
            get { return _bankName; }
            set { SetProperty(ref _bankName, value); }
        }
        public List<string> BankList
        {
            get { return _bankList; }
            set { SetProperty(ref _bankList, value); }
        }
        public string AccountNumber
        {
            get { return _accountNumber; }
            set { SetProperty(ref _accountNumber, value); }
        }
        public double CalcuatedPremium
        {
            get { return _calculatedPremium; }
            set { SetProperty(ref _calculatedPremium, value); }
        }
        public double AnnualPremium
        {
            get { return _annualPremium; }
            set { SetProperty(ref _annualPremium, value); }
        }
        public double TotalPremium
        {
            get { return _totalPremium; }
            set { SetProperty(ref _totalPremium, value); }
        }
        public double Contribution
        {
            get { return _contribution; }
            set { SetProperty(ref _contribution, value); }
        }
        public List<Branches> BranchToSave
        {
            get { return _branchToSave; }
            set { SetProperty(ref _branchToSave, value); }
        }
        public bool IsPremium
        {
            get { return _isPremium; }
            set { SetProperty(ref _isPremium, value); }
        }
        public string SelectedPaymentTerm
        {
            get { return _selectedPaymentTerm; }
            set { SetProperty(ref _selectedPaymentTerm, value); }
        }
        public int AgeAtEndOfPolicy
        {
            get { return _ageAtEndOfPolicy; }
            set { SetProperty(ref _ageAtEndOfPolicy, value); }
        }
        public List<int> PaymentTerms
        {
            get { return _paymentTerms; }
            set { SetProperty(ref _paymentTerms, value); }
        }
        public string InitiationDate
        {
            get { return _initiationDate; }
            set { SetProperty(ref _initiationDate, value); }
        }
        public string SbuCode
        {
            get { return _sbuCode; }
            set { SetProperty(ref _sbuCode, value); }
        }
        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }
        public string AgentCode
        {
            get { return _agentCode; }
            set { SetProperty(ref _agentCode, value); }
        }
        public int BranchCode
        {
            get { return _branchCode; }
            set { SetProperty(ref _branchCode, value); }
        }
        public SyncDataSample Branches
        {
            get { return _branches; }
            set { SetProperty(ref _branches, value); }
        }
        public DSAUnderPSS DSA
        {
            get { return _dSA; }
            set { SetProperty(ref _dSA, value); }
        }
        public List<DSAUnderPSS> DSAs
        {
            get { return _dSAs; }
            set { SetProperty(ref _dSAs, value); }
        }
        public Branches Branch
        {
            get { return _branch; }
            set { SetProperty(ref _branch, value); }
        }
        public List<string> BranchList
        {
            get { return _branchList; }
            set { SetProperty(ref _branchList, value); }
        }
        public string SelectedBranch
        {
            get { return _selectedbranch; }
            set { SetProperty(ref _selectedbranch, value); }
        }
        public string CustomerNumber
        {
            get { return _customerNumber; }
            set { SetProperty(ref _customerNumber, value); }
        }
        public int AgeAtNextBirthday
        {
            get { return _ageAtNextBirthday; }
            set { SetProperty(ref _ageAtNextBirthday, value); }
        }
        public string Age
        {
            get { return _age; }
            set { SetProperty(ref _age, value); }
        }
        public string Premium
        {
            get { return _premium; }
            set { SetProperty(ref _premium, value); }
        }
        public DateTime PolicyStartDate
        {
            get { return _policyStartDate; }
            set { SetProperty(ref _policyStartDate, value); }
        }
        public int PaymentTerm
        {
            get { return _paymentTerm; }
            set { SetProperty(ref _paymentTerm, value); }
        }
        public double SumAssured
        {
            get { return _sumAssured; }
            set { SetProperty(ref _sumAssured, value); }
        }
        public string PaymentFrequency
        {
            get { return _paymentFrequency; }
            set { SetProperty(ref _paymentFrequency, value); }
        }
        public List<string> PremiumList
        {
            get { return _premiumList; }
            set { SetProperty(ref _premiumList, value); }
        }
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public Agent LoggedAgent
        {
            get { return _loggedAgent; }
            set { SetProperty(ref _loggedAgent, value); }
        }
        public Prospect SelectedProspect
        {
            get { return _selectedProspect; }
            set { SetProperty(ref _selectedProspect, value); }
        }
        public bool IsExternalAgent
        {
            get { return _isExternalAgent; }
            set { SetProperty(ref _isExternalAgent, value); }
        }
        public List<string> MyDSAs
        {
            get { return _myDSAs; }
            set { SetProperty(ref _myDSAs, value); }
        }
        public string SelectedDSA
        {
            get { return _selectedDSA; }
            set { SetProperty(ref _selectedDSA, value); }
        }
        public string SbuName
        {
            get { return _sbuName; }
            set { SetProperty(ref _sbuName, value); }
        }
        public string AgentName
        {
            get { return _agentName; }
            set { SetProperty(ref _agentName, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public string RiderCode
        {
            get { return _riderCode; }
            set { SetProperty(ref _riderCode, value); }
        }
        public ProductPlan ProductPlan { get; set; }
        public BookOnline BookOnline { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }

        private DelegateCommand _changePaymentCommand;
        private DelegateCommand _fetchCommand;
        private DelegateCommand _resetCommand;
        private DelegateCommand _proceedCommand;
        public DelegateCommand ChangePaymentCommand => _changePaymentCommand ?? (_changePaymentCommand = new DelegateCommand(ExecuteChangePaymentCommand));
        public DelegateCommand FetchCommand => _fetchCommand ?? (_fetchCommand = new DelegateCommand(ExecuteFetchCommand));
        public DelegateCommand ResetCommand => _resetCommand ?? (_resetCommand = new DelegateCommand(ExecuteResetCommand));
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProceed));

        public BonusLifeBookingPageViewModel(INavigationService navigationService, IPageDialogService pageDialogService, IProspectRepository prospectRepository,
            IProductPlansRepository productPlansRepository, IAgentRepository agentRepository, Logical logical, IBranchesRepository branchesRepository, EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _prospectRepository = prospectRepository;
            _agentRepository = agentRepository;
            _productPlansRepository = productPlansRepository;
            _branchesRepository = branchesRepository;
            _logical = logical;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;

            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    //Guid prospectId;
                    //if (Guid.TryParse(parameters["ProspectId"].ToString(), out prospectId))
                    //{
                    //    SelectedProspect = await _prospectRepository.GetById(prospectId);
                    //}
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }

                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }

                if (parameters.ContainsKey("ProductPlanId"))
                {
                    Guid _productPlanId;
                    if (Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId))
                    {
                        ProductPlan = await _productPlansRepository.GetProductPlanByProductPlanId(_productPlanId);
                    }
                }

                InitializeDefaultValues();
            }
            catch (Exception ex)
            {

            }
            IsBusy = false;
        }

        private async void InitializeDefaultValues()
        {
            try
            {
                List<BankDTO> MyBanks = await _logical.GetBankList();
                foreach (BankDTO item in MyBanks)
                {
                    string bankName = string.Empty;
                    bankName = item.NameField;
                    BankList.Add(bankName);
                }
                BankList = BankList.Where(x => x != "-- Select One--").ToList();

                Title = "Bonus Life Booking Page";
                AgentName = LoggedAgent.FullName;
                AgentCode = LoggedAgent.AgentCode;
                EmailAddress = LoggedAgent.EmailAddress;
                SbuName = LoggedAgent.SbuName;
                SbuCode = LoggedAgent.SBU;
                //PaymentFrequency = "Annual";
                //PaymentTerm = "1 year";
                PolicyStartDate = DateTime.Today;
                InitiationDate = DateTime.Today.ToString("MM-dd-yyyy");
                Age = SelectedProspect.Age.ToString();
                AgeAtNextBirthday = (SelectedProspect.Age + 1);
                AgeAtEndOfPolicy = AgeAtNextBirthday + 99;
                CustomerNumber = SelectedProspect.CustomerNumber;
                var Branches = await _branchesRepository.GetBranches();
                BranchList = Branches.Select(x => x.Branch).ToList();
                BranchList = BranchList.Where(x => x != "BRANCHES").ToList();

                List<int> Numbers = new List<int>();
                for (int i = 5; i < 31; i++)
                {
                    Numbers.Add(i);
                }
                PaymentTerms = Numbers;

                if (!LoggedAgent.IsAdvisor && !LoggedAgent.IsTeamManager)
                {
                    IsExternalAgent = false;

                    DSAs = await _logical.GetDSAsUnderPss(LoggedAgent.AgentCode);

                    if (DSAs.Count > 0 && DSAs.First().PSSCode != null)
                    {
                        MyDSAs = DSAs.Select(x => x.FullName).ToList();
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        private void ExecuteChangePaymentCommand()
        {
            try
            {

                if (PaymentFrequency.Contains("Single"))
                {
                    IsSinglePayment = true;
                }
                else
                {
                    IsSinglePayment = false;
                }
                //else if (PaymentFrequency.Contains("Monthly"))
                //{

                //}
                //else if (PaymentFrequency.Contains("Quarterly"))
                //{

                //}
                //else if (PaymentFrequency.Contains("Half yearly"))
                //{

                //}

                //PaymentFrequencyLabel = PaymentFrequency + "  " + "Premium";
                //TotalPremium = AnnualPremium * SelectedPaymentTerm;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteFetchCommand()
        {
            IsBusy = true;
            try
            {
                if (string.IsNullOrEmpty(PaymentFrequency))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Please select a desired payment frequency", "Ok");
                }
                else if (SumAssured == 0 || (!IsSinglePayment && string.IsNullOrEmpty(SelectedPaymentTerm)) || Contribution == 0)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Kindly fill the fields provided", "Ok");
                }
                else
                {
                    BonusLifePremiumRequest bonusLifePremiumRequest = new BonusLifePremiumRequest
                    {
                        Age = Convert.ToString(AgeAtNextBirthday),
                        SumAssured = Convert.ToString(SumAssured),
                        PayPeriod = Convert.ToString(PaymentTerm),
                        InsPeriod = "99"
                    };

                    //if (PaymentFrequency.Contains("Single"))
                    //{
                    //    bonusLifePremiumRequest.RiderCode = "729";
                    //    PaymentTerm = 1;
                    //)

                    if (PaymentFrequency.Contains("Single"))
                    {
                        bonusLifePremiumRequest.RiderCode = "729";
                        PaymentTerm = 1;
                    }
                    else if (SelectedPaymentTerm.Contains("15"))
                    {
                        bonusLifePremiumRequest.RiderCode = "722";
                        PaymentTerm = 15;
                    }
                    else if (SelectedPaymentTerm.Contains("5"))
                    {
                        bonusLifePremiumRequest.RiderCode = "720";
                        PaymentTerm = 5;
                    }
                    else if (SelectedPaymentTerm.Contains("10"))
                    {
                        bonusLifePremiumRequest.RiderCode = "721";
                        PaymentTerm = 10;
                    }
                    RiderCode = bonusLifePremiumRequest.RiderCode;
                    var response = await _logical.CalculateBonusLifePremium(bonusLifePremiumRequest);


                    if (PaymentFrequency.Contains("Single"))
                    {
                        CalcuatedPremium = Convert.ToDouble(response.FirstOrDefault());
                        AnnualPremium = TotalPremium = CalcuatedPremium; //* PaymentTerm;
                        //TotalPremium = AnnualPremium * PaymentTerm;
                    }
                    else if (PaymentFrequency.Contains("Annual"))
                    {
                        CalcuatedPremium = Convert.ToDouble(response.FirstOrDefault());
                        AnnualPremium = CalcuatedPremium;
                        TotalPremium = AnnualPremium * PaymentTerm;
                    }
                    else if (PaymentFrequency.Contains("Monthly"))
                    {
                        CalcuatedPremium = Convert.ToDouble(response.FirstOrDefault()) * 0.09;
                        AnnualPremium = CalcuatedPremium * 12;
                        TotalPremium = AnnualPremium * PaymentTerm;
                    }
                    else if (PaymentFrequency.Contains("Quarterly"))
                    {
                        CalcuatedPremium = Convert.ToDouble(response.FirstOrDefault()) * 0.266;
                        AnnualPremium = CalcuatedPremium * 4;
                        TotalPremium = AnnualPremium * PaymentTerm;
                    }
                    else if (PaymentFrequency.Contains("Half yearly"))
                    {
                        CalcuatedPremium = Convert.ToDouble(response.FirstOrDefault()) * 0.525;
                        AnnualPremium = CalcuatedPremium * 2;
                        TotalPremium = AnnualPremium * PaymentTerm;
                    }
                    if(CalcuatedPremium > 0)
                    {
                        if (CalcuatedPremium > Contribution)
                        {
                            await _pageDialogService.DisplayAlertAsync("Error", "Kindly reset the values", "Ok");
                            IsPremium = false;
                        }
                        else
                        {
                            IsPremium = true;
                        }
                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "Unable to fetch value. Try resetting selected values and payment plan", "Ok");
                        IsPremium = false;
                    }
                }                
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                IsBusy = false;
                IsPremium = false;
                await _pageDialogService.DisplayAlertAsync("Error", "Error calculating premium. Please try again", "Ok");
            }
            IsBusy = false;
        }

        private void ExecuteResetCommand()
        {
            try
            {
                IsBusy = false;
                IsPremium = false;
                Contribution = 0;
                CalcuatedPremium = 0;
                SumAssured = 0;
                SelectedPaymentTerm = string.Empty;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteProceed()
        {
            var len = 0;
            IsBusy = true;
            try
            {
                if (string.IsNullOrEmpty(SelectedBranch))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Please select agent branch", "Ok");
                }
                else if (SumAssured < 5000000 || SumAssured > 24000000)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Minimum value = 5 million naira" + "\n\n" + "Maximum value = 24 milion naira", "Ok");
                }
                else if (string.IsNullOrEmpty(BankName))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a bank", "Ok");
                }
                else if (string.IsNullOrEmpty(AccountNumber))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Kindly enter bank account number", "Ok");
                }
                else if (AccountNumber.Length != 10)
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Account number must be 10 digits", "Ok");
                }
                else if (!Regex.IsMatch(AccountNumber, AccountNumberRegex))
                {
                    await _pageDialogService.DisplayAlertAsync("Error", "Account number must be in a correct format", "Ok");
                }
                else
                {
                    var v = await _branchesRepository.GetBranchCodeByBranch(SelectedBranch);
                    if (v != null)
                    {
                        BranchCode = v.BranchCode;
                    }
                    if (!(string.IsNullOrEmpty(SelectedDSA)))
                    {
                        DSA = DSAs.Where(x => x.FullName == SelectedDSA).FirstOrDefault();
                    }

                    if (PaymentFrequency.Contains("Single"))
                    {
                        PaymentTerm = 1;
                    }
                    else if (SelectedPaymentTerm.Contains("15"))
                    {
                        PaymentTerm = 15;
                    }
                    else if (SelectedPaymentTerm.Contains("5"))
                    {
                        PaymentTerm = 5;
                    }
                    else if (SelectedPaymentTerm.Contains("10"))
                    {
                        PaymentTerm = 10;
                    }                  
                    BookOnline = new BookOnline
                    {
                        Id = Guid.NewGuid(),
                        ProductPlanId = ProductPlan.Id,
                        AgentName = LoggedAgent.FullName,
                        AgeBeginPolicy = Convert.ToInt32(Age),
                        AgeEndPolicy = AgeAtEndOfPolicy,
                        AgentCode = LoggedAgent.AgentCode,
                        AnnualPremium = Convert.ToDecimal(AnnualPremium),
                        Assurer = LoggedAgent.FullName,
                        CustomerNo = SelectedProspect.CustomerNumber,
                        DateCreated = DateTime.Now,
                        EmailAddress = SelectedProspect.Email,
                        IntiationDate = DateTime.Now.ToString("MM/dd/yyyy"),
                        SumAssured = Convert.ToDecimal(SumAssured),
                        TransactionType = "New",
                        Amount = Convert.ToDecimal(Contribution),
                        SBU = LoggedAgent.SBU,
                        TotalPremium = Convert.ToDecimal(TotalPremium),
                        PolicyTerm = PaymentTerm,
                        Contribution = Convert.ToDecimal(Contribution),
                        LifeCoverValue = Convert.ToDecimal(SumAssured),
                        PolicyStartDate = DateTime.Today.ToString("MM/dd/yyyy"),
                        PolicyEndDate = PolicyStartDate.AddYears(99).ToString("MM/dd/yyyy"),//PolicyStartDate.AddYears(PaymentTerm).ToString("MM/dd/yyyy"),
                        PaymentFrequency = PaymentFrequency,
                        DSA = DSA?.FullName,
                        DSACode = DSA?.AgentCode,
                        BranchCode = BranchCode,
                        BankAccountNumber = AccountNumber,
                        BankName = BankName
                    };
                    BonusLifeProjectionValues req = new BonusLifeProjectionValues();
                    BonusLifeprojectionsheetRequest request = new BonusLifeprojectionsheetRequest();
                    req.dob = SelectedProspect.Birthdate.ToString("yyyy-MM-dd");
                    //req.dob = SelectedProspect.Birthdate.AddYears(1).ToString("dd/MM/yyyy");
                    req.paymentFreq = PaymentFrequency;
                    req.SumAssured = SumAssured.ToString();
                    req.contribution = Contribution.ToString();
                    req.customerName = SelectedProspect.FullName;
                    req.riderCode = RiderCode;
                    BonusLifeProjectionResponse[] res = new BonusLifeProjectionResponse[16];
                    res = await _logical.GenerateBonusLifeProjectionValues(req);

                    #region BonusLifeProjectionsheet
                    if(PaymentTerm == 1)
                    {
                        request.Contribution_1 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_2 = "0";
                        request.Contribution_3 = "0";
                        request.Contribution_4 = "0";
                        request.Contribution_5 = "0";
                        request.Contribution_6 = "0";
                        request.Contribution_7 = "0";
                        request.Contribution_8 = "0";
                        request.Contribution_9 = "0";
                        request.Contribution_10 = "0";
                        request.Contribution_11 = "0";
                        request.Contribution_12 = "0";
                        request.Contribution_13 = "0";
                        request.Contribution_14 = "0";
                        request.Contribution_15 = "0";
                    }
                    else if (PaymentTerm == 5)
                    {
                        request.Contribution_1 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_2 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_3 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_4 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_5 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_6 = "0";
                        request.Contribution_7 = "0";
                        request.Contribution_8 = "0";
                        request.Contribution_9 = "0";
                        request.Contribution_10 = "0";
                        request.Contribution_11 = "0";
                        request.Contribution_12 = "0";
                        request.Contribution_13 = "0";
                        request.Contribution_14 = "0";
                        request.Contribution_15 = "0";
                    }
                    else if(PaymentTerm == 10)
                    {
                        request.Contribution_1 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_2 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_3 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_4 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_5 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_6 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_7 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_8 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_9 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_10 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_11 = "0";
                        request.Contribution_12 = "0";
                        request.Contribution_13 = "0";
                        request.Contribution_14 = "0";
                        request.Contribution_15 = "0";
                    }
                    else if(PaymentTerm == 15)
                    {
                        request.Contribution_1 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_2 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_3 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_4 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_5 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_6 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_7 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_8 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_9 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_10 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_11 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_12 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_13 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_14 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Contribution_15 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                    }
                    if (res.Length >= 1 && res[0] != null)
                    {
                        request.Age_1 = res[0].AgeField;
                        //request.Contribution_1 =Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_1 = Convert.ToDouble(res[0].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_1 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_1 = Convert.ToDouble(res[0].SumAssuredField).ToString("N0");
                        request.Surrender_Value_1 = Convert.ToDouble(res[0].SurrenderValueField).ToString("N0");
                        request.Account_Value_1 = Convert.ToDouble(res[0].SavingsAccountValueField).ToString("N0");
                    }
                    if (res.Length >= 2 && res[1] != null)
                    {
                        request.Age_2 = res[1].AgeField;
                        //request.Contribution_2 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_2 = Convert.ToDouble(res[1].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_2 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_2 = Convert.ToDouble(res[1].SumAssuredField).ToString("N0");
                        request.Surrender_Value_2 = Convert.ToDouble(res[1].SurrenderValueField).ToString("N0");
                        request.Account_Value_2 = Convert.ToDouble(res[1].SavingsAccountValueField).ToString("N0");
                    }
                    if (res.Length >= 3 && res[2] != null)
                    {


                        request.Age_3 = res[2].AgeField;
                        //request.Contribution_3 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_3 = Convert.ToDouble(res[2].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_3 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_3 = Convert.ToDouble(res[2].SumAssuredField).ToString("N0");
                        request.Surrender_Value_3 = Convert.ToDouble(res[2].SurrenderValueField).ToString("N0");
                        request.Account_Value_3 = Convert.ToDouble(res[2].SavingsAccountValueField).ToString("N0");

                    }
                    if (res.Length >= 4 && res[3] != null)
                    {


                        request.Age_4 = res[3].AgeField;
                        //request.Contribution_4 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_4 = Convert.ToDouble(res[3].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_4 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_4 = Convert.ToDouble(res[3].SumAssuredField).ToString("N0");
                        request.Surrender_Value_4 = Convert.ToDouble(res[3].SurrenderValueField).ToString("N0");
                        request.Account_Value_4 = Convert.ToDouble(res[3].SavingsAccountValueField).ToString("N0");

                    }
                    if (res.Length >= 5 && res[4] != null)
                    {


                        request.Age_5 = res[4].AgeField;
                        //request.Contribution_5 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_5 = Convert.ToDouble(res[4].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_5 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_5 = Convert.ToDouble(res[4].SumAssuredField).ToString("N0");
                        request.Surrender_Value_5 = Convert.ToDouble(res[4].SurrenderValueField).ToString("N0");
                        request.Account_Value_5 = Convert.ToDouble(res[4].SavingsAccountValueField).ToString("N0");

                    }
                    if (res.Length >= 6 && res[5] != null)
                    {


                        request.Age_6 = res[5].AgeField;
                        //request.Contribution_6 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_6 = Convert.ToDouble(res[5].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_6 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_6 = Convert.ToDouble(res[5].SumAssuredField).ToString("N0");
                        request.Surrender_Value_6 = Convert.ToDouble(res[5].SurrenderValueField).ToString("N0");
                        request.Account_Value_6 = Convert.ToDouble(res[5].SavingsAccountValueField).ToString("N0");

                    }
                    if (res.Length >= 7 && res[6] != null)
                    {


                        request.Age_7 = res[6].AgeField;
                        //request.Contribution_7 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_7 = Convert.ToDouble(res[6].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_7 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_7 = Convert.ToDouble(res[6].SumAssuredField).ToString("N0");
                        request.Surrender_Value_7 = Convert.ToDouble(res[6].SurrenderValueField).ToString("N0");
                        request.Account_Value_7 = Convert.ToDouble(res[6].SavingsAccountValueField).ToString("N0");

                    }
                    if (res.Length >= 8 && res[7] != null)
                    {


                        request.Age_8 = res[7].AgeField;
                        //request.Contribution_8 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_8 = Convert.ToDouble(res[7].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_8 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_8 = Convert.ToDouble(res[7].SumAssuredField).ToString("N0");
                        request.Surrender_Value_8 = Convert.ToDouble(res[7].SurrenderValueField).ToString("N0");
                        request.Account_Value_8 = Convert.ToDouble(res[7].SavingsAccountValueField).ToString("N0");

                    }
                    if (res.Length >= 9 && res[8] != null)
                    {


                        request.Age_9 = res[8].AgeField;
                        //request.Contribution_9 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_9 = Convert.ToDouble(res[8].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_9 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_9 = Convert.ToDouble(res[8].SumAssuredField).ToString("N0");
                        request.Surrender_Value_9 = Convert.ToDouble(res[8].SurrenderValueField).ToString("N0");
                        request.Account_Value_9 = Convert.ToDouble(res[8].SavingsAccountValueField).ToString("N0");

                    }
                    if (res.Length >= 10 && res[9] != null)
                    {


                        request.Age_10 = res[9].AgeField;
                        //request.Contribution_10 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_10 = Convert.ToDouble(res[9].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_10 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_10 = Convert.ToDouble(res[9].SumAssuredField).ToString("N0");
                        request.Surrender_Value_10 = Convert.ToDouble(res[9].SurrenderValueField).ToString("N0");
                        request.Account_Value_10 = Convert.ToDouble(res[9].SavingsAccountValueField).ToString("N0");

                    }
                    if (res.Length >= 11 && res[10] != null)
                    {


                        request.Age_11 = res[10].AgeField;
                        //request.Contribution_11 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_11 = Convert.ToDouble(res[10].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_11 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_11 = Convert.ToDouble(res[10].SumAssuredField).ToString("N0");
                        request.Surrender_Value_11 = Convert.ToDouble(res[10].SurrenderValueField).ToString("N0");
                        request.Account_Value_11 = Convert.ToDouble(res[10].SavingsAccountValueField).ToString("N0");

                    }
                    if (res.Length >= 12 && res[11] != null)
                    {


                        request.Age_12 = res[11].AgeField;
                        //request.Contribution_12 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_12 = Convert.ToDouble(res[11].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_12 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_12 = Convert.ToDouble(res[11].SumAssuredField).ToString("N0");
                        request.Surrender_Value_12 = Convert.ToDouble(res[11].SurrenderValueField).ToString("N0");
                        request.Account_Value_12 = Convert.ToDouble(res[11].SavingsAccountValueField).ToString("N0");

                    }
                    if (res.Length >= 13 && res[12] != null)
                    {


                        request.Age_13 = res[12].AgeField;
                        //request.Contribution_13 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_13 = Convert.ToDouble(res[12].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_13 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_13 = Convert.ToDouble(res[12].SumAssuredField).ToString("N0");
                        request.Surrender_Value_13 = Convert.ToDouble(res[12].SurrenderValueField).ToString("N0");
                        request.Account_Value_13 = Convert.ToDouble(res[12].SavingsAccountValueField).ToString("N0");

                    }
                    if (res.Length >= 14 && res[13] != null)
                    {
                        request.Age_14 = res[13].AgeField;
                        //request.Contribution_14 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_14 = Convert.ToDouble(res[13].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_14 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_14 = Convert.ToDouble(res[13].SumAssuredField).ToString("N0");
                        request.Surrender_Value_14 = Convert.ToDouble(res[13].SurrenderValueField).ToString("N0");
                        request.Account_Value_14 = Convert.ToDouble(res[13].SavingsAccountValueField).ToString("N0");
                    }
                    if (res.Length >= 15 && res[14] != null)
                    {


                        request.Age_15 = res[14].AgeField;
                        //request.Contribution_15 = Convert.ToDouble(res[0].ContributionField).ToString("N0");
                        request.Investible_15 = Convert.ToDouble(res[14].SavingsInvestibleAmountField).ToString("N0");
                        request.Premium_15 = CalcuatedPremium.ToString("N0");
                        request.Sum_assured_15 = Convert.ToDouble(res[14].SumAssuredField).ToString("N0");
                        request.Surrender_Value_15 = Convert.ToDouble(res[14].SurrenderValueField).ToString("N0");
                        request.Account_Value_15 = Convert.ToDouble(res[14].SavingsAccountValueField).ToString("N0");

                    }
                    request.Agent_Name = LoggedAgent.FullName;
                    //request.AgentEmail = "rafaelchisom@gmail.com";
                    request.AgentEmail = LoggedAgent.EmailAddress;
                    request.Issue_Date = DateTime.Now.ToString("yyyy-MM-dd");
                    request.Customer_Name = SelectedProspect.FullName;
                    request.Phone_Number = SelectedProspect.MobileNumber;
                    //request.Email = "Oloyede.Akinmade@axamansard.com";
                    request.Email = SelectedProspect.Email;
                    request.Address = SelectedProspect.Address;
                    request.Total_Premium = TotalPremium.ToString("N0");
                    
                    request.Policy_Term = SelectedPaymentTerm;
                    request.Customer_Signature = SelectedProspect.FullName;

                    request.Premium_Frequency = PaymentFrequency;

                    #endregion

                    var response = await _logical.GenerateBonusLifeProjectionSheet(request);
                    if (response.IsSuccess == true)
                    {
                        BookOnline.ProjectionSheetDocument = response.DocumentString;
                        IsBusy = false;
                        await _pageDialogService.DisplayAlertAsync("Successful", "projection sheet sent", "Ok");
                    }
                    else
                    {
                        IsBusy = false;
                        await _pageDialogService.DisplayAlertAsync("Unsuccessful", "projection sheet not sent", "Ok");
                    }

                    var parameters = new NavigationParameters();
                    parameters.Add("ProspectId", SelectedProspect.Id);
                    parameters.Add("ProductPlanId", ProductPlan.Id);
                    parameters.Add("AgentId", LoggedAgent.Id);
                    parameters.Add("BookOnlineId", BookOnline);

                    await _navigationService.NavigateAsync("AddBeneficiaryPage", parameters);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                IsBusy = false;
                await _pageDialogService.DisplayAlertAsync("Unsuccessful", "projection sheet not sent", "Ok");
                var parameters = new NavigationParameters();
                parameters.Add("ProspectId", SelectedProspect.Id);
                parameters.Add("ProductPlanId", ProductPlan.Id);
                parameters.Add("AgentId", LoggedAgent.Id);
                parameters.Add("BookOnlineId", BookOnline);

                await _navigationService.NavigateAsync("AddBeneficiaryPage", parameters);
            }
            IsBusy = false;
        }
    }
}
