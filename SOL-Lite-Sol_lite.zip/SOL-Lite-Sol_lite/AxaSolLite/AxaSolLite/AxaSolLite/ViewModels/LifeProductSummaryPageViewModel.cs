﻿using AxaSolLite.Models;
using AxaSolLite.Models.CustomerOnboardingCreateCase;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AxaSolLite.ViewModels
{
	public class LifeProductSummaryPageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IPageDialogService _pageDialogService;
        private readonly IAgentRepository _agentRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly IBookOnlineRepository _bookOnlineRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        #region Fields
        private Prospect _selectedProspect;
        private List<AccountOpeningFormResponse> _generatedPdfs;
        private bool _isBusy;
        private bool _isVisible;
        private bool _isLifeSavings;
        private string _agentName;
        private string _agentCode;
        private string _sbu;
        private string _customerNo;
        private string _customerName;
        private string _intiationDate;
        private string _emailAddress;
        private string _policyClass;
        private string _policyTerm;
        private decimal _sumAssured;
        private int _ageBeginPolicy;
        private int _ageEndPolicy;
        private decimal _maxMaturityValue;
        private decimal _minMaturityValue;
        private decimal _expectedInterest;
        private decimal _expectedFuture;
        private string _paymentFrequency;
        private string _paymentOption;
        private decimal _annualPremium;
        private decimal _totalPremium;
        private decimal _contribution;
        private string _policyStartDate;
        private string _policyEndDate;
        private string _paymentDate;
        private decimal _lifeCoverValue;
        private string _sbuName;
        private List<BeneficiaryDetails> _beneficiaryList = new List<BeneficiaryDetails>();
        private decimal _bonusLifeContribution;
        private bool _isBonusLife;
        private string _ambitionReason;
        private bool _isAmbition;
        private bool _isExtendedCover;
        private bool _isPermanentDisability;
        private Guid _prospectId;
        #endregion

        #region Properties
        public bool IsExtendedCover
        {
            get { return _isExtendedCover; }
            set { SetProperty(ref _isExtendedCover, value); }
        }
        public bool IsPermanentDisability
        {
            get { return _isPermanentDisability; }
            set { SetProperty(ref _isPermanentDisability, value); }
        }
        public bool IsAmbition
        {
            get { return _isAmbition; }
            set { SetProperty(ref _isAmbition, value); }
        }
        public string AmbitionReason
        {
            get { return _ambitionReason; }
            set {SetProperty(ref _ambitionReason, value); }
        }
        public bool IsBonusLife
        {
            get { return _isBonusLife; }
            set { SetProperty(ref _isBonusLife, value); }
        }
        public decimal BonusLifeContribution
        {
            get { return _bonusLifeContribution; }
            set { SetProperty(ref _bonusLifeContribution, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public bool IsVisible
        {
            get { return _isVisible; }
            set { SetProperty(ref _isVisible, value); }
        }
        public bool IsLifeSavings
        {
            get { return _isLifeSavings; }
            set { SetProperty(ref _isLifeSavings, value); }
        }
        public string AgentName
        {
            get { return _agentName; }
            set { SetProperty(ref _agentName, value); }
        }

        public string AgentCode
        {
            get { return _agentCode; }
            set { SetProperty(ref _agentCode, value); }
        }

        public string Sbu
        {
            get { return _sbu; }
            set { SetProperty(ref _sbu, value); }
        }
        public decimal ExpectedInterest
        {
            get { return _expectedInterest; }
            set { SetProperty(ref _expectedInterest, value); }
        }
        public decimal ExpectedFuture
        {
            get { return _expectedFuture; }
            set { SetProperty(ref _expectedFuture, value); }
        }

        public string CustomerNo
        {
            get { return _customerNo; }
            set { SetProperty(ref _customerNo, value); }
        }
        public string CustomerName
        {
            get { return _customerName; }
            set { SetProperty(ref _customerName, value); }
        }

        public string IntiationDate
        {
            get { return _intiationDate; }
            set { SetProperty(ref _intiationDate, value); }
        }

        public string EmailAddress
        {
            get { return _emailAddress; }
            set { SetProperty(ref _emailAddress, value); }
        }

        public string PolicyClass
        {
            get { return _policyClass; }
            set { SetProperty(ref _policyClass, value); }
        }
        public string PolicyTerm
        {
            get { return _policyTerm; }
            set { SetProperty(ref _policyTerm, value); }
        }

        public decimal SumAssured
        {
            get { return _sumAssured; }
            set { SetProperty(ref _sumAssured, value); }
        }

        public int AgeBeginPolicy
        {
            get { return _ageBeginPolicy; }
            set { SetProperty(ref _ageBeginPolicy, value); }
        }

        public int AgeEndPolicy
        {
            get { return _ageEndPolicy; }
            set { SetProperty(ref _ageEndPolicy, value); }
        }

        public decimal MaxMaturityValue
        {
            get { return _maxMaturityValue; }
            set { SetProperty(ref _maxMaturityValue, value); }
        }

        public decimal MinMaturityValue
        {
            get { return _minMaturityValue; }
            set { SetProperty(ref _minMaturityValue, value); }
        }

        public string PaymentFrequency
        {
            get { return _paymentFrequency; }
            set { SetProperty(ref _paymentFrequency, value); }
        }
        public string PaymentOption
        {
            get { return _paymentOption; }
            set { SetProperty(ref _paymentOption, value); }
        }
        public decimal AnnualPremium
        {
            get { return _annualPremium; }
            set { SetProperty(ref _annualPremium, value); }
        }

        public decimal TotalPremium
        {
            get { return _totalPremium; }
            set { SetProperty(ref _totalPremium, value); }
        }

        public decimal Contribution
        {
            get { return _contribution; }
            set { SetProperty(ref _contribution, value); }
        }

        public string PolicyStartDate
        {
            get { return _policyStartDate; }
            set { SetProperty(ref _policyStartDate, value); }
        }

        public string PolicyEndDate
        {
            get { return _policyEndDate; }
            set { SetProperty(ref _policyEndDate, value); }
        }

        public string PaymentDate
        {
            get { return _paymentDate; }
            set { SetProperty(ref _paymentDate, value); }
        }
        public decimal LifeCoverValue
        {
            get { return _lifeCoverValue; }
            set { SetProperty(ref _lifeCoverValue, value); }
        }
        public string SbuName
        {
            get { return _sbuName; }
            set { SetProperty(ref _sbuName, value); }
        }
        public List<BeneficiaryDetails> BeneficiaryList
        {
            get { return _beneficiaryList; }
            set { SetProperty(ref _beneficiaryList, value); }
        }
        public Prospect SelectedProspect
        {
            get { return _selectedProspect; }
            set { SetProperty(ref _selectedProspect, value); }
        }
        public List<AccountOpeningFormResponse> GeneratedPdfs
        {
            get { return _generatedPdfs; }
            set { SetProperty(ref _generatedPdfs, value); }
        }
        public BookOnline BookOnline { get; set; }
        public FileVariable CapturedSignature { get; set; }
        private LifeDocumentPdfRequest _lifeDocumentPdfRequest = new LifeDocumentPdfRequest();
        public LifeDocumentPdfRequest LifeDocumentPdfRequest
        {
            get { return _lifeDocumentPdfRequest; }
            set { SetProperty(ref _lifeDocumentPdfRequest, value); }
        }
        public Agent LoggedAgent { get; set; }
        public ProductPlan ProductPlan { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }
        #endregion

        #region Commands
        private DelegateCommand _payNowCommand;
        private DelegateCommand _payLaterCommand;
        public DelegateCommand PayNowCommand => _payNowCommand ?? (_payNowCommand = new DelegateCommand(ExecutePayNowCommand));
        public DelegateCommand PayLaterCommand => _payLaterCommand ?? (_payLaterCommand = new DelegateCommand(ExecutePayLaterCommand));
        #endregion

        public LifeProductSummaryPageViewModel(INavigationService navigationService,
            IPageDialogService pageDialogService,
            IProspectRepository prospectRepository,
            IAgentRepository agentRepository, Logical logical,
            IProductPlansRepository productPlansRepository, IBookOnlineRepository bookOnlineRepository, EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _prospectRepository = prospectRepository;
            _agentRepository = agentRepository;
            _productPlansRepository = productPlansRepository;
            _bookOnlineRepository = bookOnlineRepository;
            _logical = logical;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    //Guid prospectId;
                    //if (Guid.TryParse(parameters["ProspectId"].ToString(), out prospectId))
                    //{
                    //    SelectedProspect = await _prospectRepository.GetById(prospectId);
                    //}
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }

                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }

                if (parameters.ContainsKey("BookOnline"))
                {
                    BookOnline = parameters.GetValue<BookOnline>("BookOnline");                    
                }

                if (parameters.ContainsKey("UploadFile"))
                {
                    CapturedSignature = parameters.GetValue<FileVariable>("UploadFile");
                }

                if (parameters.ContainsKey("ProductPlanId"))
                {
                    Guid _productPlanId;
                    if (Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId))
                    {
                        ProductPlan = await _productPlansRepository.GetProductPlanByProductPlanId(_productPlanId);
                    }
                }

                if (parameters.ContainsKey("LifePdfDocuments"))
                {
                    GeneratedPdfs = parameters.GetValue<List<AccountOpeningFormResponse>>("LifePdfDocuments");
                }

                InitializeDefaultValues();
            }
            catch (Exception ex)
            {

            }
            IsBusy = false;

        }

        private async void InitializeDefaultValues()
        {
            try
            {
                if (ProductPlan.PlanCategory.Contains("Edu") || ProductPlan.PlanCategory.Contains("Ambition"))
                {
                    IsVisible = true;
                }
                else if (ProductPlan.PlanCategory.Contains("Life Savings"))
                {
                    IsVisible = false;
                    IsLifeSavings = true;
                }
                else if (ProductPlan.PlanCategory.Contains("Bonus"))
                {
                    IsBonusLife = true;
                }
                if (ProductPlan.PlanCategory.Contains("Ambition"))
                {
                    IsAmbition = true;
                }               

                IsBusy = true;
                CustomerName = SelectedProspect.FullName;
                CustomerNo = SelectedProspect.CustomerNumber;
                AgentName = LoggedAgent.FullName;

                if (LoggedAgent.IsAdvisor)
                {
                    AgentCode = LoggedAgent.SubAgentCode;
                }
                else
                {
                    AgentCode = LoggedAgent.AgentCode;
                }
                
                Sbu = LoggedAgent.SBU;
                SbuName = LoggedAgent.SbuName;
                IntiationDate = BookOnline.IntiationDate;
                EmailAddress = LoggedAgent.EmailAddress;
                PolicyClass = ProductPlan.PlanCategory;
                if (BookOnline.PolicyTerm > 1)
                {
                    PolicyTerm = Convert.ToString(BookOnline.PolicyTerm) + " Years";
                }
                else
                {
                    PolicyTerm = Convert.ToString(BookOnline.PolicyTerm) + " Year";
                }
                SumAssured = BookOnline.SumAssured;
                AgeBeginPolicy = BookOnline.AgeBeginPolicy;
                AgeEndPolicy = BookOnline.AgeEndPolicy;
                MaxMaturityValue = Convert.ToDecimal(BookOnline.MaxMaturityValue);
                MinMaturityValue = Convert.ToDecimal(BookOnline.MinMaturityValue);
                PaymentFrequency = BookOnline.PaymentFrequency;
                AnnualPremium = BookOnline.AnnualPremium;
                TotalPremium = BookOnline.TotalPremium;
                Contribution = BookOnline.Amount;
                BonusLifeContribution = BookOnline.Contribution;
                PolicyStartDate = BookOnline.PolicyStartDate;
                PolicyEndDate = BookOnline.PolicyEndDate;
                LifeCoverValue = BookOnline.LifeCoverValue;
                AmbitionReason = BookOnline.AmbitionReason;
                BeneficiaryList = BookOnline.BeneficiaryList;
                ExpectedInterest = BookOnline.ExpectedInterest;
                ExpectedFuture = BookOnline.ExpectedFuture;
                IsExtendedCover = BookOnline.IsExtendedCover;
                IsPermanentDisability = BookOnline.IsPermanentDisability;

                ProductPlan.AmountPaid = BookOnline.Amount.ToString();
                int updated = await _productPlansRepository.UpdateAsync(ProductPlan);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecutePayNowCommand()
        {
            IsBusy = true;
            try
            {
                if (string.IsNullOrEmpty(PaymentOption))
                {
                    await _pageDialogService.DisplayAlertAsync("Kindly select a payment method", "", "Okay");
                    return;
                }
                if(PaymentOption.Contains("Pay with Paystack"))
                {
                    ProductPlan.IsAccountBalance = false;
                    int updated = await _productPlansRepository.UpdateAsync(ProductPlan);
                    var parameters = new NavigationParameters();
                    parameters.Add("ProspectId", SelectedProspect.Id);
                    parameters.Add("BookOnline", BookOnline);
                    parameters.Add("ProductPlanId", ProductPlan.Id);
                    parameters.Add("AgentId", LoggedAgent.Id);
                    parameters.Add("LifePdfDocuments", GeneratedPdfs);
                    parameters.Add("PolicyType", ProductPlan.PlanCategory);
                    parameters.Add("FNAProduct", ProductPlan.PlanCategory);

                    await _navigationService.NavigateAsync("PayNowPage", parameters);

                }
                else if (PaymentOption.Contains("Pay with QuoteID"))
                {
                    ProductPlan.IsAccountBalance = false;
                    int updated = await _productPlansRepository.UpdateAsync(ProductPlan);
                    var parameters = new NavigationParameters();
                    parameters.Add("ProspectId", SelectedProspect.Id);
                    parameters.Add("BookOnline", BookOnline);
                    parameters.Add("ProductPlanId", ProductPlan.Id);
                    parameters.Add("AgentId", LoggedAgent.Id);
                    parameters.Add("LifePdfDocuments", GeneratedPdfs);
                    parameters.Add("PolicyType", ProductPlan.PlanCategory);
                    parameters.Add("FNAProduct", ProductPlan.PlanCategory);

                    await _navigationService.NavigateAsync("PayLaterPage", parameters);

                }
                else if (PaymentOption.Contains("Pay with Customer Account Balance"))
                {   
                    var response = await _logical.GetCustomerAccountBalance(SelectedProspect.CustomerNumber);
                    //Balance accountBalanceResponse = new Balance()
                    //{
                    //    availBalance = 500000
                    //};
                    //response.balances = accountBalanceResponse;
                    await _pageDialogService.DisplayAlertAsync("Account Balance", "Customer account balance:" + response.balances.availBalance, "Ok");
                    if (Convert.ToDouble(ProductPlan.AmountPaid) <= response.balances.availBalance)
                    {
                        ProductPlan.IsAccountBalance = true;

                        int updated = await _productPlansRepository.UpdateAsync(ProductPlan);
                        SelectedProspect.LifeAimsBalance = response.balances.lifeBalance.ToString();
                        SelectedProspect.NonLifeAimsBalance = response.balances.nonLifeBalance.ToString();
                        SelectedProspect.TotalAimsBalance = response.balances.availBalance.ToString();

                        string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                        EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                        int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                        //int update = await _prospectRepository.UpdateAsync(SelectedProspect);
                        var parameters = new NavigationParameters();
                        parameters.Add("ProspectId", SelectedProspect.Id);
                        parameters.Add("BookOnline", BookOnline);
                        parameters.Add("ProductPlanId", ProductPlan.Id);
                        parameters.Add("AgentId", LoggedAgent.Id);
                        parameters.Add("LifePdfDocuments", GeneratedPdfs);
                        parameters.Add("PolicyType", ProductPlan.PlanCategory);
                        parameters.Add("FNAProduct", ProductPlan.PlanCategory);

                        await _navigationService.NavigateAsync("PayNowPage", parameters);
                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Insufficent Fund", "Kindly inform the customer to credit account or use a different payment option", "Ok");
                    }
                }
                else
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please select a payment option", "Ok");
                }



            }
            catch (Exception ex)
            {

            }
            IsBusy = false;
        }

        private async void ExecutePayLaterCommand() 
        {
            IsBusy = true;
            try
            {
                var parameters = new NavigationParameters();
                parameters.Add("ProspectId", SelectedProspect.Id);
                parameters.Add("BookOnline", BookOnline);
                parameters.Add("ProductPlanId", ProductPlan.Id);
                parameters.Add("AgentId", LoggedAgent.Id);
                parameters.Add("LifePdfDocuments", GeneratedPdfs);
                parameters.Add("PolicyType", ProductPlan.PlanCategory);
                parameters.Add("FNAProduct", ProductPlan.PlanCategory);

                await _navigationService.NavigateAsync("PayLaterPage", parameters);
                
            }
            catch (Exception ex)
            {

            }
            IsBusy = false;
        }
    }
}
