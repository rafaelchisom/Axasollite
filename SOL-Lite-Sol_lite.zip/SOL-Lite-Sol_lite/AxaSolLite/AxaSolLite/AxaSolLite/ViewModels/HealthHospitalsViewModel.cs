﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Xamarin.Forms;

namespace AxaSolLite.ViewModels
{
    public class HealthHospitalsViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IAgentRepository _agentRepository;
        private readonly IProspectRepository _prospectRepository;
        private readonly IPageDialogService _pageDialogService;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        private bool _isBusy;
        private Hospitals _hospitals;
        private List<string> _myHospitals = new List<string>();
        private string _selectedHospital;
        private Guid _prospectId;
        private List<ReturnedObject> _listOfHospitals = new List<ReturnedObject>();
        private bool isGroup;
        private string _groupMemberIdentifier;
        private ObservableCollection<ReturnedObject> _hospitalBindable = new ObservableCollection<ReturnedObject>();

        public ObservableCollection<ReturnedObject> HospitalBindable
        {
            get { return _hospitalBindable; }
            set { SetProperty(ref _hospitalBindable, value); }
        }
        public string GroupMemberIdentifier
        {
            get { return _groupMemberIdentifier; }
            set { SetProperty(ref _groupMemberIdentifier, value); }
        }
        public bool IsGroup
        {
            get { return isGroup; }
            set { SetProperty(ref isGroup, value); }
        }
        public List<ReturnedObject> ListOfHospitals
        {
            get { return _listOfHospitals; }
            set { SetProperty(ref _listOfHospitals, value); }
        }
        public string SelectedHospital
        {
            get { return _selectedHospital; }
            set { SetProperty(ref _selectedHospital, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public Hospitals Hospitals
        {
            get { return _hospitals; }
            set { SetProperty(ref _hospitals, value); }
        }
        public List<string> MyHospitals
        {
            get { return _myHospitals; }
            set { SetProperty(ref _myHospitals, value); }
        }
        public Prospect SelectedProspect { get; set; }
        public Agent LoggedAgent { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }
        public ProductPlan ProductPlan { get; set; }

        private DelegateCommand<string> _pickHospitalCommand;
        private ICommand _filterHospitalList;

        public DelegateCommand<string> PickHospitalCommand => _pickHospitalCommand ?? (_pickHospitalCommand = new DelegateCommand<string>(ExecutePickHospitalCommand));
        public ICommand FilterHospitalList => _filterHospitalList ?? (_filterHospitalList = new Command<string>(ExecuteFilterListCommand));

        public HealthHospitalsViewModel(INavigationService navigationService, IAgentRepository agentRepository, IProspectRepository prospectRepository,
            IPageDialogService pageDialogService, Logical logical, EncryptUtils encryptUtils, IProductPlansRepository productPlansRepository)
        {
            _navigationService = navigationService;
            _agentRepository = agentRepository;
            _prospectRepository = prospectRepository;
            _pageDialogService = pageDialogService;
            _logical = logical;
            _encryptUtils = encryptUtils;
            _productPlansRepository = productPlansRepository;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;
            try
            {
                HospitalBindable.Clear();
                ListOfHospitals.Clear();
                if (parameters.ContainsKey("ProspectId"))
                {
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }
                if (parameters.ContainsKey("AgentId"))
                {
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out Guid agentId))
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                }
                if (parameters.ContainsKey("ProductPlanId"))
                {
                    if (Guid.TryParse(parameters["ProductPlanId"].ToString(), out Guid _productPlanId))
                        ProductPlan = await _productPlansRepository.GetProductPlanByProductPlanId(_productPlanId);
                }
                if (parameters.ContainsKey("HospitalObject"))
                {
                    Hospitals = parameters.GetValue<Hospitals>("HospitalObject");
                    ListOfHospitals = Hospitals.ReturnedObject;
                    foreach(var item in ListOfHospitals)
                    {
                        item.Id = Guid.NewGuid();
                        HospitalBindable.Add(item);
                    }
                }
                if (parameters.ContainsKey("HospitalList"))
                    MyHospitals = parameters.GetValue<List<string>>("HospitalList");
                if (parameters.ContainsKey("IsGroup"))
                    IsGroup = parameters.GetValue<bool>("IsGroup");
                //if (parameters.ContainsKey("GroupMemberIdentifier"))
                //{
                //    GroupMemberIdentifier = parameters.GetValue<string>("GroupMemberIdentifier");
                //}
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            IsBusy = false;
        }

        private async void ExecutePickHospitalCommand(string IdString)
        {
            try
            {
                if (!string.IsNullOrEmpty(IdString))
                {
                    var hospitalGuid = new Guid(IdString);
                    SelectedHospital = ListOfHospitals.Where(x => x.Id == hospitalGuid).FirstOrDefault().HospitalDetails;
                    if (IsGroup)
                    {
                        if(SelectedHospitals.HospitalName == null)
                        {
                            List<string> hospitals = new List<string>
                            {
                                SelectedHospital
                            };
                            SelectedHospitals.HospitalName = hospitals;
                        }
                        else
                        {
                            //int count = SelectedHospitals.HospitalName.Count;
                            SelectedHospitals.HospitalName.Add(SelectedHospital);
                        }
                    }
                    else 
                        SelectedHospitals.SelectedHospitalName = SelectedHospital;

                    NavigationParameters parameters = new NavigationParameters
                    {
                        { "ProspectId", SelectedProspect.Id },
                        { "AgentId", LoggedAgent.Id },
                        { "ProductPlanId", ProductPlan.Id },
                        { "SelectedHospital", SelectedHospital },
                        { "IsGroup", IsGroup },
                        { "fromHospitalLists", true }
                    };

                    await _navigationService.GoBackAsync(parameters);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public void ExecuteFilterListCommand(string filterParams)
        {
            try
            {
                if (filterParams.Length >= 1)
                {
                    var suggestions = HospitalBindable.Where(c => c.HospitalDetails.ToLower().StartsWith(filterParams.ToLower()) /*|| c.LastName.ToLower().StartsWith(filterParams.ToLower())*/).ToList();
                    HospitalBindable.Clear();
                    foreach (var item in suggestions)
                        HospitalBindable.Add(item);
                }
                else if (filterParams.Length <= 1 && filterParams.Length == 0)
                {
                    var suggestions = HospitalBindable.Where(c => c.HospitalDetails.ToLower().StartsWith(filterParams.ToLower()) /*|| c.LastName.ToLower().StartsWith(filterParams.ToLower())*/).ToList();
                    var newSuggestions = ListOfHospitals.Where(e => e.HospitalDetails.ToLower().StartsWith(filterParams.ToLower()) /*|| e.LastName.ToLower().StartsWith(filterParams.ToLower())*/).ToList();

                    HospitalBindable.Clear();
                    foreach (var item in newSuggestions)
                    {
                        if (item != null)
                        {
                            HospitalBindable.Add(item);
                        }
                    }
                }
                else
                {
                    foreach (var item in ListOfHospitals)
                    {
                        HospitalBindable.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}
