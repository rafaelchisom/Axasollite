﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AxaSolLite.ViewModels
{
    public class PayLaterPageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IMotorProductRepository _motorProductRepository;
        private readonly IProductPlansRepository _productPlanRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly IPageDialogService _pageDialogService;
        private readonly ISaveLifeBookingDetails _saveLifeBookingDetails;
        private readonly ITravelProductRepository _travelProductRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        #region Fields
        private Prospect _prospect;
        private string _certificateNo;
        private Guid _productPlanId;
        private ProductPlan _productPlan;
        private MotorProduct _motorProduct;
        private string _fullName;
        private string _customerNumber;
        private string _quoteId;
        private string _premium;
        private string _policyType;
        private bool _isBusy;
        private bool _isOldQuoteId;
        private bool _isNewQuoteId;
        private List<ExtraTravellers> _extraTravellers = new List<ExtraTravellers>();
        private Guid _prospectId;
        #endregion

        #region Properties
        public Prospect Prospect
        {
            get { return _prospect = _prospect ?? (_prospect = new Prospect()); }
            set { SetProperty(ref _prospect, value); }
        }
        public ProductPlan ProductPlan
        {
            get { return _productPlan = _productPlan ?? (_productPlan = new ProductPlan()); }
            set { SetProperty(ref _productPlan, value); }
        }
        public string PolicyType
        {
            get { return _policyType; }
            set { SetProperty(ref _policyType, value); }
        }
        public string FullName
        {
            get { return _fullName; }
            set { SetProperty(ref _fullName, value); }
        }
        public string CustomerNumber
        {
            get { return _customerNumber; }
            set { SetProperty(ref _customerNumber, value); }
        }
        public string QuoteId
        {
            get { return _quoteId; }
            set { SetProperty(ref _quoteId, value); }
        }
        public string Premium
        {
            get { return _premium; }
            set { SetProperty(ref _premium, value); }
        }
        public bool isBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public bool IsOldQuoteId
        {
            get { return _isOldQuoteId; }
            set { SetProperty(ref _isOldQuoteId, value); }
        }
        public bool IsNewQuoteId
        {
            get { return _isNewQuoteId; }
            set { SetProperty(ref _isNewQuoteId, value); }
        }
        public string CertificateNo
        {
            get { return _certificateNo; }
            set { SetProperty(ref _certificateNo, value); }
        }
        private List<AccountOpeningFormResponse> _lifeDocumentPdfs = new List<AccountOpeningFormResponse>();
        public List<AccountOpeningFormResponse> LifeDocumentPdfs
        {
            get { return _lifeDocumentPdfs; }
            set { SetProperty(ref _lifeDocumentPdfs, value); }
        }
        public TravelProduct TravelProduct { get; set; }
        public List<ExtraTravellers> ExtraTravellers
        {
            get { return _extraTravellers; }
            set { SetProperty(ref _extraTravellers, value); }
        }
        public Agent LoggedAgent { get; set; }
        public MotorProduct MotorProduct { get; set; }
        public HealthProduct HealthProduct { get; set; }
        public BookOnline BookOnline { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }
        public PersonalAccidentProduct MyPersonalAccidentProduct { get; set; }

        private Logical logical = null;

        private DelegateCommand _proceedCommand;
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProceedCommand));
        #endregion

        public PayLaterPageViewModel(INavigationService navigationService,
             IProspectRepository prospectRepository,
             IMotorProductRepository motorProductRepository,
             IProductPlansRepository productPlanRepository,
             ISaveLifeBookingDetails saveLifeBookingDetails,
             IPageDialogService pageDialogService,
             ITravelProductRepository travelProductRepository,
             IAgentRepository agentRepository, EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _prospectRepository = prospectRepository;
            _productPlanRepository = productPlanRepository;
            _motorProductRepository = motorProductRepository;
            _pageDialogService = pageDialogService;
            _saveLifeBookingDetails = saveLifeBookingDetails;
            _agentRepository = agentRepository;
            _travelProductRepository = travelProductRepository;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }
        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            isBusy = true;

            try
            {
                logical = new Logical();
                if (parameters.ContainsKey("ProspectId"))
                {
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    Prospect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }
                if (parameters.ContainsKey("ProductPlanId"))
                {
                    Guid.TryParse(parameters["ProductPlanId"].ToString(), out _productPlanId);
                    ProductPlan = await _productPlanRepository.GetProductPlanByProductPlanId(_productPlanId);
                }
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }
                if (parameters.ContainsKey("MotorProductId"))
                {
                    Guid motorProductId;
                    if (Guid.TryParse(parameters["MotorProductId"].ToString(), out motorProductId))
                    {
                        MotorProduct = await _motorProductRepository.GetMotorProductById(motorProductId);
                        ProductPlan.BasicPremium = Convert.ToDecimal(MotorProduct.Premium);
                    }
                }
                if (parameters.ContainsKey("BookOnline"))
                {
                    BookOnline = parameters.GetValue<BookOnline>("BookOnline");
                    ProductPlan.BasicPremium = BookOnline.Amount;
                }
                if (parameters.ContainsKey("LifePdfDocuments"))
                {
                    LifeDocumentPdfs = parameters.GetValue<List<AccountOpeningFormResponse>>("LifePdfDocuments");
                }
                if (parameters.ContainsKey("TravelProductId"))
                {
                    if (Guid.TryParse(parameters["TravelProductId"].ToString(), out Guid travelProductId))
                    {
                        TravelProduct = await _travelProductRepository.GetTravelProductById(travelProductId);
                        ProductPlan.AmountPaid = Convert.ToString(TravelProduct.Premium);
                    }
                }
                if (parameters.ContainsKey("OtherTravellers"))
                {
                    ExtraTravellers = parameters.GetValue<List<ExtraTravellers>>("OtherTravellers");
                }
                if (parameters.ContainsKey("HealthProduct"))
                {
                    HealthProduct = parameters.GetValue<HealthProduct>("HealthProduct");
                    ProductPlan.AmountPaid =Convert.ToString(Convert.ToInt32(HealthProduct.Value) * 100);
                }
                if (parameters.ContainsKey("PersonalAccidentProduct"))
                {
                    MyPersonalAccidentProduct = parameters.GetValue<PersonalAccidentProduct>("PersonalAccidentProduct");
                    Premium = Convert.ToString(MyPersonalAccidentProduct.Premium);
                }

                FullName = Prospect.FullName;
                CustomerNumber = Prospect.CustomerNumber;
                Premium = Convert.ToString(ProductPlan.BasicPremium);
                PolicyType = ProductPlan.PlanCategory;
                Random random = new Random();
                CertificateNo = random.Next(00000001, 10000000).ToString();
                if (ProductPlan.QuoteId != null)
                {
                    ProductPlan.PaymentReference = ProductPlan.QuoteId;
                    QuoteId = ProductPlan.QuoteId;
                    ProductPlan.IsQuoteId = true;
                    ProductPlan.IsNotPolicyId = false;
                }
                else
                {
                    bool searchType = await _pageDialogService.DisplayAlertAsync("Notice!", "Pay with....", "Pre-generated Quote ID", "New Quote ID");
                    if (searchType)
                    {
                        IsOldQuoteId = true;
                        IsNewQuoteId = false;
                    }
                    else
                    {
                        IsNewQuoteId = true;
                        IsOldQuoteId = false;
                        QuoteIdMailRequest mailRequest = new QuoteIdMailRequest();
                        QuoteIdDto quoteIdRequest = new QuoteIdDto
                        {
                            AgentCode = LoggedAgent.AgentCode,
                            Amount = Convert.ToString(ProductPlan.BasicPremium),
                            IsMyAXASol = true,
                            Email = Prospect.Email,
                            Surname = Prospect.LastName,
                            OtherNames = Prospect.FirstName,
                            Phone = Prospect.MobileNumber,
                            PolicyType = "35-18-" + ProductPlan.PlanCategory//check if this is a right value
                        };
                        var quoteIdResponse = await logical.GetQuoteAsync(quoteIdRequest);
                        ProductPlan.QuoteId = quoteIdResponse.QuoteId;
                        QuoteId = ProductPlan.QuoteId;
                        SaveQuoteIdRequest quoteIdReq = new SaveQuoteIdRequest
                        {
                            QuoteId = ProductPlan.QuoteId
                        };
                        var res = await logical.SaveQuoteIdToDb(quoteIdReq);
                        if (ProductPlan.QuoteId != null)
                        {
                            ProductPlan.IsQuoteId = true;
                            ProductPlan.IsNotPolicyId = false;
                            mailRequest.CustomerName = Prospect.FullName;
                            mailRequest.CustomerNumber = Prospect.CustomerNumber;
                            mailRequest.EmailAddress = Prospect.Email;
                            //mailRequest.EmailAddress = "rafaelchisom@gmail.com";
                            mailRequest.PolicyName = ProductPlan.PlanCategory;
                            mailRequest.QuoteId = ProductPlan.QuoteId;
                            mailRequest.Sender = "myaxasolteam@axamansard.com";
                            mailRequest.CC = "";

                            var response = await logical.QuoteIdMailAsync(mailRequest);

                            if (response || !response) //change this later
                            {
                                await _pageDialogService.DisplayAlertAsync("Completed", "A Quote ID has been generated and sent to the customer's mail. Details to make payment are also in the sent mail", "Ok");
                            }
                            else
                            {
                                await _pageDialogService.DisplayAlertAsync("Oooops!", "Mail not sent. Please retry", "Ok");
                            }
                        }
                        else if (ProductPlan.QuoteId == null)
                        {
                            ProductPlan.IsQuoteId = false;
                            ProductPlan.IsNotPolicyId = true;
                            await _pageDialogService.DisplayAlertAsync("Oooops!", "Quote Id generation failed. Please retry", "Ok");
                        }
                        ProductPlan.PaymentReference = QuoteId;
                    }
                }
                int updated = await _productPlanRepository.UpdateAsync(ProductPlan);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            isBusy = false;


        }
        public string GetTransRef()
        {
            Guid guid = Guid.NewGuid();
            var TransRef = Convert.ToBase64String(guid.ToByteArray());
            return TransRef.Replace("=", "");
        }
        public async void ExecuteProceedCommand()
        {
            isBusy = true;
            try
            {
                if (string.IsNullOrEmpty(QuoteId))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please Enter a Quote ID", "Ok");
                }
                else
                {
                    if (IsOldQuoteId)
                    {
                        ProductPlan.PaymentReference = QuoteId;
                        ProductPlan.QuoteId = QuoteId;
                        ProductPlan.IsQuoteId = true;
                        ProductPlan.IsNotPolicyId = false;

                        bool answer = await _pageDialogService.DisplayAlertAsync("", "Proceed to book this policy using the Quote ID" + " " + QuoteId, "NO", "YES");

                        if(answer)
                        {
                            QuoteId = null;
                        }
                        else
                        {
                            await BookingCommand();
                        }
                    }
                    else
                    {
                        await BookingCommand();
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                await _pageDialogService.DisplayAlertAsync("Ooops!!!", "An error was encountered while attempting to upload policy booking details", "Cancel");
            }
            isBusy = false;
        }
        public async Task BookingCommand()
        {
            try
            {
                if (ProductPlan.PlanCategory == "Instant Plan" || ProductPlan.PlanCategory == "Education Plan Plus" || ProductPlan.PlanCategory == "Life Savings" || ProductPlan.PlanCategory == "Bonus Life" || ProductPlan.PlanCategory == "Ambitions")
                {
                    LifeBookingResponse lifeBookingResponse = new LifeBookingResponse();

                    BeneficiaryDetails[] MyArray = BookOnline.BeneficiaryList.ToArray();
                    AimsLifeBookingDto aimsLife = new AimsLifeBookingDto
                    {
                        AmountPaid = Convert.ToInt64(BookOnline.Amount),
                        RequestSource = "MYAXASOL",
                        TransRef = GetTransRef(),
                        PaymentSource = "Quote Id",
                        RequesterUsername = LoggedAgent.IsExternalAgent ? LoggedAgent.FullName : LoggedAgent.PssUsername,
                        CustomerDeliveryAddress = Prospect.Address,
                        XfrInfoAcmAnnSalary = 0,
                        XfrInfoAcmIdType = 0,
                        XfrInfoCustPrevPolicyFlag = 2,
                        XfrInfoDiscountRate = 0,
                        XfrInfoLcpPaymentPeriod = BookOnline.PolicyTerm,
                        XfrInfoLcpPaymentPeriod2 = BookOnline.PolicyTerm,
                        XfrInfoLcpPaymentPeriod3 = BookOnline.PolicyTerm,
                        XfrInfoLcpPaymentPeriod4 = BookOnline.PolicyTerm,
                        XfrInfoLcpRiderType2 = "",
                        XfrInfoLcpRiderType3 = "",
                        XfrInfoLcpRiderType4 = "",
                        //XfrInfoMstEndtSerial = "",
                        //AgentCode = LoggedAgent.IsAdvisor ? LoggedAgent.SubAgentCode : string.Empty,
                        XfrInfoMstAgentNo = LoggedAgent.AgentCode,
                        XfrInfoMstBranch = BookOnline.BranchCode,
                        XfrInfoMstOffice = 587,
                        XfrInfoMstCustNo = Convert.ToInt64(Prospect.CustomerNumber),
                        XfrInfoMstDocType = 0,
                        XfrInfoMstInsStDt = DateTime.Now,
                        XfrInfoMstLongTermFlag = 0,
                        XfrInfoMstPeriod = BookOnline.PolicyTerm,
                        XfrInfoMstRegDt = DateTime.Now,
                        XfrInfoCarBodyType = "",
                        XfrInfoIsapss = "",
                        XfrInfoHasDiscount = false,
                        XfrInfoAnyYesNmq = BookOnline.AnyYesNMQ,
                        XfrInfoIsreferralPolicy = "",
                        XfrInfoIspayNow = false,
                        XfrInfoLbenAddress = MyArray[0].Address,
                        XfrInfoLbenAddress3 = "",
                        XfrInfoLbenAddress4 = "",
                        XfrInfoLbenAddress5 = "",
                        XfrInfoLbenBirthDt = MyArray[0].DateOfBirth,
                        XfrInfoLbenCustRelation = MyArray[0].RelationshipCode,
                        XfrInfoLbenCustRelation3 = "",
                        XfrInfoLbenCustRelation4 = "",
                        XfrInfoLbenCustRelation5 = "",
                        XfrInfoLbenJobClass = 1,
                        XfrInfoLbenJobClass3 = "",
                        XfrInfoLbenJobClass4 = "",
                        XfrInfoLbenJobClass5 = "",
                        XfrInfoLbenMaritalStatus = MyArray[0].MaritalStatusCode,
                        XfrInfoLbenMaritalStatus3 = "",
                        XfrInfoLbenMaritalStatus4 = "",
                        XfrInfoLbenMaritalStatus5 = "",
                        XfrInfoLbenOccupation = MyArray[0].Occupation,
                        XfrInfoLbenMonthlySalary = 0,
                        XfrInfoLbenNationalNo = LoggedAgent.IsAdvisor ? LoggedAgent.SubAgentCode : string.Empty,
                        XfrInfoLbenOccupation3 = "",
                        XfrInfoLbenOccupation4 = "",
                        XfrInfoLbenOccupation5 = "",
                        XfrInfoLbenOtherName = MyArray[0].FirstName,
                        XfrInfoLbenOtherName3 = "",
                        XfrInfoLbenOtherName4 = "",
                        XfrInfoLbenOtherName5 = "",
                        XfrInfoLbenSumAssured = Convert.ToInt64(BookOnline.SumAssured),
                        XfrInfoLbenSurName = MyArray[0].LastName,
                        XfrInfoLbenSurName3 = "",
                        XfrInfoLbenSurName4 = "",
                        XfrInfoLbenSurName5 = "",
                        XfrInfoLbenTel = MyArray[0].PhoneNumber,
                        XfrInfoLbenTel3 = "",
                        XfrInfoLbenTel4 = "",
                        XfrInfoLbenTel5 = "",
                        XfrInfoLbenType1 = MyArray[0].TypeCode.ToString(),
                        Bentitle1 = MyArray[0].TitleCode,
                        XfrInfoLbenType3 = "",
                        XfrInfoLbenType4 = "",
                        XfrInfoLbenType5 = "",
                        XfrInfoLpmLoadedPrem = 0,
                        XfrInfoLinkedDocNo = 705,
                        XfrInfoLpmPeriodType = 0,
                        XfrInfoMstRenPolType = 0,
                        XfrInfoMstThrough = Convert.ToInt64(LoggedAgent.SBU),
                        XfrInfoMstTrnType = 2,
                        XfrInfoPayNowTransRef = ProductPlan.PaymentReference,
                        XfrInfoMstUwYear = DateTime.Now.Year,

                        XfrInfoNationamlNo = "",
                        XfrInfoPolicyKey = "",
                        XfrInfoQuoteNo = ProductPlan.QuoteId,
                        //XfrInfoQuoteNo = "8E4C6F94QS",
                        XfrInfoReferralCode = "",
                        XfrInfoScanDate = DateTime.Now,
                        XfrInfoScanSerial = 1036879,
                        XfrInfoUseCustomRate = false,
                        XfrInfoPeriodContrib = Convert.ToInt64(BookOnline.Contribution),
                        XFR_INFO_BOOK_FROM_BALANCE = false
                    
                        /* XFR_INFO_SOURCE_BUISNESS = 2*/
                    };

                    if (ProductPlan.PlanCategory == "Instant Plan")
                    {
                        aimsLife.XfrInfoMstPolType = 131;
                        aimsLife.XfrInfoLcpRiderType1 = 1;
                    }
                    else if (ProductPlan.PlanCategory == "Life Savings")
                    {
                        aimsLife.XfrInfoMstPolType = 476;
                        aimsLife.XfrInfoLcpRiderType1 = 1048;
                    }
                    else if (ProductPlan.PlanCategory == "Education Plan Plus")
                    {
                        aimsLife.XfrInfoMstPolType = 456;
                        aimsLife.XfrInfoLcpRiderType1 = 826;
                    }
                    else if (ProductPlan.PlanCategory == "Bonus Life")
                    {
                        aimsLife.XfrInfoMstPolType = 150;
                        if (BookOnline.PolicyTerm == 1)
                        {
                            aimsLife.XfrInfoLcpRiderType1 = 729;
                        }
                        else if (BookOnline.PolicyTerm == 5)
                        {
                            aimsLife.XfrInfoLcpRiderType1 = 720;
                        }
                        else if (BookOnline.PolicyTerm == 10)
                        {
                            aimsLife.XfrInfoLcpRiderType1 = 721;
                        }
                        else if (BookOnline.PolicyTerm == 15)
                        {
                            aimsLife.XfrInfoLcpRiderType1 = 722;
                        }
                    }
                    else if (ProductPlan.PlanCategory == "Ambitions")
                    {
                        aimsLife.XfrInfoMstPolType = 466;
                        aimsLife.XfrInfoLcpRiderType1 = 898;
                    }


                    if (MyArray.Count() > 1)
                    {
                        aimsLife.XfrInfoLbenAddress2 = MyArray[1].Address;
                        aimsLife.XfrInfoLbenCustRelation2 = MyArray[1].RelationshipCode;
                        aimsLife.XfrInfoLbenMaritalStatus2 = MyArray[1].MaritalStatusCode;
                        aimsLife.XfrInfoLbenBirthDt2 = MyArray[1].DateOfBirth;
                        aimsLife.XfrInfoLbenJobClass2 = 1;
                        aimsLife.XfrInfoLbenOccupation2 = MyArray[1].Occupation;
                        aimsLife.XfrInfoLbenOtherName2 = MyArray[1].FirstName;
                        aimsLife.XfrInfoLbenSurName2 = MyArray[1].LastName;
                        aimsLife.XfrInfoLbenTel2 = MyArray[1].PhoneNumber;
                        aimsLife.XfrInfoLbenType2 = MyArray[1].TypeCode;
                        aimsLife.Bentitle2 = MyArray[1].TitleCode;
                    }

                    AccountOpeningFormResponse[] DocumentsArray = LifeDocumentPdfs.ToArray();
                    aimsLife.LifeProposalForm = new LifeProposalForm
                    {
                        ContentType = "application/pdf",
                        Extension = "pdf",
                        FieldName = "Life Proposal",
                        FileName = DocumentsArray[0].DocumentPath,
                        FileContent = DocumentsArray[0].Document
                    };
                    aimsLife.NonMedQuestionaire = new LifeProposalForm
                    {
                        ContentType = "application/pdf",
                        Extension = "pdf",
                        FieldName = "Non Medical Questionaire",
                        FileName = DocumentsArray[1].DocumentPath,
                        FileContent = DocumentsArray[1].Document
                    };
                    if (BookOnline.PaymentFrequency == "Annual")
                    {
                        aimsLife.XfrInfoMstPayType = 4;
                    }
                    else if (BookOnline.PaymentFrequency == "Monthly")
                    {
                        aimsLife.XfrInfoMstPayType = 1;
                    }
                    else if (BookOnline.PaymentFrequency == "Quarterly")
                    {
                        aimsLife.XfrInfoMstPayType = 2;
                    }
                    else if (BookOnline.PaymentFrequency == "Half yearly")
                    {
                        aimsLife.XfrInfoMstPayType = 3;
                    }
                    else if (BookOnline.PaymentFrequency == "Single")
                    {
                        aimsLife.XfrInfoMstPayType = 5;
                    }

                    if (ProductPlan.PlanCategory == "Education Plan Plus")
                    {
                        EduPlanPdfCertRequest request = new EduPlanPdfCertRequest();
                        request.CertificateNo = CertificateNo;
                        request.PolicyId = lifeBookingResponse.PolicyID;
                        request.LifeAssured = Prospect.FullName;
                        request.DateOfBirth = Prospect.Birthdate;
                        request.AgeNextBirthday = Convert.ToString(BookOnline.AgeBeginPolicy);
                        request.SumAssured = string.Format("{0:n0}", BookOnline.SumAssured);
                        request.Premium = string.Format("{0:n0}", BookOnline.Amount);
                        request.StartDate = DateTime.Now; ;
                        request.PeriodOfCover = Convert.ToString(BookOnline.PolicyTerm) + " Years";
                        request.EndDate = (DateTime.Now.AddYears(Convert.ToInt16(BookOnline.PolicyTerm))).AddDays(-1);
                        request.PolicyTerm = Convert.ToString(BookOnline.PolicyTerm) + " Years";
                        request.PaymentFrequency = BookOnline.PaymentFrequency;
                        request.BeneficiaryFullName = MyArray[0].FullName;
                        request.IssueDate = DateTime.Now;
                        request.CustEmail = Prospect.Email;
                        request.CustName = Prospect.FullName;
                        request.RefCode = GetTransRef();
                        request.Product = ProductPlan.PlanCategory;
                        //request.AgentEmail = "raphael.ariguzor@axamansard.com";
                        request.AgentEmail = LoggedAgent.EmailAddress;
                        request.CustomerNo = Prospect.CustomerNumber;

                        SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                        {
                            ProductPlanId = ProductPlan.Id,
                            RequestData = JsonConvert.SerializeObject(aimsLife),
                            PaymentReference = ProductPlan.PaymentReference,
                            CertData = JsonConvert.SerializeObject(request)
                        };
                        int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);
                    }
                    else if (ProductPlan.PlanCategory == "Instant Plan")
                    {
                        InstantPlanPdfCertRequest request = new InstantPlanPdfCertRequest();
                        request.PolicyId = lifeBookingResponse.PolicyID;
                        request.LifeAssured = Prospect.FullName;
                        request.DateOfBirth = Prospect.Birthdate;
                        request.SumAssured = string.Format("{0:n0}", BookOnline.SumAssured);
                        request.Premium = string.Format("{0:n0}", BookOnline.Amount);
                        request.StartDate = DateTime.Now;
                        request.EndDate = (DateTime.Now.AddYears(1)).AddDays(-1);
                        request.BeneficiaryFullName = MyArray[0].FullName;
                        request.IssueDate = DateTime.Now;
                        request.CustEmail = Prospect.Email;
                        request.CustName = Prospect.FullName;
                        request.RefCode = GetTransRef();
                        request.Product = ProductPlan.PlanCategory;
                        //request.AgentEmail = "raphael.ariguzor@axamansard.com";
                        request.AgentEmail = LoggedAgent.EmailAddress;
                        request.CustomerNo = Prospect.CustomerNumber;

                        SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                        {
                            ProductPlanId = ProductPlan.Id,
                            RequestData = JsonConvert.SerializeObject(aimsLife),
                            PaymentReference = ProductPlan.PaymentReference,
                            CertData = JsonConvert.SerializeObject(request)

                        };
                        int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);
                    }
                    else if (ProductPlan.PlanCategory == "Life Savings")
                    {
                        LifeSavingPdfCertRequest request = new LifeSavingPdfCertRequest();

                        request.PolicyId = lifeBookingResponse.PolicyID;
                        request.LifeAssured = Prospect.FullName;
                        request.DateOfBirth = Prospect.Birthdate.ToString("dd-MM-yyyy");
                        request.AgeNextBirthday = Convert.ToString(BookOnline.AgeBeginPolicy);
                        request.SumAssured = string.Format("{0:n0}", BookOnline.SumAssured);
                        request.Premium = string.Format("{0:n0}", BookOnline.Amount);
                        request.StartDate = BookOnline.PolicyStartDate;
                        request.AnnualContribution = string.Format("{0:n0}", BookOnline.Amount);
                        request.EndDate = BookOnline.PolicyEndDate;
                        request.PaymentFrequency = BookOnline.PaymentFrequency;
                        request.BeneficiaryFullNameOne = MyArray[0].FullName;
                        request.BeneficiaryFullNameTwo = (MyArray.Count() > 1) ? MyArray[1].FullName : string.Empty;
                        request.BeneficiaryFullNameThree = string.Empty;
                        request.CertificateNo = CertificateNo;
                        request.IssueDate = DateTime.Now.ToString("dd-MM-yyyy");
                        request.CustEmail = Prospect.Email;
                        request.CustName = Prospect.FullName;
                        request.RefCode = GetTransRef();
                        request.Product = ProductPlan.PlanCategory;
                        //request.AgentEmail = "raphael.ariguzor@axamansard.com";
                        request.AgentEmail = LoggedAgent.EmailAddress;
                        request.CustomerNo = Prospect.CustomerNumber;
                        SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                        {
                            ProductPlanId = ProductPlan.Id,
                            RequestData = JsonConvert.SerializeObject(aimsLife),
                            PaymentReference = ProductPlan.PaymentReference,
                            CertData = JsonConvert.SerializeObject(request)

                        };
                        int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);

                    }
                    else if (ProductPlan.PlanCategory == "Bonus Life")
                    {
                        BonusLifeCertRequest bonusLifeCertRequest = new BonusLifeCertRequest
                        {
                            AgentEmail = LoggedAgent.EmailAddress,
                            EmailAddress = Prospect.Email,
                            CustomerName = Prospect.FullName,
                            CustomerNumber = Prospect.CustomerNumber,
                            AgeNextBirthday = BookOnline.AgeBeginPolicy.ToString(),
                            LifeAssured = Prospect.FullName,
                            SumAssured = BookOnline.SumAssured.ToString(),
                            CertificateNumber = CertificateNo,
                            StartDate = BookOnline.PolicyStartDate,
                            IssueDate = BookOnline.PolicyStartDate,
                            PaymentTerm = BookOnline.PolicyTerm.ToString(),
                            PolicyId = lifeBookingResponse.PolicyID, //Big check here o!!!!!!!!!!!!!!
                            DateOfBirth = Prospect.Birthdate.ToString("MM/dd/yyyy"),
                            ProductName = "Bonus Life",
                            Frequency = BookOnline.PaymentFrequency,
                            Premium = BookOnline.AnnualPremium.ToString(),
                            TransactionReference = GetTransRef(),
                            BeneficiaryOne = MyArray[0].FullName,
                            BeneficiaryTwo = (MyArray.Count() > 1) ? MyArray[1].FullName : string.Empty,
                            BeneficiaryThree = string.Empty,
                            FromAxaSol = true
                        };

                        SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                        {
                            ProductPlanId = ProductPlan.Id,
                            RequestData = JsonConvert.SerializeObject(aimsLife),
                            PaymentReference = ProductPlan.PaymentReference,
                            CertData = JsonConvert.SerializeObject(bonusLifeCertRequest)
                        };
                        int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);
                    }
                    else if (ProductPlan.PlanCategory == "Ambitions")
                    {
                        AmbitionsCertificateRequest ambitionsCertificate = new AmbitionsCertificateRequest
                        {
                            AgeNextBirthday = BookOnline.AgeBeginPolicy.ToString(),
                            LifeAssured = Prospect.FullName,
                            SumAssured = BookOnline.SumAssured.ToString("N2"),
                            CertificateNo = CertificateNo,
                            CustomerName = Prospect.FullName,
                            PolicyTerm = BookOnline.PolicyTerm.ToString(),
                            Premium = BookOnline.AnnualPremium.ToString("N2"),
                            PolicyId = lifeBookingResponse.PolicyID,
                            StartDate = BookOnline.PolicyStartDate,
                            EndDate = BookOnline.PolicyEndDate,
                            DateofBirth = Prospect.Birthdate.ToString("MM/dd/yyyy"),
                            Beneficiary = MyArray[0].FullName,
                            Beneficiary2 = (MyArray.Count() > 1) ? MyArray[1].FullName : string.Empty,
                            IssueDate = BookOnline.PolicyStartDate,
                            PeriodofCover = BookOnline.PolicyStartDate + " to " + BookOnline.PolicyEndDate,
                            AgentEmaiil = LoggedAgent.EmailAddress,
                            EmailAddress = Prospect.Email,
                            CustomerNumber = Prospect.CustomerNumber,
                            ProductName = "Ambitions",
                            TransactionReference = ProductPlan.PaymentReference
                        };

                        SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                        {
                            ProductPlanId = ProductPlan.Id,
                            RequestData = JsonConvert.SerializeObject(aimsLife),
                            PaymentReference = ProductPlan.PaymentReference,
                            CertData = JsonConvert.SerializeObject(ambitionsCertificate)
                        };
                        int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);
                    }
                    else if (ProductPlan.PlanCategory == "Life Plus")
                    {
                        LifePlusCertificateRequest request = new LifePlusCertificateRequest()
                        {
                            AgeNextBirthday = BookOnline.AgeBeginPolicy.ToString(),
                            LifeAssured = Prospect.FullName,
                            SumAssured = BookOnline.SumAssured.ToString("N2"),
                            CertificateNo = CertificateNo,
                            CustomerName = Prospect.FullName,
                            PolicyId = lifeBookingResponse.PolicyID,
                            StartDate = BookOnline.PolicyStartDate,
                            EndDate = BookOnline.PolicyEndDate,
                            DateofBirth = Prospect.Birthdate.ToString("MM/dd/yyyy"),
                            Beneficiary = MyArray[0].FullName,
                            Beneficiary2 = (MyArray.Count() > 1) ? MyArray[1].FullName : string.Empty,
                            IssueDate = BookOnline.PolicyStartDate,
                            AgentEmaiil = LoggedAgent.EmailAddress,
                            EmailAddress = Prospect.Email,
                            CustomerNumber = Prospect.CustomerNumber,
                            ProductName = "Life Plus",
                            TransactionReference = ProductPlan.PaymentReference,
                            PaymentFrequency = BookOnline.PaymentFrequency,
                            AnnualContribution = BookOnline.AnnualPremium.ToString("N2"),
                        };
                        SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                        {
                            ProductPlanId = ProductPlan.Id,
                            RequestData = JsonConvert.SerializeObject(aimsLife),
                            PaymentReference = ProductPlan.PaymentReference,
                            CertData = JsonConvert.SerializeObject(request)
                        };
                        int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);
                    }              
                }
                else
                {
                    SaveBookingDetails saveBookingDetails = new SaveBookingDetails
                    {
                        ProductPlanId = ProductPlan.Id,
                        PaymentReference = ProductPlan.PaymentReference
                    };
                    int saved = await _saveLifeBookingDetails.SaveAsync(saveBookingDetails);
                }

                int x = await _productPlanRepository.UpdateAsync(ProductPlan);
                if (x > 0)
                {

                    await _productPlanRepository.UpdateAsync(ProductPlan);
                    var navigationParameter = new NavigationParameters();
                    navigationParameter.Add("ProspectId", Prospect.Id);
                    navigationParameter.Add("ProductPlanId", ProductPlan.Id);
                    navigationParameter.Add("AgentId", LoggedAgent.Id);
                    navigationParameter.Add("BookOnline", BookOnline);


                    await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", navigationParameter, null, false);
                }
                else
                {
                    await _pageDialogService.DisplayAlertAsync("Ooops!!!", "An error was encountered while attempting to upload policy booking details", "Cancel");
                    var navigationParameter = new NavigationParameters();
                    navigationParameter.Add("ProspectId", Prospect.Id);
                    navigationParameter.Add("ProductPlanId", ProductPlan.Id);
                    navigationParameter.Add("AgentId", LoggedAgent.Id);
                    await _navigationService.GoBackAsync();
                }

            }
            catch(Exception ex)
            {

            }
        }
    }
}
