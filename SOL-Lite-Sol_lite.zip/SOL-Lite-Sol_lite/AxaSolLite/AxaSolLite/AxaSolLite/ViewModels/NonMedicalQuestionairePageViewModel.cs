﻿using AxaSolLite.Models;
using AxaSolLite.Models.CustomerOnboardingCreateCase;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Plugin.FilePicker;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AxaSolLite.ViewModels
{
    public class NonMedicalQuestionairePageViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IPageDialogService _pageDialogService;
        private readonly IAgentRepository _agentRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly IBookOnlineRepository _bookOnlineRepository;
        private readonly IMediaManager _deviceManager;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        private Prospect _selectedProspect;

        private string _questionOne;
        private string _questionTwo;
        private string _questionThree;
        private string _questionFour;
        private string _questionFive;
        private string _questionSix;
        private string _questionSeven;
        private string _questionEight;
        private string _questionNine;
        private string _questionTen;
        private string _questionEleven;
        private string _questionTwelve;
        private string _questionThirteen;
        private string _questionForteen;
        private string _questionFifteen;
        private string _questionSixteen;
        private string _questionSeventeen;

        private bool _isQuestionOne;
        private bool _isQuestionTwo;
        private bool _isQuestionThree;
        private bool _isFemale;
        private bool _isQuestionFive;
        private bool _isQuestionSix;
        private bool _isQuestionSeven;
        private bool _isQuestionEight;
        private bool _isQuestionNine;
        private bool _isQuestionTen;
        private bool _isQuestionEleven;
        private bool _isQuestionTwelve;
        private bool _isQuestionThirteen;
        private bool _isQuestionForteen;
        private bool _isQuestionFifteen;
        private bool _isQuestionSixteen;
        private bool _isQuestionSeventeen;
        //private bool _isNo;
        //private bool _isVisible;
        //private bool _isNoTwo;
        //private bool _isYesTwo;
        //private bool _isNoThree;
        //private bool _isYesThree;
        //private bool _isNoFour;
        //private bool _isYesFour;
        //private bool _isNoFive;
        //private bool _isYesFive;
        //private bool _isNoSix;
        //private bool _isYesSix;
        //private bool _isNoSeven;
        //private bool _isYesSeven;
        //private bool _isNoEight;
        //private bool _isYesEight;
        //private bool _isNoNine;
        //private bool _isYesNine;
        //private bool _isNoTen;
        //private bool _isYesTen;
        //private bool _isNoEleven;
        //private bool _isYesEleven;
        //private bool _isNoTwelve;
        //private bool _isYesTwelve;
        //private bool _isNoThirteen;
        //private bool _isYesThirteen;
        //private bool _isNoForteen;
        //private bool _isYesForteen;
        //private bool _isNoFifteen;
        //private bool _isYesFifteen;
        //private bool _isNoSixteen;
        //private bool _isYesSixteen;
        //private bool _isNoSeventeen;
        //private bool _isYesSeventeen;
        private List<bool> _myQuestions = new List<bool>();
        private string _height;
        private string _weight;
        private byte[] _photo;
        private string[] _fileTypes;
        private byte[] _contents;
        private string _contentType;
        private string _fileLabel;
        private string _fileLabelPath;
        private bool _requiresUpload;
        private ObservableCollection<FileVariable> _fileNameList = new ObservableCollection<FileVariable>();

        public ObservableCollection<FileVariable> FileNameList
        {
            get { return _fileNameList; }
            set { SetProperty(ref _fileNameList, value); }
        }
        public bool RequiresUpload
        {
            get { return _requiresUpload; }
            set { SetProperty(ref _requiresUpload, value); }
        }
        private Guid _prospectId;
        private bool _isBusy;
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        private string _extraDetails;
        private string _noOfChildren;
        private DateTime _expectedDelveryDate;
        private List<AccountOpeningFormResponse> _generatedPdfs;
        public List<AccountOpeningFormResponse> GeneratedPdfs
        {
            get { return _generatedPdfs; }
            set { SetProperty(ref _generatedPdfs, value); }
        }
        public DateTime ExpectedDeliveryDate
        {
            get { return _expectedDelveryDate; }
            set { SetProperty(ref _expectedDelveryDate, value); }
        }
        public string NoOfChildren
        {
            get { return _noOfChildren; }
            set { SetProperty(ref _noOfChildren, value); }
        }
        public string ExtraDetails
        {
            get { return _extraDetails; }
            set { SetProperty(ref _extraDetails, value); }
        }
        public string QuestionOne
        {
            get { return _questionOne; }
            set { SetProperty(ref _questionOne, value); }
        }
        public string QuestionTwo
        {
            get { return _questionTwo; }
            set { SetProperty(ref _questionTwo, value); }
        }
        public string QuestionThree
        {
            get { return _questionThree; }
            set { SetProperty(ref _questionThree, value); }
        }
        public string QuestionFour
        {
            get { return _questionFour; }
            set { SetProperty(ref _questionFour, value); }
        }
        public string QuestionFive
        {
            get { return _questionFive; }
            set { SetProperty(ref _questionFive, value); }
        }
        public string QuestionSix
        {
            get { return _questionSix; }
            set { SetProperty(ref _questionSix, value); }
        }
        public string QuestionSeven
        {
            get { return _questionSeven; }
            set { SetProperty(ref _questionSeven, value); }
        }
        public string QuestionEight
        {
            get { return _questionEight; }
            set { SetProperty(ref _questionEight, value); }
        }
        public string QuestionNine
        {
            get { return _questionNine; }
            set { SetProperty(ref _questionNine, value); }
        }
        public string QuestionTen
        {
            get { return _questionTen; }
            set { SetProperty(ref _questionTen, value); }
        }
        public string QuestionEleven
        {
            get { return _questionEleven; }
            set { SetProperty(ref _questionEleven, value); }
        }
        public string QuestionTwelve
        {
            get { return _questionTwelve; }
            set { SetProperty(ref _questionTwelve, value); }
        }
        public string QuestionThirteen
        {
            get { return _questionThirteen; }
            set { SetProperty(ref _questionThirteen, value); }
        }
        public string QuestionForteen
        {
            get { return _questionForteen; }
            set { SetProperty(ref _questionForteen, value); }
        }
        public string QuestionFifteen
        {
            get { return _questionFifteen; }
            set { SetProperty(ref _questionFifteen, value); }
        }
        public string QuestionSixteen
        {
            get { return _questionSixteen; }
            set { SetProperty(ref _questionSixteen, value); }
        }
        public string QuestionSeventeen
        {
            get { return _questionSeventeen; }
            set { SetProperty(ref _questionSeventeen, value); }
        }
        public string Height
        {
            get { return _height; }
            set { SetProperty(ref _height, value); }
        }
        public string Weight
        {
            get { return _weight; }
            set { SetProperty(ref _weight, value); }
        }
        //public bool IsNo
        //{
        //    get { return _isNo; }
        //    set { SetProperty(ref _isNo, value); }
        //}
        //public bool IsNoTwo
        //{
        //    get { return _isNoTwo; }
        //    set { SetProperty(ref _isNoTwo, value); }
        //}
        //public bool IsYesTwo
        //{
        //    get { return _isYesTwo; }
        //    set { SetProperty(ref _isYesTwo, value); }
        //}
        //public bool IsNoThree
        //{
        //    get { return _isNoThree; }
        //    set { SetProperty(ref _isNoThree, value); }
        //}
        //public bool IsYesThree
        //{
        //    get { return _isYesThree; }
        //    set { SetProperty(ref _isYesThree, value); }
        //}
        //public bool IsNoFour
        //{
        //    get { return _isNoFour; }
        //    set { SetProperty(ref _isNoFour, value); }
        //}
        //public bool IsYesFour
        //{
        //    get { return _isYesFour; }
        //    set { SetProperty(ref _isYesFour, value); }
        //}
        //public bool IsNoFive
        //{
        //    get { return _isNoFive; }
        //    set { SetProperty(ref _isNoFive, value); }
        //}
        //public bool IsYesFive
        //{
        //    get { return _isYesFive; }
        //    set { SetProperty(ref _isYesFive, value); }
        //}
        //public bool IsNoSix
        //{
        //    get { return _isNoSix; }
        //    set { SetProperty(ref _isNoSix, value); }
        //}
        //public bool IsYesSix
        //{
        //    get { return _isYesSix; }
        //    set { SetProperty(ref _isYesSix, value); }
        //}
        //public bool IsNoSeven
        //{
        //    get { return _isNoSeven; }
        //    set { SetProperty(ref _isNoSeven, value); }
        //}
        //public bool IsYesSeven
        //{
        //    get { return _isYesSeven; }
        //    set { SetProperty(ref _isYesSeven, value); }
        //}
        //public bool IsNoEight
        //{
        //    get { return _isNoEight; }
        //    set { SetProperty(ref _isNoEight, value); }
        //}
        //public bool IsYesEight
        //{
        //    get { return _isYesEight; }
        //    set { SetProperty(ref _isYesEight, value); }
        //}
        //public bool IsNoNine
        //{
        //    get { return _isNoNine; }
        //    set { SetProperty(ref _isNoNine, value); }
        //}
        //public bool IsYesNine
        //{
        //    get { return _isYesNine; }
        //    set { SetProperty(ref _isYesNine, value); }
        //}
        //public bool IsNoTen
        //{
        //    get { return _isNoTen; }
        //    set { SetProperty(ref _isNoTen, value); }
        //}
        //public bool IsYesTen
        //{
        //    get { return _isYesTen; }
        //    set { SetProperty(ref _isYesTen, value); }
        //}
        //public bool IsNoEleven
        //{
        //    get { return _isNoEleven; }
        //    set { SetProperty(ref _isNoEleven, value); }
        //}
        //public bool IsYesEleven
        //{
        //    get { return _isYesEleven; }
        //    set { SetProperty(ref _isYesEleven, value); }
        //}
        //public bool IsNoTwelve
        //{
        //    get { return _isNoTwelve; }
        //    set { SetProperty(ref _isNoTwelve, value); }
        //}
        //public bool IsYesTwelve
        //{
        //    get { return _isYesTwelve; }
        //    set { SetProperty(ref _isYesTwelve, value); }
        //}
        //public bool IsNoThirteen
        //{
        //    get { return _isNoThirteen; }
        //    set { SetProperty(ref _isNoThirteen, value); }
        //}
        //public bool IsYesThirteen
        //{
        //    get { return _isYesThirteen; }
        //    set { SetProperty(ref _isYesThirteen, value); }
        //}
        //public bool IsNoForteen
        //{
        //    get { return _isNoForteen; }
        //    set { SetProperty(ref _isNoForteen, value); }
        //}
        //public bool IsYesForteen
        //{
        //    get { return _isYesForteen; }
        //    set { SetProperty(ref _isYesForteen, value); }
        //}
        //public bool IsNoFifteen
        //{
        //    get { return _isNoFifteen; }
        //    set { SetProperty(ref _isNoFifteen, value); }
        //}
        //public bool IsYesFifteen
        //{
        //    get { return _isYesFifteen; }
        //    set { SetProperty(ref _isYesFifteen, value); }
        //}
        //public bool IsNoSixteen
        //{
        //    get { return _isNoSixteen; }
        //    set { SetProperty(ref _isNoSixteen, value); }
        //}
        //public bool IsYesSixteen
        //{
        //    get { return _isYesSixteen; }
        //    set { SetProperty(ref _isYesSixteen, value); }
        //}
        //public bool IsNoSeventeen
        //{
        //    get { return _isNoSeventeen; }
        //    set { SetProperty(ref _isNoSeventeen, value); }
        //}
        //public bool IsYesSeventeen
        //{
        //    get { return _isYesSeventeen; }
        //    set { SetProperty(ref _isYesSeventeen, value); }
        //}
        //public bool IsVisible
        //{
        //    get { return _isVisible; }
        //    set { SetProperty(ref _isVisible, value); }
        //}
        public bool IsQuestionOne
        {
            get { return _isQuestionOne; }
            set { SetProperty(ref _isQuestionOne, value); }
        }
        public bool IsQuestionTwo
        {
            get { return _isQuestionTwo; }
            set { SetProperty(ref _isQuestionTwo, value); }
        }
        public bool IsQuestionThree
        {
            get { return _isQuestionThree; }
            set { SetProperty(ref _isQuestionThree, value); }
        }
        public bool IsFemale
        {
            get { return _isFemale; }
            set { SetProperty(ref _isFemale, value); }
        }
        public bool IsQuestionFive
        {
            get { return _isQuestionFive; }
            set { SetProperty(ref _isQuestionFive, value); }
        }
        public bool IsQuestionSix
        {
            get { return _isQuestionSix; }
            set { SetProperty(ref _isQuestionSix, value); }
        }
        public bool IsQuestionSeven
        {
            get { return _isQuestionSeven; }
            set { SetProperty(ref _isQuestionSeven, value); }
        }
        public bool IsQuestionEight
        {
            get { return _isQuestionEight; }
            set { SetProperty(ref _isQuestionEight, value); }
        }
        public bool IsQuestionNine
        {
            get { return _isQuestionNine; }
            set { SetProperty(ref _isQuestionNine, value); }
        }
        public bool IsQuestionTen
        {
            get { return _isQuestionTen; }
            set { SetProperty(ref _isQuestionTen, value); }
        }
        public bool IsQuestionEleven
        {
            get { return _isQuestionEleven; }
            set { SetProperty(ref _isQuestionEleven, value); }
        }
        public bool IsQuestionTwelve
        {
            get { return _isQuestionTwelve; }
            set { SetProperty(ref _isQuestionTwelve, value); }
        }
        public bool IsQuestionThirteen
        {
            get { return _isQuestionThirteen; }
            set { SetProperty(ref _isQuestionThirteen, value); }
        }
        public bool IsQuestionForteen
        {
            get { return _isQuestionForteen; }
            set { SetProperty(ref _isQuestionForteen, value); }
        }
        public bool IsQuestionFifteen
        {
            get { return _isQuestionFifteen; }
            set { SetProperty(ref _isQuestionFifteen, value); }
        }
        public bool IsQuestionSixteen
        {
            get { return _isQuestionSixteen; }
            set { SetProperty(ref _isQuestionSixteen, value); }
        }
        public bool IsQuestionSeventeen
        {
            get { return _isQuestionSeventeen; }
            set { SetProperty(ref _isQuestionSeventeen, value); }
        }
        public byte[] Photo
        {
            get { return _photo; }
            set { SetProperty(ref _photo, value); }
        }
        public Prospect SelectedProspect
        {
            get { return _selectedProspect; }
            set { SetProperty(ref _selectedProspect, value); }
        }
        public List<bool> MyQuestions
        {
            get { return _myQuestions; }
            set { SetProperty(ref _myQuestions, value); }
        }
        public byte[] Contents
        {
            get { return _contents; }
            set { SetProperty(ref _contents, value); }
        }
        public string ContentType
        {
            get { return _contentType; }
            set { SetProperty(ref _contentType, value); }
        }
        public string FileLabel
        {
            get { return _fileLabel; }
            set { SetProperty(ref _fileLabel, value); }
        }
        public string[] FileTypes
        {
            get { return _fileTypes; }
            set { SetProperty(ref _fileTypes, value); }
        }
        public string FileLabelPath
        {
            get { return _fileLabelPath; }
            set { SetProperty(ref _fileLabelPath, value); }
        }
        public Agent LoggedAgent { get; set; }
        public ProductPlan ProductPlan { get; set; }
        public double Premium { get; private set; }
        public BookOnline BookOnline { get; set; }
        public ProposalQuestionnaire ProposalQuestionnaire { get; set; }
        public FileVariable CapturedSignature { get; set; }
        public EncryptedProspect EncryptedProspect { get; set; }
        private LifeDocumentPdfRequest _lifeDocumentPdfRequest = new LifeDocumentPdfRequest();
        public LifeDocumentPdfRequest LifeDocumentPdfRequest
        {
            get { return _lifeDocumentPdfRequest; }
            set { SetProperty(ref _lifeDocumentPdfRequest, value); }
        }

        private DelegateCommand _pickfileCommand;
        private DelegateCommand _toggleChangeCommand;
        private DelegateCommand _proceedCommand;

        public DelegateCommand ToggleChangeCommand => _toggleChangeCommand ?? (_toggleChangeCommand = new DelegateCommand(ExecuteToggleChangeCommand));
        public DelegateCommand PickFileCommand => _pickfileCommand ?? (_pickfileCommand = new DelegateCommand(ExecutePickFileCommand));
        public DelegateCommand ProceedCommand => _proceedCommand ?? (_proceedCommand = new DelegateCommand(ExecuteProceedCommand));

        public NonMedicalQuestionairePageViewModel(INavigationService navigationService,
            IPageDialogService pageDialogService, IMediaManager mediaManager,
            IProspectRepository prospectRepository,
            IAgentRepository agentRepository, Logical logical,
            IProductPlansRepository productPlansRepository, IBookOnlineRepository bookOnlineRepository, EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _prospectRepository = prospectRepository;
            _agentRepository = agentRepository;
            _productPlansRepository = productPlansRepository;
            _bookOnlineRepository = bookOnlineRepository;
            _logical = logical;
            _encryptUtils = encryptUtils;
            _deviceManager = mediaManager;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            IsBusy = true;
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    Guid.TryParse(parameters["ProspectId"].ToString(), out _prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(_prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }
                if (parameters.ContainsKey("AgentId"))
                {
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out Guid agentId))
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                }
                if (parameters.ContainsKey("BookOnline"))
                {
                    BookOnline = parameters.GetValue<BookOnline>("BookOnline");
                    Premium = Convert.ToDouble(BookOnline.Amount);
                }
                if (parameters.ContainsKey("UploadFile"))
                    CapturedSignature = parameters.GetValue<FileVariable>("UploadFile");
                if (parameters.ContainsKey("ProductPlanId"))
                {
                    if (Guid.TryParse(parameters["ProductPlanId"].ToString(), out Guid _productPlanId))
                        ProductPlan = await _productPlansRepository.GetProductPlanByProductPlanId(_productPlanId);
                }
                if (parameters.ContainsKey("ProposalQuestionnaire"))
                    ProposalQuestionnaire = parameters.GetValue<ProposalQuestionnaire>("ProposalQuestionnaire");
                if (parameters.ContainsKey("ProposalQuestionnaire"))
                    ProposalQuestionnaire = parameters.GetValue<ProposalQuestionnaire>("ProposalQuestionnaire");
                if (SelectedProspect.Gender == 0)
                    IsFemale = true;

                QuestionOne = "Has an application for life insurance on your life ever been declined, deferred or accepted with higher than standard premiums or an exclusion applied on health grounds?";
                QuestionTwo = "Have you suffered from any serious personal accident involving fractured skull or bones or unconsciousness or other injury?";
                QuestionThree = "Are you presently receiving a disability benefit or incapable for work or have you ever had a claim for disability, accident, medical care or critical illness and/or other benefits?";
                QuestionFour = "Have you ever had or received medical advice or treatment for any of the following?";
                QuestionFive = "Chest pain, high blood pressure, heart attack, stroke, diabetes, any heart/blood disorders or vascular diseases";
                QuestionSix = "Cancer, tumor/lump/polyps or growth of any kind";
                QuestionSeven = "Gastrointestinal, respiratory, ears, eyes, epilepsy, neurological, psychiatric, kidney, liver, metabolic and endocrine disorders";
                QuestionEight = "Joint, limb or bone conditions, auto immune diseases, infectious diseases";
                QuestionNine = "Hepatitis B or C, HIV, Lyme, tuberculosis, alcohol or drug dependency";
                QuestionTen = "Are you currently receiving any medical treatment or do you intend seeking or have been advised to seek medical treatment for any health problems or are you awaiting the results of any tests/investigations?";
                QuestionEleven = "Apart from the condition listed, have you ever seen a Doctor or health professional, or been prescribed medication for any other condition which has lasted for more than (apart from usual flu and colds) five (5) days?";
                QuestionTwelve = "Has your biological mother, father, or any sister or brother been diagnosed prior to age 60 with any of the following? Cancer, Heart attack, Stroke or any other inherited condition";
                QuestionThirteen = "Is there anything you have suffered from which has not been mentioned above?";
                QuestionForteen = "Are your periods irregular or unnatural?";
                QuestionFifteen = "Have you suffered any uterine or ovarian disease or displacements or had any gynecological operations?";
                QuestionSixteen = "Are you pregnant?";
                QuestionSeventeen = "Have you had any miscarriages, stillbirths or difficult delivery?";

                //ExpectedDeliveryDate = DateTime.Today;
            }
            catch (Exception ex)
            {

            }
            IsBusy = false;
        }

        private void ExecuteToggleChangeCommand()
        {
            try
            {
                if (IsQuestionOne || IsQuestionTwo || IsQuestionThree || IsQuestionFive || IsQuestionSix || IsQuestionSeven || IsQuestionEight || IsQuestionNine
                    || IsQuestionTen || IsQuestionEleven || IsQuestionTwelve || IsQuestionThirteen || IsQuestionForteen || IsQuestionFifteen || IsQuestionSixteen
                    || IsQuestionSeventeen)
                    RequiresUpload = true;
                else
                    RequiresUpload = false;
            }
            catch (Exception ex)
            {

            }
        }

        private async Task<List<AccountOpeningFormResponse>> GenerateLifePdfDocuments()
        {
            try
            {
                MyQuestions = new List<bool>();
                LifeDocumentPdfRequest.NMQPdfRequest = new NMQPdfRequest();
                LifeDocumentPdfRequest.LifeSummaryRequest = new LifeSummaryRequest();

                BookOnline.ProductPlanId = ProductPlan.Id;
                BookOnline.Height = LifeDocumentPdfRequest.NMQPdfRequest.Height = Height;
                BookOnline.Weight = LifeDocumentPdfRequest.NMQPdfRequest.Weight = Weight;
                BookOnline.IsQuestionOne = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionOne = IsQuestionOne;
                BookOnline.IsQuestionTwo = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionTwo = IsQuestionTwo;
                BookOnline.IsQuestionThree = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionThree = IsQuestionThree;
                //BookOnline.IsQuestionFour = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionFour = IsFemale;
                BookOnline.IsQuestionFive = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionFive = IsQuestionFive;
                BookOnline.IsQuestionSix = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionSix = IsQuestionSix;
                BookOnline.IsQuestionSeven = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionSeven = IsQuestionSeven;
                BookOnline.IsQuestionEight = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionEight = IsQuestionEight;
                BookOnline.IsQuestionNine = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionNine = IsQuestionNine;
                BookOnline.IsQuestionTen = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionTen = IsQuestionTen;
                BookOnline.IsQuestionEleven = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionEleven = IsQuestionEleven;
                BookOnline.IsQuestionTwelve = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionTwelve = IsQuestionTwelve;
                BookOnline.IsQuestionThirteen = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionThirteen = IsQuestionThirteen;
                BookOnline.IsQuestionForteen = IsQuestionForteen;
                LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionForteen = !IsQuestionForteen; //The value is inverted to cater for the inversion in the question too
                BookOnline.IsQuestionFifteen = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionFifteen = IsQuestionFifteen;
                BookOnline.IsQuestionSixteen = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionSixteen = IsQuestionSixteen;
                BookOnline.IsQuestionSeventeen = LifeDocumentPdfRequest.NMQPdfRequest.IsQuestionSeventeen = IsQuestionSeventeen;
                BookOnline.ExpectedDeliveryDate = LifeDocumentPdfRequest.NMQPdfRequest.ExpectedDeliveryDate = ExpectedDeliveryDate;
                BookOnline.ExtraDetails = LifeDocumentPdfRequest.NMQPdfRequest.ExtraDetails = ExtraDetails;
                BookOnline.NoOfChildren = LifeDocumentPdfRequest.NMQPdfRequest.NoOfChildren = Convert.ToInt32(NoOfChildren);

                LifeDocumentPdfRequest.Customer = SelectedProspect;
                LifeDocumentPdfRequest.LoggedAgent = LoggedAgent;
                LifeDocumentPdfRequest.Signature = CapturedSignature;
                LifeDocumentPdfRequest.LifeSummaryRequest.PaymentFrequency = BookOnline.PaymentFrequency;
                LifeDocumentPdfRequest.LifeSummaryRequest.PolicyTerm = BookOnline.PolicyTerm;
                LifeDocumentPdfRequest.LifeSummaryRequest.PolicyType = ProductPlan.PlanCategory;
                LifeDocumentPdfRequest.LifeSummaryRequest.SumAssured = BookOnline.SumAssured;
                LifeDocumentPdfRequest.LifeSummaryRequest.TotalPremium = BookOnline.TotalPremium;
                LifeDocumentPdfRequest.LifeSummaryRequest.BeneficiaryList = BookOnline.BeneficiaryList;
                LifeDocumentPdfRequest.LifeSummaryRequest.AccountNumber = BookOnline.BankAccountNumber;
                LifeDocumentPdfRequest.LifeSummaryRequest.BankName = BookOnline.BankName;
                LifeDocumentPdfRequest.LifeSummaryRequest.BVN = BookOnline.BVN;

                if (ProductPlan.PlanCategory == "Ambitions" || ProductPlan.PlanCategory == "Education Plan Plus" || ProductPlan.PlanCategory == "Instant Plan" || ProductPlan.PlanCategory == "CashBack Term Life" || ProductPlan.PlanCategory == "Life Plus")
                {
                    LifeDocumentPdfRequest.LifeSummaryRequest.DynamicColumnName1 = "DEPOSIT PREMIUM PAID";
                    LifeDocumentPdfRequest.LifeSummaryRequest.DynamicColumnValue1 = "NGN " + BookOnline.Amount.ToString("N0");

                    LifeDocumentPdfRequest.LifeSummaryRequest.DynamicColumnName2 = "POLICY TERM";
                    LifeDocumentPdfRequest.LifeSummaryRequest.DynamicColumnValue2 = BookOnline.PolicyTerm.ToString() + " year(s)";
                }
                if (ProductPlan.PlanCategory == "Life Savings")
                {
                    LifeDocumentPdfRequest.LifeSummaryRequest.DynamicColumnName1 = "PROPOSED MONTHLY CONTRIBUTION";
                    LifeDocumentPdfRequest.LifeSummaryRequest.DynamicColumnValue1 = "NGN " + BookOnline.Amount.ToString("N0");

                    LifeDocumentPdfRequest.LifeSummaryRequest.DynamicColumnName2 = "INVESTMENT PERIOD";
                    LifeDocumentPdfRequest.LifeSummaryRequest.DynamicColumnValue2 = BookOnline.PolicyTerm.ToString() + " year(s)";
                }
                if (ProductPlan.PlanCategory == "Bonus Life")
                {
                    LifeDocumentPdfRequest.LifeSummaryRequest.DynamicColumnName1 = "EXPECTED PREMIUM";
                    LifeDocumentPdfRequest.LifeSummaryRequest.DynamicColumnValue1 = "NGN " + BookOnline.Amount.ToString("N0");

                    LifeDocumentPdfRequest.LifeSummaryRequest.DynamicColumnName2 = "PREMIUM PAYMENT TERM";
                    LifeDocumentPdfRequest.LifeSummaryRequest.DynamicColumnValue2 = BookOnline.PolicyTerm.ToString() + " year(s)";
                }

                LifeDocumentPdfRequest.ProposalQuestionnaire = ProposalQuestionnaire;
                GeneratedPdfs = await _logical.GenerateLifePDFs(LifeDocumentPdfRequest);
                if(GeneratedPdfs != null && GeneratedPdfs.Count > 0) //Adding the medical support document into the other generated documents here
                {
                    foreach (FileVariable item in FileNameList)
                    {
                        AccountOpeningFormResponse medicalReport = new AccountOpeningFormResponse
                        {
                            Document = item.FileContent,
                            DocumentPath = item.FileName,
                            ContentType = item.ContentType,
                            Extension = item.Extension
                        };
                        GeneratedPdfs.Add(medicalReport);
                    }
                }

                #region MyQuestions                
                MyQuestions.Add(IsQuestionOne);
                MyQuestions.Add(IsQuestionTwo);
                MyQuestions.Add(IsQuestionThree);
                MyQuestions.Add(IsQuestionFive);
                MyQuestions.Add(IsQuestionSix);
                MyQuestions.Add(IsQuestionSeven);
                MyQuestions.Add(IsQuestionEight);
                MyQuestions.Add(IsQuestionNine);
                MyQuestions.Add(IsQuestionTen);
                MyQuestions.Add(IsQuestionEleven);
                MyQuestions.Add(IsQuestionTwelve);
                MyQuestions.Add(IsQuestionThirteen);
                MyQuestions.Add(IsQuestionForteen);
                MyQuestions.Add(IsQuestionFifteen);
                MyQuestions.Add(IsQuestionSixteen);
                MyQuestions.Add(IsQuestionSeventeen);

                var res = MyQuestions.FindAll(
                    delegate (bool exist)
                    {
                        return exist == true;
                    });
                if (res.Count > 0)
                {
                    BookOnline.AnyYesNMQ = true;
                }
                else
                {
                    BookOnline.AnyYesNMQ = false;
                }
                #endregion
            }
            catch (Exception ex)
            {

            }
            return GeneratedPdfs;
        }

        //private async void ExecutePayNowCommand()
        //{
        //    IsBusy = true;
        //    try
        //    {
        //        if (string.IsNullOrEmpty(Height))
        //        {
        //            await _pageDialogService.DisplayAlertAsync("Warning", "Please input height", "Ok");
        //        }
        //        else if (string.IsNullOrEmpty(Weight))
        //        {
        //            await _pageDialogService.DisplayAlertAsync("Warning", "Please input weight", "Ok");
        //        }
        //        else if (ExpectedDeliveryDate < DateTime.Today)
        //        {
        //            await _pageDialogService.DisplayAlertAsync("Warning", "Expected delivery date cannot be earlier than today", "Ok");
        //        }
        //        else
        //        {

        //            await GenerateLifePdfDocuments();

        //            var parameters = new NavigationParameters();
        //            parameters.Add("ProspectId", SelectedProspect.Id);
        //            parameters.Add("BookOnline", BookOnline);
        //            parameters.Add("ProductPlanId", ProductPlan.Id);
        //            parameters.Add("AgentId", LoggedAgent.Id);
        //            parameters.Add("LifePdfDocuments", GeneratedPdfs);
        //            parameters.Add("PolicyType", ProductPlan.PlanCategory);
        //            parameters.Add("FNAProduct", ProductPlan.PlanCategory);

        //            await _navigationService.NavigateAsync("PayNowPage", parameters);
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //    IsBusy = false;
        //}

        //private async void ExecutePayLaterCommand()
        //{
        //    IsBusy = true;
        //    try
        //    {
        //        if (string.IsNullOrEmpty(Height))
        //        {
        //            await _pageDialogService.DisplayAlertAsync("Warning", "Please input height", "Ok");
        //        }
        //        else if (string.IsNullOrEmpty(Weight))
        //        {
        //            await _pageDialogService.DisplayAlertAsync("Warning", "Please input weight", "Ok");
        //        }
        //        else
        //        {
        //            await GenerateLifePdfDocuments();

        //            var parameters = new NavigationParameters();
        //            parameters.Add("ProspectId", SelectedProspect.Id);
        //            parameters.Add("BookOnline", BookOnline);
        //            parameters.Add("ProductPlanId", ProductPlan.Id);
        //            parameters.Add("AgentId", LoggedAgent.Id);
        //            parameters.Add("LifePdfDocuments", GeneratedPdfs);
        //            parameters.Add("PolicyType", ProductPlan.PlanCategory);
        //            parameters.Add("FNAProduct", ProductPlan.PlanCategory);

        //            await _navigationService.NavigateAsync("PayLaterPage", parameters);
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //    IsBusy = false;
        //}

        private async void ExecutePickFileCommand()
        {
            try
            {
                bool choice = await _pageDialogService.DisplayAlertAsync("Confirm", "Please select how you wish to upload a document", "Camera", "Gallery");

                if (choice)
                {
                    if (_deviceManager.CameraAvailable)
                    {
                        var newPhoto = await _deviceManager.TakePhotoAsync();

                        if (newPhoto != null && newPhoto.FileContent.Length <= 4194304)
                        {
                            Photo = newPhoto.FileContent;
                            Contents = Photo;
                            FileVariable CameraTaken = new FileVariable
                            {
                                FileName = newPhoto.FileName,
                                FileContent = Convert.ToBase64String(Contents),
                                FieldName = "Supporting Document",
                                ContentType = "image/jpg",
                                Extension = "jpg"
                            };
                            FileLabel = newPhoto.FileName;
                            FileNameList.Add(CameraTaken);
                        }
                    }
                }
                else
                {
                    if (Device.RuntimePlatform == Device.Android)
                    {
                        FileTypes = new string[] { "image/png", "image/jpeg", "application/pdf" };
                    }

                    await PickedFiles(FileTypes);

                    FileVariable medicalDocument = new FileVariable
                    {
                        FileName = FileLabel,
                        FieldName = "Supporting Document",
                        FileContent = Convert.ToBase64String(Contents),
                        ContentType = ContentType,
                        Extension = !ContentType.ToLower().Contains("jpeg") ? ContentType.Substring((ContentType.Length - 3), 3) : ContentType.Substring((ContentType.Length - 4), 4)
                    };
                    FileNameList.Add(medicalDocument);
                    FileLabel = FileLabel;
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        public async Task PickedFiles(string[] fileTypes)
        {
            try
            {
                var pickedFile = await CrossFilePicker.Current.PickFile(fileTypes);

                if (pickedFile != null)
                {
                    FileLabel = pickedFile.FileName;
                    FileLabelPath = pickedFile.FilePath;

                    if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase)
                       || pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase))
                    {
                        Contents = pickedFile.DataArray;

                        if (pickedFile.FileName.EndsWith("pdf", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "application/pdf";
                        }
                        else if (pickedFile.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "image" + "/jpg";
                        }
                        else if (pickedFile.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase))
                        {
                            ContentType = "image" + "/png";
                        }
                        else
                            ContentType = "image" + "/jpeg";
                    }

                   //FileSize = FileSizeFormatter.FormatSize(Contents.Length);

                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteProceedCommand()
        {
            IsBusy = true;
            try
            {
                if (string.IsNullOrEmpty(Height))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please input height", "Ok");
                }
                else if (string.IsNullOrEmpty(Weight))
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please input weight", "Ok");
                }
                else if (IsQuestionSixteen && ExpectedDeliveryDate < DateTime.Today)
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Expected delivery date cannot be earlier than today", "Ok");
                }
                else
                {
                    await GenerateLifePdfDocuments();

                    if (GeneratedPdfs.Count != 0)
                    {
                        var parameters = new NavigationParameters();
                        parameters.Add("ProspectId", SelectedProspect.Id);
                        parameters.Add("BookOnline", BookOnline);
                        parameters.Add("ProductPlanId", ProductPlan.Id);
                        parameters.Add("AgentId", LoggedAgent.Id);
                        parameters.Add("LifePdfDocuments", GeneratedPdfs);
                        parameters.Add("PolicyType", ProductPlan.PlanCategory);
                        parameters.Add("FNAProduct", ProductPlan.PlanCategory);

                        await _navigationService.NavigateAsync("LifeProductSummaryPage", parameters);
                    }
                    else
                    {
                        await _pageDialogService.DisplayAlertAsync("Error", "There was an error generating the life documents. Please check your network connection and retry", "Ok");
                    }
                }
            }
            catch (Exception ex)
            {

            }
            IsBusy = false;

        }
    }
}
