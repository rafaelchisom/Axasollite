﻿using AxaSolLite.Models;
using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AxaSolLite.ViewModels
{
    public class CustomerSearchWithNumberViewModel : BindableBase, INavigationAware
    {
        private readonly INavigationService _navigationService;
        private readonly IPageDialogService _pageDialogService;
        private readonly IProspectRepository _prospectRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly IProductPlansRepository _productPlansRepository;
        private readonly Logical _logical;
        private readonly EncryptUtils _encryptUtils;

        private bool _isBusy;
        private Prospect _selectedProspect;
        private Agent _loggedAgent;
        private string _customerNumber;
        private CustomerDetailsReponse _customer;

        public CustomerDetailsReponse Customer
        {
            get { return _customer; }
            set { SetProperty(ref _customer, value); }
        }
        public string CustomerNumber
        {
            get { return _customerNumber; }
            set { SetProperty(ref _customerNumber, value); }
        }
        public bool IsBusy
        {
            get { return _isBusy; }
            set { SetProperty(ref _isBusy, value); }
        }
        public Agent LoggedAgent
        {
            get { return _loggedAgent; }
            set { SetProperty(ref _loggedAgent, value); }
        }
        public Prospect SelectedProspect
        {
            get { return _selectedProspect; }
            set { SetProperty(ref _selectedProspect, value); }
        }
        public EncryptedProspect EncryptedProspect { get; set; }

        private DelegateCommand _searchForCustomer;
        public DelegateCommand SearchForCustomer => _searchForCustomer ?? (_searchForCustomer = new DelegateCommand(ExecuteSearch));

        public CustomerSearchWithNumberViewModel(INavigationService navigationService, IPageDialogService pageDialogService,
            Logical logical, IProspectRepository prospectRepository, IAgentRepository agentRepository, IProductPlansRepository productPlansRepository,
            EncryptUtils encryptUtils)
        {
            _navigationService = navigationService;
            _pageDialogService = pageDialogService;
            _prospectRepository = prospectRepository;
            _agentRepository = agentRepository;
            _productPlansRepository = productPlansRepository;
            _logical = logical;
            _encryptUtils = encryptUtils;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public async void OnNavigatedTo(INavigationParameters parameters)
        {
            Guid prospectId;
            try
            {
                if (parameters.ContainsKey("ProspectId"))
                {
                    //if (Guid.TryParse(parameters["ProspectId"].ToString(), out prospectId))
                    //{
                    //    SelectedProspect = await _prospectRepository.GetById(prospectId);
                    //}
                    Guid.TryParse(parameters["ProspectId"].ToString(), out prospectId);
                    EncryptedProspect = await _prospectRepository.GetById(prospectId);
                    string serializedProspect = _encryptUtils.aesDecrypt(EncryptedProspect.Prospect);
                    SelectedProspect = JsonConvert.DeserializeObject<Prospect>(serializedProspect);
                }
                if (parameters.ContainsKey("AgentId"))
                {
                    Guid agentId;
                    if (Guid.TryParse(parameters["AgentId"].ToString(), out agentId))
                    {
                        LoggedAgent = await _agentRepository.GetAgentByAgentId(agentId);
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        private async void ExecuteSearch()
        {
            IsBusy = true;
            try
            {
                if (!string.IsNullOrEmpty(CustomerNumber))
                {
                    Customer = await _logical.GetCustomerDetailsByCustomerNumber(CustomerNumber);
                    if (Customer.IsSuccessful)
                    {
                        await _pageDialogService.DisplayAlertAsync("Customer found!", "Name : " + Customer.Result.CustomerName + "\n\n" + "Email Address: " + Customer.Result.EmailAddress + "\n\n" + "Phone Number: " + Customer.Result.PhoneNumber, "Ok");
                        SelectedProspect.CustomerName = Customer.Result.CustomerName.Trim();
                        string[] Names = SelectedProspect.CustomerName.Split(' ');
                        var inx = Names.Length;

                        var Name = 0;

                        if(inx == 2)
                        {
                            Name = 1;
                        }
                        else if (inx >= 3)
                        {
                            Name = inx -1;
                            
                        }
                       

                        

                        if ((Names[0] != null))
                        {
                            AimsCustomerUpdateModel aimsCustomerUpdateModel = new AimsCustomerUpdateModel
                            {
                                FirstName = SelectedProspect.FirstName,
                                LastName = SelectedProspect.LastName,
                                EmailAddress = SelectedProspect.Email,
                                PhoneNumber = SelectedProspect.MobileNumber,
                                DateOfBirth = SelectedProspect.Birthdate,

                                
                                NewFirstName = Names[0],                             
                                NewLastName = Names[Name],
                                NewDateOfBirth = Customer.Result.DateOfBirth,
                                NewEmailAddress = Customer.Result.EmailAddress,
                                NewPhoneNumber = Customer.Result.PhoneNumber,
                                CustomerNumber = Customer.Result.CustomerNumber,
                                CustoemerAddress = Customer.Result.CustomerAddress,
                                
                            };
                            
                            bool prospectUpdated = await _logical.UpdateCustomerInformationWithAimsRecord(aimsCustomerUpdateModel);
                        }

                        //SelectedProspect.FirstName = Names[0];
                        //SelectedProspect.LastName = Names[Name];
                        SelectedProspect.FullName = Customer.Result.CustomerName;

                        //if (Customer.Result.EmailAddress != null)
                        //{
                        //    SelectedProspect.Email = Customer.Result.EmailAddress;

                        //}
                        if (Customer.Result.CustomerAddress != null)
                        {
                            SelectedProspect.Address = Customer.Result.CustomerAddress;
                        }
                        if (Customer.Result.PhoneNumber != null)
                        {
                            SelectedProspect.MobileNumber = Customer.Result.PhoneNumber;
                        }
                        if (Customer.Result.DateOfBirth != null)
                        {
                            SelectedProspect.Birthdate = Convert.ToDateTime(Customer.Result.DateOfBirth);
                        }

                        SelectedProspect.CustomerNumber = CustomerNumber;
                      

                        var res = await _logical.GetLeadAccountStatus(SelectedProspect.CustomerNumber);
                        if(res.IsLeadAccount && res.IsFullyKyCed)
                        {
                            SelectedProspect.CaseCreated = true;
                            var ProductPlan = await _productPlansRepository.GetProductPlansByProspectId(SelectedProspect.Id);
                            foreach (var item in ProductPlan.ToList())
                            {
                                item.IsNotPolicyId = true;
                                await _productPlansRepository.UpdateAsync(item);
                            }

                            string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                            EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                            int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                            //await _prospectRepository.UpdateAsync(SelectedProspect);

                            //ProspectToUpdate prospectToUpdate = null;
                            //prospectToUpdate = new ProspectToUpdate
                            //{
                            //    CustomerNumber = SelectedProspect.CustomerNumber,
                            //    EmailAddress = SelectedProspect.Email,
                            //    DateOfBirth = SelectedProspect.Birthdate,
                            //    FirstName = SelectedProspect.FirstName,
                            //    LastName = SelectedProspect.LastName,
                            //    PhoneNumber = SelectedProspect.MobileNumber
                            //};

                            // bool updated = await _logical.UpdateProspectDetails(prospectToUpdate);

                            var navigationParameter = new NavigationParameters();
                            navigationParameter.Add("ProspectId", SelectedProspect.Id);
                            navigationParameter.Add("AgentId", LoggedAgent.Id);

                            await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", navigationParameter);

                        }
                        else if(res.IsLeadAccount && !res.IsFullyKyCed)
                        {
                            var Ischoice = await _pageDialogService.DisplayAlertAsync("Customer not fully Ekyced", "Complete customer onboarding Now", "YES", "NO");
                            if (Ischoice)
                            {

                                bool useNIN = await _pageDialogService.DisplayAlertAsync("", "Confirm how to complete onboarding", "Use NIN", "Use Manual");
                                if (useNIN)
                                {

                                    var navigationParameters = new NavigationParameters();
                                    navigationParameters.Add("ProspectId", SelectedProspect.Id);
                                    navigationParameters.Add("AgentId", LoggedAgent.Id);
                                    await _navigationService.NavigateAsync("NINOnboardingPage", navigationParameters, null, false);
                                }
                                else
                                {
                                    var navigationParameters = new NavigationParameters();
                                    navigationParameters.Add("ProspectId", SelectedProspect.Id);
                                    navigationParameters.Add("AgentId", LoggedAgent.Id);
                                    await _navigationService.NavigateAsync("CustomerOnboardingPage", navigationParameters, null, false);


                                }
                            }
                            else
                            {
                                SelectedProspect.IsEkycStatus = true;
                                string serializedProspect = JsonConvert.SerializeObject(SelectedProspect);
                                EncryptedProspect.Prospect = _encryptUtils.aesEncrypt(serializedProspect);
                                int update = await _prospectRepository.UpdateAsync(EncryptedProspect);
                                //await _prospectRepository.UpdateAsync(SelectedProspect);
                                var navigationParameter = new NavigationParameters();
                                navigationParameter.Add("ProspectId", SelectedProspect.Id);
                                navigationParameter.Add("AgentId", LoggedAgent.Id);

                                await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", navigationParameter);
                            }
                        }
                        else if (!res.IsLeadAccount && !res.IsFullyKyCed)
                        {
                            SelectedProspect.IsEkycStatus = true;
                            await _prospectRepository.UpdateAsync(EncryptedProspect);
                            var navigationParameter = new NavigationParameters();
                            navigationParameter.Add("ProspectId", SelectedProspect.Id);
                            navigationParameter.Add("AgentId", LoggedAgent.Id);

                            await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", navigationParameter);

                        }
                    }
                    else
                    {
                        bool reaffirm = await _pageDialogService.DisplayAlertAsync("No record found!", "Kindly reaffirm the customer ID", "Okay", "Cancel");
                        if (reaffirm)
                        {
                            //Do nothing....hahaha
                        }
                        else
                        {
                            var navigationParameters = new NavigationParameters();
                            navigationParameters.Add("ProspectId", SelectedProspect.Id);
                            navigationParameters.Add("AgentId", LoggedAgent.Id);

                            await _navigationService.NavigateAsync("AxaSolLite:///BaseMasterDetailPage/MyNavigationPage/ProductLogPage", navigationParameters);
                        }
                    }
                }
                else
                {
                    await _pageDialogService.DisplayAlertAsync("Warning", "Please provide a valid customer number and retry", "Ok");
                }
            }
            catch (Exception ex)
            {

            }
            IsBusy = false;
        }
    }
}
