﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Enums
{
    public enum ProductType
    {
        Motor = 29,
        Travel = 35,
        Life = 2
    }
}
