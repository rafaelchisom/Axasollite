﻿using Xamarin.Forms;

namespace AxaSolLite.Extensions
{
    public class ProspectDataTemplateSelector : DataTemplateSelector
    {
        public DataTemplate NewProspectTemplate { get; set; }
        public DataTemplate EditProspectTemplate { get; set; }
        public DataTemplate ViewProspectTemplate { get; set; }

        protected override DataTemplate OnSelectTemplate(object item, BindableObject container)
        {
            return EditProspectTemplate;
        }
    }
}