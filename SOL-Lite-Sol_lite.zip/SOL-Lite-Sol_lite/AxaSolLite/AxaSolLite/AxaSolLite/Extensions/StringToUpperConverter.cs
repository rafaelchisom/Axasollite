﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace AxaSolLite.Extensions
{
    //This class has been modified to only capitalize the first letter of the entry. To revert this, comment line 16 and uncomment line 17
    public class StringToUpperConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string)
            {
                if (value != null && value.ToString().Length > 0)
                {
                    value = value.ToString().Replace(value.ToString().Substring(0, 1), value.ToString().Substring(0, 1).ToUpper());
                    //return value.ToString().ToUpperInvariant();
                    return value;
                }
            }

            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value;
        }
    }
}