﻿using System;
using System.IO;
using Xamarin.Forms;

namespace AxaSolLite.Extensions
{
    public class ArrayToImageConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            try
            {
                if (value == null)
                {
                    return null;
                }

                var bArray = (byte[])value;

                var imgsrc = ImageSource.FromStream(() =>
                {
                    var ms = new MemoryStream(bArray);
                    ms.Position = 0;
                    return ms;
                });

                return imgsrc;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}