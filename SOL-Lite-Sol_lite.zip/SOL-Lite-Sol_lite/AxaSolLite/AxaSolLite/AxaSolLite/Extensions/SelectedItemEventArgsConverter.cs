﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace AxaSolLite.Extensions
{
    public class SelectedItemEventArgsConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            try
            {
                var eventArgs = value as SelectedItemChangedEventArgs;
                return eventArgs.SelectedItem;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}