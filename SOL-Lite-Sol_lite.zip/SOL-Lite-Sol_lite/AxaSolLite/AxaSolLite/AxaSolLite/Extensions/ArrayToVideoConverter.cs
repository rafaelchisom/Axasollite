﻿using Octane.Xam.VideoPlayer;
using System;
using System.IO;

namespace AxaSolLite.Extensions
{
    public class ArrayToVideoConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            try
            {
                if (value == null)
                    return null;

                var bArray = (byte[])value;

                var imgsrc = VideoSource.FromStream(
                    () =>
                    {
                        var ms = new MemoryStream(bArray);
                        ms.Position = 0;
                        return ms;
                    }, parameter.ToString());

                return imgsrc;
            }
            catch (Exception ex)
            {
                string error = ex.ToString();
            }

            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}