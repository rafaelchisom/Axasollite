﻿using System;

namespace AxaSolLite.Extensions
{
    public static class StaticConverters
    {
        public static int Convert(string value, int defaultValue = default(int))
        {
            try
            {
                int returnValue = 0;
                int.TryParse(value.Trim(), out returnValue);
                return returnValue;
            }
            catch (Exception)
            {
                return defaultValue;
            }
        }
    }
}