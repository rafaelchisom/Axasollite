﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace AxaSolLite.Extensions
{
    public class ToggledEventConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            try
            {
                var eventArgs = value as ToggledEventArgs;
                return eventArgs.Value;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}