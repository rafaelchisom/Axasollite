﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace AxaSolLite.Extensions
{
    internal class ValueChangedEventArgsConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            try
            {
                var eventArgs = value as ValueChangedEventArgs;
                return eventArgs.NewValue;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}