﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace AxaSolLite.Extensions
{
    public class IntegerToTitleConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            try
            {
                if (value is int)
                {
                    if ((int)value == 0) { return ""; }
                    if ((int)value == 1) { return "N/A"; }
                    if ((int)value == 2) { return "Mr."; }
                    if ((int)value == 3) { return "Mrs."; }
                    if ((int)value == 4) { return "Ms."; }
                    if ((int)value == 5) { return "Atty."; }
                    if ((int)value == 6) { return "Madame"; }
                    if ((int)value == 7) { return "Sir"; }
                    if ((int)value == 8) { return "Hon."; }
                }
                return value;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}