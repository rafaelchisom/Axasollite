﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace AxaSolLite.Extensions
{
    public class IntegerToCountryConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            try
            {
                if (value is int)
                {
                    if ((int)value == 0) { return ""; }
                    if ((int)value == 1) { return "Philippines "; }
                    if ((int)value == 2) { return "Japan"; }
                    if ((int)value == 3) { return "Thailand"; }
                    if ((int)value == 4) { return "Singapore"; }
                    if ((int)value == 5) { return "India"; }
                    if ((int)value == 6) { return "China"; }
                    if ((int)value == 7) { return "Indonesia"; }
                    if ((int)value == 8) { return "Malaysia"; }
                }
                return value;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}