﻿using AXASolutions.App.Services;
using System;
using System.Globalization;
using Xamarin.Forms;

namespace AXASolutions.App.Extensions
{
    public class DateToInsuranceAgeConverter : IValueConverter
    {
        private int returnValue;

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            ICalculatorService calculatorService = new CalculatorService();

            try
            {
                var insruanceAge = calculatorService.GetInsuranceAge((DateTime)value);
                if (insruanceAge < 0)
                    insruanceAge = 0;
                returnValue = insruanceAge;
                return returnValue;
            }
            catch
            {
                return null;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return returnValue;
        }
    }
}