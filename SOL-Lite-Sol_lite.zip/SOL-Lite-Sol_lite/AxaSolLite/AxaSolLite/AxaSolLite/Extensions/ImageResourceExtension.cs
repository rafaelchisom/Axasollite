﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace AxaSolLite.Extensions
{
    [ContentProperty("Source")]
    public class ImageResourceExtension : IMarkupExtension
    {
        public string Source { get; set; }
        public const string ResourceNamespace = "AxaSolLite.Resources.Assets.";

        public object ProvideValue(IServiceProvider serviceProvider)
        {
            try
            {
                if (Source == null)
                {
                    return null;
                }

                if (!Source.StartsWith(ResourceNamespace))
                {
                    Source = ResourceNamespace + Source;
                }

                // Do your translation lookup here, using whatever method you require

                var imageSource = ImageSource.FromResource(Source);

                return imageSource;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}