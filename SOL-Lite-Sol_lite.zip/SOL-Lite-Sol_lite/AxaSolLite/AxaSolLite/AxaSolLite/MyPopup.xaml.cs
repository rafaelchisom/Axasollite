﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.CommunityToolkit.UI.Views;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace AxaSolLite
{
    public partial class MyPopup : ContentPage
    {
        private string _name;
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public Action<PopupOptions> CallBack { get; set; }

        public MyPopup(string name, Action<PopupOptions> callBack)
        {
            InitializeComponent();
            CallBack = callBack;            
        }

        //private void Button_Clicked(object sender, EventArgs e)
        //{
        //    PopupOptions dd = new PopupOptions
        //    {
        //        Name = " Idemudia",
        //        Color = "blue",
        //        Size = "20px"
        //    };

        //    CallBack(dd);
        //}
    }
}