﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class BranchRepository : BaseRepository, IBranchesRepository
    {
        public BranchRepository(IDBConnectionParameters dBConnectionParameters)
           : base(dBConnectionParameters)
        {

        }
        public async Task<Branches> GetBranchByBranchCode(int branchCode)
        {
            return await Connection.Table<Branches>().Where(x => x.BranchCode == branchCode).FirstOrDefaultAsync();
        }

        public async Task<Branches> GetBranchCodeByBranch(string branch)
        {
            return await Connection.Table<Branches>().Where(x => x.Branch == branch).FirstOrDefaultAsync();
        }

        public async Task<List<Branches>> GetBranches()
        {
            return await Connection.Table<Branches>().ToListAsync();
        }

        public async Task<int> SaveAll(List<Branches> Branches)
        {
            return await Connection.InsertAllAsync(Branches);
        }
    }
}
