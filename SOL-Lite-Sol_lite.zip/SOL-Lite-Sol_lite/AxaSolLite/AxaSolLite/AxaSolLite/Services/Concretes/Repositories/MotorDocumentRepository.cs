﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class MotorDocumentRepository : BaseRepository, IMotorDocumentRepository
    {
        public MotorDocumentRepository(IDBConnectionParameters dBConnectionParameters)
            : base(dBConnectionParameters)
        {
        }
        public async Task<List<Documents>> GetMotorDocumentsByMotorProductId(Guid motorProductId)
        {
            return await Connection.Table<Documents>().Where(x => x.MotorProductId == motorProductId).ToListAsync();
        }

        public async Task<int> SaveAllAsync(List<Documents> model)
        {
            return await Connection.InsertAllAsync(model);
        }
    }
}
