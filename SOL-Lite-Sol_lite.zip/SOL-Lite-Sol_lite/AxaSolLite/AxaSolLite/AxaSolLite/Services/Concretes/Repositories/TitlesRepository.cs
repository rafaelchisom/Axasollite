﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class TitlesRepository : BaseRepository, ITitlesRepository
    {
        public TitlesRepository(IDBConnectionParameters dBConnectionParameters)
            :base(dBConnectionParameters)
        {

        }

        public async Task<Titles> GetTitleByTitleCode(int titleCode)
        {
            return await Connection.Table<Titles>().Where(x => x.TitleCode == titleCode).FirstOrDefaultAsync();
            
        }

        public async Task<Titles> GetTitleCodeByTitle(string title)
        {
            return await Connection.Table<Titles>().Where(x => x.Title == title).FirstOrDefaultAsync();
        }

        public async Task<List<Titles>> GetTitles()
        {
            return await Connection.Table<Titles>().ToListAsync();
        }


        public async Task<int> SaveAll(List<Titles> titles)
        {
            return await Connection.InsertAllAsync(titles);
        }
    }
}
