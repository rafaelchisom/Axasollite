﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class MotorRepository : BaseRepository, IMotorRepository
    {
        public MotorRepository(IDBConnectionParameters dBConnectionParameters)
            : base(dBConnectionParameters)
        {

        }
        public async Task<SerializedMotorRenewalObject> GetMotorByProductPlan(Guid productPlanId)
        {
            return await Connection.Table<SerializedMotorRenewalObject>().Where(x => x.ProductPlanId == productPlanId).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(SerializedMotorRenewalObject model)
        {
            return await Connection.InsertAsync(model);
        }

        public async Task<int> UpdateAsync(SerializedMotorRenewalObject model)
        {
            return await Connection.UpdateAsync(model);
        }
    }
}
