﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class GenBizBranchRepository : BaseRepository, IGenBizBranchRepository
    {
        public GenBizBranchRepository(IDBConnectionParameters dBConnectionParameters)
            : base(dBConnectionParameters)
        {

        }

        public async Task<GenBizBranch> GetBranchByBranchCode(int branchCode)
        {
            return await Connection.Table<GenBizBranch>().Where(x => x.BranchCode == branchCode).FirstOrDefaultAsync();
        }

        public async Task<GenBizBranch> GetBranchByBranchName(string branchName)
        {
            return await Connection.Table<GenBizBranch>().Where(x => x.BranchName == branchName).FirstOrDefaultAsync();
        }

        public async Task<List<GenBizBranch>> GetGenBizBranches()
        {
           return await Connection.Table<GenBizBranch>().ToListAsync();
        }

        public async Task<int> SaveAllAsync(List<GenBizBranch> branches)
        {
            return await Connection.InsertAllAsync(branches);
        }
    }
}
