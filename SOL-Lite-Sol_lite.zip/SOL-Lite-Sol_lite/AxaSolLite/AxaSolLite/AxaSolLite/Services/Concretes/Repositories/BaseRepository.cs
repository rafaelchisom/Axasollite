﻿using AxaSolLite.Services.Concretes.Managers;
using AxaSolLite.Services.Contracts;
using SQLite;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class BaseRepository : IBaseRepository
    {
        protected readonly SQLiteAsyncConnection Connection;

        protected BaseRepository(IDBConnectionParameters dbConnectionParameters)
        {
            if (Connection == null)
            {
                Connection = SQLiteDatabase.GetConnection(dbConnectionParameters);
            }
        }
    }
}
