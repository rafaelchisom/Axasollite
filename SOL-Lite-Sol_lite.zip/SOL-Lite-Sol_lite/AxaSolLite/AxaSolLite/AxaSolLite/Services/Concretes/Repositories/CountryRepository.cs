﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class CountryRepository : BaseRepository, ICountryRepository
    {
        public CountryRepository(IDBConnectionParameters dBConnectionParameters)
            : base(dBConnectionParameters)
        {

        }

        public async Task<List<Countries>> GetCountries()
        {
            return await Connection.Table<Countries>().ToListAsync();
        }

        public async Task<Countries> GetCountryByCountryCode(int countryCode)
        {
            return await Connection.Table<Countries>().Where(x => x.CountryCode == countryCode).FirstOrDefaultAsync();
        }

        public async Task<Countries> GetCountryByCountryName(string country)
        {
            return await Connection.Table<Countries>().Where(x => x.Country == country).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAllAsync(List<Countries> model)
        {
            return await Connection.InsertAllAsync(model);
        }

        public async Task<int> SaveAsync(Countries model)
        {
            //await Task.Delay(3000);
            int x = 0;
            try
            {
                x = await Connection.InsertAsync(model);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return x;
        }
    }
}
