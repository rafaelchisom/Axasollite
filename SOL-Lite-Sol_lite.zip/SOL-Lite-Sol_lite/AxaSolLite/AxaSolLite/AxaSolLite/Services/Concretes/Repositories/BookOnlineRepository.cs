﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class BookOnlineRepository : BaseRepository, IBookOnlineRepository
    {
        public BookOnlineRepository(IDBConnectionParameters dBConnectionParameters)
            : base(dBConnectionParameters)
        {

        }

        public async Task<BookOnline> GetBookingByProductPlanId(Guid productPlanId)
        {
            return await Connection.Table<BookOnline>().Where(x => x.ProductPlanId == productPlanId).FirstOrDefaultAsync();
        }

        public async Task<BookOnline> GetBookOnlineById(Guid Id)
        {
            return await Connection.Table<BookOnline>().Where(x => x.Id == Id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveBooking(BookOnline model)
        {
            return await Connection.InsertAsync(model);
        }

        public async Task<int> UpdateBooking(BookOnline model)
        {
            return await Connection.UpdateAsync(model);
        }
    }
}
