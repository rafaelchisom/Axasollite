﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class MotorBoughtRepository : BaseRepository, IMotorBoughtRepository
    {
        public MotorBoughtRepository(IDBConnectionParameters dBConnectionParameters) 
            : base(dBConnectionParameters)
        {

        }

        public async Task<MotorBought> GetById(int id)
        {
            return await Connection.Table<MotorBought>().Where(x => x.Id == id).FirstOrDefaultAsync();
        }

        public async Task<List<MotorBought>> GetByYearOfMake(int yearOfMake)
        {
            return await Connection.Table<MotorBought>().Where(x => x.YearOfManufacture == yearOfMake).ToListAsync();
        }

        public async Task<int> SaveAsync(MotorBought motorBought)
        {
            return await Connection.InsertAsync(motorBought);
        }

        public async Task<int> UpdateAsync(MotorBought motorBought)
        {
            return await Connection.UpdateAsync(motorBought);
        }
    }
}
