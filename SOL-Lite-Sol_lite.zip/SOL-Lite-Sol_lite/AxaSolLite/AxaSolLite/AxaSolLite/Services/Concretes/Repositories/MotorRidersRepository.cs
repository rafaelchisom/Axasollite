﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class MotorRidersRepository : BaseRepository, IMotorRidersRepository
    {
        public MotorRidersRepository(IDBConnectionParameters dBConnectionParameters)
            : base(dBConnectionParameters)
        {

        }

        public async Task<MotorRiders> GetMotorRidersByMotorProductId(Guid motorProductId)
        {
            return await Connection.Table<MotorRiders>().Where(x => x.MotorProductId == motorProductId).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(MotorRiders model)
        {
            return await Connection.InsertAsync(model);
        }
    }
}
