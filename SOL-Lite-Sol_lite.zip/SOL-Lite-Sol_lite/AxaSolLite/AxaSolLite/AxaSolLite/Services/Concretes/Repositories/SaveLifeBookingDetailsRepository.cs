﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
   public class SaveLifeBookingDetailsRepository : BaseRepository, ISaveLifeBookingDetails
   {
        public SaveLifeBookingDetailsRepository(IDBConnectionParameters dBConnectionParameters)
            : base(dBConnectionParameters)
        {

        }
        public async Task<SaveBookingDetails> GetLifeBookingDetailsById(Guid id)
        {
            return await Connection.Table<SaveBookingDetails>().Where(x => x.Id == id).FirstOrDefaultAsync();
        }

        public async Task<SaveBookingDetails> GetLifeBookingDetailsByProductPlanId(Guid productPlanId)
        {
            return await Connection.Table<SaveBookingDetails>().Where(x => x.ProductPlanId == productPlanId).FirstOrDefaultAsync();
        }

        public async Task<int> UpdateAsync(SaveBookingDetails model)
        {
            return await Connection.UpdateAsync(model);
        }

        public async Task<int> SaveAsync(SaveBookingDetails model)
        {
            return await Connection.InsertAsync(model);
        }
   }
}
