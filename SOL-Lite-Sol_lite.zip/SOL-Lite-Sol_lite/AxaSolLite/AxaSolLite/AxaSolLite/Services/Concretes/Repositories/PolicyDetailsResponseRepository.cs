﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class PolicyDetailsResponseRepository : BaseRepository, IPolicyDetailsResponseRepository
    {
        public PolicyDetailsResponseRepository(IDBConnectionParameters dBConnectionParameters)
            : base(dBConnectionParameters)
        {

        }

        public async Task<List<PolicyDetailsResponseToSave>> GetListOfPolicyDetailsByProductPlan(Guid productPlanId)
        {
            return await Connection.Table<PolicyDetailsResponseToSave>().Where(x => x.ProductPlanId == productPlanId).ToListAsync();
        }

        public async Task<PolicyDetailsResponseToSave> GetPolicyDetailsByProductPlan(Guid productPlanId)
        {
            return await Connection.Table<PolicyDetailsResponseToSave>().Where(x => x.ProductPlanId == productPlanId).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(PolicyDetailsResponseToSave model)
        {
            return await Connection.InsertAsync(model);
        }

        public async Task<int> UpdateAsync(PolicyDetailsResponseToSave model)
        {
            return await Connection.UpdateAsync(model);
        }
    }
}
