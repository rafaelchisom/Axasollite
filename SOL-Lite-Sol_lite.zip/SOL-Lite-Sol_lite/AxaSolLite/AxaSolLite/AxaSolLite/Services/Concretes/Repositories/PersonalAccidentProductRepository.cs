﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class PersonalAccidentProductRepository : BaseRepository, IPersonalAccidentProductRepository
    {
        public PersonalAccidentProductRepository(IDBConnectionParameters dBConnectionParameters) : base(dBConnectionParameters)
        {

        }

        public async Task<PersonalAccidentRepositoryObject> GetPersonalAccidentProductByProductPlan(Guid productPlanId)
        {
            return await Connection.Table<PersonalAccidentRepositoryObject>().Where(x => x.ProductPlanId == productPlanId).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(PersonalAccidentRepositoryObject model)
        {
            return await Connection.InsertAsync(model);
        }

        public async Task<int> UpdateAsync(PersonalAccidentRepositoryObject model)
        {
            return await Connection.UpdateAsync(model);
        }
    }
}
