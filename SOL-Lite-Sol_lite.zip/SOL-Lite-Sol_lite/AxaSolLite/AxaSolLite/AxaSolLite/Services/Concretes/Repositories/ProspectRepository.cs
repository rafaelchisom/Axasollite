﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class ProspectRepository : BaseRepository, IProspectRepository
    {
        public ProspectRepository(IDBConnectionParameters dbConnectionParameters)
          : base(dbConnectionParameters)
        {
        }

        public async Task<List<EncryptedProspect>> GetAll()
        {
            return await Connection.Table<EncryptedProspect>().ToListAsync();
        }

        public async Task<List<Prospect>> GetAllByUserId(Guid userId, bool IncludeDeleted = false)
        {
            return await Connection.Table<Prospect>().Where(x => x.UserId == userId).ToListAsync();
        }

        public async Task<EncryptedProspect> GetByClientId(Guid clientId)
        {
            return await Connection.Table<EncryptedProspect>().Where(x => x.ProspectId == clientId).FirstOrDefaultAsync();
        }

        public async Task<EncryptedProspect> GetById(Guid Id)
        {
            return await Connection.Table<EncryptedProspect>().Where(x => x.ProspectId == Id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveProspectClientAsync(EncryptedProspect prospectClient)
        {
            return await Connection.InsertAsync(prospectClient);
        }

        public async Task<int> UpdateAsync(EncryptedProspect selectedProspect)
        {
            return await Connection.UpdateAsync(selectedProspect);
        }

        public async Task<int> UpdateAllAsync(List<EncryptedProspect> prospects)
        {
            return await Connection.UpdateAllAsync(prospects);
        }

        public async Task<List<Prospect>> GetProspectsByAgentId(int AgentId)
        {
            return await Connection.Table<Prospect>().Where(x => x.Agentid == AgentId).ToListAsync(); //intentionally didnt change this because it isn't really in use
        }

        public async Task<int> SaveAll(List<EncryptedProspect> prospects)
        {
            return await Connection.InsertAllAsync(prospects);
        }
    }
}
