﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class HealthPayloadRepository : BaseRepository, IHealthPayloadRepository
    {
        public HealthPayloadRepository (IDBConnectionParameters dBConnectionParameters)
            : base(dBConnectionParameters)
        {

        }

        public async Task<HealthBookingRequest> GetHealthPayloadByProductId(Guid productId)
        {
            return await Connection.Table<HealthBookingRequest>().Where(x => x.ProductId == productId).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(HealthBookingRequest payload)
        {
            return await Connection.InsertAsync(payload);
        }

        public async Task<int> UpdateAsync(HealthBookingRequest payload)
        {
            return await Connection.UpdateAsync(payload);
        }
    }
}
