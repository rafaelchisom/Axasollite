﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class ExtraTravellerRepository : BaseRepository, IExtraTravellerRepository
    {
        public ExtraTravellerRepository(IDBConnectionParameters dBConnectionParameters)
            :base(dBConnectionParameters)
        {

        }

        public async Task<List<ExtraTravellers>> GetAllExtraTravellers()
        {
            return await Connection.Table<ExtraTravellers>().ToListAsync();
        }

        public async Task<List<ExtraTravellers>> GetOtherTravellersByTravelProductId(Guid travelProductId)
        {
            return await Connection.Table<ExtraTravellers>().Where(x => x.TravelProductId == travelProductId).ToListAsync();
        }

        public async Task<int> SaveAllAsync(List<ExtraTravellers> model)
        {
            return await Connection.InsertAllAsync(model);
        }
    }
}
