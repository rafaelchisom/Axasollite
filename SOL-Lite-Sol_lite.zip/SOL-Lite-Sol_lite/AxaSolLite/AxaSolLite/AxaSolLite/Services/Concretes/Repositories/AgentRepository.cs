﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class AgentRepository : BaseRepository, IAgentRepository
    {
        public AgentRepository(IDBConnectionParameters dbConnectionParameters) : base(dbConnectionParameters)
        {
        }
        public async Task<int> SaveAsync(Agent model)
        {
            await Connection.DeleteAllAsync<Agent>();
            return await Connection.InsertAsync(model);
        }
        public async Task<int> SaveAllAsync(List<Agent> model)
        {
            return await Connection.InsertAllAsync(model);
        }
        public async Task<Agent> GetAgent(Guid param)
        {
            return await Connection.Table<Agent>().Where(x => x.Id == param).FirstOrDefaultAsync();
        }
        public async Task<Agent> GetAgentByAgentId(Guid AgentId)
        {
            return await Connection.Table<Agent>().Where(x => x.Id == AgentId).FirstOrDefaultAsync();
        }
        public async Task<List<Agent>> GetAgents()
        {
            return await Connection.Table<Agent>().ToListAsync();
        }
        public async Task<int> UpdateAsync(Agent model)
        {
            return await Connection.UpdateAsync(model);
        }
        public async Task<Agent> GetByName(string username)
        {
            return await Connection.Table<Agent>().Where(x => x.PssUsername == username).FirstOrDefaultAsync();
        }
    }
}
