﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class StatesRepository : BaseRepository, IStatesRepository
    {
        public StatesRepository(IDBConnectionParameters dbConnectionParameters)
            : base(dbConnectionParameters)
        {

        }

        public async Task<List<States>> GetAllStates()
        {
            return await Connection.Table<States>().ToListAsync();
        }

        public async Task<States> GetStateCodeByState(string state)
        {
            return await Connection.Table<States>().Where(x => x.State == state).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAll(List<States> model)
        {
            
            return await Connection.InsertAllAsync(model);
        }
    }
}
