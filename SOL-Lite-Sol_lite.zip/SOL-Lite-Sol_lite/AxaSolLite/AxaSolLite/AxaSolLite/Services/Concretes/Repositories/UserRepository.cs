﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class UserRepository : BaseRepository, IUserRepository
    {
        public UserRepository(IDBConnectionParameters dbConnectionParameters)
            : base(dbConnectionParameters)
        {
        }

        public async Task<User> GetById(Guid userId)
        {
            return await Connection.Table<User>().Where(x => x.Id == userId).FirstOrDefaultAsync();
        }

        public async Task<User> GetByName(string username)
        {
            return await Connection.Table<User>().Where(x => x.UserName == username).FirstOrDefaultAsync();
        }

        public async Task<int> Update(User user)
        {
            return await Connection.UpdateAsync(user);
        }

        public async Task<int> SaveAsync(User user)
        {
            return await Connection.InsertAsync(user);
        }
    }
}
