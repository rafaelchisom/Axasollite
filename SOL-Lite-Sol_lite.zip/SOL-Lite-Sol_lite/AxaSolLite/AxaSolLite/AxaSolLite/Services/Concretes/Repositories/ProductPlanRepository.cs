﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class ProductPlanRepository : BaseRepository, IProductPlansRepository
    {
        public ProductPlanRepository(IDBConnectionParameters dbConnectionParameters) : base(dbConnectionParameters)
        {
        }
        public async Task<int> SaveAsync(ProductPlan model)
        {
            return await Connection.InsertAsync(model);
        }
        public async Task<int> SaveAllAsync(List<ProductPlan> model)
        {
            return await Connection.InsertAllAsync(model);
        }
        public async Task<ProductPlan> GetProductPlan(Guid param)
        {
            return await Connection.Table<ProductPlan>().Where(x => x.Id == param).FirstOrDefaultAsync();
        }
        public async Task<ProductPlan> GetProductPlanByProductPlanId(Guid ProductPlanId)
        {
            return await Connection.Table<ProductPlan>().Where(x => x.Id == ProductPlanId).FirstOrDefaultAsync();
        }
        public async Task<List<ProductPlan>> GetProductPlansByProspectId(Guid ProspectId)
        {
            return await Connection.Table<ProductPlan>().Where(x => x.ProspectId == ProspectId).ToListAsync();
        }
        public async Task<List<ProductPlan>> GetProductPlans()
        {
            return await Connection.Table<ProductPlan>().ToListAsync();
        }
        public async Task<int> UpdateAsync(ProductPlan model)
        {
            return await Connection.UpdateAsync(model);
        }
    }
}
