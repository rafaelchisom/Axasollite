﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Repositories
{
    public class SyncDateRepository : BaseRepository, ISyncDateRecordRepository
    {
        public SyncDateRepository(IDBConnectionParameters dBConnectionParameters)
            : base(dBConnectionParameters)
        {

        }

        public async Task<List<SyncDate>> GetSyncDates()
        {
            return await Connection.Table<SyncDate>().ToListAsync();
        }

        public async Task<int> SaveSyncDate(SyncDate date)
        {
            return await Connection.InsertAsync(date);
        }
    }
}
