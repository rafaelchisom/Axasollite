﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Managers
{
    public class ValidationService : IValidationService
    {
        #region FIELDS

        private const string EmailRegex = @"^(?("")("".+?(?<!\\)""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
             @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$";

        private const string GenderRegex = @"^[0-1]$";

        private const string NumericRegex = @"^(\d{7}|\d{11})$";

        private const string PasswordRegex = @"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^\w\s]).{8,}$";

        private const string RelationshipRegex = @"^[1-6]$";

        private const string validText = @"^[a-zA-Z]+$";

        #endregion FIELDS

        public IDictionary<string, string> ValidateProspect(Prospect prospect)
        {
            var errors = new Dictionary<string, string>();

            if (string.IsNullOrEmpty(prospect.FirstName)
                || string.IsNullOrWhiteSpace(prospect.FirstName))
            {
                errors.Add("FirstName", "Please input a First Name");
            }
            else if(!Regex.IsMatch(prospect.FirstName, validText))
            {
                errors.Add("FirstName", "First name in a wrong format");
            }
            if (!string.IsNullOrEmpty(prospect.MiddleName) && !Regex.IsMatch(prospect.MiddleName, validText))
            {
                errors.Add("MiddleName", "Middle name in a wrong format");
            }
            if (string.IsNullOrEmpty(prospect.LastName)
                || string.IsNullOrWhiteSpace(prospect.LastName))
            {
                errors.Add("LastName", "Please input a Last Name");
            }
            else if (!Regex.IsMatch(prospect.LastName, validText))
            {
                errors.Add("LastName", "Last name in a wrong format");
            }
            if (string.IsNullOrEmpty(prospect.Email)
                || !Regex.IsMatch(prospect.Email, EmailRegex, RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(250)))
            {
                errors.Add("Email", "Please input a valid e-mail");
            }
            if (string.IsNullOrEmpty(prospect.MobileNumber)
                || !Regex.IsMatch(prospect.MobileNumber, NumericRegex, RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250)))
            {
                errors.Add("MobileNumber", "Please input a valid mobile number");
            }
            if (!Regex.IsMatch(prospect.Gender.ToString(), GenderRegex, RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250)))
            {
                errors.Add("Gender", "Please input a gender");
            }
            if (prospect.Age < 18 || prospect.Age > 99)
            {
                errors.Add("Birthdate", "Please input a valid birthdate");
            }
            return errors;
        }

        public bool ValidatePasswordPattern(string password)
        {
            bool isValid = IsMatched(password, PasswordRegex);
            return isValid;
        }

        public bool ValidateEmailPattern(string email)
        {
            bool isValid = IsMatched(email, EmailRegex);
            return isValid;
        }

        private bool IsMatched(string comparator, string regexPattern)
        {
            bool isMatched = Regex.IsMatch(comparator, regexPattern, RegexOptions.IgnorePatternWhitespace, TimeSpan.FromMilliseconds(250));

            return isMatched;
        }

        public async Task<bool> IsValidEmail(string email)
        {
            try
            {
                if (Regex.IsMatch(email, EmailRegex, RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250)))
                {
                    return true;
                }
                else
                    return false;
            }
            catch(Exception)
            {
                return false;
            }
        }

        public async Task<bool> IsValidPhoneNumber(string mobileNumber)
        {
            try
            {
                if (Regex.IsMatch(mobileNumber, NumericRegex, RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250)))
                {
                    return true;
                }
                else
                    return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }

}
