﻿using AxaSolLite.Services.Contracts;
using System;

namespace AxaSolLite.Services.Concretes.Managers
{
    public class CalculatorService : ICalculatorService
    {
        public decimal ConvertStringToDecimal(string input)
        {
            var output = 0M;

            if (input == string.Empty || string.IsNullOrWhiteSpace(input))
            {
                return output;
            }
            try
            {
                return Convert.ToDecimal($"{Convert.ToDecimal(input):N2}");
            }
            catch (Exception)
            {
                return output;
            }
        }

        public decimal ConvertToPercentEquivalentDecimal(int input)
        {
            var output = 0M;

            try
            {
                output = Convert.ToDecimal($"{(input / 100M):N2}");

                return output;
            }
            catch (Exception)
            {
                return output;
            }
        }

        public decimal ConvertToPercentEquivalentDecimal(decimal input)
        {
            var output = 0M;

            try
            {
                output = Convert.ToDecimal($"{(input / 100M):N2}");

                return output;
            }
            catch (Exception)
            {
                return output;
            }
        }

        public int GetAgeInYears(DateTime birthDate)
        {
            return DateTime.Now.Year - birthDate.Year;
        }

        public int GetInsuranceAge(DateTime birthDate, DateTime? computationStartDate = null)
        {
            if (computationStartDate == null)
            {
                computationStartDate = DateTime.Now;
            }

            int yearDifference = DateTime.Now.Year - birthDate.Date.Year;

            if (DateTime.IsLeapYear(birthDate.Year) && !DateTime.IsLeapYear(DateTime.Now.Year))
            {
                birthDate = birthDate.AddDays(1);
            }

            DateTime currentBirthdate = birthDate.AddYears(yearDifference);

            DateTime nextBirtdate = currentBirthdate.AddYears(1);

            DateTime lastYearBirtdate = currentBirthdate.AddYears(-1);

            var xDate = new DateTime();
            var xDate1 = new DateTime();

            TimeSpan xDayDuration1;
            TimeSpan xDayDuration2;

            if (currentBirthdate.Month > DateTime.Now.Month
                || currentBirthdate.Month == DateTime.Now.Month
                && currentBirthdate.Day >= DateTime.Now.Day)
            {
                xDate = lastYearBirtdate;
                xDayDuration1 = currentBirthdate - DateTime.Now;
                xDayDuration2 = DateTime.Now - xDate;
            }
            else
            {
                xDate = nextBirtdate;
                xDayDuration1 = DateTime.Now - currentBirthdate;
                xDayDuration2 = xDate - DateTime.Now;
            }

            if (xDayDuration1 > xDayDuration2)
            {
                xDate1 = xDate;
            }
            else
            {
                xDate1 = currentBirthdate;
            }

            int age = xDate1.Year - birthDate.Year;

            if (age < 1)
            {
                age = 1;
            }

            return age;
        }

        public decimal GetRound(decimal value, int leftSignificant = 2)
        {
            //will round up to first two digits
            //eg. 1234567890 will become 1200000000
            decimal valueDigits = Math.Round(Math.Abs(value), 0).ToString().Length - leftSignificant;
            decimal roundTo = 10;

            for (int x = 1; x < valueDigits; x++)
            {
                roundTo *= 10;
            }

            decimal ExcessAmount = value % roundTo;
            if (ExcessAmount >= roundTo / 2)
            {
                value = value - ExcessAmount + roundTo;
            }
            else
            {
                value = value - ExcessAmount;
            }

            return value;
        }

        public decimal GetRoundUp(decimal value, int leftSignificant = 2)
        {
            //will round up to first two digits
            //eg. 1234567890 will become 1200000000
            decimal valueDigits = Math.Round(Math.Abs(value), 0).ToString().Length - leftSignificant;
            decimal roundTo = 10;

            for (int x = 1; x < valueDigits; x++)
            {
                roundTo *= 10;
            }

            decimal excessAmount = value % roundTo;
            if (excessAmount < (roundTo / 2))
            {
                value -= excessAmount;
            }
            else
            {
                value += roundTo - excessAmount;
            }

            return value;
        }

        public decimal GetRoundUp2(decimal value, int leftSignificant = 2)
        {
            //will round up to first two digits
            //eg. 1234567890 will become 1200000000
            decimal valueDigits = Math.Round(Math.Abs(value), 0).ToString().Length - leftSignificant;
            decimal roundTo = 10;

            for (int x = 1; x < valueDigits; x++)
            {
                roundTo *= 10;
            }

            decimal ExcessAmount = value % roundTo;
            if (ExcessAmount > 0)
            {
                value = value - ExcessAmount + roundTo;
            }

            return value;
        }

        public bool IsDependent(DateTime birthDate)
        {
            int age = GetInsuranceAge(birthDate);

            if (age > 0 && age < 12)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public decimal RoundToCeilingHundreds(decimal number)
        {
            return Math.Ceiling(number / 100M) * 100;
        }

        public decimal RoundToNearestHundreds(decimal number)
        {
            return Math.Round(number / 100M, 0) * 100;
        }

        public decimal RoundUpHundredths(decimal number)
        {
            string strNumber = number.ToString("N5");
            int decimalPointIndex = strNumber.IndexOf(".");
            char tenth = strNumber[decimalPointIndex + 1];
            char hundredth = strNumber[decimalPointIndex + 2];
            char thousandth = strNumber[decimalPointIndex + 3];

            number = Math.Truncate(100 * number);

            if (!(tenth == '0' && hundredth == '0' && thousandth == '0'))
            {
                if (thousandth != '0')
                {
                    ++number;
                }
            }

            number = number / 100;

            return number;
        }

        public int GetAgeAtNextBirthday(DateTime Birthdate)
        {
            int Age = 0;    
            try
            {
                Age = DateTime.Today.Year - Birthdate.Year;
                var rr = DateTime.Today.AddYears(-Age);
                if ((Birthdate < rr))
                    Age += 1;
            }
            catch (Exception)
            {
                throw;
            }
            return Age;
        }
    }
}
