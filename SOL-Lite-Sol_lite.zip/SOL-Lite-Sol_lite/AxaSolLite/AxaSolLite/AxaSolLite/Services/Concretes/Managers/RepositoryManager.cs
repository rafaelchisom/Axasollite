﻿using System;
using System.Threading.Tasks;
using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using SQLite;

namespace AxaSolLite.Services.Concretes.Managers
{
    public class RepositoryManager : IRepositoryManager 
    {
        private readonly IDBConnectionParameters _dbConnectionParameters;
        private readonly SQLiteAsyncConnection _connection;

        public bool IsInitialized { get; private set; }

        public RepositoryManager(IDBConnectionParameters dbConnectionParameters)
        {
            _dbConnectionParameters = dbConnectionParameters;
            IsInitialized = false;
            _connection = SQLiteDatabase.GetConnection(_dbConnectionParameters);
        }

        public async Task<bool> Initialize()
        {
            try
            {
                if (!IsInitialized)
                {
                    try
                    {
                        await _connection.CreateTableAsync<EncryptedProspect>();
                        await _connection.CreateTableAsync<Titles>();
                        await _connection.CreateTableAsync<States>();
                        await _connection.CreateTableAsync<Countries>();
                        await _connection.CreateTableAsync<MotorProduct>();
                        await _connection.CreateTableAsync<MotorRiders>();
                        await _connection.CreateTableAsync<ProductPlan>();
                        await _connection.CreateTableAsync<Agent>();
                        await _connection.CreateTableAsync<Documents>();
                        await _connection.CreateTableAsync<SaveBookingDetails>();
                        await _connection.CreateTableAsync<SyncDate>();
                        await _connection.CreateTableAsync<Branches>();
                        await _connection.CreateTableAsync<GenBizBranch>();
                        await _connection.CreateTableAsync<TravelProduct>();
                        await _connection.CreateTableAsync<ExtraTravellers>();
                        await _connection.CreateTableAsync<EmarketingStatus>();
                        await _connection.CreateTableAsync<HealthBookingRequest>();
                        await _connection.CreateTableAsync<PolicyDetailsResponseToSave>();
                        await _connection.CreateTableAsync<SerializedMotorRenewalObject>();
                        await _connection.CreateTableAsync<PersonalAccidentRepositoryObject>();
                        await _connection.CreateTableAsync<MotorBought>();
                        IsInitialized = true;
                    }
                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                IsInitialized = false;
            }
            return IsInitialized;
        }
    }
}
