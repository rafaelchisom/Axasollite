﻿
namespace AxaSolLite.Services.Concretes.Managers
{
    public class AxaSolUrls
    {
        static string BaseUrl2 = "https://online.axamansard.com/AXASalesProcessor/";
        static string BaseUrl = "https://careers.axamansard.com/AXASalesProcessor/";

        //static string LocalBaseUrl = "http://localhost:52190/";  //tech-sys33.axamansard.com/AxaSalesProcessor/";

        public static string SignIn = BaseUrl2 + "api/Dmt/SignIn"; //LIVE!!!!!!!!!!!!!!!!
        public static string InitiatePayStackPayment = BaseUrl + "api/Dmt/InitiatePayStackPaymentAsyncTest"; //LIVE!!!!!!!!!!!!!
        public static string VerifyPayStackPayment = BaseUrl + "api/Dmt/VerifyPayStackTransactionAsyncTest"; //LIVE!!!!!!!!!!!!!

        public static string ExternalAgentSignIn = BaseUrl + "api/Dmt/ExternalAgentSignInResponseAsync";
        public static string UpdateExternalAgentPassword = BaseUrl + "api/Dmt/UpdateExternalAgentResponseAsync";
        public static string GetOTP = BaseUrl + "api/Dmt/GetOTPResponseAsync";
        public static string ChangePassword = BaseUrl + "api/Dmt/ChangePasswordAsync";
        public static string PssAgentDetails = BaseUrl + "api/Dmt/GetAgentDetailsResponse";
        public static string EppCalculator = BaseUrl + "api/Dmt/getEPPCalculatorAsync";
        public static string SearchCustomer = BaseUrl + "api/Dmt/GetSearchCustomerResponse";
        public static string getTravelCost = BaseUrl2 + "api/Dmt/GetTravelCost";
        public static string getDigitalCredentials = BaseUrl2 + "api/Dmt/GetDigitalAPIDetails";
        public static string getHealthCredentials = BaseUrl + "api/Dmt/GetHealthAPICredentials";
        public static string getHealthAPICredentials = BaseUrl2 + "api/Dmt/GetHealthAPICredentials";

        public static string generalBizPdfCert = BaseUrl + "api/Booking/GeneralBizPdfCertificate";
        public static string InstantPlanPdfCert = BaseUrl + "api/Booking/GenerateInstantPlanPdfCertificate";
        public static string BonusLifePdfCert = BaseUrl + "api/Booking/GenerateBonusLifeSoftCopyCert";
        public static string AmbitionsCert = BaseUrl2 + "api/Booking/GenerateAmbitionsCertificate";
        public static string LifePlusCert = BaseUrl2 + "api/Booking/GenerateLifePlusCertificate";
        public static string EduPlanPdfCert = BaseUrl + "api/Booking/GenerateEduPlanPdfCertificate";
        public static string lifesavingsPdfCert = BaseUrl + "api/Booking/GenerateLifesavingsPdfCertificate";
        public static string customerOnboarding = BaseUrl + "api/Dmt/CustomerOnboarding"; //BaseUrl + "api/Dmt/CustomerOnboarding";
        public static string customerOnboardingCase = BaseUrl + "api/Dmt/CustomerOnboardingCase";
        //public static string verifyOnboardingStatus = BaseUrl + "api/Dmt/GetCaseIdStatus?appuid=";
        public static string accountCreationForm = BaseUrl + "api/Dmt/AccountOpeningForm";
        public static string customerOnboardingMail = BaseUrl + "api/Dmt/CustomerOnboardingEmail";
        public static string MaxAndMinBenefit = BaseUrl2 + "api/dmt/api/PMGateway/calculateFunerally";
        public static string getBankList = BaseUrl2 + "api/dmt/getBankListAsync";
        public static string calculateBonusLifePremium = BaseUrl2 + "api/Dmt/CalculateBonusLifePremium"; 
        public static string GeneralBusinessBooking = BaseUrl + "api/policybooking/genbiz";
        public static string TravelBooking = BaseUrl + "api/Booking/TravelBooking";
        public static string travelCertificate = BaseUrl2 + "api/Dmt/PrintTravelCertificate";
        public static string getQuote = BaseUrl + "api/QuoteSystem/PostQuoteRequest";
        public static string quoteIdMail = BaseUrl + "api/Dmt/QuoteIdMail";
        public static string saveBookingDetails = BaseUrl + "api/Dmt/InsertBookingDetailsIntoDB";
        public static string getProspectTitles = BaseUrl + "api/Dmt/GetProspectTitles";
        public static string getCountryList = BaseUrl + "api/Dmt/GetCountryList";
        public static string getNationalities = BaseUrl + "api/Dmt/GetNationalities";
        public static string getStatesByCountryId = BaseUrl2 + "api/Dmt/GetStateList?countryId=";
        public static string getPolicyClass = BaseUrl2 + "api/Dmt/GetPolicyClass";
        public static string getPolicyTypeByClassCode = BaseUrl2 + "api/Dmt/GetPolicyTypeByClassId?classId=";
        public static string getMotorMakes = BaseUrl2 + "api/Dmt/GetMotorMakes";
        public static string getMotorModelByMakeId = BaseUrl2 + "api/Dmt/GetMotorModelsByMakeId?makeId=";
        public static string GetPolicyId = BaseUrl + "api/Dmt/getPolicyIdAsync";
        public static string MotorTruePrice = BaseUrl2 + "api/Dmt/GetMotorTruePrice";
        public static string AutoGoBooking = BaseUrl + "api/Booking/AutoGoBooking";
        public static string getMotorRidersByPolicyTypeId = BaseUrl + "api/Dmt/GetMotorRiders?policyTypeId=";
        public static string generateMotorSummaryPdf = BaseUrl2 + "api/Dmt/CreateMotorSummaryPdf";
        public static string sendBookingcaseId = BaseUrl2 + "api/Dmt/PolicyCaseIdMail";
        public static string getBookingDetailsByAgentCode = BaseUrl + "api/Dmt/FilterBookingLogByAgentCode?agentCode=";
        public static string logBookingDetails = BaseUrl + "api/Dmt/LogBookingDetails";
        public static string insertProspectDetails = BaseUrl + "api/Dmt/InsertProspectIntoDB";
        public static string updateProspectDetails = BaseUrl + "api/Dmt/UpdateProspectDetails";
        public static string confirmOnboardingCaseCreated = BaseUrl + "api/Dmt/ConfirmOnboardingCaseCreation";
        public static string getProspectsByAgentCode = BaseUrl + "api/Dmt/GetProspectsByAgentCode?agentCode=";
        public static string getProspectDetails = BaseUrl + "api/Dmt/GetProspectDetails";
        public static string saveCertificateDetails = BaseUrl + "api/Dmt/InsertCertificateDetailsIntoDB";
        public static string savePaymentReference = BaseUrl + "api/Dmt/InsertPaymentReferenceIntoDB";
        public static string saveQuoteId = BaseUrl + "api/Dmt/InsertQuoteIdIntoDB";
        public static string GetMonthlyDashboardForPss = BaseUrl + "api/Dmt/GetMonthlyDashboardForPss?Year=&Month=&PssUsername=";
        public static string GetMonthlyDashboardForTeamManagers = BaseUrl + "api/Dmt/GetMonthlyDashboardForTeamManagers?Year=&Month=&Username=";
        public static string GetMonthlyDashboardForAdvisors = BaseUrl + "api/Dmt/GetMonthlyDashboardForAdvisors?Year=&Month=&Username=";
        public static string GetYearToDateDashboardForPss = BaseUrl + "api/Dmt/GetYearToDateDashboardForPss?Year=&Month=&PssUsername=";
        public static string GetYearToDateDashboardForTeamManagers = BaseUrl + "api/Dmt/GetYearToDateDashboardForTeamManagers?Year=&Month=&Username=";
        public static string GetYearToDateDashboardForAdvisors = BaseUrl + "api/Dmt/GetYearToDateDashboardForAdvisors?Year=&Month=&Username=";
        public static string GetTeamManagerDetails = BaseUrl + "api/Dmt/GetTeamManagersDetailsByAgentcode?AgentCode=";
        public static string GetAdvisorDetails = BaseUrl2 + "api/Dmt/GetAdvisorsDetailsByAgentcode?AgentCode=";
        public static string getCustomerDetailsByCustomerNumber = BaseUrl + "api/Dmt/GetCustomerDetailsByCustomerNumber?customerNumber=";
        public static string getSBUDetails = BaseUrl + "api/Dmt/GetSBUDetails";
        public static string getPolicyProcessingDetails = BaseUrl + "api/Dmt/GetPolicyProcessingDetailsBySBU?sbuCode=";
        public static string generateLifePdfDocs = BaseUrl2 + "api/Booking/GenerateNMQandProposalForm"; //LIVE!!!!!!!!!!!!!!!!!!!
        public static string bookLifePolicy = BaseUrl + "api/Booking/BookLifePolicy";

        public static string InstanPlanQuoteApi = "https://api.axamansard.com/api/insurance/Life/instant-plan/quote"; //BaseUrl + "api/DMT/GetNewInstantPlanQuotes?obj=";
        public static string AxamansardAPI_token = "https://online.axamansard.com/AXASalesProcessor/api/DMT/GetAxaMansardAPIToken"; //"https://api.axamansard.com/api/tokens";
        public static string getAllInstantPlanQuote = BaseUrl2 + "api/Dmt/GetInstantPlanQuote";
        public static string AxamansardAPI_User = "AXASOL";
        public static string AxamansardAPI_Pass = "TnRpULV4_niIAstlv0ou6p@gkuulLkzVm7hov^OStCTA";
        public static string getDSAsUnderPsS = BaseUrl + "api/Dmt/x";
        public static string EpaymentMail = BaseUrl + "api/Dmt/EpaymentMail";
        public static string FeedbackMail = BaseUrl + "api/Dmt/FeedBackMail";
        public static string LoginAuditTrail = BaseUrl + "api/Dmt/InsertLoginAuditTrailIntoDB";
        public static string checkExistingUser = BaseUrl + "api/Dmt/CheckNewUserSignIn?username=";
        public static string getBranches = BaseUrl + "api/Dmt/GetBranches?type=";
        public static string tokenCredentials = BaseUrl + "api/Dmt/GetInstantPlanTokenCredentials";
        public static string ReferralLinkMail = BaseUrl + "api/Dmt/ReferralLink";
        public static string ValidateAgentAuthToken = BaseUrl + "api/Dmt/ValidateAgentAuthToken";
        public static string InsertAgentAuthTokenIntoDB = BaseUrl + "api/Dmt/InsertAgentAuthTokenIntoDB";
        public static string DeleteAgentAuthTokenIntoDB = BaseUrl + "api/Dmt/DeleteAgentAuthTokenIntoDB";
        public static string getTravelDestinations = BaseUrl2 + "api/Dmt/GetDigitalTravelDestinations";
        public static string getTravelVariants = BaseUrl + "api/Dmt/GetTravelVariantsByPlanTypeAndDestination?";
        public static string getTraveRIPlanSample = BaseUrl + "api/Dmt/GetTravelRIObject";
        public static string InsertPaymentDetails = BaseUrl + "api/Dmt/InsertPaymentDetailsIntoDB";
        public static string updateCustomerWithAimsRecord = BaseUrl + "api/Dmt/UpdateCustomerInformationWithAimsRecord";
        public static string getCities = BaseUrl + "api/Dmt/GetCities?stateCode=";
        public static string getAmbitionReasons = BaseUrl + "api/Dmt/GetReasonsForAmbition";
        public static string EformLinkMail = BaseUrl + "api/Dmt/EformLink";
        public static string InsertPaperFnaIntoDB = BaseUrl + "api/Dmt/InsertPaperFnaIntoDB";
        public static string RegisterBearerToken = BaseUrl + "api/Account/Register";
        public static string TokenGeneration = BaseUrl + "api/Dmt/DecryptAndGenerateToken";
        public static string LifeSavingsQuote = BaseUrl + "api/Dmt/LifeSavingsQuote";
        public static string getEFormsProducts = BaseUrl + "api/Dmt/GetProductsForEForms";
        //public static string getAllInstantPlanQuote = BaseUrl + "api/Dmt/GetInstantPlanQuote";
        public static string TestorLive = BaseUrl;
        public static string getReferralLinkBaseUrl = BaseUrl + "api/Dmt/GetReferralLinkBaseUrl";
        public static string SavedBookingRequest = BaseUrl + "api/Dmt/SavedBookingRequest";
        public static string getEformsLinkBaseUrl = BaseUrl + "api/Dmt/GetEformsBaseUrl";
        public static string InitiatePayStackPaymentTest = BaseUrl + "api/Dmt/InitiatePayStackPaymentAsyncTest";
        public static string VerifyPayStackPaymentTest = BaseUrl + "api/Dmt/VerifyPayStackTransactionAsyncTest";
        public static string GenerateEppProjectionSheet = BaseUrl2 + "api/Booking/GenerateEppProjectionSheet";
        public static string GenerateLifePlusProjectionSheet = BaseUrl + "api/Booking/GenerateLifePlusProjectionSheet";
        public static string GetPaymentResponse = BaseUrl + "api/Dmt/GetPaymentResponseAsync?quoteid=";
        public static string logReferralRate = BaseUrl + "api/Dmt/InsertReferralRate";
        public static string logAgentComplaint = BaseUrl + "api/Dmt/InsertProcessEfficiency";
        public static string logFeatureUsage = BaseUrl + "api/Dmt/InsertFeatureUsage";
        public static string getOccupationList = BaseUrl + "api/Dmt/GetOccupationList";
        public static string UpdateProductLog = BaseUrl + "api/Dmt/UpdateProductLogData";
        public static string SelectProductLog = BaseUrl + "api/Dmt/GetProductLogData?tableName=&parentId=";
        public static string InsertProductLog = BaseUrl + "api/Dmt/InsertProductLogData";
        public static string EmarketingMail = BaseUrl + "api/Dmt/Emarketing";
        public static string verifyOnboardingStatus = BaseUrl + "api/Dmt/GetCaseIdStatus?caseid=";
        public static string encryptValue = BaseUrl + "api/Dmt/GetEncryptValue?value=";
        public static string personalAccidentCalculator = BaseUrl + "api/Dmt/CalculatePersonalAccidentPremium";
        public static string bookPersonalAccident = BaseUrl + "api/Booking/BookPersonalAccident";
        public static string PaperFNAMail = BaseUrl + "api/Dmt/PaperFnaMail";
        public static string CashbackQuote = BaseUrl2 + "api/Dmt/Cashbackquote";
        public static string gracePeriodUrl = BaseUrl + "api/Dmt/GetGracePeriod";
        public static string onyxURL = BaseUrl + "api/Dmt/OnyxCarValue";
        public static string getBeneficiaryRelationship = BaseUrl + "api/Dmt/GetBeneficiaryRelationships";
        public static string GenerateBonusLifeProjectionSheet = BaseUrl2 + "api/Booking/GenerateBonusLifeProjectionSheet";
        public static string GenerateBonusLifeProjectionValues = BaseUrl2 + "api/Dmt/BonusLifeProjectionValues";
        public static string getCustomerDetailsByCustomerName = BaseUrl + "api/Dmt/GetCustomerDetailsByCustName?Custname=";
        public static string getPolicyDetailsByCustomerNumber = BaseUrl + "api/Dmt/GetPolicyDetailsByCustNumber?Custnumber=";
        public static string getPolicyDetailsByPolicyNumber = BaseUrl + "api/Dmt/GetPolicyDetailsByPolicyNumber?policyId=";
        public static string renewMotorPolicy = BaseUrl + "api/Booking/RenewMotorPolicy";
        public static string getCarColors = BaseUrl + "api/Dmt/GetCarColors";
        public static string getNINDetails = BaseUrl + "api/Dmt/GetNinDetails";
        public static string InsertCustomerSignature = BaseUrl + "api/Dmt/InsertCustomerSignature";
        public static string GenerateLeadAccount = BaseUrl + "api/Dmt/GenerateLeadAccout";
        public static string InsertNewPaymrntDetails = BaseUrl + "api/Dmt/InsertNewPaymentDetailsIntoDB";
        public static string getCustomerAccountBalance = BaseUrl + "api/Dmt/GetCustomerAccountBalance?customerNumber=";
        public static string getLeadAccountStatus = BaseUrl + "api/Dmt/GetLeadAccountStatus?customerNumber=";
        public static string SendLeadAccountMail = BaseUrl + "api/Dmt/SendLeadAccountMail";
        public static string SendPaymentNotificationMail = BaseUrl + "api/Dmt/SendPaymentNotificationMail";

        public static string UpdateCustomerAccount = "https://careers.axamansard.com/API.Liquidations/api/Updates/updatecustomerdetails"; //BaseUrl2 + "api/Dmt/UpdateCustomerDetails";
        public static string SendCompleteEkycMail = BaseUrl + "api/Dmt/";
        public static string getGracePeriod = BaseUrl + "api/Dmt/GetGracePeriod";
        public static string editProspectInfo = BaseUrl + "api/Dmt/EditProspectInformation";
        public static string sendPersonalAccidentCert = BaseUrl + "api/Booking/SendPersonalAccidentCertificate";
        public static string EkycReport = BaseUrl + "api/Dmt/EkycReport";
        public static string UpdateEkycStatus = BaseUrl + "api/Dmt/UpdateEkycReport";
        public static string getTravelQuotes = "https://www.axamansard.com/webapis/api/insurance/Travel/travel-plan-cost/";
        public static string getTravelQuoteKey = BaseUrl2 + "api/Dmt/GetTravelQuotes";
        public static string GetUserAccountStatus = BaseUrl + "api/Dmt/GetUserAccountStatusByUsername?Username=";
        public static string InsertUserAccountStatus = BaseUrl + "api/Dmt/InsertUserAccountStatus";
        public static string UpdateUserAccountStatus = BaseUrl + "api/Dmt/UpdateUserAccountStatus?Username=";
        public static string getAAMDetailsByAdvisorsCode = BaseUrl + "api/Dmt/GetAAMDetailsByAdvisorsCode?AgentCode=";
        public static string getApprovalLogByCaseId = BaseUrl + "api/Dmt/GetApprovalLogByCaseId?CaseId=";
        public static string getApprovalLogByAgentCode = BaseUrl + "api/Dmt/GetApprovalLogByAgentCode?AgentCode=";
        public static string InsertApprovalLog = BaseUrl + "api/Dmt/InsertApprovalLog";
        public static string UpdateApprovalLog = BaseUrl + "api/Dmt/UpdateApprovalLog";
        public static string SendApprovalMail = BaseUrl + "api/Dmt/SendApprovalMail";
        public static string SendApprovalRequestMail = BaseUrl + "api/Dmt/SendApprovalRequestMail";
        public static string getNaicomId = BaseUrl + "api/Booking/GetNaicomId";
        public static string SendHealthApprovalMail = BaseUrl2 + "api/Dmt/SendHealthApprovalMail";
        public static string BVNVerify = BaseUrl2 + "api/Dmt/VerifyBVN";
        public static string InvestmentClient = BaseUrl2 + "api/Dmt/CreateInvestmentClient";
        public static string getPaystackBanks = BaseUrl2 + "api/Dmt/getPayStackBankList";
        public static string syncInHealthProposalQuestions = BaseUrl + "api/Dmt/GetHealthProposalQuestions";
        public static string getName = BaseUrl + "api/Dmt/GetName";
    }
}



