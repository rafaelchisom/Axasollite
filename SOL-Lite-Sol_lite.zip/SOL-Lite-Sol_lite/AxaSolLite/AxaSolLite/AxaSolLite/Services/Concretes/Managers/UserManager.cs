﻿using AxaSolLite.Models;
using AxaSolLite.Services.Contracts;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Managers
{
    public class UserManager : BindableBase, IUserManager
    {
        #region FIELDS

        private IUserRepository _userRepository;
        //private ILoggingServices _loggingServices;
        //private IPasswordHashManager _passwordHashManager;
        //private IAppConfigurationManager _appConfigurationServices;
        //private ITelemetryRepository _telemetryRepository;
        //private IDeviceSessionManager _deviceManager;

        private Guid _id;
        private int _agentId;
        private int _roleId;
        private string _userName;
        private string _LastName;
        private string _FirstName;
        private byte[] _agentProfilePicture;
        private bool _IsLoggedIn;
        private bool _RequiresPIN;
        private string _ResponseToken;
        private DateTime _DateLastLogin;
        private DateTime _DateLastActivity;
        private DateTime _LastSyncDate;

        #endregion FIELDS

        #region PROPERTIES

        public Guid Id
        {
            get { return _id; }
            set { SetProperty(ref _id, value); }
        }

        public string FirstName
        {
            get { return _FirstName; }
            set { SetProperty(ref _FirstName, value); }
        }

        public string LastName
        {
            get { return _LastName; }
            set { SetProperty(ref _LastName, value); }
        }

        public string UserName
        {
            get { return _userName; }
            set { SetProperty(ref _userName, value); }
        }

        public string FullName
        {
            get { return _FirstName + " " + _LastName; }
        }

        public bool IsLoggedIn
        {
            get { return _IsLoggedIn; }
            private set { SetProperty(ref _IsLoggedIn, value); }
        }

        public bool RequiresPIN
        {
            get { return _RequiresPIN; }
            private set { SetProperty(ref _RequiresPIN, value); }
        }

        public string RequestToken
        {
            get { return _ResponseToken; }
            set { SetProperty(ref _ResponseToken, value); }
        }

        public DateTime DateLastLogin
        {
            get { return _DateLastLogin; }
            private set { SetProperty(ref _DateLastLogin, value); }
        }

        public DateTime DateLastActivity
        {
            get { return _DateLastLogin; }
            private set { SetProperty(ref _DateLastActivity, value); }
        }

        public DateTime LastSyncDate
        {
            get { return _LastSyncDate; }
            private set { SetProperty(ref _LastSyncDate, value); }
        }

        public int AgentId
        {
            get { return _agentId; }
            set { SetProperty(ref _agentId, value); }
        }

        public byte[] AgentProfilePicture
        {
            get { return _agentProfilePicture; }
            private set { SetProperty(ref _agentProfilePicture, value); }
        }

        public int RoleId
        {
            get { return _roleId; }
            private set { SetProperty(ref _roleId, value); }
        }

        #endregion PROPERTIES

        public UserManager(IUserRepository userRepository
           )
        {
            _userRepository = userRepository;
            //_loggingServices = loggingServices;
            //_passwordHashManager = passwordHashManager;
            //_appConfigurationServices = appConfigurationServices;
            //_telemetryRepository = telemetryRepository;
            //_deviceManager = deviceManager;
        }

        #region axa.ph login

        //public async Task<LoginResult> Login6(string userName, string password, bool requiresPin = false, string responseToken = "")
        //{
        //    try
        //    {
        //        RequiresPIN = requiresPin;
        //        RequestToken = responseToken;

        //        if (userName == string.Empty || password == string.Empty)
        //        {
        //            return LoginResult.Missing;
        //        }

        //        int daysRequiredPriorSync = _appConfigurationServices.Login_MaxDaysRequiredPriorSync;
        //        //int daysRequiredPriorSync = 50;
        //        int maxLoginAttempts = _appConfigurationServices.Login_MaxPasswordLockoutAttempts;

        //        //HOW TO DETECT DATETIME NOW CHANGES?
        //        DateTime consistentDateNow = DateTime.Now;

        //        User user = await _userRepository.GetByName(userName);

        //        // User not yet in database. Maybe you need to sync?
        //        if (user == null)
        //        {
        //            return LoginResult.UserNotFound;
        //        }

        //        // Invalid attempts. Locks the account.
        //        if (user.LoginAttempts != null && user.LoginAttempts >= maxLoginAttempts)
        //        {
        //            return LoginResult.LockedOut;
        //        }

        //        // Inactive
        //        if (!user.IsActive)
        //        {
        //            return LoginResult.InActive;
        //        }

        //        //After all checks, we now check for passwords.
        //        bool passwordMatch = _passwordHashManager.Validate(password, user.Salt, user.Password);

        //        if (passwordMatch)
        //        {
        //            //User does not have any issues. Will now continue to process login.
        //            this.IsLoggedIn = true;

        //            this.Id = user.Id;
        //            this.AgentId = user.GlobalAgentId;
        //            this.DateLastLogin = consistentDateNow;
        //            this.FirstName = user.FirstName;
        //            this.LastName = user.LastName;
        //            this.UserName = userName;
        //            this.AgentProfilePicture = user.AgentProfilePicture;
        //            this.RequestToken = user.RequestToken;
        //            this.LastSyncDate = user.LastSyncDate.HasValue ? user.LastSyncDate.Value : DateTime.MinValue;

        //            user.LastSuccessfulLoginDate = consistentDateNow;
        //            user.LoginAttempts = 0;

        //            if (user.FirstLoginDate == null)
        //            {
        //                user.FirstLoginDate = consistentDateNow;
        //            }

        //            await _userRepository.Update(user);

        //            // User is logged-in but account too old
        //            if (user.LastSyncDate != null && user.LastSyncDate.HasValue && user.LastSyncDate.Value > DateTime.MinValue)
        //            {
        //                int daysElapsed = (consistentDateNow - user.LastSyncDate.Value).Days;

        //                if (daysElapsed >= daysRequiredPriorSync)
        //                {
        //                    return LoginResult.RequiresSync;
        //                }
        //                else
        //                {
        //                    //SUCCESS
        //                    return LoginResult.Success;
        //                }
        //            }
        //            else
        //            {
        //                //NULL
        //                return LoginResult.RequiresSync;
        //            }

        //            return LoginResult.Success;
        //            //return LoginResult.RequiresSync;
        //        }

        //        //If you got here, we will have to update the user of the password login attempts.
        //        if (user.LoginAttempts.HasValue)
        //        {
        //            user.LoginAttempts++;
        //        }
        //        else
        //        {
        //            user.LoginAttempts = 1;
        //        }

        //        await _userRepository.Update(user);

        //        return LoginResult.Failed;
        //    }
        //    catch (Exception ex)
        //    {
        //        _loggingServices.Create(5, ex);
        //    }

        //    //As a catch bucket. Always fail the authentication.
        //    return LoginResult.Failed;
        //}

        #endregion axa.ph login

        #region my login

        //public async Task<LoginResult> Login(string userName, string password, ReportAgentStatusOnlineResponse reportAgentStatusOnlineResponse, bool requiresPin = false, string responseToken = "")
        //{
        //    try
        //    {
        //        if (reportAgentStatusOnlineResponse.AgentProfileStatus == "PROFILE_NOT_CREATED")
        //        {
        //            return LoginResult.ProfileNotCreated;
        //        }

        //        if (reportAgentStatusOnlineResponse.AgentProfileStatus == null && reportAgentStatusOnlineResponse.AgentNewSalt == null && reportAgentStatusOnlineResponse.AgentProfileStatus != "PROFILE_NOT_CREATED" && reportAgentStatusOnlineResponse.Token != null)
        //        {
        //            return LoginResult.Failed;
        //        }

        //        if (userName == string.Empty || password == string.Empty)
        //        {
        //            return LoginResult.Missing;
        //        }

        //        int daysRequiredPriorSync = _appConfigurationServices.Login_MaxDaysRequiredPriorSync;
        //        //int daysRequiredPriorSync = 50;
        //        int maxLoginAttempts = _appConfigurationServices.Login_MaxPasswordLockoutAttempts;

        //        //HOW TO DETECT DATETIME NOW CHANGES?
        //        DateTime consistentDateNow = DateTime.Now;

        //        User user = await _userRepository.GetByName(userName.ToLower());

        //        // User not yet in database. Maybe you need to sync?
        //        if (user == null)
        //        {
        //            return LoginResult.UserNotFound;
        //        }

        //        // Invalid attempts. Locks the account.
        //        if (user.LoginAttempts != null && user.LoginAttempts >= maxLoginAttempts)
        //        {
        //            return LoginResult.LockedOut;
        //        }

        //        // Inactive
        //        if (!user.IsActive)
        //        {
        //            return LoginResult.InActive;
        //        }
        //        //After all checks, we now check for passwords.
        //        //I moved the dmt sign in to the sync service
        //        //DmtSignInReq dmtSignInReq = new DmtSignInReq();
        //        //dmtSignInReq.username = userName;
        //        //dmtSignInReq.password = password;
        //        //var SignInStatus = await Logical.SignIn(dmtSignInReq);
        //        //bool passwordMatch = _passwordHashManager.Validate(password, user.Salt, user.Password);
        //        bool passwordMatch = false;
        //        if (password == user.Password)
        //        {
        //            passwordMatch = true;
        //        }
        //        if (passwordMatch)
        //        {
        //            requiresPin = false;
        //            //return LoginResult.RequiresSync;
        //            //User does not have any issues. Will now continue to process login.
        //            this.IsLoggedIn = true;

        //            this.Id = user.Id;
        //            this.AgentId = user.GlobalAgentId;
        //            this.DateLastLogin = consistentDateNow;
        //            this.FirstName = user.FirstName;
        //            this.LastName = user.LastName;
        //            this.UserName = userName;
        //            this.AgentProfilePicture = user.AgentProfilePicture;
        //            this.RequestToken = user.RequestToken;
        //            this.LastSyncDate = user.LastSyncDate.HasValue ? user.LastSyncDate.Value : DateTime.MinValue;

        //            user.LastSuccessfulLoginDate = consistentDateNow;
        //            user.LoginAttempts = 0;

        //            if (user.FirstLoginDate == null)
        //            {
        //                user.FirstLoginDate = consistentDateNow;
        //            }

        //            await _userRepository.Update(user);

        //            // User is logged-in but account too old
        //            if (user.LastSyncDate != null && user.LastSyncDate.HasValue && user.LastSyncDate.Value > DateTime.MinValue)
        //            {
        //                int daysElapsed = (consistentDateNow - user.LastSyncDate.Value).Days;

        //                if (daysElapsed >= daysRequiredPriorSync)
        //                {
        //                    return LoginResult.RequiresSync;
        //                }
        //                else
        //                {
        //                    //SUCCESS
        //                    return LoginResult.Success;
        //                }
        //            }
        //            else
        //            {
        //                //NULL
        //                //meant to return sync
        //                return LoginResult.RequiresSync;
        //            }

        //            //return LoginResult.Success;
        //            //return LoginResult.RequiresSync;
        //        }

        //        if (password != user.Password)
        //        {
        //            return LoginResult.Failed;
        //        }
        //        //If you got here, we will have to update the user of the password login attempts.
        //        if (user.LoginAttempts.HasValue)
        //        {
        //            user.LoginAttempts++;
        //        }
        //        else
        //        {
        //            user.LoginAttempts = 1;
        //        }

        //        // await _userRepository.Update(user);

        //        return LoginResult.Failed;
        //    }
        //    catch (Exception ex)
        //    {
        //        _loggingServices.Create(5, ex);
        //    }

        //    //As a catch bucket. Always fail the authentication.
        //    return LoginResult.Failed;
        //}

        #endregion my login

        public async Task<bool> Logout()
        {
            IsLoggedIn = false;

            var user = await _userRepository.GetById(this.Id);

            this.Id = Guid.Empty;
            this.AgentId = 0;
            this.DateLastLogin = DateTime.Now;
            this.FirstName = string.Empty;
            this.LastName = string.Empty;
            this.UserName = string.Empty;
            this.IsLoggedIn = true;
            this.AgentProfilePicture = null;
            this.DateLastActivity = DateTime.Now;

            return true;
        }

        public ChangePasswordResult ChangePassword(string oldPassword,
            string entryPassword,
            string newPassword,
            string confirmNewPassword)
        {
            if (entryPassword != oldPassword)
            {
                return ChangePasswordResult.WrongPassword;
            }
            if (newPassword == oldPassword)
            {
                return ChangePasswordResult.WrongPassword;
            }
            if (confirmNewPassword != newPassword)
            {
                return ChangePasswordResult.NotMatchedConfirmNew;
            }
            return ChangePasswordResult.Success;
        }

        //public async Task ReportAction(int actionId = 0, string name = "", string detail = "")
        //{
        //    //Decided to include the telemetry with user since I have access to the current AgentId and UserName.
        //    var usage = new UsageTelemetry();
        //    usage.Page = name;
        //    usage.Detail = detail;
        //    usage.ActionId = actionId;
        //    usage.AgentId = this.AgentId;
        //    usage.AgentUserName = this.UserName;
        //    usage.DateCreated = DateTime.Now;
        //    usage.DeviceId = _deviceManager.DeviceInstallationId;
        //    usage.SessionId = _deviceManager.SessionId;
        //    await _telemetryRepository.SaveAsync(usage);
        //}

        public async Task ReportSyncAsync()
        {
            User user = await _userRepository.GetById(this.Id);
            user.LastSyncDate = DateTime.Now;
            LastSyncDate = (DateTime)user.LastSyncDate;
            await _userRepository.Update(user);
        }

        public async Task UpdateprofilePicture(byte[] newProfilePicture)
        {
            var currentUser = await _userRepository.GetById(this.Id);
            currentUser.AgentProfilePicture = newProfilePicture;
            await _userRepository.Update(currentUser);

            AgentProfilePicture = newProfilePicture;
        }

        public async Task<int> UpdateLocal(string userName,
            int agentId,
            bool agentIsActive,
            int agentNewPasswordRetry,
            string agentNewPassword,
            string agentNewSalt,
            string agentFirstName,
            string agentLastName,
            string agentMobile,
            string agentEmail,
            string channelCode,
            string requestToken)
        {
            User user = await _userRepository.GetByName(userName);

            if (user != null)
            {
                user.Salt = agentNewSalt;
                user.Password = agentNewPassword;
                user.UpdatedDate = DateTime.Now;
                user.IsActive = agentIsActive;
                user.FirstName = agentFirstName;
                user.LastName = agentLastName;
                user.RequestToken = requestToken;
                user.ContactNo = agentMobile;
                user.EmailAddress = agentEmail;
                user.ChannelCode = channelCode;

                if (agentNewPasswordRetry > -1)
                {
                    user.LoginAttempts = agentNewPasswordRetry;
                }

                if (agentId != 0)
                {
                    user.GlobalAgentId = agentId;
                    user.AgentId = agentId;
                }

                return await _userRepository.Update(user);
            }
            else
            {
                user = new User();
                user.UserName = userName;
                user.Password = agentNewPassword;
                user.Salt = agentNewSalt;
                user.CreatedDate = DateTime.Now;
                user.IsActive = agentIsActive;
                user.FirstName = agentFirstName;
                user.LastName = agentLastName;
                user.RequestToken = requestToken;
                user.ContactNo = agentMobile;
                user.EmailAddress = agentEmail;
                user.ChannelCode = channelCode;

                if (agentNewPasswordRetry > -1)
                {
                    user.LoginAttempts = agentNewPasswordRetry;
                }

                if (agentId != 0)
                {
                    user.GlobalAgentId = agentId;
                    user.AgentId = agentId;
                }

                return await _userRepository.SaveAsync(user);
            }
        }

        //public bool CheckIfRequiresSync()
        //{
        //    if (LastSyncDate != null && LastSyncDate > DateTime.MinValue)
        //    {
        //        int daysRequiredPriorSync = _appConfigurationServices.Login_MaxDaysRequiredPriorSync;

        //        //HOW TO DETECT DATETIME NOW CHANGES?
        //        DateTime consistentDateNow = DateTime.Now;

        //        int daysElapsed = (consistentDateNow - LastSyncDate).Days;

        //        return (daysElapsed >= daysRequiredPriorSync);
        //    }
        //    else
        //    {
        //        return true;
        //    }
        //}

        public async Task<int> UpdateUserToken(string responseToken)
        {
            try
            {
                if (!string.IsNullOrEmpty(responseToken))
                {
                    this.RequestToken = responseToken;
                    User user = await _userRepository.GetByName(this.UserName);
                    if (user != null)
                    {
                        user.RequestToken = responseToken;
                        return await _userRepository.SaveAsync(user);
                    }
                }
            }
            catch (Exception ex)
            {
                string error = ex.ToString();
            }

            return 0;
        }
    }
}
