﻿using AxaSolLite.Services.Contracts;
using SQLite;
using System;

namespace AxaSolLite.Services.Concretes.Managers
{
    public class SQLiteDatabase
    {
        public static SQLiteAsyncConnection GetConnection(IDBConnectionParameters dbConnectionParameters)
        {
            SQLiteConnectionString sqlLiteConnectionString = null;
            try
            {
                sqlLiteConnectionString = new SQLiteConnectionString(dbConnectionParameters.FilePath, storeDateTimeAsTicks: false);
                var connectionFactory = new Func<SQLiteConnectionWithLock>(() => new SQLiteConnectionWithLock(sqlLiteConnectionString));
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                throw;
            }
           
            return new SQLiteAsyncConnection(sqlLiteConnectionString);
        }
    }
}
