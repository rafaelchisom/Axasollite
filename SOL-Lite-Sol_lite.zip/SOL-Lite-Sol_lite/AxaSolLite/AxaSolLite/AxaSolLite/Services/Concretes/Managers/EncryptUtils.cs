﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Cryptography;
using System.Text;
using Xamarin.Forms;

namespace AxaSolLite.Services.Concretes.Managers
{
    public class EncryptUtils
    {
        private readonly int RecurseCount = 5;

        private readonly char[] SkeyArray = { 'a', 'o', 'k', 'l', 'a', 'i', 'n', 'e', 'o', 'c', 'i', 'k', 't', 't', 'f', 'p', 'j', 'a', 'r', 'x', 'z', 'd', 's', 'w', 'j', 's', 'a' , 'q' };

        SecureString secureString = new SecureString();
            
        public EncryptUtils()
        {

        }

        public string aesEncrypt(string content)
        {
            int RecurseCount = 5;
            string encryptedText = RecursiveEncryptAES(content, RecurseCount);

            return encryptedText;
        }

        public string aesDecrypt(string content)
        {
            return RecursiveDecryptAES(content, RecurseCount);
        }

        private string InternalEncryptAES(string content)
        {
            string keyToday = ConvertToUNSecureString();
            byte[] key = Encoding.UTF8.GetBytes(ConvertToUNSecureString());
            byte[] iv = new byte[key.Length];

            byte[] encrypted;

            using (AesManaged aesAlg = new AesManaged())
            {
                aesAlg.Key = key;
                aesAlg.IV = iv;

                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(content);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }
            return Convert.ToBase64String(encrypted);
        }

        private string InternalDecryptAES(string content)
        {
            string plaintext = null;
            try
            {
                string keyToday = ConvertToUNSecureString();
                byte[] key = Encoding.UTF8.GetBytes(ConvertToUNSecureString());
                byte[] iv = new byte[key.Length];

                byte[] cipherText = Convert.FromBase64String(content);

                using (AesManaged aesAlg = new AesManaged())
                {
                    aesAlg.Key = key;
                    aesAlg.IV = iv;
                    aesAlg.Padding = PaddingMode.PKCS7;

                    ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                    using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                    {
                        using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                            {
                                plaintext = srDecrypt.ReadToEnd();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return plaintext;
        }

        private string RecursiveEncryptAES(string content, int count)
        {
            if (count > 0)
            {
                return RecursiveEncryptAES(InternalEncryptAES(content), count - 1);
            }
            else
            {
                return InternalEncryptAES(content);
            }
        }

        private string RecursiveDecryptAES(string content, int count)
        {
            if (count > 0)
            {
                return RecursiveDecryptAES(InternalDecryptAES(content), count - 1);
            }
            else
            {
                return InternalDecryptAES(content);
            }
        }

        private string GetKeyToday()
        {
            return string.Join("", (SkeyArray.ToList().Where(x => SkeyArray.ToList().IndexOf(x) % 2 == 0).ToList()));
        }

        public string sha256Encrypt(string password, string salt)
        {
            string saltAndPwd = String.Concat(password, salt);
            UTF8Encoding encoder = new UTF8Encoding();
            SHA256Managed sha256hasher = new SHA256Managed();
            byte[] hashedDataBytes = sha256hasher.ComputeHash(encoder.GetBytes(saltAndPwd));
            string _newPasswordHash = Convert.ToBase64String(hashedDataBytes);
            return _newPasswordHash;
        }

        public string ConvertToUNSecureString()
        {

            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(Application.Current.Properties["Usage"] as SecureString);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }

    }
}
