﻿using AxaSolLite.Models;
using AxaSolLite.Models.CustomerOnboardingCreateCase;
using AxaSolLite.Services.Contracts;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Managers
{
    public class Logical
    {
        private readonly IAgentRepository _agentRepository;
        readonly string Bearer2 = "rzaz2a_jJ1HPoYIjYcBBZV4dRWnQSwe1i8ONLwf5RyvSZ4w__ZQv2fbbTGmO2GFpWsDVGMIXnLy9Up2w8dIjqx5BYhZv5slecH7Ls0or-UOJ0piJeU5d-_1hc3w9olS97xiBoLgOnMypzDB49Bo2m_G1_cX4Q6cENuier3WXzhRJVddEY4O0A29ck1akxOuZSOXHyu8fIgYR89WieArESpSmTvw60TSJ07ZgBMDpjHEbV6u6jyEyI3PbkiqZaz0756PBOJrqV7b6vyX5tD_14OGZk7W3hKTBFQDYaDmT3zE7q_ySDMZ_F8KGgofnH2daU2lVzzCYBAHtQoO6UCNK3xAewYFF8QvUahR58lGl6rlY9s-x5KipyeEdQmjCSgjsVL_8Lr2IjdCdZC61ak-n4OFqz7AfaX8UYELZo8Yv3jz9ytd9zJarKADtDCv1KdeE8KQnNpsx0bIH8QJosZyLZ9JZCgDD9zK5krf2anctZQ71sI3-kAuhJkZPCYIZM17y";
        readonly string Bearer = "my0fV5GKWvYw2sNdku_285vBXMnzZazcLK-lH0bS78MHdfLgtCIZgXL_PJMXGPmtanfuo9FYEdO_PIx22214XVes2zYApaoEqq6BSRtZK_RkrO3J8MaS-y3Ky-EK1JKSVBWV8P77rW6T6A28I0mo9OiV18WwcEjaT_ztLZ7pb1TgJDlsVyFIxJnLUhYnd9fJcGDpcHaKH-FhwHdX9WkgtZOiIUDrUhrMsZwabNUd7DSbR3GDh2sp3xq-rT81LPoLg48cbPp7stWEh65gAhW-iE4304FsceAQO8RIbMGv3oQFcGWYQGOFq70279EiGXrdfvatMkF73LwgS4mnaaTIIxFkk4CO_9xzHpervKI2ODXXUc8tfBKs5GSqCUicucIfh5gtpjKr4bkMyNzbVtZ5QBB_PkIy6OjOpj7rq3bs8vkufiGnFFOliXcV41WJJIzniAHk-y9RxhmOsHF3l395PYaPeodOYPjlmpoynM0O--sFOWYChbwggXrkqV8mZ2ic";
        public Logical()
        {

        }

        public Logical(IAgentRepository agentRepository)
        {
            _agentRepository = agentRepository;
        }
        //public async Task<Agent> GetLastAgent()
        //{
        //    Agent Agent = new Agent();
        //    try
        //    {
        //        List<Agent> Agents = await _agentRepository.GetAgents();
        //        Agent = Agents.LastOrDefault();
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //    return Agent;
        //}

        public async Task<CustomerOnboardingResponse> CustomerOnboardingResponseAsync(CustomerOnboardingRequest request)
        {
            CustomerOnboardingResponse customerOnboardingResponse = new CustomerOnboardingResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);


                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.customerOnboarding, content);
                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{
                //    EncryptionReq req = new EncryptionReq();
                //    //req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    //AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                //        response = await clientHelper.PostAsync(AxaSolUrls.customerOnboarding, content);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            customerOnboardingResponse = JsonConvert.DeserializeObject<CustomerOnboardingResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            customerOnboardingResponse = JsonConvert.DeserializeObject<CustomerOnboardingResponse>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    customerOnboardingResponse = JsonConvert.DeserializeObject<CustomerOnboardingResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    customerOnboardingResponse = JsonConvert.DeserializeObject<CustomerOnboardingResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return customerOnboardingResponse;
        }

        public async Task<CreatePMCaseResponse> CustomerCaseCreateAsync(PMRequestParam pMRequestParam)
        {
            CreatePMCaseResponse createPMCaseResponse = new CreatePMCaseResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);


                string requestBody = JsonConvert.SerializeObject(pMRequestParam);
                var content = new StringContent(requestBody, Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                clientHelper.Timeout = TimeSpan.FromMinutes(10);
                var response = await clientHelper.PostAsync(AxaSolUrls.customerOnboardingCase, content);
                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                //        response = await clientHelper.PostAsync(AxaSolUrls.customerOnboardingCase, content);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            createPMCaseResponse = JsonConvert.DeserializeObject<CreatePMCaseResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            createPMCaseResponse = JsonConvert.DeserializeObject<CreatePMCaseResponse>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    createPMCaseResponse = JsonConvert.DeserializeObject<CreatePMCaseResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    createPMCaseResponse = JsonConvert.DeserializeObject<CreatePMCaseResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return createPMCaseResponse;
        }

        public async Task<CustomerOnboardingMailResponse> CustomerOnboardingMail(CustomerOnboardingMailRequest request)
        {
            CustomerOnboardingMailResponse response = new CustomerOnboardingMailResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var Response = await clientHelper.PostAsync(AxaSolUrls.customerOnboardingMail, content);

                //if (Response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                //        Response = await clientHelper.PostAsync(AxaSolUrls.customerOnboardingMail, content);
                //        if (Response.IsSuccessStatusCode)
                //        {
                //            var value = Response.Content.ReadAsStringAsync().Result;
                //            response = JsonConvert.DeserializeObject<CustomerOnboardingMailResponse>(value);
                //        }
                //        else
                //        {
                //            var value = Response.Content.ReadAsStringAsync().Result;
                //            response = JsonConvert.DeserializeObject<CustomerOnboardingMailResponse>(value);
                //        }
                //    }

                //}


                if (Response.IsSuccessStatusCode)
                {
                    var value = Response.Content.ReadAsStringAsync().Result;
                    response = JsonConvert.DeserializeObject<CustomerOnboardingMailResponse>(value);
                }
                else
                {
                    var value = Response.Content.ReadAsStringAsync().Result;
                    response = JsonConvert.DeserializeObject<CustomerOnboardingMailResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return response;
        }

        public async Task<AccountOpeningFormResponse> AccountCreationFormAsync(AccountCreationFormModel accountCreationFormModel)
        {
            AccountOpeningFormResponse Response = new AccountOpeningFormResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);


                var content = new StringContent(JsonConvert.SerializeObject(accountCreationFormModel), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.accountCreationForm, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.accountCreationForm, content);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            string message = response.ReasonPhrase;
                //            var Message = response.RequestMessage;
                //            Response = JsonConvert.DeserializeObject<AccountOpeningFormResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            Response = JsonConvert.DeserializeObject<AccountOpeningFormResponse>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    string message = response.ReasonPhrase;
                    var Message = response.RequestMessage;
                    Response = JsonConvert.DeserializeObject<AccountOpeningFormResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<AccountOpeningFormResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }

        public async Task<List<AccountOpeningFormResponse>> GenerateLifePDFs(LifeDocumentPdfRequest request)
        {
            List<AccountOpeningFormResponse> Response = new List<AccountOpeningFormResponse>();
            string value = null;
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);

                client.Timeout = TimeSpan.FromMinutes(5);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);

                string serializedRequst = JsonConvert.SerializeObject(request);
                var content = new StringContent(serializedRequst, Encoding.UTF8, "application/json");
                var response = await client.PostAsync(AxaSolUrls.generateLifePdfDocs, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await client.PostAsync(AxaSolUrls.generateLifePdfDocs, content);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            value = response.Content.ReadAsStringAsync().Result;

                //            Response = JsonConvert.DeserializeObject<List<AccountOpeningFormResponse>>(value);
                //        }
                //        else
                //        {
                //            value = response.Content.ReadAsStringAsync().Result;
                //            Response = JsonConvert.DeserializeObject<List<AccountOpeningFormResponse>>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    value = response.Content.ReadAsStringAsync().Result;

                    Response = JsonConvert.DeserializeObject<List<AccountOpeningFormResponse>>(value);
                }
                else
                {
                    value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<List<AccountOpeningFormResponse>>(value);
                }
            }
            catch (Exception ex)
            {

            }
            return Response;
        }

        public async Task<SyncDataSample> GetProspectTitles()
        {
            SyncDataSample titles = new SyncDataSample();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);


                //var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(AxaSolUrls.getProspectTitles);



                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    titles = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    titles = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return titles;
        }

        public async Task<SyncDataSample> GetBeneficiaryRelationships()
        {
            SyncDataSample beneficiaryRelationships = new SyncDataSample();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(AxaSolUrls.getBeneficiaryRelationship);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    beneficiaryRelationships = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    beneficiaryRelationships = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return beneficiaryRelationships;
        }

        public async Task<SyncDataSample> GetNationalities()
        {
            SyncDataSample Nationalities = new SyncDataSample();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);


                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(AxaSolUrls.getCountryList);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.GetAsync(AxaSolUrls.getNationalities);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            Nationalities = JsonConvert.DeserializeObject<SyncDataSample>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            Nationalities = JsonConvert.DeserializeObject<SyncDataSample>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Nationalities = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Nationalities = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Nationalities;
        }

        public async Task<SyncDataSample> GetCountryList()
        {
            SyncDataSample countries = new SyncDataSample();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);


                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(AxaSolUrls.getCountryList);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.GetAsync(AxaSolUrls.getCountryList);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            countries = JsonConvert.DeserializeObject<SyncDataSample>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            countries = JsonConvert.DeserializeObject<SyncDataSample>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    countries = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    countries = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return countries;
        }

        public async Task<List<ResultSample>> GetCities(int stateCode)
        {
            List<ResultSample> Cities = new List<ResultSample>();

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);

                httpClient.Timeout = TimeSpan.FromMinutes(5);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.GetAsync(AxaSolUrls.getCities + stateCode.ToString());

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Cities = JsonConvert.DeserializeObject<List<ResultSample>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Cities = JsonConvert.DeserializeObject<List<ResultSample>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Cities;
        }

        public async Task<SyncDataSample> GetStates(int countryId)
        {
            SyncDataSample states = new SyncDataSample();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await clientHelper.GetAsync(AxaSolUrls.getStatesByCountryId + countryId.ToString());

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{
                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.GetAsync(AxaSolUrls.getStatesByCountryId + countryId.ToString());
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            states = JsonConvert.DeserializeObject<SyncDataSample>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            states = JsonConvert.DeserializeObject<SyncDataSample>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    states = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    states = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return states;
        }

        public async Task<SyncDataSample> GetPolicyClass()
        {
            SyncDataSample policyClass = new SyncDataSample();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await clientHelper.GetAsync(AxaSolUrls.getPolicyClass);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                //        response = await clientHelper.GetAsync(AxaSolUrls.getPolicyClass);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            policyClass = JsonConvert.DeserializeObject<SyncDataSample>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            policyClass = JsonConvert.DeserializeObject<SyncDataSample>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    policyClass = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    policyClass = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return policyClass;
        }

        public async Task<SyncDataSample> GetPolicyTypes(int classCode)
        {
            SyncDataSample policyTypes = new SyncDataSample();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await clientHelper.GetAsync(AxaSolUrls.getPolicyTypeByClassCode + classCode.ToString());

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.GetAsync(AxaSolUrls.getPolicyTypeByClassCode + classCode.ToString());
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            policyTypes = JsonConvert.DeserializeObject<SyncDataSample>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            policyTypes = JsonConvert.DeserializeObject<SyncDataSample>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    policyTypes = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    policyTypes = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return policyTypes;
        }

        public async Task<MotorDetailSample> GetMotorMakes()
        {
            MotorDetailSample motorMakes = new MotorDetailSample();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await clientHelper.GetAsync(AxaSolUrls.getMotorMakes);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.GetAsync(AxaSolUrls.getMotorMakes);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            motorMakes = JsonConvert.DeserializeObject<MotorDetailSample>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            motorMakes = JsonConvert.DeserializeObject<MotorDetailSample>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    motorMakes = JsonConvert.DeserializeObject<MotorDetailSample>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    motorMakes = JsonConvert.DeserializeObject<MotorDetailSample>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return motorMakes;
        }

        public async Task<MakeModeDetailsSample> GetMotorModels(int makeId)
        {
            MakeModeDetailsSample motorModels = new MakeModeDetailsSample();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await clientHelper.GetAsync(AxaSolUrls.getMotorModelByMakeId + makeId.ToString());

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.GetAsync(AxaSolUrls.getMotorModelByMakeId + makeId.ToString());
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            motorModels = JsonConvert.DeserializeObject<MakeModeDetailsSample>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            motorModels = JsonConvert.DeserializeObject<MakeModeDetailsSample>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    motorModels = JsonConvert.DeserializeObject<MakeModeDetailsSample>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    motorModels = JsonConvert.DeserializeObject<MakeModeDetailsSample>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return motorModels;
        }

        public async Task<MotorTruePriceResponseModel> GetMotorTruePriceAsync(MotorTruePriceRequestDto request)
        {
            MotorTruePriceResponseModel getMotorTruePriceResponse = new MotorTruePriceResponseModel();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await clientHelper.PostAsync(AxaSolUrls.MotorTruePrice, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    getMotorTruePriceResponse = JsonConvert.DeserializeObject<MotorTruePriceResponseModel>(value);

                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    getMotorTruePriceResponse = JsonConvert.DeserializeObject<MotorTruePriceResponseModel>(value);


                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return getMotorTruePriceResponse;

        }

        public async Task<List<MotorRiderResponse>> GetMotorRiders(int policyTypeId)
        {
            List<MotorRiderResponse> motorRiders = new List<MotorRiderResponse>();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(AxaSolUrls.getMotorRidersByPolicyTypeId + policyTypeId.ToString());

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.GetAsync(AxaSolUrls.getMotorRidersByPolicyTypeId + policyTypeId.ToString());
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            motorRiders = JsonConvert.DeserializeObject<List<MotorRiderResponse>>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            motorRiders = JsonConvert.DeserializeObject<List<MotorRiderResponse>>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    motorRiders = JsonConvert.DeserializeObject<List<MotorRiderResponse>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    motorRiders = JsonConvert.DeserializeObject<List<MotorRiderResponse>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return motorRiders;
        }

        public async Task<DmtSignResModel> SignIn(DmtSignInReq dmtSignInReq)
        {
            DmtSignResModel ItemObj = new DmtSignResModel();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                var content = new StringContent(JsonConvert.SerializeObject(dmtSignInReq), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await clientHelper.PostAsync(AxaSolUrls.SignIn, content);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    ItemObj = JsonConvert.DeserializeObject<DmtSignResModel>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    ItemObj = JsonConvert.DeserializeObject<DmtSignResModel>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return ItemObj;
        }

        public async Task<GetAgentDetailsResponse> GetAgentDetailsResponseAsync(GetAgentDetailsRequest request)
        {
            GetAgentDetailsResponse getAgentDetailsResponse = new GetAgentDetailsResponse();
            try
            {
                //ServicePointManager.SecurityProtocol = (SecurityProtocolType)768 | (SecurityProtocolType)3072;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

              

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var response = await clientHelper.PostAsync(AxaSolUrls.PssAgentDetails, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    getAgentDetailsResponse = JsonConvert.DeserializeObject<GetAgentDetailsResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    getAgentDetailsResponse = JsonConvert.DeserializeObject<GetAgentDetailsResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return getAgentDetailsResponse;
        }

        public async Task<SearchCustomerResponse> GetSearchCustomerResponseAsync(SearchCustomerRequest request)
        {
            SearchCustomerResponse getSearchCustomerResponse = new SearchCustomerResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.SearchCustomer, content);


                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{
                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.SearchCustomer, content);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            getSearchCustomerResponse = JsonConvert.DeserializeObject<SearchCustomerResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            getSearchCustomerResponse = JsonConvert.DeserializeObject<SearchCustomerResponse>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    getSearchCustomerResponse = JsonConvert.DeserializeObject<SearchCustomerResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    getSearchCustomerResponse = JsonConvert.DeserializeObject<SearchCustomerResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return getSearchCustomerResponse;
        }

        public async Task<RefreshButtonResponse> GetPolicyIdAsync(RefreshButtonRequest request)
        {
            RefreshButtonResponse getPolicyIdResponse = new RefreshButtonResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.GetPolicyId, content);


                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.GetPolicyId, content);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            getPolicyIdResponse = JsonConvert.DeserializeObject<RefreshButtonResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            getPolicyIdResponse = JsonConvert.DeserializeObject<RefreshButtonResponse>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    getPolicyIdResponse = JsonConvert.DeserializeObject<RefreshButtonResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    getPolicyIdResponse = JsonConvert.DeserializeObject<RefreshButtonResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return getPolicyIdResponse;
        }

        public async Task<PayStackPaymentResponse> InitiatePayStackPaymentAsync(PayStackPaymentRequest payStackPaymentRequest)
        {
            PayStackPaymentResponse paymentResponse = new PayStackPaymentResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                var content = new StringContent(JsonConvert.SerializeObject(payStackPaymentRequest), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);

                var response = await clientHelper.PostAsync(AxaSolUrls.InitiatePayStackPayment, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    paymentResponse = JsonConvert.DeserializeObject<PayStackPaymentResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    paymentResponse.Message = JsonConvert.DeserializeObject<PayStackPaymentResponse>(value).Message;
                }
            }
            catch (Exception ex)
            {
                paymentResponse.Message = ex.Message.ToString();
            }

            return paymentResponse;
        }

        public async Task<VerifyPayStackPaymentResponse> VerifyPayStackPaymentResponseAsync(VerifyPayStackPaymentRequest request)
        {
            VerifyPayStackPaymentResponse verifyPayStackPaymentResponse = new VerifyPayStackPaymentResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                //var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.VerifyPayStackPayment, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    verifyPayStackPaymentResponse = JsonConvert.DeserializeObject<VerifyPayStackPaymentResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    verifyPayStackPaymentResponse.Message = JsonConvert.DeserializeObject<VerifyPayStackPaymentResponse>(value).Message;
                }
            }
            catch (Exception ex)
            {
                verifyPayStackPaymentResponse.Message = ex.Message.ToString();
            }

            return verifyPayStackPaymentResponse;
        }

        public async Task<AutoGoResponse> AutoGoBookingResponseAsync(AutoGoRequest request)
        {
            AutoGoResponse AutoGoBookingResponse = new AutoGoResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.AutoGoBooking, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.AutoGoBooking, content);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            AutoGoBookingResponse = JsonConvert.DeserializeObject<AutoGoResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            AutoGoBookingResponse = JsonConvert.DeserializeObject<AutoGoResponse>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    AutoGoBookingResponse = JsonConvert.DeserializeObject<AutoGoResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    AutoGoBookingResponse = JsonConvert.DeserializeObject<AutoGoResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return AutoGoBookingResponse;
        }

        public async Task<GeneralBizPdfCertResponse> SendPolicyCertificate(GeneralBizPdfCertRequest request)
        {
            GeneralBizPdfCertResponse certResponse = new GeneralBizPdfCertResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                //var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.PostAsync(AxaSolUrls.generalBizPdfCert, content);
                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await client.PostAsync(AxaSolUrls.generalBizPdfCert, content);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return certResponse;
        }

        public async Task<GeneralBizPdfCertResponse> EduPlanCertificate(EduPlanPdfCertRequest request)
        {
            GeneralBizPdfCertResponse certResponse = new GeneralBizPdfCertResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                //var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.PostAsync(AxaSolUrls.EduPlanPdfCert, content);
                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{
                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await client.PostAsync(AxaSolUrls.EduPlanPdfCert, content);

                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return certResponse;
        }

        public async Task<GeneralBizPdfCertResponse> InstantPlanCertificate(InstantPlanPdfCertRequest request)
        {
            GeneralBizPdfCertResponse certResponse = new GeneralBizPdfCertResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                //var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.PostAsync(AxaSolUrls.InstantPlanPdfCert, content);
                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await client.PostAsync(AxaSolUrls.InstantPlanPdfCert, content);

                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return certResponse;
        }

        public async Task<GeneralBizPdfCertResponse> BonusLifeCertificate(BonusLifeCertRequest request)
        {
            GeneralBizPdfCertResponse Response = new GeneralBizPdfCertResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.BonusLifePdfCert, content);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }

        public async Task<GeneralBizPdfCertResponse> AmbitionsCertificate(AmbitionsCertificateRequest request)
        {
            GeneralBizPdfCertResponse Response = new GeneralBizPdfCertResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await httpClient.PostAsync(AxaSolUrls.AmbitionsCert, content);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }

        public async Task<AccountOpeningFormResponse> GenerateMotorSummaryPdf(MotorPdfRequest pdfRequest)
        {
            AccountOpeningFormResponse Response = new AccountOpeningFormResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(pdfRequest), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await clientHelper.PostAsync(AxaSolUrls.generateMotorSummaryPdf, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.generateMotorSummaryPdf, content);

                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            Response = JsonConvert.DeserializeObject<AccountOpeningFormResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            Response = JsonConvert.DeserializeObject<AccountOpeningFormResponse>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<AccountOpeningFormResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<AccountOpeningFormResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }

        public async Task<LifeBookingResponse> BookLifePolicy(AimsLifeBookingDto request)
        {
            LifeBookingResponse Response = new LifeBookingResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                string requestBody = JsonConvert.SerializeObject(request);
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(requestBody, Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.bookLifePolicy, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.bookLifePolicy, content);

                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            Response = JsonConvert.DeserializeObject<LifeBookingResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            Response = JsonConvert.DeserializeObject<LifeBookingResponse>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<LifeBookingResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<LifeBookingResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }

        public async Task<bool> SendBookingCaseIdMail(AgentBookingCaseMailRequest request)
        {
            bool MailSent = false;

            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await clientHelper.PostAsync(AxaSolUrls.sendBookingcaseId, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.sendBookingcaseId, content);

                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            MailSent = JsonConvert.DeserializeObject<bool>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            MailSent = JsonConvert.DeserializeObject<bool>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return MailSent;

        }

        public async Task<bool> InsertProspectDetails(ProspectDetails prospect)
        {
            bool saved = false;

            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(prospect), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.insertProspectDetails, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int save = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (save == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.insertProspectDetails, content);

                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            saved = JsonConvert.DeserializeObject<bool>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            saved = JsonConvert.DeserializeObject<bool>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return saved;
        }

        public async Task<bool> UpdateProspectDetails(ProspectToUpdate prospect)
        {
            bool updated = false;

            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(prospect), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.updateProspectDetails, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int save = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (save == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.updateProspectDetails, content);

                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            updated = JsonConvert.DeserializeObject<bool>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            updated = JsonConvert.DeserializeObject<bool>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    updated = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    updated = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return updated;
        }

        public async Task<bool> UpdateCustomerInformationWithAimsRecord(AimsCustomerUpdateModel model)
        {
            bool updated = false;

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.updateCustomerWithAimsRecord, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    updated = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    updated = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return updated;
        }

        public async Task<bool> ConfirmOnboardingCaseCreated(ProspectCaseCreated model)
        {
            bool updated = false;

            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.confirmOnboardingCaseCreated, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int save = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (save == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.confirmOnboardingCaseCreated, content);

                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            updated = JsonConvert.DeserializeObject<bool>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            updated = JsonConvert.DeserializeObject<bool>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    updated = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    updated = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return updated;
        }

        public async Task<List<ProspectDetails>> GetProspectsByAgentCode(string agentCode)
        {
            List<ProspectDetails> prospects = new List<ProspectDetails>();

            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(AxaSolUrls.getProspectsByAgentCode + agentCode);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.GetAsync(AxaSolUrls.getProspectsByAgentCode + agentCode);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            prospects = JsonConvert.DeserializeObject<List<ProspectDetails>>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            prospects = JsonConvert.DeserializeObject<List<ProspectDetails>>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    prospects = JsonConvert.DeserializeObject<List<ProspectDetails>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    prospects = JsonConvert.DeserializeObject<List<ProspectDetails>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return prospects;
        }

        public async Task<ProspectDetails> GetProspect(CheckExistingProspectModel model)
        {
            ProspectDetails prospect = new ProspectDetails();

            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.getProspectDetails, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int save = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (save == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.getProspectDetails, content);

                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            prospect = JsonConvert.DeserializeObject<ProspectDetails>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            prospect = JsonConvert.DeserializeObject<ProspectDetails>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    prospect = JsonConvert.DeserializeObject<ProspectDetails>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    prospect = JsonConvert.DeserializeObject<ProspectDetails>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return prospect;
        }

        public async Task<bool> LogBookingDetails(BookingDetails bookingDetails)
        {
            bool Logged = false;
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(bookingDetails), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.logBookingDetails, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{
                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int save = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (save == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.logBookingDetails, content);

                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            Logged = JsonConvert.DeserializeObject<bool>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            Logged = JsonConvert.DeserializeObject<bool>(value);
                //        }
                //    }
                //}
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Logged = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Logged = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Logged;
        }

        public async Task<List<BookingDetails>> GetBookingsByAgentCode(string agentCode)
        {
            List<BookingDetails> bookingDetails = new List<BookingDetails>();

            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(AxaSolUrls.getBookingDetailsByAgentCode + agentCode);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    bookingDetails = JsonConvert.DeserializeObject<List<BookingDetails>>(value);
                    bookingDetails = bookingDetails.OrderByDescending(x => x.CreatedDate).ToList();

                    foreach (BookingDetails item in bookingDetails)
                    {
                        if (item.IsPolicyID == 0)
                        {
                            item.IsCaseID = 1;
                        }
                    }
                    await Task.Delay(3000);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    bookingDetails = JsonConvert.DeserializeObject<List<BookingDetails>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return bookingDetails;
        }

        public async Task<QuoteIdDto> GetQuoteAsync(QuoteIdDto quote)
        {
            QuoteIdDto Response = new QuoteIdDto();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                ErrorModel errorModel = null;

                var content = new StringContent(JsonConvert.SerializeObject(quote), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.getQuote, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<QuoteIdDto>(value); ;
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<QuoteIdDto>(value);
                    var error1 = response.ReasonPhrase;
                    var error2 = response.RequestMessage;
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return Response;
        }

        public async Task<bool> QuoteIdMailAsync(QuoteIdMailRequest request)
        {
            bool MailSent = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.quoteIdMail, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }



            return MailSent;
        }

        public async Task<bool> SaveBookingDetailsToDb(SaveBookingDetailsRequest bookingRequest)
        {
            bool saved = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                var content = new StringContent(JsonConvert.SerializeObject(bookingRequest), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.saveBookingDetails, content);


                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }


            return saved;
        }
        public async Task<bool> SaveCertificateDetailsToDb(SaveCertificateDetailsRequest certRequest)
        {
            bool saved = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                var content = new StringContent(JsonConvert.SerializeObject(certRequest), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.saveCertificateDetails, content);


                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }


            return saved;
        }
        public async Task<bool> SavePaymentReferenceToDb(SavePaymentReferenceRequest paymentRefRequest)
        {
            bool saved = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                var content = new StringContent(JsonConvert.SerializeObject(paymentRefRequest), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.savePaymentReference, content);


                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }


            return saved;
        }

        public async Task<int> CheckNewUserSignIn(string username, string deviceId)
        {
            int ExistingUser = 0;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.GetAsync(AxaSolUrls.checkExistingUser + username + "&deviceId=" + deviceId);


                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    ExistingUser = JsonConvert.DeserializeObject<int>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    ExistingUser = JsonConvert.DeserializeObject<int>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return ExistingUser;
        }
        public async Task<bool> SaveLoginAuditTrailToDb(LoginAuditTrailRequest Request)
        {
            bool saved = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                var content = new StringContent(JsonConvert.SerializeObject(Request), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.LoginAuditTrail, content);


                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }


            return saved;
        }
        public async Task<bool> SaveQuoteIdToDb(SaveQuoteIdRequest quoteIdRequest)
        {
            bool saved = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                var content = new StringContent(JsonConvert.SerializeObject(quoteIdRequest), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.saveQuoteId, content);


                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }


            return saved;
        }
        public async Task<List<PssCommissionDto>> GetMonthlyDashboardForPss(int Year, int Month, string PssUsername)
        {
            List<PssCommissionDto> pssMonthlyResponse = new List<PssCommissionDto>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                var UrlLink = "https://online.axamansard.com/AXASalesProcessor/api/Dmt/GetMonthlyDashboardForPss?Year=" + Year + "&Month=" + Month + "&PssUsername=" + PssUsername;

                //var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(UrlLink);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    pssMonthlyResponse = JsonConvert.DeserializeObject<List<PssCommissionDto>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    pssMonthlyResponse = JsonConvert.DeserializeObject<List<PssCommissionDto>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return pssMonthlyResponse;


        }
        public async Task<List<TeamManagerCommisionDto>> GetMonthlyDashboardForTeamManagers(int Year, int Month, string Username)
        {
            List<TeamManagerCommisionDto> TmMonthlyResponse = new List<TeamManagerCommisionDto>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                var UrlLink = "https://online.axamansard.com/AXASalesProcessor/api/Dmt/GetMonthlyDashboardForTeamManagers?Year=" + Year + "&Month=" + Month + "&Username=" + Username;
                //var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(UrlLink);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    TmMonthlyResponse = JsonConvert.DeserializeObject<List<TeamManagerCommisionDto>>(value);
                }

                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    TmMonthlyResponse = JsonConvert.DeserializeObject<List<TeamManagerCommisionDto>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return TmMonthlyResponse;

        }
        public async Task<List<AdvisorCommissionDto>> GetMonthlyDashboardForAdvisors(int Year, int Month, string Username)
        {
            List<AdvisorCommissionDto> AdvisorMonthlyResponse = new List<AdvisorCommissionDto>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                var UrlLink = "https://online.axamansard.com/AXASalesProcessor/api/Dmt/GetMonthlyDashboardForAdvisors?Year=" + Year + "&Month=" + Month + "&Username=" + Username;
                //var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(UrlLink);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    AdvisorMonthlyResponse = JsonConvert.DeserializeObject<List<AdvisorCommissionDto>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    AdvisorMonthlyResponse = JsonConvert.DeserializeObject<List<AdvisorCommissionDto>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return AdvisorMonthlyResponse;

        }
        public async Task<List<PssCommissionDto>> GetYearToDateDashboardForPss(int Year, int Month, string PssUsername)
        {
            List<PssCommissionDto> pssYTDResponse = new List<PssCommissionDto>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                var UrlLink = "https://online.axamansard.com/AXASalesProcessor/api/Dmt/GetYearToDateDashboardForPss?Year=" + Year + "&Month=" + Month + "&PssUsername=" + PssUsername;

                //var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(UrlLink);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    pssYTDResponse = JsonConvert.DeserializeObject<List<PssCommissionDto>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    pssYTDResponse = JsonConvert.DeserializeObject<List<PssCommissionDto>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return pssYTDResponse;

        }
        public async Task<List<TeamManagerCommisionDto>> GetYearToDateDashboardForTeamManagers(int Year, int Month, string Username)
        {
            List<TeamManagerCommisionDto> TmYTDResponse = new List<TeamManagerCommisionDto>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                var UrlLink = "https://online.axamansard.com/AXASalesProcessor/api/Dmt/GetYearToDateDashboardForTeamManagers?Year=" + Year + "&Month=" + Month + "&Username=" + Username;
                //var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(UrlLink);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    TmYTDResponse = JsonConvert.DeserializeObject<List<TeamManagerCommisionDto>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    TmYTDResponse = JsonConvert.DeserializeObject<List<TeamManagerCommisionDto>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return TmYTDResponse;

        }
        public async Task<List<AdvisorCommissionDto>> GetYearToDateDashboardForAdvisors(int Year, int Month, string Username)
        {
            List<AdvisorCommissionDto> AdvisorYTDResponse = new List<AdvisorCommissionDto>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                var UrlLink = "https://online.axamansard.com/AXASalesProcessor/api/Dmt/GetYearToDateDashboardForAdvisors?Year=" + Year + "&Month=" + Month + "&Username=" + Username;
                //var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(UrlLink);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    AdvisorYTDResponse = JsonConvert.DeserializeObject<List<AdvisorCommissionDto>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    AdvisorYTDResponse = JsonConvert.DeserializeObject<List<AdvisorCommissionDto>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return AdvisorYTDResponse;

        }
        public async Task<ExternalAgentResponse> ExternalAgentSignInResponseAsync(ExternalAgentSignInRequest request)
        {
            ExternalAgentResponse ExternalAgentSignInResponse = new ExternalAgentResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);


                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                var response = await clientHelper.PostAsync(AxaSolUrls.ExternalAgentSignIn, content);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    ExternalAgentSignInResponse.Message = value;
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    ExternalAgentSignInResponse.Message = value;

                }
            }
            catch (Exception ex)
            {
                ExternalAgentSignInResponse.Message = ex.Message.ToString();
            }

            return ExternalAgentSignInResponse;


        }
        public async Task<ExternalAgentResponse> UpdateExternalAgentResponseAsync(UpdateExternalAgentPasswordRequest request)
        {
            ExternalAgentResponse UpdateExternalAgentResponse = new ExternalAgentResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                var response = await clientHelper.PostAsync(AxaSolUrls.UpdateExternalAgentPassword, content);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    UpdateExternalAgentResponse.Message = value;
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    UpdateExternalAgentResponse.Message = value;
                }
            }
            catch (Exception ex)
            {
                UpdateExternalAgentResponse.Message = ex.Message.ToString();
            }
            return UpdateExternalAgentResponse;
        }
        public async Task<ExternalAgentResponse> GetOTPResponseAsync(GetOTPRequest request)
        {
            ExternalAgentResponse getOTPResponse = new ExternalAgentResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                var response = await clientHelper.PostAsync(AxaSolUrls.GetOTP, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    getOTPResponse.Message = value;
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    getOTPResponse.Message = value;
                }
            }
            catch (Exception ex)
            {
                getOTPResponse.Message = ex.Message.ToString();
            }

            return getOTPResponse;
        }
        public async Task<ExternalAgentResponse> ChangePasswordAsync(ForgotPasswordRequest request)
        {
            ExternalAgentResponse forgotPasswordResponse = new ExternalAgentResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);


                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                var response = await clientHelper.PostAsync(AxaSolUrls.ChangePassword, content);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    forgotPasswordResponse.Message = value;
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    forgotPasswordResponse.Message = value;
                }
            }
            catch (Exception ex)
            {
                forgotPasswordResponse.Message = ex.Message.ToString();
            }

            return forgotPasswordResponse;
        }
        public async Task<List<TeamManagerDetailsDto>> GetTeamManagersDetailsByAgentcode(string AgentCode)
        {
            List<TeamManagerDetailsDto> TeamManagerResponse = new List<TeamManagerDetailsDto>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                //var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(AxaSolUrls.GetTeamManagerDetails + AgentCode);

                if (response.IsSuccessStatusCode)

                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    TeamManagerResponse = JsonConvert.DeserializeObject<List<TeamManagerDetailsDto>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    TeamManagerResponse = JsonConvert.DeserializeObject<List<TeamManagerDetailsDto>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return TeamManagerResponse;

        }
        public async Task<List<AdvisorDetailsDto>> GetAdvisorsDetailsByAgentcode(string AgentCode)
        {
            List<AdvisorDetailsDto> AdvisorResponse = new List<AdvisorDetailsDto>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                //var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await clientHelper.GetAsync(AxaSolUrls.GetAdvisorDetails + AgentCode);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    AdvisorResponse = JsonConvert.DeserializeObject<List<AdvisorDetailsDto>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    AdvisorResponse = JsonConvert.DeserializeObject<List<AdvisorDetailsDto>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return AdvisorResponse;

        }

        public async Task<CustomerDetailsReponse> GetCustomerDetailsByCustomerNumber(string customerNumber)
        {
            CustomerDetailsReponse customerDetailsReponse = new CustomerDetailsReponse();
            string value = null;

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.getCustomerDetailsByCustomerNumber + customerNumber);

                if (response.IsSuccessStatusCode)
                {
                    value = response.Content.ReadAsStringAsync().Result;

                    customerDetailsReponse = JsonConvert.DeserializeObject<CustomerDetailsReponse>(value);
                }
                else
                {
                    value = response.Content.ReadAsStringAsync().Result;
                    customerDetailsReponse = JsonConvert.DeserializeObject<CustomerDetailsReponse>(value);
                }
            }
            catch (Exception ex)
            {

            }
            return customerDetailsReponse;
        }

        public async Task<List<SBUDetails>> GetSBUDetails()
        {
            List<SBUDetails> Response = new List<SBUDetails>();
            string value = null;

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.getSBUDetails);

                if (response.IsSuccessStatusCode)
                {
                    value = response.Content.ReadAsStringAsync().Result;

                    Response = JsonConvert.DeserializeObject<List<SBUDetails>>(value);
                }
                else
                {
                    value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<List<SBUDetails>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }

        public async Task<List<PolicyProcessingDetails>> GetPolicyProcessingDetailsBySBU(int sbuCode)
        {
            List<PolicyProcessingDetails> Response = new List<PolicyProcessingDetails>();
            string value = null;

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.getPolicyProcessingDetails + sbuCode);

                if (response.IsSuccessStatusCode)
                {
                    value = response.Content.ReadAsStringAsync().Result;

                    Response = JsonConvert.DeserializeObject<List<PolicyProcessingDetails>>(value);
                }
                else
                {
                    value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<List<PolicyProcessingDetails>>(value);
                }
            }
            catch (Exception ex)
            {

            }
            return Response;
        }

        public async Task<TokenRequest> GetInstantPlanTokenCredentials()
        {
            TokenRequest tokenRequest = new TokenRequest();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.tokenCredentials);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    tokenRequest = JsonConvert.DeserializeObject<TokenRequest>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    tokenRequest = JsonConvert.DeserializeObject<TokenRequest>(value);
                }
            }
            catch (Exception ex)
            {

            }
            return tokenRequest;
        }

        public async Task<TokenResponse> GetAxamansardAPIToken()
        {
            TokenResponse tokenResponse = new TokenResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };

                using (HttpClient httpClient = new HttpClient(clientHandler))
                {
                    httpClient.Timeout = TimeSpan.FromMinutes(5);
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                    //httpClient.DefaultRequestHeaders.Add("x-api-key", request.Api_key);
                    //httpClient.DefaultRequestHeaders.Add("x-api-secret", request.Api_secret);
                    //httpClient.DefaultRequestHeaders.Add("x-client-key", request.Client_key);

                    var response = await httpClient.GetAsync(AxaSolUrls.AxamansardAPI_token);

                    if (response.IsSuccessStatusCode)
                    {
                        var value = response.Content.ReadAsStringAsync().Result;
                        tokenResponse = JsonConvert.DeserializeObject<TokenResponse>(value);
                    }
                    else
                    {
                        var value = response.Content.ReadAsStringAsync().Result;
                        tokenResponse = JsonConvert.DeserializeObject<TokenResponse>(value);
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }



            return tokenResponse;
        }

        public async Task<List<InstantPlanQuote>> GetInstantPlanQuotes_New(string obj)
        {
            List<InstantPlanQuote> instantPlanQuotes = new List<InstantPlanQuote>();

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };

                using (HttpClient httpClient = new HttpClient(clientHandler))
                {
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", obj);
                    var response = await httpClient.GetAsync(AxaSolUrls.InstanPlanQuoteApi);

                    response.EnsureSuccessStatusCode();
                    if (response.IsSuccessStatusCode)
                    {
                        var value = response.Content.ReadAsStringAsync().Result;
                        instantPlanQuotes = JsonConvert.DeserializeObject<List<InstantPlanQuote>>(value);
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return instantPlanQuotes;
        }

        public async Task<List<InstantPlanQuoteReq>> GetAllInstantPlanQuotes()
        {
            List<InstantPlanQuoteReq> instantPlanQuote = new List<InstantPlanQuoteReq>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };

                using (HttpClient httpClient = new HttpClient(clientHandler))
                {
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                    var response = await httpClient.GetAsync(AxaSolUrls.getAllInstantPlanQuote);
                    response.EnsureSuccessStatusCode();
                    if (response.IsSuccessStatusCode)
                    {
                        var value = response.Content.ReadAsStringAsync().Result;
                        instantPlanQuote = JsonConvert.DeserializeObject<List<InstantPlanQuoteReq>>(value);
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return instantPlanQuote;
        }

        public async Task<List<DSAUnderPSS>> GetDSAsUnderPss(string agentCode)
        {
            List<DSAUnderPSS> Response = new List<DSAUnderPSS>();
            string value = null;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.getDSAsUnderPsS + agentCode);

                if (response.IsSuccessStatusCode)
                {
                    value = response.Content.ReadAsStringAsync().Result;

                    Response = JsonConvert.DeserializeObject<List<DSAUnderPSS>>(value);
                }
                else
                {
                    value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<List<DSAUnderPSS>>(value);
                }
            }
            catch (Exception ex)
            {

            }
            return Response;
        }

        public async Task<getMaxBenefitResponse> GetBenefitResponseAsync(getMaxBenefitRequest request)
        {
            getMaxBenefitResponse getBenefitResponse = new getMaxBenefitResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                //var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await clientHelper.PostAsync(AxaSolUrls.MaxAndMinBenefit, content);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    getBenefitResponse = JsonConvert.DeserializeObject<getMaxBenefitResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    getBenefitResponse = JsonConvert.DeserializeObject<getMaxBenefitResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return getBenefitResponse;

        }

        public async Task<List<BankDTO>> GetBankList()
        {
            List<BankDTO> BankList = new List<BankDTO>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await clientHelper.GetAsync(AxaSolUrls.getBankList);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    BankList = JsonConvert.DeserializeObject<List<BankDTO>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    BankList = JsonConvert.DeserializeObject<List<BankDTO>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return BankList;

        }

        public async Task<List<string>> CalculateBonusLifePremium(BonusLifePremiumRequest request)
        {
            List<string> Response = new List<string>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                //var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                //clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                //var response = await clientHelper.GetAsync(AxaSolUrls.calculateBonusLifePremium + content);
                var req = new HttpRequestMessage
                {
                    Method = HttpMethod.Get,
                    RequestUri = new Uri(AxaSolUrls.calculateBonusLifePremium),
                    Content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json"),
                };

                var response = await clientHelper.SendAsync(req).ConfigureAwait(false);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<List<string>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<List<string>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }

        public async Task<bool> SendEpaymentMail(EpaymentRequest request)
        {
            bool MailSent = false;

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.EpaymentMail, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return MailSent;

        }

        public async Task<bool> SendFeedbackMail(FeedbackRequest request)
        {
            bool MailSent = false;

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.FeedbackMail, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return MailSent;

        }

        public async Task<SyncDataSample> GetBranches(int type)
        {
            SyncDataSample Response = new SyncDataSample();
            string value = null;

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.getBranches + type);

                if (response.IsSuccessStatusCode)
                {
                    value = response.Content.ReadAsStringAsync().Result;

                    Response = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
                else
                {
                    value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
            }
            catch (Exception ex)
            {

            }
            return Response;
        }

        public async Task<List<DestinationCountries>> GetTravelDestinations()
        {
            List<DestinationCountries> Response = new List<DestinationCountries>();
            string value = null;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await client.GetAsync(AxaSolUrls.getTravelDestinations);

                if (response.IsSuccessStatusCode)
                {
                    value = response.Content.ReadAsStringAsync().Result;

                    Response = JsonConvert.DeserializeObject<List<DestinationCountries>>(value);
                }
                else
                {
                    value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<List<DestinationCountries>>(value);
                }
            }
            catch (Exception ex)
            {

            }
            return Response;
        }

        public async Task<List<TravelVariants>> GetTravelVariants(int planTypeId, int destinationId)
        {
            List<TravelVariants> Response = new List<TravelVariants>();
            string value = null;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.getTravelVariants + "planTypeId=" + planTypeId + "&destinationId=" + destinationId);

                if (response.IsSuccessStatusCode)
                {
                    value = response.Content.ReadAsStringAsync().Result;

                    Response = JsonConvert.DeserializeObject<List<TravelVariants>>(value);
                }
                else
                {
                    value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<List<TravelVariants>>(value);
                }
            }
            catch (Exception ex)
            {

            }
            return Response;
        }

        public async Task<TravelRIPlanSample> GetTravelRIObject(TravelRIPlanRequest request)
        {
            TravelRIPlanSample travelRIPlanSample = new TravelRIPlanSample();

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.getTraveRIPlanSample, content);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    travelRIPlanSample = JsonConvert.DeserializeObject<TravelRIPlanSample>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    travelRIPlanSample = JsonConvert.DeserializeObject<TravelRIPlanSample>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return travelRIPlanSample;
        }

        public async Task<TravelCostResponse> TravelCostAsync(TravelCostRequestModel request)
        {
            TravelCostResponse Response = new TravelCostResponse();
            DigitalAPICredentials digitalAPICredentials = new DigitalAPICredentials();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await httpClient.GetAsync(AxaSolUrls.getDigitalCredentials);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    digitalAPICredentials = JsonConvert.DeserializeObject<DigitalAPICredentials>(value);

                    if (digitalAPICredentials != null && !string.IsNullOrEmpty(digitalAPICredentials.Url) && !string.IsNullOrEmpty(digitalAPICredentials.Base64EncodedUsernamePassword))
                    {
                        string newJson = JsonConvert.SerializeObject(request);
                        var client = new RestClient(digitalAPICredentials.Url);
                        var MyRequest = new RestRequest(Method.POST);

                        MyRequest.AddHeader("Authorization", "Basic " + digitalAPICredentials.Base64EncodedUsernamePassword);
                        MyRequest.AddHeader("Content-Type", "application/json");
                        MyRequest.AddParameter("undefined", newJson, ParameterType.RequestBody);

                        IRestResponse result = client.Execute(MyRequest);
                        if (result.StatusCode == System.Net.HttpStatusCode.OK)
                        {
                            Response = JsonConvert.DeserializeObject<TravelCostResponse>(result.Content);
                        }
                        else
                        {
                            Response = JsonConvert.DeserializeObject<TravelCostResponse>(result.Content);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return Response;
        }

        public async Task<AutoGoResponse> TravelBookingAsync(TravelBookingRequest request)
        {
            AutoGoResponse travelBookingResponse = new AutoGoResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                string requestBody = JsonConvert.SerializeObject(request);

                var content = new StringContent(requestBody, Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.TravelBooking, content);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    travelBookingResponse = JsonConvert.DeserializeObject<AutoGoResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    travelBookingResponse = JsonConvert.DeserializeObject<AutoGoResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return travelBookingResponse;
        }

        public async Task<string> TravelCertificateAndMailAsync(TravelCertRequest request)
        {
            string response = string.Empty;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);

                string req = JsonConvert.SerializeObject(request);
                var content = new StringContent(req, Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var res = await httpClient.PostAsync(AxaSolUrls.travelCertificate, content);

                if (res.IsSuccessStatusCode)
                {
                    var value = res.Content.ReadAsStringAsync().Result;
                    response = JsonConvert.DeserializeObject<string>(value);
                }
                else
                {
                    var value = res.Content.ReadAsStringAsync().Result;
                    response = JsonConvert.DeserializeObject<string>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return response;
        }

        public async Task<bool> SendReferralLinkMail(ReferralLinkRequest request)
        {

            bool MailSent = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(10);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.ReferralLinkMail, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return MailSent;

        }
        public async Task<bool> InsertAgentAuthTokenIntoDB(AgentAuth request)
        {

            bool Inserted = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(10);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.InsertAgentAuthTokenIntoDB, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Inserted = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Inserted = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Inserted;

        }
        public async Task<bool> DeleteAgentAuthTokenIntoDB(AgentAuth request)
        {

            bool Deleted = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(10);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.DeleteAgentAuthTokenIntoDB, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Deleted = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Deleted = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Deleted;

        }
        public async Task<AgentAuthResponse> ValidateAgentAuthToken(AgentAuth request)
        {
            AgentAuthResponse AgentAuthResponse = new AgentAuthResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                // var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.ValidateAgentAuthToken, content);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    AgentAuthResponse = JsonConvert.DeserializeObject<AgentAuthResponse>(value);

                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    AgentAuthResponse = JsonConvert.DeserializeObject<AgentAuthResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return AgentAuthResponse;

        }
        public async Task<bool> SendEformLinkMail(EformRequest request)
        {

            bool MailSent = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(10);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.EformLinkMail, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return MailSent;

        }
        public async Task<bool> InsertPaperFnaIntoDB(PaperFna request)
        {

            bool Inserted = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(10);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.InsertPaperFnaIntoDB, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Inserted = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Inserted = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Inserted;

        }
        public async Task<HttpResponseMessage> BearerTokenRegister(RegisterToken request)
        {
            var response = new HttpResponseMessage();

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(10);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                //clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                response = await clientHelper.PostAsync(AxaSolUrls.RegisterBearerToken, content);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return response;

        }
        public async Task<BearerTokenResponse> TokenGeneration(EncryptionReq request)
        {
            BearerTokenResponse Response = new BearerTokenResponse();

            try
            {

                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                //var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");

                var response = await clientHelper.PostAsync(AxaSolUrls.TokenGeneration, content);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<BearerTokenResponse>(value);

                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<BearerTokenResponse>(value);


                }


            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;

        }
        public async Task<LifeSavingsResponse> GetLifeSavingsQuote(LifeSavingsRequest request)
        {
            LifeSavingsResponse lifeSavingResponse = new LifeSavingsResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                //var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.LifeSavingsQuote, content);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    lifeSavingResponse = JsonConvert.DeserializeObject<LifeSavingsResponse>(value);

                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    lifeSavingResponse = JsonConvert.DeserializeObject<LifeSavingsResponse>(value);


                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return lifeSavingResponse;

        }
        public async Task<bool> InsertPaymentDetails(PaymentDetails payment)
        {
            bool saved = false;

            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(payment), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.InsertPaymentDetails, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int save = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (save == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.InsertPaymentDetails, content);

                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            saved = JsonConvert.DeserializeObject<bool>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            saved = JsonConvert.DeserializeObject<bool>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return saved;
        }
        public async Task<List<Products>> GetEformsProducts()
        {
            List<Products> Products = new List<Products>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.GetAsync(AxaSolUrls.getEFormsProducts);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Products = JsonConvert.DeserializeObject<List<Products>>(value);
                }

                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Products = JsonConvert.DeserializeObject<List<Products>>(value);

                }
            }
            catch (Exception ex)
            {

                ex.Message.ToString();
            }
            return Products;
        }

        public async Task<EformsBaseUrl> GetReferralLinkBaseUrl()
        {
            EformsBaseUrl Response = new EformsBaseUrl();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.GetAsync(AxaSolUrls.getReferralLinkBaseUrl);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<EformsBaseUrl>(value);
                }

                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<EformsBaseUrl>(value);

                }
            }
            catch (Exception ex)
            {

                ex.Message.ToString();
            }
            return Response;
        }
        public async Task<bool> SavedBookingDetails(SavedBookingRequest savedBooking)
        {
            bool Logged = false;

            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(savedBooking), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.SavedBookingRequest, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int save = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (save == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.SavedBookingRequest, content);

                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            Logged = JsonConvert.DeserializeObject<bool>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            Logged = JsonConvert.DeserializeObject<bool>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Logged = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Logged = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Logged;
        }
        public async Task<EformsBaseUrl> GetEformsBaseUrl()
        {
            EformsBaseUrl Response = new EformsBaseUrl();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.GetAsync(AxaSolUrls.getEformsLinkBaseUrl);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<EformsBaseUrl>(value);
                }

                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<EformsBaseUrl>(value);

                }
            }
            catch (Exception ex)
            {

                ex.Message.ToString();
            }
            return Response;
        }
        public async Task<PayStackPaymentResponse> InitiatePayStackPaymentAsyncTest(PayStackPaymentRequest payStackPaymentRequest)
        {
            PayStackPaymentResponse paymentResponse = new PayStackPaymentResponse();

            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                //var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";

                var content = new StringContent(JsonConvert.SerializeObject(payStackPaymentRequest), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);

                var response = await clientHelper.PostAsync(AxaSolUrls.InitiatePayStackPaymentTest, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                //        response = await clientHelper.PostAsync(AxaSolUrls.InitiatePayStackPaymentTest, content);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            paymentResponse = JsonConvert.DeserializeObject<PayStackPaymentResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            paymentResponse.Message = JsonConvert.DeserializeObject<PayStackPaymentResponse>(value).Message;
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    paymentResponse = JsonConvert.DeserializeObject<PayStackPaymentResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    paymentResponse.Message = JsonConvert.DeserializeObject<PayStackPaymentResponse>(value).Message;
                }
            }
            catch (Exception ex)
            {
                paymentResponse.Message = ex.Message.ToString();
            }

            return paymentResponse;
        }

        public async Task<VerifyPayStackPaymentResponse> VerifyPayStackPaymentResponseAsyncTest(VerifyPayStackPaymentRequest request)
        {
            VerifyPayStackPaymentResponse verifyPayStackPaymentResponse = new VerifyPayStackPaymentResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                //var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.VerifyPayStackPaymentTest, content);

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await clientHelper.PostAsync(AxaSolUrls.VerifyPayStackPaymentTest, content);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            verifyPayStackPaymentResponse = JsonConvert.DeserializeObject<VerifyPayStackPaymentResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            verifyPayStackPaymentResponse.Message = JsonConvert.DeserializeObject<VerifyPayStackPaymentResponse>(value).Message;
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    verifyPayStackPaymentResponse = JsonConvert.DeserializeObject<VerifyPayStackPaymentResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    verifyPayStackPaymentResponse.Message = JsonConvert.DeserializeObject<VerifyPayStackPaymentResponse>(value).Message;
                }
            }
            catch (Exception ex)
            {
                verifyPayStackPaymentResponse.Message = ex.Message.ToString();
            }

            return verifyPayStackPaymentResponse;
        }
        public async Task<GeneralBizPdfCertResponse> GenerateEppProjectionSheet(EPPprojectionsheetRequest request)
        {
            GeneralBizPdfCertResponse certResponse = new GeneralBizPdfCertResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                //var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";
                var RequestData = JsonConvert.SerializeObject(request);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await client.PostAsync(AxaSolUrls.GenerateEppProjectionSheet, content);
                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{

                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await client.PostAsync(AxaSolUrls.generalBizPdfCert, content);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return certResponse;
        }

        public async Task<QuotePaymentResponse> GetPaymentResponseAsync(string quoteid)
        {
            QuotePaymentResponse Response = new QuotePaymentResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.GetAsync(AxaSolUrls.GetPaymentResponse + quoteid);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<QuotePaymentResponse>(value);
                }

                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<QuotePaymentResponse>(value);

                }
            }
            catch (Exception ex)
            {

                ex.Message.ToString();
            }
            return Response;
        }
        public async Task<bool> InsertFeatureUsage(FeatureUsage featureUsage)
        {
            bool inserted = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(featureUsage), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.logFeatureUsage, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return inserted;
        }

        public async Task<bool> InsertFeedbackDetails(AxaSolLiteProcessEfficiency processEfficiency)// tobis example 
        {
            bool inserted = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(processEfficiency), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.logAgentComplaint, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return inserted;
        }


        public async Task<bool> InsertCustomerReferralRate(AxaSolLiteReferralRate liteReferralRate)
        {
            bool inserted = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(liteReferralRate), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.logReferralRate, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return inserted;
        }
        public async Task<GeneralBizPdfCertResponse> LifeSavingsCertificate(LifeSavingPdfCertRequest request)
        {
            GeneralBizPdfCertResponse certResponse = new GeneralBizPdfCertResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                //var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.PostAsync(AxaSolUrls.lifesavingsPdfCert, content);
                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{
                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await client.PostAsync(AxaSolUrls.lifesavingsPdfCert, content);

                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                //        }
                //    }

                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return certResponse;
        }
        public async Task<SyncDataSample> GetOccupationList()
        {
            SyncDataSample occupation = new SyncDataSample();
            try
            {
                //Agent AgentBearer = await GetLastAgent();

                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(AxaSolUrls.getOccupationList);

              

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    occupation = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    occupation = JsonConvert.DeserializeObject<SyncDataSample>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return occupation;
        }
        public async Task<bool> InsertCustomerSignature(ProspectSignatureConsent request)
        {
            bool inserted = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.InsertCustomerSignature, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return inserted;
        }
        public async Task<CaseIdStatusResponse> VerifyCaseApproval(string caseid)
        {
            CaseIdStatusResponse Response = new CaseIdStatusResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.GetAsync(AxaSolUrls.verifyOnboardingStatus + caseid);



                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<CaseIdStatusResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<CaseIdStatusResponse>(value);
                }

            }
            catch (Exception edx)
            {
                edx.Message.ToString();
            }
            return Response;
        }
        public async Task<string> GetEncryptValue(string value)
        {
            string Response = string.Empty;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.GetAsync(AxaSolUrls.encryptValue + value);



                if (response.IsSuccessStatusCode)
                {
                    var val = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<string>(val);
                }
                else
                {
                    var val = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<string>(val);
                }

            }
            catch (Exception edx)
            {
                edx.Message.ToString();
            }
            return Response;
        }
        public async Task<bool> SendEMarketingMail(EmarketingRequest request)
        {

            bool MailSent = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(10);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.EmarketingMail, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return MailSent;

        }
        public async Task<bool> SendPaperFNAMail(PaperFnaRequest request)
        {

            bool MailSent = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(10);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.PaperFNAMail, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return MailSent;

        }

        public async Task<List<string>> GetReasonsForAmbition()
        {
            List<string> Reasons = new List<string>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                httpClient.Timeout = TimeSpan.FromMinutes(5);

                var response = await httpClient.GetAsync(AxaSolUrls.getAmbitionReasons);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Reasons = JsonConvert.DeserializeObject<List<string>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Reasons = JsonConvert.DeserializeObject<List<string>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return Reasons;
        }

        public async Task<List<ProductLogDataResponse>> GetProductLogData(string productname, string parentid)
        {
            List<ProductLogDataResponse> ProductLogData = new List<ProductLogDataResponse>();

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);

                var Urllink = "https://careers.axamansard.com/AXASalesProcessor/api/Dmt/GetProductLogData?tableName=" + productname + "&parentId=" + parentid;

                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.GetAsync(Urllink);

                response.EnsureSuccessStatusCode();
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    ProductLogData = JsonConvert.DeserializeObject<List<ProductLogDataResponse>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    ProductLogData = JsonConvert.DeserializeObject<List<ProductLogDataResponse>>(value);

                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return ProductLogData;
        }
        public async Task<bool> UpdateProductLogData(UpdateProductLogDataRequest productlog)
        {
            bool saved = false;

            try
            {

                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(productlog), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.UpdateProductLog, content);


                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return saved;
        }
        public async Task<bool> InsertProductLogData(ProductLogDataRequest productlogdata)
        {
            bool saved = false;

            try
            {

                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(productlogdata), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.InsertProductLog, content);


                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    saved = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return saved;
        }



        public async Task<CashBackQuoteResponse> GetCashBackQuote(CashBackQuoteRequest request)
        {
            CashBackQuoteResponse cashbackResponse = new CashBackQuoteResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                //var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";

                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await clientHelper.PostAsync(AxaSolUrls.CashbackQuote, content);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    cashbackResponse = JsonConvert.DeserializeObject<CashBackQuoteResponse>(value);

                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    cashbackResponse = JsonConvert.DeserializeObject<CashBackQuoteResponse>(value);


                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return cashbackResponse;

        }
        public async Task<Hospitals> GetHospitals(string url, string token, string PlanCode, string state)
        {
            Hospitals hospitals = new Hospitals();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var response = await httpClient.GetAsync(url + "/" + PlanCode + "/" + state + "/get-retail-hospitals");

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    hospitals = JsonConvert.DeserializeObject<Hospitals>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    hospitals = JsonConvert.DeserializeObject<Hospitals>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return hospitals;
        }

        public async Task<List<Genotypes>> GetGenotypes(string url, string token)
        {
            List<Genotypes> genotypes = new List<Genotypes>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var response = await httpClient.GetAsync(url + "/get-genotype");

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    genotypes = JsonConvert.DeserializeObject<List<Genotypes>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    genotypes = JsonConvert.DeserializeObject<List<Genotypes>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return genotypes;
        }

        public async Task<List<Plans>> GetHealthPlanCost(string url, string token)
        {
            List<Plans> Plans = new List<Plans>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var response = await httpClient.GetAsync(url + "/get-plans");

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Plans = JsonConvert.DeserializeObject<List<Plans>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Plans = JsonConvert.DeserializeObject<List<Plans>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return Plans;
        }

        public async Task<List<HealthStates>> GetHealthStates(string url, string token)
        {
            List<HealthStates> states = new List<HealthStates>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var response = await httpClient.GetAsync(url + "/hospital-states");

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    states = JsonConvert.DeserializeObject<List<HealthStates>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    states = JsonConvert.DeserializeObject<List<HealthStates>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return states;
        }

        public async Task<List<Towns>> GetHealthTowns(string url, string token, string state)
        {
            List<Towns> Towns = new List<Towns>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var response = await httpClient.GetAsync(url + "/" + state + "/hospital-town");

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Towns = JsonConvert.DeserializeObject<List<Towns>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Towns = JsonConvert.DeserializeObject<List<Towns>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return Towns;
        }

        public async Task<List<HealthPreExistingConditions>> GetPreExistingConditions(string url, string token)
        {
            List<HealthPreExistingConditions> healthPreExistingConditions = new List<HealthPreExistingConditions>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var response = await httpClient.GetAsync(url + "/get-conditions");

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    healthPreExistingConditions = JsonConvert.DeserializeObject<List<HealthPreExistingConditions>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    healthPreExistingConditions = JsonConvert.DeserializeObject<List<HealthPreExistingConditions>>(value);
                }
            }
            catch (Exception d)
            {
                d.Message.ToString();
            }
            return healthPreExistingConditions;
        }

        public async Task<HealthBookingResponse> BookHealthPolicy(HealthBookingObject healthBookingObject, string token, string url)
        {
            HealthBookingResponse Response = new HealthBookingResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.Timeout = TimeSpan.FromMinutes(10);
                string SerializedObject = JsonConvert.SerializeObject(healthBookingObject);
                var content = new StringContent(JsonConvert.SerializeObject(healthBookingObject), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var response = await httpClient.PostAsync(url + "process-health", content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<HealthBookingResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<HealthBookingResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return Response;
        }

        public async Task<HealthAPICredentials> GetHealthAPICredentials()
        {
            HealthAPICredentials healthAPICredentials = new HealthAPICredentials();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.GetAsync(AxaSolUrls.getHealthCredentials);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    healthAPICredentials = JsonConvert.DeserializeObject<HealthAPICredentials>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    healthAPICredentials = JsonConvert.DeserializeObject<HealthAPICredentials>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return healthAPICredentials;
        }

        public async Task<GeneralBizPdfCertResponse> GenerateLifePlusProjectionSheet(LifePlusProjectionSheetRequest request)
        {
            GeneralBizPdfCertResponse certResponse = new GeneralBizPdfCertResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);

                var RequestData = JsonConvert.SerializeObject(request);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.PostAsync(AxaSolUrls.GenerateLifePlusProjectionSheet, content);
                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{
                //    EncryptionReq req = new EncryptionReq();
                //    req.encryptedDetails = AgentBearer.TokenEncrypt;
                //    BearerTokenResponse res = await TokenGeneration(req);
                //    AgentBearer.AgentAuthToken = res.AccessToken;
                //    int saved = await _agentRepository.UpdateAsync(AgentBearer);
                //    if (saved == 1)
                //    {
                //        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AgentBearer.AgentAuthToken);
                //        response = await client.PostAsync(AxaSolUrls.GenerateLifePlusProjectionSheet, content);
                //        if (response.IsSuccessStatusCode)
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                //        }
                //        else
                //        {
                //            var value = response.Content.ReadAsStringAsync().Result;
                //            certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                //        }
                //    }
                //}

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return certResponse;
        }

        public async Task<GeneralBizPdfCertResponse> LifePlusCertificate(LifePlusCertificateRequest request)
        {
            GeneralBizPdfCertResponse Response = new GeneralBizPdfCertResponse();

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                string SerializedRequest = JsonConvert.SerializeObject(request);
                var content = new StringContent(SerializedRequest, Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await httpClient.PostAsync(AxaSolUrls.LifePlusCert, content);
                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return Response;
        }
        public async Task<GeneralBizPdfCertResponse> GenerateBonusLifeProjectionSheet(BonusLifeprojectionsheetRequest request)
        {
            GeneralBizPdfCertResponse certResponse = new GeneralBizPdfCertResponse();
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                //var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";
                var RequestData = JsonConvert.SerializeObject(request);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await client.PostAsync(AxaSolUrls.GenerateBonusLifeProjectionSheet, content);


                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    certResponse = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return certResponse;
        }
        public async Task<BonusLifeProjectionResponse[]> GenerateBonusLifeProjectionValues(BonusLifeProjectionValues request)
        {
            BonusLifeProjectionResponse[] Response = new BonusLifeProjectionResponse[16];
            try
            {
                //Agent AgentBearer = await GetLastAgent();
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                //var Bearer = "5mxOif9hqlXWwhnIFgofgF_Ft1s7Ed_1S9Ok25BDhDk_qGRIgF8PWBinor5MHbRZnSvhWuLEmTY0O59b694aquYw5ckNeUgPSy_HkDmUjUjxU-xXtWyY-QVABEbANruAm7OIbzYtYayqG0bPU9-zLAcA0gQHczdkgsIGxZXT5WiduOApLrX4oklPdMS2HqWtOW0NpyX4F0KFowrVznN04lIkiyoOBCWNq8PnlgssGOMrVQ1kHJ0O6lgoqY1IiGUVkqfppLn9xuCSPYZDcXjOBoHg7fwLkrtR7xf9kZNiy6l7Kikg6vok2uYD0KBGhafLg4tcqRIc2-Vpyxntw-mRGwgcVST_h9M250EXfbmm9vLAN1ekwgI2VOtsOSEZjF16bLm7rRq9So_nARFfzpajKjeurDVGsVGYN9vnFhUcCIkDb5y3O0FEeq_Jik0F_7-BUc6_pSN9rxL7WXJ6DILfZ0TKz5-m22dWA0dshDYzV84aZ44DeER8eKC-dYHTujAH";
                var RequestData = JsonConvert.SerializeObject(request);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await client.PostAsync(AxaSolUrls.GenerateBonusLifeProjectionValues, content);


                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<BonusLifeProjectionResponse[]>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<BonusLifeProjectionResponse[]>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }

        public async Task<PersonalAccidentCalcResponse> PersonalAccidentCalc(PersonalAccidentCalcRequest request)
        {
            PersonalAccidentCalcResponse personalAccidentCalcResponse = new PersonalAccidentCalcResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var content = new StringContent(JsonConvert.SerializeObject(request), System.Text.Encoding.UTF8, "application/json");
                var response = await httpClient.PostAsync(AxaSolUrls.personalAccidentCalculator, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    personalAccidentCalcResponse = JsonConvert.DeserializeObject<PersonalAccidentCalcResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    personalAccidentCalcResponse = JsonConvert.DeserializeObject<PersonalAccidentCalcResponse>(value);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return personalAccidentCalcResponse;
        }

        public async Task<PersonalAccidentBookingResponse> BookPersonalAccident(PersonalAccidentBookingDTO request)
        {
            PersonalAccidentBookingResponse Response = new PersonalAccidentBookingResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);

                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                string reqObj = JsonConvert.SerializeObject(request);
                var content = new StringContent(reqObj, System.Text.Encoding.UTF8, "application/json");
                var response = await httpClient.PostAsync(AxaSolUrls.bookPersonalAccident, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<PersonalAccidentBookingResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<PersonalAccidentBookingResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return Response;
        }

        public async Task<GeneralBizPdfCertResponse> SendPersonalAccidentCertificate(PersonalAccidentCertificateRequest request)
        {
            GeneralBizPdfCertResponse Response = new GeneralBizPdfCertResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);

                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                string reqObj = JsonConvert.SerializeObject(request);
                var content = new StringContent(reqObj, System.Text.Encoding.UTF8, "application/json");
                var response = await httpClient.PostAsync(AxaSolUrls.sendPersonalAccidentCert, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<GeneralBizPdfCertResponse>(value);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Response;
        }

        public async Task<int> GetPolicyGracePeriod(string PolicyNo)
        {
            int gracePeriod = 0;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);

                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.GetAsync(AxaSolUrls.gracePeriodUrl + PolicyNo);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    gracePeriod = JsonConvert.DeserializeObject<int>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    gracePeriod = JsonConvert.DeserializeObject<int>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return gracePeriod;
        }

        public async Task<OnyxResponse> GetOnyxValues(string PolicyNo)
        {
            OnyxResponse onyxResponse = new OnyxResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);

                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.GetAsync(AxaSolUrls.onyxURL + PolicyNo);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    onyxResponse = JsonConvert.DeserializeObject<OnyxResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    onyxResponse = JsonConvert.DeserializeObject<OnyxResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return onyxResponse;
        }

        public async Task<List<CustNameDetailsResponse>> GetCustomerDetailsByCustomerName(string customerName)
        {
            List<CustNameDetailsResponse> customerDetailsReponse = new List<CustNameDetailsResponse>();
            string value = null;

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.getCustomerDetailsByCustomerName + customerName);

                if (response.IsSuccessStatusCode)
                {
                    value = response.Content.ReadAsStringAsync().Result;

                    customerDetailsReponse = JsonConvert.DeserializeObject<List<CustNameDetailsResponse>>(value);
                }
                else
                {
                    value = response.Content.ReadAsStringAsync().Result;
                    customerDetailsReponse = JsonConvert.DeserializeObject<List<CustNameDetailsResponse>>(value);
                }
            }
            catch (Exception ex)
            {

            }
            return customerDetailsReponse;
        }
        public async Task<CustNumberDetailsResponse> GetPolicyDetailsByCustomerNumber(string customerNumber)
        {
            CustNumberDetailsResponse policyDetailsReponse = new CustNumberDetailsResponse();
            string value = null;

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.getPolicyDetailsByCustomerNumber + customerNumber);

                if (response.IsSuccessStatusCode)
                {
                    value = response.Content.ReadAsStringAsync().Result;

                    policyDetailsReponse = JsonConvert.DeserializeObject<CustNumberDetailsResponse>(value);
                }
                else
                {
                    value = response.Content.ReadAsStringAsync().Result;
                    policyDetailsReponse = JsonConvert.DeserializeObject<CustNumberDetailsResponse>(value);
                }
            }
            catch (Exception ex)
            {

            }
            return policyDetailsReponse;
        }
        public async Task<List<PolicyNumberDetailsResponse>> GetPolicyDetailsByPolicyNumber(string PolicyId)
        {
            List<PolicyNumberDetailsResponse> policyDetailsReponse = new List<PolicyNumberDetailsResponse>();
            string value = null;

            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.getPolicyDetailsByPolicyNumber + PolicyId);

                if (response.IsSuccessStatusCode)
                {
                    value = response.Content.ReadAsStringAsync().Result;

                    policyDetailsReponse = JsonConvert.DeserializeObject<List<PolicyNumberDetailsResponse>>(value);
                }
                else
                {
                    value = response.Content.ReadAsStringAsync().Result;
                    policyDetailsReponse = JsonConvert.DeserializeObject<List<PolicyNumberDetailsResponse>>(value);
                }
            }
            catch (Exception ex)
            {

            }
            return policyDetailsReponse;
        }
        public async Task<LeadGeneratorResponse> GenerateLeadAccount(LeadGeneratorRequest request)
        {
            LeadGeneratorResponse Response = new LeadGeneratorResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                string requestString = JsonConvert.SerializeObject(request);
                var content = new StringContent(requestString, System.Text.Encoding.UTF8, "application/json");
                var response = await client.PostAsync(AxaSolUrls.GenerateLeadAccount, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<LeadGeneratorResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<LeadGeneratorResponse>(value);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Response;
        }

        public async Task<RenewalBookingResponse> RenewMotorPolicy(AutoClassicRenewalRequest request)
        {
            RenewalBookingResponse Response = new RenewalBookingResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(request), System.Text.Encoding.UTF8, "application/json");
                var response = await clientHelper.PostAsync(AxaSolUrls.renewMotorPolicy, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<RenewalBookingResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<RenewalBookingResponse>(value);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Response;
        }

        public async Task<List<ResultSample>> GetCarColors()
        {
            List<ResultSample> Response = new List<ResultSample>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var response = await clientHelper.GetAsync(AxaSolUrls.getCarColors);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<List<ResultSample>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<List<ResultSample>>(value);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Response;
        }

        public async Task<NINResponse> GetNINDetails(NINRequest nINRequest)
        {
            NINResponse Response = new NINResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                var content = new StringContent(JsonConvert.SerializeObject(nINRequest), System.Text.Encoding.UTF8, "application/json");
                //var content = new StringContent(JsonConvert.SerializeObject(nINRequest), System.Text.Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var response = await clientHelper.PostAsync(AxaSolUrls.getNINDetails, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<NINResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<NINResponse>(value);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Response;
        }

        public async Task<bool> InsertPolicyIdPayment(NewPaymentDetails request)
        {
            bool inserted = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.InsertNewPaymrntDetails, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return inserted;
        }

        public async Task<AccountBalanceResponse> GetCustomerAccountBalance(string customerNumber)
        {
            AccountBalanceResponse Response = new AccountBalanceResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.getCustomerAccountBalance + customerNumber);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<AccountBalanceResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<AccountBalanceResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }

        public async Task<LeadAccountStatusResponse> GetLeadAccountStatus(string customerNumber)
        {
            LeadAccountStatusResponse Response = new LeadAccountStatusResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.getLeadAccountStatus + customerNumber);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<LeadAccountStatusResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<LeadAccountStatusResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }

        public async Task<bool> SendLeadAccountMail(LeadAccountMailRequest request)
        {
            bool MailSent = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(10);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.SendLeadAccountMail, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return MailSent;
        }

        public async Task<bool> SendPaymentNotificationMail(PaymentNotificationRequest request)
        {

            bool MailSent = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(10);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.SendPaymentNotificationMail, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return MailSent;

        }

        public async Task<CustomerUpdateResponse> UpdateCustomerDetails(CustomerUpdate update)
        {
            CustomerUpdateResponse Response = new CustomerUpdateResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
                var serializedRequest = JsonConvert.SerializeObject(update);
                var content = new StringContent(serializedRequest, System.Text.Encoding.UTF8, "application/json");
                //clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var response = await clientHelper.PostAsync(AxaSolUrls.UpdateCustomerAccount, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<CustomerUpdateResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<CustomerUpdateResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return Response;
        }

        public async Task<bool> SendEkycCompletedMail(string CustNo, string CustName, string CustEmail, string AgentEmail)
        {
            bool MailSent = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.SendCompleteEkycMail + "SendEkyCompletedMail?CustNo=" + CustNo + "&CustName=" + CustName + "&CustEmail=" + CustEmail + "&AgentEmail=" + AgentEmail);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return MailSent;
        }

        public async Task<string> GetGracePeriod()
        {
            string gracePeriod = string.Empty;
            try
            {

              
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);
               
                clientHelper.Timeout = TimeSpan.FromMinutes(10);
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
              
                var response = await clientHelper.GetAsync(AxaSolUrls.getGracePeriod);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    gracePeriod = JsonConvert.DeserializeObject<string>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    gracePeriod = JsonConvert.DeserializeObject<string>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return gracePeriod;

        }

        public async Task<bool> EditProspectInformation(ProspectUpdate model)
        {
            bool updated = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
                var response = await client.PostAsync(AxaSolUrls.editProspectInfo, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    updated = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    updated = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return updated;
        }

        public async Task<bool> EkycReport(EkycReportRequest request)
        {
            bool inserted = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.EkycReport, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return inserted;
        }

        public async Task<bool> UpdateEkycReport(UpdateEkycStatus request)
        {
            bool updated = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.UpdateEkycStatus, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    updated = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    updated = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return updated;
        }
        public async Task<UserAccountStatus> GetUserAccountStatusByUsername(string Username)
        {
            UserAccountStatus Response = new UserAccountStatus();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.GetUserAccountStatus + Username);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<UserAccountStatus>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<UserAccountStatus>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }
        public async Task<bool> UpdateUserAccountStatus(string Username)
        {
            bool updated = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.Timeout = TimeSpan.FromMinutes(5);
               
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.GetAsync(AxaSolUrls.UpdateUserAccountStatus + Username);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    updated = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    updated = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return updated;
        }
        public async Task<bool> InsertUserAccountStatus(InsertAccountStatus Request)
        {
            bool inserted = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(Request), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.InsertUserAccountStatus, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return inserted;
        }
        public async Task<AAMDetails> GetAAMDetailsByAdvisorsCode(string AgentCode)
        {
            AAMDetails Response = new AAMDetails();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.getAAMDetailsByAdvisorsCode + AgentCode);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<AAMDetails>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<AAMDetails>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }
        public async Task<ApprovalLog> GetApprovalLogByCaseId(string CaseId)
        {
            ApprovalLog Response = new ApprovalLog();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.getApprovalLogByCaseId + CaseId);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<ApprovalLog>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<ApprovalLog>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }
        public async Task<List<ApprovalLog>> GetApprovalLogByAgentCode(string AgentCode)
        {
            List<ApprovalLog> Response = new List<ApprovalLog>();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient client = new HttpClient(clientHandler);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await client.GetAsync(AxaSolUrls.getApprovalLogByAgentCode + AgentCode);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<List<ApprovalLog>>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<List<ApprovalLog>>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }
        public async Task<bool> UpdateApprovalLog(UpdateApprovaLog Request)
        {
            bool updated = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(Request), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.UpdateApprovalLog, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    updated = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    updated = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return updated;
        }
        public async Task<bool> InsertApprovalLog(ApprovalLogRequest Request)
        {
            bool inserted = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient(clientHandler);
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(Request), Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await httpClient.PostAsync(AxaSolUrls.InsertApprovalLog, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    inserted = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return inserted;
        }
        public async Task<bool> SendApprovalMail(ApprovalMail request)
        {
            bool MailSent = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(10);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.SendApprovalMail, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return MailSent;
        }
        public async Task<bool> SendApprovalRequestMail(ApprovalRquestMail request)
        {
            bool MailSent = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(10);
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.SendApprovalRequestMail, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    MailSent = JsonConvert.DeserializeObject<bool>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return MailSent;
        }  
        public async Task<TravelQuotesResponse> GetTravelQuotesKey (TravelQuotesModel travelQuotesModel)
        {
            TravelQuotesResponse travelQuotesResponse = new TravelQuotesResponse();
            try
            {
                string serializedRequest = JsonConvert.SerializeObject(travelQuotesModel);

                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient httpClient = new HttpClient();
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(serializedRequest, Encoding.UTF8, "application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);

                var response = await httpClient.PostAsync(AxaSolUrls.getTravelQuoteKey, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    travelQuotesResponse = JsonConvert.DeserializeObject<TravelQuotesResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    travelQuotesResponse = JsonConvert.DeserializeObject<TravelQuotesResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return travelQuotesResponse;
        }
        public async Task<NaicomIdResponse> GetNaicomId (string NaicomId, bool isLife)
        {
            NaicomIdResponse Response = new NaicomIdResponse();
            try
            {
                NaicomIdLoad naicomIdLoad = new NaicomIdLoad
                {
                    RequestPayload = NaicomId,
                    IsLife = isLife
                };
                //Agent AgentBearer = await GetLastAgent();

                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(naicomIdLoad), Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
                var response = await clientHelper.PostAsync(AxaSolUrls.getNaicomId, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<NaicomIdResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<NaicomIdResponse>(value);
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Response;
        }

        public async Task<bool> SendHealthApprovalMail(HealthApprovalDetails healthApprovalDetails)
        {
            bool Sent = false;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                string Request = JsonConvert.SerializeObject(healthApprovalDetails);
                var content = new StringContent(Request, Encoding.UTF8, "application/json");
                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                var response = await clientHelper.PostAsync(AxaSolUrls.SendHealthApprovalMail, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    var Response = JsonConvert.DeserializeObject<EmailSenderVM>(value);
                    Sent = Response.ActionStatus;
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    var Response = JsonConvert.DeserializeObject<EmailSenderVM>(value);
                    Sent = Response.ActionStatus;
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return Sent;
        }

        public async Task<InvestmentConfirmBVNResponse> BVNVerify(InvestmentConfirmBvnRequest request)
        {
            InvestmentConfirmBVNResponse Response = new InvestmentConfirmBVNResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(request), System.Text.Encoding.UTF8, "application/json");
                var response = await clientHelper.PostAsync(AxaSolUrls.BVNVerify, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<InvestmentConfirmBVNResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<InvestmentConfirmBVNResponse>(value);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Response;
        }

        public async Task<CreateClientResponse> InvestmentClientOnboard(InvestmentCreateClientRequest request)
        {
            CreateClientResponse Response = new CreateClientResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                clientHelper.Timeout = TimeSpan.FromMinutes(5);
                var content = new StringContent(JsonConvert.SerializeObject(request), System.Text.Encoding.UTF8, "application/json");
                var response = await clientHelper.PostAsync(AxaSolUrls.InvestmentClient, content);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<CreateClientResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<CreateClientResponse>(value);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Response;
        }

        public async Task<PaystackBankListResponse> GetPaystackBanks()
        {
            PaystackBankListResponse Response = new PaystackBankListResponse();
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                HttpClient clientHelper = new HttpClient(clientHandler);

                clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer2);
                clientHelper.Timeout = TimeSpan.FromMinutes(5);

                var response = await clientHelper.GetAsync(AxaSolUrls.getPaystackBanks);

                if (response.IsSuccessStatusCode)
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<PaystackBankListResponse>(value);
                }
                else
                {
                    var value = response.Content.ReadAsStringAsync().Result;
                    Response = JsonConvert.DeserializeObject<PaystackBankListResponse>(value);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Response;
        }

        public async Task<IDictionary<string, string>> SyncHealthProposalQuestions()
        {
            HttpClientHandler clientHandler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; }
            };
            HttpClient clientHelper = new HttpClient(clientHandler)
            {
                Timeout = TimeSpan.FromMinutes(5)
            };
            clientHelper.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Bearer);
            var response = await clientHelper.GetAsync(AxaSolUrls.syncInHealthProposalQuestions);
            try
            {
                var value = response.Content.ReadAsStringAsync().Result;
                var Questions = JsonConvert.DeserializeObject<Dictionary<string, string>>(value);
                return Questions;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return null;
        }

        public async Task<bool> GetMyName(string user)
        {
            string url = AxaSolUrls.getName;
            return true;
            //Call API
        }
    }        
}


