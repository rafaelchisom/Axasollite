﻿using AxaSolLite.Services.Contracts;
using Plugin.Media;
using System;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Concretes.Managers
{
    public class MediaManager : IMediaManager
    {
        private readonly IFileService _fileService;

        private bool _cameraAvailable;

        public bool CameraAvailable
        {
            get
            {
                _cameraAvailable = GetCameraAvailability();
                return _cameraAvailable;
            }
        }

        public MediaManager(IFileService fileService)
        {
            _fileService = fileService;
        }

        private bool GetCameraAvailability()
        {
            try
            {
                return CrossMedia.Current.IsCameraAvailable && CrossMedia.Current.IsTakePhotoSupported;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<byte[]> SelectPhotoAsync()
        {
            try
            {
                var mediaOptions = new Plugin.Media.Abstractions.PickMediaOptions();

                var file = await CrossMedia.Current.PickPhotoAsync(mediaOptions);

                if (file != null)
                {
                    byte[] photofromFile = _fileService.Open(file.Path);
                    return photofromFile;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
                return null;
            }
        }

        public async Task<PhotoTaken> TakePhotoAsync()
        {
            PhotoTaken photoTaken = new PhotoTaken();
            try
            {
                var mediaOptions = new Plugin.Media.Abstractions.StoreCameraMediaOptions
                {
                    Directory = "",
                    Name = Guid.NewGuid() + ".jpg",
                    CompressionQuality = 30,
                    CustomPhotoSize = 50,
                };

                var file = await CrossMedia.Current.TakePhotoAsync(mediaOptions);

                if (file != null)
                {
                    photoTaken.FileContent = _fileService.Open(file.Path);
                    photoTaken.FileName = mediaOptions.Name;
                    _fileService.Delete(file.Path);
                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return photoTaken;
        }
    }
    public class PhotoTaken
    {
        public byte[] FileContent { get; set; }
        public string FileName { get; set; }
    }
}
