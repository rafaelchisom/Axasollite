﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface ICountryRepository
    {
        Task<List<Countries>> GetCountries();
        Task<Countries> GetCountryByCountryCode(int countryCode);
        Task<Countries> GetCountryByCountryName(string country);
        Task<int> SaveAsync(Countries model);
        Task<int> SaveAllAsync(List<Countries> model);
    }
}
