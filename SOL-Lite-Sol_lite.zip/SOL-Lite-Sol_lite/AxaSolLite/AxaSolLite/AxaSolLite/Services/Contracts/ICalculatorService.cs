﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Services.Contracts
{
    public interface ICalculatorService
    {
        int GetInsuranceAge(DateTime birthDate, DateTime? computationStartDate = null);

        int GetAgeInYears(DateTime birthDate);

        //decimal GetOccPremium(decimal OccRating, decimal sumInsured, decimal flatRate);

        decimal GetRoundUp(decimal value, int leftSignificant = 2);

        decimal GetRoundUp2(decimal value, int leftSignificant = 2);

        decimal GetRound(decimal value, int leftSignificant = 2);

        bool IsDependent(DateTime birthDate);

        //decimal CalculatePlanPremium(decimal SumInsured, decimal PlanPremiumRate, decimal PlanPremiumRateDiscount);

        decimal RoundToNearestHundreds(decimal number);

        decimal RoundToCeilingHundreds(decimal number);

        //decimal RoundValueForProposedSolutionsPremium(decimal value);

        decimal RoundUpHundredths(decimal number);

        //decimal GetBelow57Premium(decimal hmPremiumRate, decimal fundGap);

        //decimal Get57Premium(decimal hmPremiumRate, decimal ciAt70, decimal fundGap);

        //decimal GetPercentageAnnualIncome(decimal premium, decimal income);

        //decimal GetFundGap(decimal healthNeed, decimal healthExistingFund);

        //decimal GetInitialRetirementFund(decimal income, int age, decimal monthlyExpenseRate, decimal monthlyPension, int? pensionEndAge);

        //decimal GetRetirementFund(decimal rate, int pensionMonths, decimal withdrawals);

        //decimal GetMonthlyPension(decimal income, decimal monthlyExpenseRate);

        //decimal GetPensionMonths(int pensionEndAge, int retirementAge);

        //decimal GetTotalPensionAmount(int pensionMonths, int monthlyPension);

        //decimal GetSinglePremium(int age, int? retirementAge, decimal retirementFund, decimal? existingFund, bool isInitial);

        //decimal GetRegularPremium(int age, int? RetirementAge, decimal singlePremium, decimal axeleratorFactor, bool isInitial);

        //decimal GetPVOfRegPremium(decimal singlePremium, decimal axeleratorFactor);

        //decimal GetGAP(decimal retirementFund, decimal? existingFund);

        //int ConvertSliderValue(double sliderValue, int min, int max, double multiplier);

        decimal ConvertToPercentEquivalentDecimal(int input);

        decimal ConvertToPercentEquivalentDecimal(decimal input);

        decimal ConvertStringToDecimal(string input);
    }
}
