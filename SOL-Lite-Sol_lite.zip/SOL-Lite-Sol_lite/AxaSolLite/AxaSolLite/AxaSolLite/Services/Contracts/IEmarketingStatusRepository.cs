﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IEmarketingStatusRepository
    {
        Task<List<EmarketingStatus>> GetEmarketingStatusByProductPlanId(Guid prospectId);
        Task<EmarketingStatus> GetEmarketingStatusById(Guid Id);
        Task<int> SaveEmarketingStatus(EmarketingStatus model);
        Task<int> UpdateEmarketingStatus(EmarketingStatus model);
    }
}
