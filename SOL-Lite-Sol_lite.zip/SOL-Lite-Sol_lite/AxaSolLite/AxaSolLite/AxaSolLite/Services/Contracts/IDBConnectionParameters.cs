﻿using SQLite.Net.Interop;

namespace AxaSolLite.Services.Contracts
{
    public interface IDBConnectionParameters
    {
        string FilePath { get; }
        ISQLitePlatform Platform { get; }
    }
}
