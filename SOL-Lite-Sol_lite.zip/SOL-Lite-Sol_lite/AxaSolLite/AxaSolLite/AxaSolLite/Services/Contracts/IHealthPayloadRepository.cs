﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IHealthPayloadRepository 
    {
        Task<int> SaveAsync(HealthBookingRequest payload);
        Task<int> UpdateAsync(HealthBookingRequest payload);
        Task<HealthBookingRequest> GetHealthPayloadByProductId(Guid productId);
    }
}
