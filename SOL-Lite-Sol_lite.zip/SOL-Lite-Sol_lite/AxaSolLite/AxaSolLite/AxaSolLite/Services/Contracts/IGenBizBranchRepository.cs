﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IGenBizBranchRepository
    {
        Task<List<GenBizBranch>> GetGenBizBranches();
        Task<GenBizBranch> GetBranchByBranchCode(int branchCode);
        Task<GenBizBranch> GetBranchByBranchName(string branchName);
        Task<int> SaveAllAsync(List<GenBizBranch> branches);
    }
}
