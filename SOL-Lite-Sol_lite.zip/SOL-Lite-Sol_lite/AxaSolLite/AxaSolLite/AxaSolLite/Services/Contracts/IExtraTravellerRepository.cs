﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IExtraTravellerRepository
    {
        Task<List<ExtraTravellers>> GetAllExtraTravellers();

        Task<List<ExtraTravellers>> GetOtherTravellersByTravelProductId(Guid travelProductId);

        Task<int> SaveAllAsync(List<ExtraTravellers> model);
    }
}
