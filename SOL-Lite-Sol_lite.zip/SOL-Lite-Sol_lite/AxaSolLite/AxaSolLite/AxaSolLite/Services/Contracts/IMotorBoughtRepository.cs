﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IMotorBoughtRepository
    {
        Task<int> SaveAsync(MotorBought motorBought);
        Task<int> UpdateAsync(MotorBought motorBought);
        Task<List<MotorBought>> GetByYearOfMake(int yearOfMake);
        Task<MotorBought> GetById (int id);
    }
}
