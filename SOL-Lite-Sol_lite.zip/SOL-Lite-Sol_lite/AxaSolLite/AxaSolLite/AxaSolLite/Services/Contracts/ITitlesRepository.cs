﻿using AxaSolLite.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface ITitlesRepository
    {
        Task<List<Titles>> GetTitles();

        Task<Titles> GetTitleCodeByTitle(string title);

        Task<Titles> GetTitleByTitleCode(int titleCode);

        Task<int> SaveAll(List<Titles> titles);
    }
}
