﻿using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IRepositoryManager
    {
        bool IsInitialized { get; }

        Task<bool> Initialize();
    }
}
