﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IUserManager
    {
        Guid Id { get; set; }
        int AgentId { get; set; }
        string FirstName { get; set; }
        string FullName { get; }
        string LastName { get; set; }
        bool IsLoggedIn { get; }
        DateTime DateLastLogin { get; }
        DateTime DateLastActivity { get; }
        DateTime LastSyncDate { get; }
        string UserName { get; set; }
        string RequestToken { get; }
        int RoleId { get; }
        byte[] AgentProfilePicture { get; }

        Task<bool> Logout();

        //Task<LoginResult> Login(string userName, string password, ReportAgentStatusOnlineResponse reportAgentStatusOnlineResponse, bool requiresPin, string responseToken);

        ChangePasswordResult ChangePassword(string oldPassword, string confirmOldpassword, string newPassword, string confirmNewPassword);

        //Task ReportAction(int actionId, string page, string detail);

        //Task ReportSyncAsync();

        Task UpdateprofilePicture(byte[] newProfilePicture);

        Task<int> UpdateLocal(string userName, int agentId, bool agentIsActive, int agentNewPasswordRetry, string agentNewPassword, string agentNewSalt, string agentFirstName, string agentLastName, string agentMobile, string agentEmail, string channelCode, string requestToken);

        //bool CheckIfRequiresSync();

        Task<int> UpdateUserToken(string responseToken);
    }

    public enum LoginResult
    {
        Failed, Success, LockedOut, UserNotFound, RequiresChangePassword, RequiresVerification, Missing, InActive, RequiresSync, ProfileNotCreated
    }

    public enum ChangePasswordResult
    {
        Success, NotMatchedConfirmNew, NotMatchedNewOld, WrongPassword
    }
}
