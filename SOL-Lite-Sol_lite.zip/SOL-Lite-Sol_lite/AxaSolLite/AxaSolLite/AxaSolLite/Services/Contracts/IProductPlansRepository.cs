﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IProductPlansRepository
    {
        Task<List<ProductPlan>> GetProductPlans();

        Task<ProductPlan> GetProductPlan(Guid param);

        Task<ProductPlan> GetProductPlanByProductPlanId(Guid ProductPlanId);

        Task<List<ProductPlan>> GetProductPlansByProspectId(Guid ProspectId);

        Task<int> SaveAsync(ProductPlan model);

        Task<int> SaveAllAsync(List<ProductPlan> model);

        Task<int> UpdateAsync(ProductPlan model);
    }
}
