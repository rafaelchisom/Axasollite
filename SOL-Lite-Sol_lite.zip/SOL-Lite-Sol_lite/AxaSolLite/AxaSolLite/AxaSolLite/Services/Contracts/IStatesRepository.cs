﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IStatesRepository
    {
        Task<List<States>> GetAllStates();

        Task<States> GetStateCodeByState(string state);

        Task<int> SaveAll(List<States> model);
    }
}
