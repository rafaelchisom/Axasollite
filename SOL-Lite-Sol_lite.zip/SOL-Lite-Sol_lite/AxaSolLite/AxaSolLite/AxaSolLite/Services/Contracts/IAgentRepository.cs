﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IAgentRepository
    {
        Task<List<Agent>> GetAgents();

        Task<Agent> GetAgent(Guid param);
       

        Task<Agent> GetAgentByAgentId(Guid AgentId);

        Task<int> SaveAsync(Agent model);

        Task<int> UpdateAsync(Agent model);

        Task<int> SaveAllAsync(List<Agent> model);
        Task<Agent> GetByName(string username);
    }
}
