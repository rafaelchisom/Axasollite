﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Services.Contracts
{
    public interface IValidationService
    {
        //IDictionary<string, string> ValidateLeads(Leads leads);

        IDictionary<string, string> ValidateProspect(Prospect prospect);

        bool ValidateEmailPattern(string email);

        bool ValidatePasswordPattern(string password);

        //IDictionary<string, string> ValidateDependents(List<Dependent> dependent);
    }
}
