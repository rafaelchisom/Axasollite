﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Services.Contracts
{
    public interface IFileService
    {
        string Save(byte[] Payload, string FileName);

        byte[] Open(string FileName);

        bool Delete(string FileName);

        string FolderPath { get; }
    }
}
