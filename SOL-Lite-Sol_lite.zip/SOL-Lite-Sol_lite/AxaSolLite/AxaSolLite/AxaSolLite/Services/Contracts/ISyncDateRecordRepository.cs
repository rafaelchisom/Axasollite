﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface ISyncDateRecordRepository
    {
        Task<int> SaveSyncDate(SyncDate date);
        Task<List<SyncDate>> GetSyncDates();
    }
}
