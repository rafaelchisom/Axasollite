﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
   public interface ISaveLifeBookingDetails
    {
        Task<SaveBookingDetails> GetLifeBookingDetailsById(Guid id);

        Task<SaveBookingDetails> GetLifeBookingDetailsByProductPlanId(Guid productPlanId);

        Task<int> UpdateAsync(SaveBookingDetails model);

        Task<int> SaveAsync(SaveBookingDetails model);
    }
}
