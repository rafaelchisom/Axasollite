﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IBookOnlineRepository
    {
        Task<BookOnline> GetBookingByProductPlanId(Guid productPlanId);
        Task<BookOnline> GetBookOnlineById(Guid Id);
        Task<int> SaveBooking(BookOnline model);
        Task<int> UpdateBooking(BookOnline model);
    }
}
