﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IProspectRepository
    {
        Task<List<EncryptedProspect>> GetAll();

        Task<EncryptedProspect> GetById(Guid Id);

        Task<EncryptedProspect> GetByClientId(Guid clientId);

        Task<int> SaveProspectClientAsync(EncryptedProspect prospectClient);

        Task<List<Prospect>> GetAllByUserId(Guid id, bool IncludeDeleted = false);

        Task<int> UpdateAsync(EncryptedProspect selectedProspect);

        Task<int> UpdateAllAsync(List<EncryptedProspect> prospects);
        Task<int> SaveAll(List<EncryptedProspect> prospects);
        Task<List<Prospect>> GetProspectsByAgentId(int AgentId);
    }
}
