﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IPolicyDetailsResponseRepository
    {
        Task<int> SaveAsync(PolicyDetailsResponseToSave model);
        Task<PolicyDetailsResponseToSave> GetPolicyDetailsByProductPlan (Guid productPlanId);
        Task<List<PolicyDetailsResponseToSave>> GetListOfPolicyDetailsByProductPlan(Guid productPlanId);
        Task<int> UpdateAsync(PolicyDetailsResponseToSave model);
    }
}
