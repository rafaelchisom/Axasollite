﻿using AxaSolLite.Services.Concretes.Managers;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IMediaManager
    {
        bool CameraAvailable { get; }

        Task<PhotoTaken> TakePhotoAsync();
        

        Task<byte[]> SelectPhotoAsync();
    }
}
