﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IMotorRepository
    {
        Task<int> SaveAsync(SerializedMotorRenewalObject model);
        Task<int> UpdateAsync(SerializedMotorRenewalObject model);
        Task<SerializedMotorRenewalObject> GetMotorByProductPlan(Guid productPlanId);
    }
}
