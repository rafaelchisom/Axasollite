﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IMotorProductRepository
    {
        Task<MotorProduct> GetMotorProductById(Guid id);

        Task<MotorProduct> GetMotorProductByProductPlanId(Guid productPlanId);

        Task<int> UpdateAsync(MotorProduct model);

        Task<int> SaveAsync(MotorProduct model);

        Task<List<MotorProduct>> GetMotorProductsByProductPlanId(Guid productPlanId);
    }
}
