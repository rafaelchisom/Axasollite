﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IPersonalAccidentProductRepository
    {
        Task<int> SaveAsync(PersonalAccidentRepositoryObject model);
        Task<PersonalAccidentRepositoryObject> GetPersonalAccidentProductByProductPlan(Guid productPlanId);
        Task<int> UpdateAsync(PersonalAccidentRepositoryObject model);
    }
}
