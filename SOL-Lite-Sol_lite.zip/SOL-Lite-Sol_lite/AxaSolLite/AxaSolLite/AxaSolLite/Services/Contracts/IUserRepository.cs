﻿using AxaSolLite.Models;
using System;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface IUserRepository
    {
        Task<User> GetByName(string username);

        Task<int> Update(User user);

        Task<User> GetById(Guid userId);

        Task<int> SaveAsync(User user);
    }
}
