﻿using AxaSolLite.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Services.Contracts
{
    public interface ITravelProductRepository
    {
        Task<TravelProduct> GetTravelProductByProductPlanId(Guid productPlanId);

        Task<TravelProduct> GetTravelProductById(Guid travelProductId);

        Task<int> SaveAsync(TravelProduct model);

        Task<int> UpdateAsync(TravelProduct model);
    }
}
