﻿
namespace AxaSolLite.Services.Contracts
{
    public interface IBaseRepository
    {
    }
}
