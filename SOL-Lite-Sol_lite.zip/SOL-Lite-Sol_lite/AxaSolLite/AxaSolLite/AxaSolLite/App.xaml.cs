﻿using Prism;
using Prism.Ioc;
using AxaSolLite.ViewModels;
using AxaSolLite.Views;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Prism.Unity;
using AxaSolLite.Services.Concretes.Managers;
using Unity.Lifetime;
using AxaSolLite.Services.Contracts;
using AxaSolLite.Services.Concretes.Repositories;
using Prism.Plugin.Popups;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
namespace AxaSolLite
{
   
    public partial class App : PrismApplication
    {
        public App() : this(null) { }

        public App(IPlatformInitializer initializer) : base(initializer) { }

        protected override async void OnInitialized()
        {
            try
            {
                InitializeComponent();
           
                await NavigationService.NavigateAsync("NavigationPage/LoginPage");
                //await NavigationService.NavigateAsync("PersonalAccidentBeneficiaryPage");
            }
            catch (System.Exception ex)
            {
                ex.Message.ToString();
            }            
        }

        protected override void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterPopupNavigationService();
            containerRegistry.RegisterPopupDialogService();

            containerRegistry.Register<IRepositoryManager, RepositoryManager>(); 
            containerRegistry.Register<ICalculatorService, CalculatorService>();
            containerRegistry.Register<IBaseRepository, BaseRepository>();
            containerRegistry.Register<IMediaManager, MediaManager>();
            containerRegistry.Register<IValidationService, ValidationService>();
            containerRegistry.Register<IUserRepository, UserRepository>();
            containerRegistry.Register<IUserManager, UserManager>();
            containerRegistry.Register<IProspectRepository, ProspectRepository>();
            containerRegistry.Register<ITitlesRepository, TitlesRepository>();
            containerRegistry.Register<ICountryRepository, CountryRepository>();
            containerRegistry.Register<IStatesRepository, StatesRepository>();
            containerRegistry.Register<IMotorProductRepository, MotorProductRepository>();
            containerRegistry.Register<IMotorRidersRepository, MotorRidersRepository>();
            containerRegistry.Register<IAgentRepository, AgentRepository>();
            containerRegistry.Register<IProductPlansRepository, ProductPlanRepository>();
            containerRegistry.Register<IMotorDocumentRepository, MotorDocumentRepository>();
            containerRegistry.Register<IBookOnlineRepository, BookOnlineRepository>();
            containerRegistry.Register<ISaveLifeBookingDetails, SaveLifeBookingDetailsRepository>();
            containerRegistry.Register<ISyncDateRecordRepository, SyncDateRepository>();
            containerRegistry.Register<IBranchesRepository, BranchRepository>();
            containerRegistry.Register<IGenBizBranchRepository, GenBizBranchRepository>();
            containerRegistry.Register<ITravelProductRepository, TravelProductRepository>();
            containerRegistry.Register<IExtraTravellerRepository, ExtraTravellerRepository>();
            containerRegistry.Register<IHealthPayloadRepository, HealthPayloadRepository>();
            containerRegistry.Register<IEmarketingStatusRepository, EmarketingStatusRepository>();
            containerRegistry.Register<IPolicyDetailsResponseRepository, PolicyDetailsResponseRepository>();
            containerRegistry.Register<IMotorRepository, MotorRepository>();
            containerRegistry.Register<IPersonalAccidentProductRepository, PersonalAccidentProductRepository>();

            containerRegistry.RegisterForNavigation<NavigationPage>();
            containerRegistry.RegisterForNavigation<MainPage, MainPageViewModel>();
            containerRegistry.RegisterForNavigation<ProspectRegistrationPage, ProspectRegistrationPageViewModel>();
            containerRegistry.RegisterForNavigation<BaseMasterDetailPage, BaseMasterDetailPageViewModel>();
            containerRegistry.RegisterForNavigation<BaseNavigationPage, BaseNavigationPageViewModel>();
            containerRegistry.RegisterForNavigation<MyNavigationPage, MyNavigationPageViewModel>();
            containerRegistry.RegisterForNavigation<CustomerOnboardingPage, CustomerOnboardingPageViewModel>();
            containerRegistry.RegisterForNavigation<VehicleDetailsPage, VehicleDetailsPageViewModel>();
            containerRegistry.RegisterForNavigation<VehicleSummaryPage, VehicleSummaryPageViewModel>();
            containerRegistry.RegisterForNavigation<MotorValuationPage, MotorValuationPageViewModel>();           
            containerRegistry.RegisterForNavigation<LoginPage, LoginPageViewModel>();
            containerRegistry.RegisterForNavigation<AgentWelcomePage, AgentWelcomePageViewModel>();           
            containerRegistry.RegisterForNavigation<ProductLogPage, ProductLogPageViewModel>();
            containerRegistry.RegisterForNavigation<CustomerDataPage, CustomerDataPageViewModel>();
            containerRegistry.RegisterForNavigation<AutoGoBookingPage, AutoGoBookingPageViewModel>();           
            containerRegistry.RegisterForNavigation<PayNowPage, PayNowPageViewModel>();
            containerRegistry.RegisterForNavigation<AutoGoSumPage, AutoGoSumPageViewModel>();
            containerRegistry.RegisterForNavigation<ProspectListPage, ProspectListPageViewModel>();
            containerRegistry.RegisterForNavigation<ProspectViewPage, ProspectViewPageViewModel>();
            containerRegistry.RegisterForNavigation<GeneralLogPage, GeneralLogPageViewModel>();
            containerRegistry.RegisterForNavigation<ProspectViewDetails, ProspectViewDetailsViewModel>();
            containerRegistry.RegisterForNavigation<PayLaterPage, PayLaterPageViewModel>();
            containerRegistry.RegisterForNavigation<PssCommissionPage, PssCommissionPageViewModel>();
            containerRegistry.RegisterForNavigation<AdvisorCommissionPage, AdvisorCommissionPageViewModel>();
            containerRegistry.RegisterForNavigation<TeamManagerCommissionPage, TeamManagerCommissionPageViewModel>();
            containerRegistry.RegisterForNavigation<ExternalAgentLoginPage, ExternalAgentLoginPageViewModel>();
            containerRegistry.RegisterForNavigation<ExternalAgentForgotPasswordPage, ExternalAgentForgotPasswordPageViewModel>();
            containerRegistry.RegisterForNavigation<FirstTimeLoginPage, FirstTimeLoginPageViewModel>();
            containerRegistry.RegisterForNavigation<EduplanBookingPage, EduplanBookingPageViewModel>();
            containerRegistry.RegisterForNavigation<AddBeneficiaryPage, AddBeneficiaryPageViewModel>();
            containerRegistry.RegisterForNavigation<InstantPlanBookingPage, InstantPlanBookingPageViewModel>();
            containerRegistry.RegisterForNavigation<NonMedicalQuestionairePage, NonMedicalQuestionairePageViewModel>();
            containerRegistry.RegisterForNavigation<LifeProductSummaryPage, LifeProductSummaryPageViewModel>();
            containerRegistry.RegisterForNavigation<MyProfilePage, MyProfilePageViewModel>();
            containerRegistry.RegisterForNavigation<AgentFeedbackPage, AgentFeedbackPageViewModel>();

            containerRegistry.RegisterForNavigation<LifeSavingsBookingPage, LifeSavingsBookingPageViewModel>();
            containerRegistry.RegisterForNavigation<TrainingVideoPage, TrainingVideoPageViewModel>();
            containerRegistry.RegisterForNavigation<CustomerSearchWithNumber, CustomerSearchWithNumberViewModel>();
            containerRegistry.RegisterForNavigation<ProductVideoPage, ProductVideoPageViewModel>();
            containerRegistry.RegisterForNavigation<AgentReferralLink, AgentReferralLinkViewModel>();
            containerRegistry.RegisterForNavigation<TravelQuotePage, TravelQuotePageViewModel>();
            containerRegistry.RegisterForNavigation<TravelDetailsPage, TravelDetailsPageViewModel>();
            containerRegistry.RegisterForNavigation<TravelSummaryPage, TravelSummaryPageViewModel>();
            containerRegistry.RegisterForNavigation<TravelQuoteDisplay, TravelQuoteDisplayViewModel>();
            containerRegistry.RegisterForNavigation<PaperFnaPage, PaperFnaPageViewModel>();
            containerRegistry.RegisterForNavigation<EFormsPageNew, EFormsPageNewViewModel>();
            containerRegistry.RegisterForNavigation<BonusLifeBookingPage, BonusLifeBookingPageViewModel>();
            containerRegistry.RegisterForNavigation<AmbitionsBookingPage, AmbitionsBookingPageViewModel>();
            containerRegistry.RegisterForNavigation<CashBackTermLife, CashBackTermLifeViewModel>();
            containerRegistry.RegisterForNavigation<EmarketingPage, EmarketingPageViewModel>();

            containerRegistry.RegisterForNavigation<BaseTabbedPage, BaseTabbedPageViewModel>();
            containerRegistry.RegisterForNavigation<LifePlusBookingPage, LifePlusBookingPageViewModel>();

            containerRegistry.RegisterForNavigation<HealthBookingPage, HealthBookingPageViewModel>();
            containerRegistry.RegisterForNavigation<HealthSummaryPage, HealthSummaryPageViewModel>();
            containerRegistry.RegisterForNavigation<PersonalAccident, PersonalAccidentViewModel>();
            containerRegistry.RegisterForNavigation<HomeRenewalPage, HomeRenewalPageViewModel>();
            containerRegistry.RegisterForNavigation<RenewalPage, RenewalPageViewModel>();
            containerRegistry.RegisterForNavigation<RenewalPage, RenewalPageViewModel>();
            containerRegistry.RegisterForNavigation<RenewalSearchPage, RenewalSearchPageViewModel>();
            containerRegistry.RegisterForNavigation<VehicleRenewalDetails, VehicleRenewalDetailsViewModel>();
            containerRegistry.RegisterForNavigation<VehicleRenewalSummary, VehicleRenewalSummaryViewModel>();
            containerRegistry.RegisterForNavigation<NINOnboardingPage, NINOnboardingPageViewModel>();
            containerRegistry.RegisterForNavigation<LeadAccountPage, LeadAccountPageViewModel>();
            containerRegistry.RegisterForNavigation<PersonalAccidentSummaryPage, PersonalAccidentSummaryPageViewModel>();
            containerRegistry.RegisterForNavigation<PersonalAccidentBeneficiaryPage, PersonalAccidentBeneficiaryPageViewModel>();
            containerRegistry.RegisterForNavigation<TestPage, TestPageViewModel>();
            containerRegistry.RegisterForNavigation<ApprovalLogPage, ApprovalLogPageViewModel>();
            containerRegistry.RegisterForNavigation<ApprovalLogInformationPage, ApprovalLogInformationPageViewModel>();
            containerRegistry.RegisterForNavigation<HealthHospitals, HealthHospitalsViewModel>();
            containerRegistry.RegisterForNavigation<MyPopup, MyPopupViewModel>();
            containerRegistry.RegisterForNavigation<InvestmentOnboardPage, InvestmentOnboardPageViewModel>();
            containerRegistry.RegisterForNavigation<HealthProposalQuestionnaire, HealthProposalQuestionnaireViewModel>();
            containerRegistry.RegisterForNavigation<BuyVehicle, BuyVehicleViewModel>();
        }
    }
}
