﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace AxaSolLite.Behaviors
{
    public class NewDatePickerBehavior : BehaviorBase<DatePicker>
    {
        private const string HexColor = "#c91432"; //RED

        private static readonly BindablePropertyKey IsValidPropertyKey = BindableProperty.CreateReadOnly("IsValid", typeof(bool), typeof(DatePickerBehavior), false);

        public static readonly BindableProperty IsValidProperty = IsValidPropertyKey.BindableProperty;

        public bool IsValid
        {
            get { return (bool)base.GetValue(IsValidProperty); }
            private set { base.SetValue(IsValidPropertyKey, value); }
        }

        protected override void OnAttachedTo(DatePicker picker)
        {
            picker.DateSelected += OnSelectedIndexChanged;
            base.OnAttachedTo(picker);
        }

        protected override void OnDetachingFrom(DatePicker picker)
        {
            picker.DateSelected -= OnSelectedIndexChanged;
            base.OnDetachingFrom(picker);
        }

        private void OnSelectedIndexChanged(object sender, EventArgs args)
        {
            Color color = Color.FromHex(HexColor);

            var picker = (DatePicker)sender;

            if (picker.Date < DateTime.Today)
            {
                picker.BackgroundColor = Color.Default;
            }
            else
            {
                IsValid = true;
                picker.BackgroundColor = Color.Default;
            }
        }
    }
}
