﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using Xamarin.Forms;

namespace AxaSolLite.Behaviors
{
    public class NumericValidationBehavior : BehaviorBase<Entry>
    {
        private const string NumericRegex = @"^(\d{7}|\d{11})$";
        private const string HexColor = "#c91432"; //RED

        private static readonly BindablePropertyKey IsValidPropertyKey = BindableProperty.CreateReadOnly("IsValid", typeof(bool), typeof(NumericValidationBehavior), false);

        public static readonly BindableProperty IsValidProperty = IsValidPropertyKey.BindableProperty;

        public bool IsValid
        {
            get { return (bool)base.GetValue(IsValidProperty); }
            private set { base.SetValue(IsValidPropertyKey, value); }
        }

        protected override void OnAttachedTo(Entry entry)
        {
            entry.TextChanged += OnEntryTextChanged;
            base.OnAttachedTo(entry);
        }

        protected override void OnDetachingFrom(Entry entry)
        {
            entry.TextChanged -= OnEntryTextChanged;
            base.OnDetachingFrom(entry);
        }

        private void OnEntryTextChanged(object sender, TextChangedEventArgs args)
        {
            Color color = Color.FromHex(HexColor);

            if (!string.IsNullOrEmpty(args.NewTextValue))
            {
                IsValid = (Regex.IsMatch(args.NewTextValue, NumericRegex, RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250)));

                ((Entry)sender).BackgroundColor = IsValid ? Color.Default : color;
            }
            else
            {
                ((Entry)sender).BackgroundColor = color;
            }
        }
    }

}
