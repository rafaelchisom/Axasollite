﻿using AxaSolLite.Behaviors;
using System;
using Xamarin.Forms;

namespace AxaSolLite.Behaviors
{
    public class DatePickerBehavior : BehaviorBase<DatePicker>
    {
        private const string HexColor = "#c91432"; //RED

        private static readonly BindablePropertyKey IsValidPropertyKey = BindableProperty.CreateReadOnly("IsValid", typeof(bool), typeof(DatePickerBehavior), false);

        public static readonly BindableProperty IsValidProperty = IsValidPropertyKey.BindableProperty;

        public bool IsValid
        {
            get { return (bool)base.GetValue(IsValidProperty); }
            private set { base.SetValue(IsValidPropertyKey, value); }
        }

        protected override void OnAttachedTo(DatePicker picker)
        {
            picker.DateSelected += OnSelectedIndexChanged;
            base.OnAttachedTo(picker);
        }

        protected override void OnDetachingFrom(DatePicker picker)
        {
            picker.DateSelected -= OnSelectedIndexChanged;
            base.OnDetachingFrom(picker);
        }

        private void OnSelectedIndexChanged(object sender, EventArgs args)
        {
            Color color = Color.FromHex(HexColor);

            var picker = (DatePicker)sender;

            if (picker.Date >= DateTime.Now)
            {
                picker.BackgroundColor = color;
            }
            else
            {
                IsValid = true;
                picker.BackgroundColor = Color.Default;
            }
        }
    }
}