﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class SaveBookingDetails : BaseModel
    {
        public SaveBookingDetails()
        {
            Id = Guid.NewGuid();
        }
        public Guid ProductPlanId { get; set; }
        public string RequestData { get; set; }
        public string CertData { get; set; }
        public string PaymentReference { get; set; }
        public bool Saved { get; set; }
    }
}
