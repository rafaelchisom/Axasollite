﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class ProductPlan : BaseModel
    {
        public ProductPlan()
        {
            Id = Guid.NewGuid();
        }

        public Guid ProspectId { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public Nullable<System.DateTime> UpdatedDate { get; set; }
        public string PlanDescription { get; set; }
        public string PlanCategory { get; set; }
        public string PlanIcon { get; set; }
        public decimal BasicPremium { get; set; }
        public string PolicyId { get; set; }
        public string QuoteId { get; set; }
        public bool IsQuoteId { get; set; }
        public bool IsPolicyId { get; set; }
        public bool IsNotPolicyId { get; set; }
        public string CaseId { get; set; }
        public bool IsAccountBalance { get; set; }
        public bool IsCaseId { get; set; }
        public bool IsRetryBooking { get; set; }
        public bool IsMailSent { get; set; }
        public bool IsNotMailSent { get; set; }
        public bool IsEnrolleeID { get; set; }
        public string EnrolleeID { get; set; }
        public string PaymentReference { get; set; }
        public string app_uid { get; set; }
        public string AmountPaid { get; set; }
        public bool IsLife { get; set; }
        public bool IsRenewal { get; set; }
        public bool IsSameAgent { get; set; }
        public int NoOfVehicles { get; set; }
        public bool NeedsApproval { get; set; }
        public string PaymentOption { get; set; }
        public bool HasDiscount { get; set; }
        public double DiscountRate { get; set; }
        public bool IsRetryRenewal { get; set; }
        public string ApprovalId { get; set; }
        public bool IsTMApprovalSent { get; set; }
        public bool IsApproved { get; set; }
        public bool IsRejected { get; set; }
        public bool IsPaymentVerfied { get; set; }
        public string NaicomRequestId { get; set; }
        public string NaicomId { get; set; }
    }
}
