﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class PayStackPaymentResponse
    {
        [JsonProperty("status")]
        public bool Status { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("data")]
        public PayStackData Data { get; set; }
    }

    public class PayStackData
    {
        [JsonProperty("authorization_url")]
        public string AuthorizationUrl { get; set; }

        [JsonProperty("access_code")]
        public string AccessCode { get; set; }

        [JsonProperty("reference")]
        public string Reference { get; set; }
    }
}
