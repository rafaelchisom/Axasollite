﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class CustomerUpdate
    {
        [JsonProperty("Title")]
        public int Title { get; set; }

        [JsonProperty("Firstname")]
        public string Firstname { get; set; }

        [JsonProperty("Middlename")]
        public string Middlename { get; set; }

        [JsonProperty("Lastname")]
        public string Lastname { get; set; }

        [JsonProperty("Full_Name")]
        public string FullName { get; set; }

        [JsonProperty("Customer_No")]
        public string CustomerNo { get; set; }

        [JsonProperty("Nationality")]
        public string Nationality { get; set; }

        [JsonProperty("Nationality_Code")]
        public int NationalityCode { get; set; }

        [JsonProperty("Religion_Code")]
        public int ReligionCode { get; set; }

        [JsonProperty("Address")]
        public string Address { get; set; }

        [JsonProperty("City_Code")]
        public int CityCode { get; set; }

        [JsonProperty("Gender")]
        public string Gender { get; set; }

        [JsonProperty("Gender_Code")]
        public int GenderCode { get; set; }

        [JsonProperty("State_Code")]
        public int StateCode { get; set; }

        [JsonProperty("Telephone_No")]
        public string TelephoneNo { get; set; }

        [JsonProperty("Occupation_Code")]
        public int OccupationCode { get; set; }

        [JsonProperty("DOB")]
        public string Dob { get; set; }

        [JsonProperty("DOB_Code")]
        public DateTimeOffset DobCode { get; set; }

        [JsonProperty("Email")]
        public string Email { get; set; }

        [JsonProperty("BVN")]
        public string Bvn { get; set; }

        [JsonProperty("NIN")]
        public string Nin { get; set; }

        [JsonProperty("SBU")]
        public int Sbu { get; set; }
    }
}
