﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
   public class ProspectSignatureConsent
    {
        public string CustomerName { get; set; }
        public string CustomerSignature { get; set; }
    }
}
