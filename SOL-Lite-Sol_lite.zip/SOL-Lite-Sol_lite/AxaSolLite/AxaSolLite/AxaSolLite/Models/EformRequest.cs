﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class EformRequest
    {
        public string EmailAddress { get; set; }
        public string AgentEmail { get; set; }
        public string FullName { get; set; }
        public string Plan { get; set; }
        public string EformLink { get; set; }
        
    }
}
