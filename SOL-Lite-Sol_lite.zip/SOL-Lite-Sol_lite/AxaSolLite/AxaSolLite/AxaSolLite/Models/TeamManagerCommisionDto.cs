﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class TeamManagerCommisionDto
    {
        [JsonProperty("Tm_USERNAME")]
        public string TmUsername { get; set; }

        [JsonProperty("NumberOfAdvisors")]
        public long NumberOfAdvisors { get; set; }

        [JsonProperty("NumberOfSeniorAdvisors")]
        public long NumberOfSeniorAdvisors { get; set; }

        [JsonProperty("ActiveAdvisors")]
        public long ActiveAdvisors { get; set; }

        [JsonProperty("InactiveAdvisors")]
        public long InactiveAdvisors { get; set; }

        [JsonProperty("ActiveSeniorAdvisors")]
        public long ActiveSeniorAdvisors { get; set; }

        [JsonProperty("InactiveSeniorAdvisors")]
        public long InactiveSeniorAdvisors { get; set; }

        [JsonProperty("IndividualLifeInflow")]
        public string IndividualLifeInflow { get; set; }

        [JsonProperty("IndividualLifeCommission")]
        public string IndividualLifeCommission { get; set; }

        [JsonProperty("IndividualLifeBonus")]
        public long IndividualLifeBonus { get; set; }

        [JsonProperty("GroupLifeInflow")]
        public string GroupLifeInflow { get; set; }

        [JsonProperty("GroupLifeCommission")]
        public string GroupLifeCommission { get; set; }

        [JsonProperty("GroupLifeBonus")]
        public long GroupLifeBonus { get; set; }

        [JsonProperty("LifeInflow")]
        public string LifeInflow { get; set; }

        [JsonProperty("Life_Commission")]
        public string LifeCommission { get; set; }

        [JsonProperty("Life_Bonus")]
        public long LifeBonus { get; set; }

        [JsonProperty("Total")]
        public string Total { get; set; }
    }
}
