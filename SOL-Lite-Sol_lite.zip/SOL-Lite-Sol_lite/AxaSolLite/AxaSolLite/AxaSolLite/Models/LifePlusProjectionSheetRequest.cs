﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class LifePlusProjectionSheetRequest
    {
        public DateTime DOB { get; set; }
        public int Duration { get; set; }
        public double AnnualContribution { get; set; }
        public double SumAssured { get; set; }
        public string CustomerName { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public string AgentName { get; set; }
        public string AgentEmail { get; set; }
        public string DateOfBirth { get; set; }
        public string AgeAtNextBirthday { get; set; }
        public string CustomerSignature { get; set; }
        public string ContentType { get; set; }
        public string IssueDate { get; set; }
    }
}
