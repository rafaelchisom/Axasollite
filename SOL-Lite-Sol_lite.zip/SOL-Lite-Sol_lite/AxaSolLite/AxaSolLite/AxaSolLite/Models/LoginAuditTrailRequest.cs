﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
   public  class LoginAuditTrailRequest
    {
        public string UserName { get; set; }
        public string AgentName { get; set; }
        public string AgentCode { get; set; }
        public string SbuCode { get; set; }
        public string SbuName { get; set; }
        public string Grp { get; set; }
        public string AgentType { get; set; }
        public string DeviceId { get; set; }
    }
}
