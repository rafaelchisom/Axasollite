﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class InvestmentConfirmBvnRequest
    {
        [JsonProperty("AccountNumber")]

        public string AccountNumber { get; set; }

        [JsonProperty("BankID")]
        public int BankId { get; set; }

        [JsonProperty("BVN")]
        public string Bvn { get; set; }
    }
    public class InvestmentConfirmBVNResponse
    {
        [JsonProperty("isSuccessful")]
        public bool IsSuccessful { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("returnedObject")]
        public ReturnedObjects ReturnedObject { get; set; }

        [JsonProperty("returnedCode")]
        public object ReturnedCode { get; set; }

        [JsonProperty("certificate")]
        public object Certificate { get; set; }

        [JsonProperty("validationErrors")]
        public object ValidationErrors { get; set; }
    }

    public partial class ReturnedObjects
    {
        [JsonProperty("bvn")]
        public string Bvn { get; set; }

        [JsonProperty("isBlacklisted")]
        public bool IsBlacklisted { get; set; }

        [JsonProperty("accountNumber")]
        public string AccountNumber { get; set; }

        [JsonProperty("isMatched")]
        public bool IsMatched { get; set; }
    }
    public class InvestmentCreateClientRequest
    {
        [JsonProperty("AgentCode")]
        public object AgentCode { get; set; }

        [JsonProperty("ID")]
        public long Id { get; set; }

        [JsonProperty("uuid")]
        public object Uuid { get; set; }

        [JsonProperty("AccountType")]
        public long AccountType { get; set; }

        [JsonProperty("TitleID")]
        public long TitleId { get; set; }

        [JsonProperty("Surname")]
        public string Surname { get; set; }

        [JsonProperty("Firstname")]
        public string Firstname { get; set; }

        [JsonProperty("MiddleName")]
        public object MiddleName { get; set; }

        [JsonProperty("MothersMaidenName")]
        public string MothersMaidenName { get; set; }

        [JsonProperty("Gender")]
        public long Gender { get; set; }

        [JsonProperty("Nationality")]
        public long Nationality { get; set; }

        [JsonProperty("DOB")]
        public DateTimeOffset Dob { get; set; }

        [JsonProperty("CountryOfBirth")]
        public long CountryOfBirth { get; set; }

        [JsonProperty("DualCitizenship")]
        public object DualCitizenship { get; set; }

        [JsonProperty("Occupation")]

        public long Occupation { get; set; }

        [JsonProperty("ResidentPermitNo")]
        public object ResidentPermitNo { get; set; }

        [JsonProperty("Country")]
        public long Country { get; set; }

        [JsonProperty("StateID")]
        public long StateId { get; set; }

        [JsonProperty("ResidentialAddress")]
        public string ResidentialAddress { get; set; }

        [JsonProperty("ZipCode")]
        public object ZipCode { get; set; }

        [JsonProperty("MobileNo")]
        public string MobileNo { get; set; }

        [JsonProperty("HomePhone")]
        public object HomePhone { get; set; }

        [JsonProperty("Fax")]
        public object Fax { get; set; }

        [JsonProperty("OfficeAddress")]
        public object OfficeAddress { get; set; }

        [JsonProperty("OfficePhone")]
        public object OfficePhone { get; set; }

        [JsonProperty("EmailAddress")]
        public string EmailAddress { get; set; }

        [JsonProperty("NOKName")]
        public string NokName { get; set; }

        [JsonProperty("NOKAddress")]
        public string NokAddress { get; set; }

        [JsonProperty("NOKPhone")]
        public string NokPhone { get; set; }

        [JsonProperty("NOKEmail")]
        public string NokEmail { get; set; }

        [JsonProperty("NOKRelationship")]
        public long NokRelationship { get; set; }

        [JsonProperty("NOKOtherRelationship")]
        public object NokOtherRelationship { get; set; }

        [JsonProperty("BVN")]
        public string Bvn { get; set; }

        [JsonProperty("BVNVerified")]
        public bool BvnVerified { get; set; }

        [JsonProperty("CorrespondenceAddress")]
        public object CorrespondenceAddress { get; set; }

        [JsonProperty("ForeignMailingAddress")]
        public object ForeignMailingAddress { get; set; }

        [JsonProperty("ForeignPhoneNo")]
        public object ForeignPhoneNo { get; set; }

        [JsonProperty("TIN")]
        public object Tin { get; set; }

        [JsonProperty("IsStandingInstruction")]
        public object IsStandingInstruction { get; set; }

        [JsonProperty("IDType")]
        public object IdType { get; set; }

        [JsonProperty("DriversLicenseOrPassportNo")]
        public object DriversLicenseOrPassportNo { get; set; }

        [JsonProperty("AccountPurposeID")]
        public long AccountPurposeId { get; set; }

        [JsonProperty("AccountPurpose")]
        public string AccountPurpose { get; set; }

        [JsonProperty("WealthSourceID")]
        public long WealthSourceId { get; set; }

        [JsonProperty("WealthSource")]
        public string WealthSource { get; set; }

        [JsonProperty("IncomeClass")]
        public object IncomeClass { get; set; }

        [JsonProperty("IsPartOnboarding")]
        public bool IsPartOnboarding { get; set; }

        [JsonProperty("FundsOrigin")]
        public object FundsOrigin { get; set; }

        [JsonProperty("PoliticalExposure")]
        public string PoliticalExposure { get; set; }

        [JsonProperty("DiscoveryCode")]
        public long DiscoveryCode { get; set; }

        [JsonProperty("ConfirmationCode")]
        public object ConfirmationCode { get; set; }

        [JsonProperty("SecurityQuestion")]
        public string SecurityQuestion { get; set; }

        [JsonProperty("SecurityAnswer")]
        public string SecurityAnswer { get; set; }

        [JsonProperty("InviteCode")]
        public object InviteCode { get; set; }

        [JsonProperty("Source")]
        public long Source { get; set; }

        [JsonProperty("PartnerID")]
        public long PartnerId { get; set; }

        [JsonProperty("PayoutDividend")]
        public bool PayoutDividend { get; set; }

        [JsonProperty("DisableLiquidation")]
        public bool DisableLiquidation { get; set; }

        [JsonProperty("ReferralCode")]
        public object ReferralCode { get; set; }

        [JsonProperty("hasPin")]
        public bool HasPin { get; set; }

        [JsonProperty("hasFD")]
        public bool HasFd { get; set; }

        [JsonProperty("hasRiskAssessmentProfile")]
        public bool HasRiskAssessmentProfile { get; set; }

        [JsonProperty("AccruedInterest")]
        public double AccruedInterest { get; set; }

        [JsonProperty("CurrentBalance")]
        public double CurrentBalance { get; set; }

        [JsonProperty("BookBalance")]
        public double BookBalance { get; set; }

        [JsonProperty("RiskProfile")]
        public object RiskProfile { get; set; }

        [JsonProperty("JointClient")]
        public object JointClient { get; set; }

        [JsonProperty("BankAccounts")]
        public List<BankAccount> BankAccounts { get; set; }
    }

    public class BankAccount
    {
        [JsonProperty("BankID")]
        public int BankId { get; set; }

        [JsonProperty("AccountNo")]

        public string AccountNo { get; set; }

        [JsonProperty("AccountName")]
        public string AccountName { get; set; }

        [JsonProperty("SortCode")]
        public object SortCode { get; set; }

        [JsonProperty("isActive")]
        public bool IsActive { get; set; }

        [JsonProperty("ClientBankID")]
        public long ClientBankId { get; set; }

        [JsonProperty("BankName")]
        public object BankName { get; set; }
    }
    public class CreateClientResponse
    {
        [JsonProperty("success")]
        public bool Success { get; set; }

        [JsonProperty("detail")]
        public object Detail { get; set; }
        [JsonProperty("message")]
        public string Message { get; set; }


    }

}
