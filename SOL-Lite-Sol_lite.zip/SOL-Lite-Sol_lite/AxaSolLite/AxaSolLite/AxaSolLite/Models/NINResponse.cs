﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace AxaSolLite.Models
{
    public class NINResponse
    {
        [JsonProperty("isSuccessful")]
        public bool IsSuccessful { get; set; }

        [JsonProperty("data")]
        public Data Data { get; set; }

        [JsonProperty("statusCode")]

        public string StatusCode { get; set; }

        [JsonProperty("code")]

        public string Code { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }
    }

    public partial class Data
    {
        [JsonProperty("fieldMatches")]
        public object FieldMatches { get; set; }

        [JsonProperty("nin")]
        public string Nin { get; set; }

        [JsonProperty("uid")]
        public string Uid { get; set; }

        [JsonProperty("firstname")]
        public string Firstname { get; set; }

        [JsonProperty("lastname")]
        public string Lastname { get; set; }

        [JsonProperty("middlename")]
        public string Middlename { get; set; }

        [JsonProperty("phone")]
        public string Phone { get; set; }

        [JsonProperty("gender")]
        public string Gender { get; set; }

        [JsonProperty("birthdate")]
        public string Birthdate { get; set; }

        [JsonProperty("photo")]
        public string Photo { get; set; }

        [JsonProperty("nationality")]
        public string Nationality { get; set; }

        [JsonProperty("profession")]
        public string Profession { get; set; }

        [JsonProperty("stateOfOrigin")]
        public string StateOfOrigin { get; set; }

        [JsonProperty("lgaOfOrigin")]
        public string LgaOfOrigin { get; set; }

        [JsonProperty("placeOfOrigin")]
        public string PlaceOfOrigin { get; set; }

        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("height")]
        public string Height { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("birthState")]
        public string BirthState { get; set; }

        [JsonProperty("birthCountry")]
        public string BirthCountry { get; set; }

        [JsonProperty("nSpokenLang")]
        public string NSpokenLang { get; set; }

        [JsonProperty("religion")]
        public string Religion { get; set; }

        [JsonProperty("address1")]
        public string Address1 { get; set; }

        [JsonProperty("lga")]
        public string Lga { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("signature")]
        public string Signature { get; set; }

        [JsonProperty("verifiedWith")]
        public string VerifiedWith { get; set; }

        [JsonProperty("nextOfKin")]
        public NextOfKin NextOfKin { get; set; }

        [JsonProperty("residence")]
        public Residence Residence { get; set; }
    }

    public partial class NextOfKin
    {
        [JsonProperty("firstname")]
        public string Firstname { get; set; }

        [JsonProperty("lastname")]
        public string Lastname { get; set; }

        [JsonProperty("middlename")]
        public string Middlename { get; set; }

        [JsonProperty("address1")]
        public string Address1 { get; set; }

        [JsonProperty("address2")]
        public string Address2 { get; set; }

        [JsonProperty("lga")]
        public string Lga { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("town")]
        public string Town { get; set; }
    }

    public partial class Residence
    {
        [JsonProperty("address1")]
        public string Address1 { get; set; }

        [JsonProperty("lga")]
        public string Lga { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }
    }

}
