﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class AimsCustomerUpdateModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime DateOfBirth { get; set; }



        public string NewFirstName { get; set; }
        public string NewLastName { get; set; }
        public string NewEmailAddress { get; set; }
        public string NewPhoneNumber { get; set; }
        public DateTime NewDateOfBirth { get; set; }
        public string CustomerNumber { get; set; }
        public string CustoemerAddress { get; set; }
    }
}
