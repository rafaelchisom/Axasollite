﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class NewPaymentDetails
    {
        public string PolicyId { get; set; }
        public string Narration { get; set; }
        public string PolicyType { get; set; }
        public string RefNumber { get; set; }
        public double AmountPaid { get; set; }
        public double AmountUtilized { get; set; }
        public string CustomerName { get; set; }
        public string CustomerID { get; set; }
        public string AgentCode { get; set; }
        public string Sbu { get; set; }
        public string AgentName { get; set; }
        public string AgentType { get; set; }
    }
}
