﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class MotorTruePriceRequestDto
    {
        [JsonProperty("make")]
        public string make { get; set; }

        [JsonProperty("model")]
        public string model { get; set; }

        [JsonProperty("year_of_manufacture")]
        public string year_of_manufacture { get; set; }
    }
}
