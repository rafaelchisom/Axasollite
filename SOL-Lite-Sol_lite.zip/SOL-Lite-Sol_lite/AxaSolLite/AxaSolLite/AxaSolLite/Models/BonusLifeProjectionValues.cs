﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class BonusLifeProjectionValues
    {
        public string dob { get; set; }
        public string riderCode { get; set; }

        public string contribution { get; set; }
        public string SumAssured { get; set; }
        public string customerName { get; set; }


        public string paymentFreq { get; set; }
    }
}
