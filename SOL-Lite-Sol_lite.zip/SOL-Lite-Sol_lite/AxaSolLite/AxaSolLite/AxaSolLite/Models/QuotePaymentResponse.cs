﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class QuotePaymentResponse
    {
        [JsonProperty("IsSuccessful")]
        public bool IsSuccessful { get; set; }

        [JsonProperty("Result")]
        public responses Result { get; set; }

    }
    public class responses
    {
        [JsonProperty("QuoteId")]
        public string QuoteId { get; set; }

        [JsonProperty("CustomerNo")]
        public string CustomerNo { get; set; }

        [JsonProperty("PolicyClass")]
        public int PolicyClass { get; set; }

        [JsonProperty("PolicyCode")]
        public int PolicyCode { get; set; }

        [JsonProperty("PolicyId")]
        public object PolicyId { get; set; }

        [JsonProperty("PolicyType")]
        public string PolicyType { get; set; }

        [JsonProperty("Name")]
        public string Name { get; set; }

        [JsonProperty("Email")]
        public string Email { get; set; }

        [JsonProperty("Phone")]
        public string Phone { get; set; }

        [JsonProperty("DateGenerated")]
        public string DateGenerated { get; set; }

        [JsonProperty("AgentCode")]
        public string AgentCode { get; set; }

        [JsonProperty("QuoteAmount")]
        public double QuoteAmount { get; set; }

        [JsonProperty("Amount_Utilised")]
        public object AmountUtilised { get; set; }

        [JsonProperty("AmountPaid")]
        public double AmountPaid { get; set; }

        [JsonProperty("PaymentDate")]
        public string PaymentDate { get; set; }
    }
}
