﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class EformsBaseUrl
    {
        public string BaseUrl { get; set; }
    }
}
