﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Models
{
    public class Titles
    {
        public int TitleCode { get; set; }
        public string Title { get; set; }
    }
}
