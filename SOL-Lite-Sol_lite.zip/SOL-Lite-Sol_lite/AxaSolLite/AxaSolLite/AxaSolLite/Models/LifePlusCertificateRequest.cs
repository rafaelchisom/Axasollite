﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class LifePlusCertificateRequest
    {
        public string CertificateNo { get; set; }
        public string PolicyId { get; set; }
        public string LifeAssured { get; set; }
        public string DateofBirth { get; set; }
        public string AgeNextBirthday { get; set; }
        public string SumAssured { get; set; }
        public string AnnualContribution { get; set; }
        public string PaymentFrequency { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string Beneficiary { get; set; }
        public string Beneficiary2 { get; set; }
        public string CustomerName { get; set; }
        public string IssueDate { get; set; }
        public string AgentEmaiil { get; set; }
        public string TransactionReference { get; set; }
        public string ProductName { get; set; }
        public string CustomerNumber { get; set; }
        public string EmailAddress { get; set; }
    }
}
