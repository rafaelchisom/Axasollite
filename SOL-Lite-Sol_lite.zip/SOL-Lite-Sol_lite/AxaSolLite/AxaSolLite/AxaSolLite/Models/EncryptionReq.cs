﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class EncryptionReq
    {
        public string encryptedDetails { get; set; }
    }
}
