﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class PaymentNotificationRequest
    {
        public string EmailAddress { get; set; }
        public string FullName { get; set; }
        public string CustomerNumber { get; set; }
        public string TransactionID { get; set; }
        public string PolicyID { get; set; }
        public string PaymentAmount { get; set; }
        public string PaymentDate { get; set; }
        public string TimePayment { get; set; }
    }
}
