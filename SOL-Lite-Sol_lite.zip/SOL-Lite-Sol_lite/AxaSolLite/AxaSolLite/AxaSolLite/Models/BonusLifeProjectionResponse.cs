﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{

    public class BonusLifeProjectionResponse
    {
        [JsonProperty("ageField")]

        public string AgeField { get; set; }

        [JsonProperty("yearField")]

        public string YearField { get; set; }

        [JsonProperty("contributionField")]
        public string ContributionField { get; set; }

        [JsonProperty("totalContributionField")]
        public string TotalContributionField { get; set; }

        [JsonProperty("premiumField")]
        public string PremiumField { get; set; }

        [JsonProperty("stampDutyField")]
        public string StampDutyField { get; set; }

        [JsonProperty("maintenanceExpenseField")]
        public string MaintenanceExpenseField { get; set; }

        [JsonProperty("naicomFeeField")]
        public string NaicomFeeField { get; set; }

        [JsonProperty("reinsuranceCostField")]
        public string ReinsuranceCostField { get; set; }

        [JsonProperty("commissionField")]
        public string CommissionField { get; set; }

        [JsonProperty("premium_InvestibleAmountField")]
        public string PremiumInvestibleAmountField { get; set; }

        [JsonProperty("premium_InterestField")]
        public string PremiumInterestField { get; set; }

        [JsonProperty("premium_BalanceField")]
        public string PremiumBalanceField { get; set; }

        [JsonProperty("savings_InvestibleAmountField")]
        public string SavingsInvestibleAmountField { get; set; }

        [JsonProperty("savings_InterestField")]
        public string SavingsInterestField { get; set; }

        [JsonProperty("savings_AccountValueField")]
        public string SavingsAccountValueField { get; set; }

        [JsonProperty("surrenderValueField")]
        public string SurrenderValueField { get; set; }

        [JsonProperty("sumAssuredField")]

        public string SumAssuredField { get; set; }

        [JsonProperty("costOfInsuranceField")]

        public string CostOfInsuranceField { get; set; }

        [JsonProperty("agentNameField")]
        public string AgentNameField { get; set; }

        [JsonProperty("customerNameField")]
        public string CustomerNameField { get; set; }

        [JsonProperty("paymentFreqField")]
        public string PaymentFreqField { get; set; }
    }


}
