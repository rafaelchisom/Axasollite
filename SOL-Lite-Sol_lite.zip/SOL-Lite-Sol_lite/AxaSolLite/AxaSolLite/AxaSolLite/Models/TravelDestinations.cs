﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class TravelDestinations
    {
        public int Id { get; set; }
        public string Destination { get; set; }
    }
    public class TravelVariants
    {
        public int Id { get; set; }
        public string Variant { get; set; }
    }
}
