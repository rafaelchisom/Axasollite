﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class NaicomIdMotorRequest
    {
        [JsonProperty("coverageStartDate")]
        public DateTime CoverageStartDate { get; set; }

        [JsonProperty("coverageEndDate")]
        public DateTime CoverageEndDate { get; set; }

        [JsonProperty("policyInternalID")]
        public string PolicyInternalId { get; set; }

        [JsonProperty("productCode")]
        public string ProductCode { get; set; }

        [JsonProperty("productType")]
        public string ProductType { get; set; }

        [JsonProperty("customerName")]
        public string CustomerName { get; set; }

        [JsonProperty("addressLine")]
        public string AddressLine { get; set; }

        [JsonProperty("cityLGA")]
        public string CityLga { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("phone")]
        public string Phone { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("premium")]
        public string Premium { get; set; }

        [JsonProperty("ownerLicense")]
        public string OwnerLicense { get; set; }

        [JsonProperty("commissionFee")]
        public string CommissionFee { get; set; }

        [JsonProperty("insuredValue")]
        public string InsuredValue { get; set; }

        [JsonProperty("docNo")]
        public int DocNo { get; set; }

        [JsonProperty("docType")]
        public int DocType { get; set; }

        [JsonProperty("motorDetails")]
        public List<MotorDetail> MotorDetails { get; set; }
    }

    public partial class MotorDetail
    {
        [JsonProperty("insuredNo")]
        public string InsuredNo { get; set; }

        [JsonProperty("vehicleID")]
        public string VehicleId { get; set; }

        [JsonProperty("plateNo")]
        public string PlateNo { get; set; }

        [JsonProperty("regNo")]
        public string RegNo { get; set; }

        [JsonProperty("regDate")]
        public DateTime RegDate { get; set; }

        [JsonProperty("regExpDate")]
        public DateTime RegExpDate { get; set; }

        [JsonProperty("autoType")]
        public string AutoType { get; set; }

        [JsonProperty("autoMake")]
        public string AutoMake { get; set; }

        [JsonProperty("autoModel")]
        public string AutoModel { get; set; }

        [JsonProperty("autoColor")]
        public string AutoColor { get; set; }

        [JsonProperty("autoYear")]
        public string AutoYear { get; set; }

        [JsonProperty("vehicleIdentityNo")]
        public string VehicleIdentityNo { get; set; }
    }
}
