﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class getMaxBenefitRequest
    {
        public int CustomerAge { get; set; }
        public int PolTerm { get; set; }
        public double annualPremium { get; set; }

        public double SumAssured { get; set; }
        public int invOption { get; set; }
    }
}
