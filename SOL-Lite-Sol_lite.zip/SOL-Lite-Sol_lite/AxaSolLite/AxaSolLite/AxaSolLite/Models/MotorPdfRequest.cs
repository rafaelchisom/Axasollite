﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class MotorPdfRequest
    {       
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string Gender { get; set; }
        public string DateOfBirth { get; set; }
        public string PhoneNumber { get; set; }
        public string ContactAddress { get; set; }
        public string State { get; set; }
        public string VehicleYear { get; set; }
        public string VehicleModel { get; set; }
        public string VehicleMake { get; set; }
        public string RegistrationNumber { get; set; }
        public string ChassisNumber { get; set; }
        public string EngineNumber { get; set; }
        public string PolicyStartDate { get; set; }
        public string DurationOfPolicy { get; set; }
        public string PremiumPaid { get; set; }
        public string PolicyTerm { get; set; }
        public string CarValue { get; set; }
        public string Rider1 { get; set; }
        public string Rider2 { get; set; }
        public string Rider3 { get; set; }
        public string Rider4 { get; set; }
        public string PolicyType { get; set; }
        public string CapturedSignature { get; set; }
    }
}
