﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class SBUDetails
    {
        public string SBU_Code { get; set; }
        public string SBU_Desc { get; set; }
    }
}
