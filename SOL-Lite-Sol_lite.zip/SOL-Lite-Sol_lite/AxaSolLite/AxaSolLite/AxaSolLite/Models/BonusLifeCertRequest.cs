﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class BonusLifeCertRequest
    {
        public string PolicyId { get; set; }
        public string CertificateNumber { get; set; }
        public string LifeAssured { get; set; }
        public string DateOfBirth { get; set; }
        public string SumAssured { get; set; }
        public string AgeNextBirthday { get; set; }
        public string Premium { get; set; }
        public string Frequency { get; set; }
        public string StartDate { get; set; }
        public string PaymentTerm { get; set; }
        public string BeneficiaryOne { get; set; }
        public string BeneficiaryTwo { get; set; }
        public string BeneficiaryThree { get; set; }
        public string CustomerName { get; set; }
        public string IssueDate { get; set; }
        public string EmailAddress { get; set; }
        public string AgentEmail { get; set; }
        public string ProductName { get; set; }
        public string CustomerNumber { get; set; }
        public string TransactionReference { get; set; }
        public bool FromAxaSol { get; set; }
        public string NaicomId { get; set; }
    }
}
