﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class EncryptResponse
    {
        public string EncryptValue { get; set; }
    }
}
