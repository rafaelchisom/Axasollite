﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class EPPprojectionsheetRequest
    {
        public string Agent_Name { get; set; }
        public string Issue_Date { get; set; }
        public string Customer_Name { get; set; }
        public string Phone_Number { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string Total_Premium { get; set; }
        public string Premium_Frequency { get; set; }
        public string Policy_Term { get; set; }
        public string Customer_Signature { get; set; }
        public string AgentEmail { get; set; }
        public string Product { get; set; }
        public string Lower_Maturity_Value { get; set; }
        public string Higher_Maturity_Value { get; set; }


        #region Age
        public string Year_1 { get; set; }
        public string Year_2 { get; set; }
        public string Year_3 { get; set; }
        public string Year_4 { get; set; }
        public string Year_5 { get; set; }
        public string Year_6 { get; set; }
        public string Year_7 { get; set; }
        public string Year_8 { get; set; }
        public string Year_9 { get; set; }
        public string Year_10 { get; set; }
        public string Year_11 { get; set; }
        public string Year_12 { get; set; }
        public string Year_13 { get; set; }
        public string Year_14 { get; set; }
        public string Year_15 { get; set; }
        public string Year_16 { get; set; }
        public string Year_17 { get; set; }
        public string Year_18 { get; set; }
        public string Year_19 { get; set; }
        public string Year_20 { get; set; }
        public string Year_21 { get; set; }
        public string Year_22 { get; set; }
        public string Year_23 { get; set; }
        public string Year_24 { get; set; }
        public string Year_25 { get; set; }
        public string Year_26 { get; set; }
        public string Year_27 { get; set; }
        public string Year_28 { get; set; }

        #endregion
        #region Contribution
        public string Contribution_1 { get; set; }
        public string Contribution_2 { get; set; }
        public string Contribution_3 { get; set; }
        public string Contribution_4 { get; set; }
        public string Contribution_5 { get; set; }
        public string Contribution_6 { get; set; }
        public string Contribution_7 { get; set; }
        public string Contribution_8 { get; set; }
        public string Contribution_9 { get; set; }
        public string Contribution_10 { get; set; }
        public string Contribution_11 { get; set; }
        public string Contribution_12 { get; set; }
        public string Contribution_13 { get; set; }
        public string Contribution_14 { get; set; }
        public string Contribution_15 { get; set; }
        public string Contribution_16 { get; set; }
        public string Contribution_17 { get; set; }
        public string Contribution_18 { get; set; }
        public string Contribution_19 { get; set; }
        public string Contribution_20 { get; set; }
        public string Contribution_21 { get; set; }
        public string Contribution_22 { get; set; }
        public string Contribution_23 { get; set; }
        public string Contribution_24 { get; set; }
        public string Contribution_25 { get; set; }
        public string Contribution_26 { get; set; }
        public string Contribution_27 { get; set; }
        public string Contribution_28 { get; set; }

        #endregion
        #region LowerSumAssured
        public string Lower_Sum_Assured_1 { get; set; }
        public string Lower_Sum_Assured_2 { get; set; }
        public string Lower_Sum_Assured_3 { get; set; }
        public string Lower_Sum_Assured_4 { get; set; }
        public string Lower_Sum_Assured_5 { get; set; }
        public string Lower_Sum_Assured_6 { get; set; }
        public string Lower_Sum_Assured_7 { get; set; }
        public string Lower_Sum_Assured_8 { get; set; }
        public string Lower_Sum_Assured_9 { get; set; }
        public string Lower_Sum_Assured_10 { get; set; }
        public string Lower_Sum_Assured_11 { get; set; }
        public string Lower_Sum_Assured_12 { get; set; }
        public string Lower_Sum_Assured_13 { get; set; }
        public string Lower_Sum_Assured_14 { get; set; }
        public string Lower_Sum_Assured_15 { get; set; }
        public string Lower_Sum_Assured_16 { get; set; }
        public string Lower_Sum_Assured_17 { get; set; }
        public string Lower_Sum_Assured_18 { get; set; }
        public string Lower_Sum_Assured_19 { get; set; }
        public string Lower_Sum_Assured_20 { get; set; }
        public string Lower_Sum_Assured_21 { get; set; }
        public string Lower_Sum_Assured_22 { get; set; }
        public string Lower_Sum_Assured_23 { get; set; }
        public string Lower_Sum_Assured_24 { get; set; }
        public string Lower_Sum_Assured_25 { get; set; }
        public string Lower_Sum_Assured_26 { get; set; }
        public string Lower_Sum_Assured_27 { get; set; }
        public string Lower_Sum_Assured_28 { get; set; }

        #endregion
        #region LowerPolicyValue
        public string Lower_Policy_Value_1 { get; set; }
        public string Lower_Policy_Value_2 { get; set; }
        public string Lower_Policy_Value_3 { get; set; }
        public string Lower_Policy_Value_4 { get; set; }
        public string Lower_Policy_Value_5 { get; set; }
        public string Lower_Policy_Value_6 { get; set; }
        public string Lower_Policy_Value_7 { get; set; }
        public string Lower_Policy_Value_8 { get; set; }
        public string Lower_Policy_Value_9 { get; set; }
        public string Lower_Policy_Value_10 { get; set; }
        public string Lower_Policy_Value_11 { get; set; }
        public string Lower_Policy_Value_12 { get; set; }
        public string Lower_Policy_Value_13 { get; set; }
        public string Lower_Policy_Value_14 { get; set; }
        public string Lower_Policy_Value_15 { get; set; }
        public string Lower_Policy_Value_16 { get; set; }
        public string Lower_Policy_Value_17 { get; set; }
        public string Lower_Policy_Value_18 { get; set; }
        public string Lower_Policy_Value_19 { get; set; }
        public string Lower_Policy_Value_20 { get; set; }
        public string Lower_Policy_Value_21 { get; set; }
        public string Lower_Policy_Value_22 { get; set; }
        public string Lower_Policy_Value_23 { get; set; }
        public string Lower_Policy_Value_24 { get; set; }
        public string Lower_Policy_Value_25 { get; set; }
        public string Lower_Policy_Value_26 { get; set; }
        public string Lower_Policy_Value_27 { get; set; }
        public string Lower_Policy_Value_28 { get; set; }

        #endregion
        #region LowerSurrenderValue
        public string Lower_Surrender_Value_1 { get; set; }
        public string Lower_Surrender_Value_2 { get; set; }
        public string Lower_Surrender_Value_3 { get; set; }
        public string Lower_Surrender_Value_4 { get; set; }
        public string Lower_Surrender_Value_5 { get; set; }
        public string Lower_Surrender_Value_6 { get; set; }
        public string Lower_Surrender_Value_7 { get; set; }
        public string Lower_Surrender_Value_8 { get; set; }
        public string Lower_Surrender_Value_9 { get; set; }
        public string Lower_Surrender_Value_10 { get; set; }
        public string Lower_Surrender_Value_11 { get; set; }
        public string Lower_Surrender_Value_12 { get; set; }
        public string Lower_Surrender_Value_13 { get; set; }
        public string Lower_Surrender_Value_14 { get; set; }
        public string Lower_Surrender_Value_15 { get; set; }
        public string Lower_Surrender_Value_16 { get; set; }
        public string Lower_Surrender_Value_17 { get; set; }
        public string Lower_Surrender_Value_18 { get; set; }
        public string Lower_Surrender_Value_19 { get; set; }
        public string Lower_Surrender_Value_20 { get; set; }
        public string Lower_Surrender_Value_21 { get; set; }
        public string Lower_Surrender_Value_22 { get; set; }
        public string Lower_Surrender_Value_23 { get; set; }
        public string Lower_Surrender_Value_24 { get; set; }
        public string Lower_Surrender_Value_25 { get; set; }
        public string Lower_Surrender_Value_26 { get; set; }
        public string Lower_Surrender_Value_27 { get; set; }
        public string Lower_Surrender_Value_28 { get; set; }

        #endregion
        #region HigherSumAssured
        public string Higher_Sum_Assured_1 { get; set; }
        public string Higher_Sum_Assured_2 { get; set; }
        public string Higher_Sum_Assured_3 { get; set; }
        public string Higher_Sum_Assured_4 { get; set; }
        public string Higher_Sum_Assured_5 { get; set; }
        public string Higher_Sum_Assured_6 { get; set; }
        public string Higher_Sum_Assured_7 { get; set; }
        public string Higher_Sum_Assured_8 { get; set; }
        public string Higher_Sum_Assured_9 { get; set; }
        public string Higher_Sum_Assured_10 { get; set; }
        public string Higher_Sum_Assured_11 { get; set; }
        public string Higher_Sum_Assured_12 { get; set; }
        public string Higher_Sum_Assured_13 { get; set; }
        public string Higher_Sum_Assured_14 { get; set; }
        public string Higher_Sum_Assured_15 { get; set; }
        public string Higher_Sum_Assured_16 { get; set; }
        public string Higher_Sum_Assured_17 { get; set; }
        public string Higher_Sum_Assured_18 { get; set; }
        public string Higher_Sum_Assured_19 { get; set; }
        public string Higher_Sum_Assured_20 { get; set; }
        public string Higher_Sum_Assured_21 { get; set; }
        public string Higher_Sum_Assured_22 { get; set; }
        public string Higher_Sum_Assured_23 { get; set; }
        public string Higher_Sum_Assured_24 { get; set; }
        public string Higher_Sum_Assured_25 { get; set; }
        public string Higher_Sum_Assured_26 { get; set; }
        public string Higher_Sum_Assured_27 { get; set; }
        public string Higher_Sum_Assured_28 { get; set; }

        #endregion
        #region HigherPolicyValue
        public string Higher_Policy_Value_1 { get; set; }
        public string Higher_Policy_Value_2 { get; set; }
        public string Higher_Policy_Value_3 { get; set; }
        public string Higher_Policy_Value_4 { get; set; }
        public string Higher_Policy_Value_5 { get; set; }
        public string Higher_Policy_Value_6 { get; set; }
        public string Higher_Policy_Value_7 { get; set; }
        public string Higher_Policy_Value_8 { get; set; }
        public string Higher_Policy_Value_9 { get; set; }
        public string Higher_Policy_Value_10 { get; set; }
        public string Higher_Policy_Value_11 { get; set; }
        public string Higher_Policy_Value_12 { get; set; }
        public string Higher_Policy_Value_13 { get; set; }
        public string Higher_Policy_Value_14 { get; set; }
        public string Higher_Policy_Value_15 { get; set; }
        public string Higher_Policy_Value_16 { get; set; }
        public string Higher_Policy_Value_17 { get; set; }
        public string Higher_Policy_Value_18 { get; set; }
        public string Higher_Policy_Value_19 { get; set; }
        public string Higher_Policy_Value_20 { get; set; }
        public string Higher_Policy_Value_21 { get; set; }
        public string Higher_Policy_Value_22 { get; set; }
        public string Higher_Policy_Value_23 { get; set; }
        public string Higher_Policy_Value_24 { get; set; }
        public string Higher_Policy_Value_25 { get; set; }
        public string Higher_Policy_Value_26 { get; set; }
        public string Higher_Policy_Value_27 { get; set; }
        public string Higher_Policy_Value_28 { get; set; }

        #endregion
        #region HigherSurrenderValue
        public string Higher_Surrender_Value_1 { get; set; }
        public string Higher_Surrender_Value_2 { get; set; }
        public string Higher_Surrender_Value_3 { get; set; }
        public string Higher_Surrender_Value_4 { get; set; }
        public string Higher_Surrender_Value_5 { get; set; }
        public string Higher_Surrender_Value_6 { get; set; }
        public string Higher_Surrender_Value_7 { get; set; }
        public string Higher_Surrender_Value_8 { get; set; }
        public string Higher_Surrender_Value_9 { get; set; }
        public string Higher_Surrender_Value_10 { get; set; }
        public string Higher_Surrender_Value_11 { get; set; }
        public string Higher_Surrender_Value_12 { get; set; }
        public string Higher_Surrender_Value_13 { get; set; }
        public string Higher_Surrender_Value_14 { get; set; }
        public string Higher_Surrender_Value_15 { get; set; }
        public string Higher_Surrender_Value_16 { get; set; }
        public string Higher_Surrender_Value_17 { get; set; }
        public string Higher_Surrender_Value_18 { get; set; }
        public string Higher_Surrender_Value_19 { get; set; }
        public string Higher_Surrender_Value_20 { get; set; }
        public string Higher_Surrender_Value_21 { get; set; }
        public string Higher_Surrender_Value_22 { get; set; }
        public string Higher_Surrender_Value_23 { get; set; }
        public string Higher_Surrender_Value_24 { get; set; }
        public string Higher_Surrender_Value_25 { get; set; }
        public string Higher_Surrender_Value_26 { get; set; }
        public string Higher_Surrender_Value_27 { get; set; }
        public string Higher_Surrender_Value_28 { get; set; }

        #endregion
    }
}
