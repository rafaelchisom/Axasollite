﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class AutoClassicRenewalRequest
    {
        [JsonProperty("custNumber")]
        public string CustNumber { get; set; }

        [JsonProperty("agentCode")]
        public string AgentCode { get; set; }

        [JsonProperty("subAgentCode")]
        public string SubAgentCode { get; set; }

        [JsonProperty("branchCode")]
        public int BranchCode { get; set; }

        [JsonProperty("sbuCode")]
        public int SbuCode { get; set; }

        [JsonProperty("uwYear")]
        public int UwYear { get; set; }

        [JsonProperty("startDate")]
        public DateTimeOffset StartDate { get; set; }

        [JsonProperty("coverDays")]
        public int CoverDays { get; set; }

        [JsonProperty("premiumPaymentType")]
        public int PremiumPaymentType { get; set; }

        [JsonProperty("insuredVehicles")]
        public List<InsuredVehicle> InsuredVehicles { get; set; }

        [JsonProperty("policyID")]
        public string PolicyId { get; set; }
        public string ProductType { get; set; }
    }

    public class InsuredVehicle
    {
        [JsonProperty("startDate")]
        public DateTimeOffset StartDate { get; set; }

        [JsonProperty("regDate")]
        public DateTimeOffset RegDate { get; set; }

        [JsonProperty("endDate")]
        public DateTimeOffset EndDate { get; set; }

        [JsonProperty("coverDays")]
        public int CoverDays { get; set; }

        [JsonProperty("annualSalary")]
        public double AnnualSalary { get; set; }

        [JsonProperty("sumInsured")]
        public double SumInsured { get; set; }

        [JsonProperty("plateNumber")]
        public string PlateNumber { get; set; }

        [JsonProperty("plateColor")]
        public int PlateColor { get; set; }

        [JsonProperty("make")]
        public int Make { get; set; }

        [JsonProperty("model")]
        public string Model { get; set; }

        [JsonProperty("prodYear")]
        public int ProdYear { get; set; }

        [JsonProperty("engineNumber")]
        public string EngineNumber { get; set; }

        [JsonProperty("chasisNumber")]
        public string ChasisNumber { get; set; }

        [JsonProperty("chasisCode")]
        public int ChasisCode { get; set; }

        [JsonProperty("regPlace")]
        public int RegPlace { get; set; }

        [JsonProperty("plateType")]
        public int PlateType { get; set; }

        [JsonProperty("rates")]
        public Rates Rates { get; set; }

        [JsonProperty("driversName")]
        public string DriversName { get; set; }

        [JsonProperty("remarkCode")]
        public int RemarkCode { get; set; }

        [JsonProperty("carTrackerAmount")]
        public double CarTrackerAmount { get; set; }
    }

    public class Rates
    {
        [JsonProperty("basicPremRate")]
        public decimal BasicPremRate { get; set; }

        [JsonProperty("tppdRate")]
        public decimal TppdRate { get; set; }

        [JsonProperty("ebbRate")]
        public decimal EbbRate { get; set; }

        [JsonProperty("floodRate")]
        public decimal FloodRate { get; set; }

        [JsonProperty("srccRate")]
        public decimal SrccRate { get; set; }

        [JsonProperty("extraChargeRate")]
        public decimal ExtraChargeRate { get; set; }
    }
}
