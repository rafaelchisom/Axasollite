﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace AxaSolLite.Models
{
    public partial class AimsLifeBookingDto
    {
        [JsonProperty("XFR_INFO_MST_POL_TYPE")]
        public long XfrInfoMstPolType { get; set; }

        [JsonProperty("XFR_INFO_MST_BRANCH")]
        public long XfrInfoMstBranch { get; set; }

        [JsonProperty("XFR_INFO_MST_OFFICE")]
        public long XfrInfoMstOffice { get; set; }

        [JsonProperty("XFR_INFO_MST_AGENT_NO")]
        public string XfrInfoMstAgentNo { get; set; }

        [JsonProperty("XFR_INFO_MST_PAY_TYPE")]
        public long XfrInfoMstPayType { get; set; }

        [JsonProperty("XFR_INFO_MST_PERIOD")]
        public long XfrInfoMstPeriod { get; set; }

        [JsonProperty("XFR_INFO_LPM_PERIOD_TYPE")]
        public long XfrInfoLpmPeriodType { get; set; }

        [JsonProperty("XFR_INFO_LCP_PAYMENT_PERIOD")]
        public long XfrInfoLcpPaymentPeriod { get; set; }

        [JsonProperty("XFR_INFO_LCP_PAYMENT_PERIOD2")]
        public long XfrInfoLcpPaymentPeriod2 { get; set; }

        [JsonProperty("XFR_INFO_LCP_PAYMENT_PERIOD3")]
        public long XfrInfoLcpPaymentPeriod3 { get; set; }

        [JsonProperty("XFR_INFO_LCP_PAYMENT_PERIOD4")]
        public long XfrInfoLcpPaymentPeriod4 { get; set; }

        [JsonProperty("XFR_INFO_LCP_RIDER_TYPE1")]
        public long XfrInfoLcpRiderType1 { get; set; }

        [JsonProperty("XFR_INFO_LCP_RIDER_TYPE2")]
        public string XfrInfoLcpRiderType2 { get; set; }

        [JsonProperty("XFR_INFO_MST_CUST_NO")]
        public long XfrInfoMstCustNo { get; set; }

        [JsonProperty("XFR_INFO_CUST_PREV_POLICY_FLAG")]
        public long XfrInfoCustPrevPolicyFlag { get; set; }

        [JsonProperty("XFR_INFO_ACM_ANN_SALARY")]
        public long XfrInfoAcmAnnSalary { get; set; }

        [JsonProperty("XFR_INFO_LINKED_DOC_NO")]
        public long XfrInfoLinkedDocNo { get; set; }

        [JsonProperty("XFR_INFO_MST_UW_YEAR")]
        public long XfrInfoMstUwYear { get; set; }

        [JsonProperty("XFR_INFO_MST_REG_DT")]
        public DateTimeOffset XfrInfoMstRegDt { get; set; }

        [JsonProperty("XFR_INFO_MST_INS_ST_DT")]
        public DateTimeOffset XfrInfoMstInsStDt { get; set; }

        [JsonProperty("XFR_INFO_SCAN_DATE")]
        public DateTimeOffset XfrInfoScanDate { get; set; }

        [JsonProperty("XFR_INFO_MST_THROUGH")]
        public long XfrInfoMstThrough { get; set; }

        [JsonProperty("XFR_INFO_LPM_LOADED_PREM")]
        public long XfrInfoLpmLoadedPrem { get; set; }

        [JsonProperty("XFR_INFO_ACM_ID_TYPE")]
        public long XfrInfoAcmIdType { get; set; }

        [JsonProperty("XFR_INFO_LBEN_SUM_ASSURED")]
        public long XfrInfoLbenSumAssured { get; set; }

        [JsonProperty("XFR_INFO_LBEN_NATIONAL_NO")]
        public string XfrInfoLbenNationalNo { get; set; }

        [JsonProperty("XFR_INFO_LBEN_MONTHLY_SALARY")]
        public long XfrInfoLbenMonthlySalary { get; set; }

        [JsonProperty("XFR_INFO_LBEN_SUR_NAME")]
        public string XfrInfoLbenSurName { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TEL")]
        public string XfrInfoLbenTel { get; set; }

        [JsonProperty("XFR_INFO_LBEN_CUST_RELATION")]
        public long XfrInfoLbenCustRelation { get; set; }

        [JsonProperty("XFR_INFO_LBEN_OCCUPATION")]
        public long XfrInfoLbenOccupation { get; set; }

        [JsonProperty("XFR_INFO_LBEN_OTHER_NAME")]
        public string XfrInfoLbenOtherName { get; set; }

        [JsonProperty("XFR_INFO_LBEN_MARITAL_STATUS")]
        public long XfrInfoLbenMaritalStatus { get; set; }

        [JsonProperty("XFR_INFO_LBEN_ADDRESS")]
        public string XfrInfoLbenAddress { get; set; }

        [JsonProperty("XFR_INFO_LBEN_BIRTH_DT")]
        public DateTimeOffset XfrInfoLbenBirthDt { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TYPE1")]
        public string XfrInfoLbenType1 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_SUR_NAME2")]
        public string XfrInfoLbenSurName2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TEL2")]
        public string XfrInfoLbenTel2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_OTHER_NAME2")]
        public string XfrInfoLbenOtherName2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_OCCUPATION2")]

        public long XfrInfoLbenOccupation2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_MARITAL_STATUS2")]

        public long XfrInfoLbenMaritalStatus2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_JOB_CLASS")]

        public long XfrInfoLbenJobClass { get; set; }

        [JsonProperty("XFR_INFO_LBEN_JOB_CLASS2")]

        public long XfrInfoLbenJobClass2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_CUST_RELATION2")]

        public long XfrInfoLbenCustRelation2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_ADDRESS2")]
        public string XfrInfoLbenAddress2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_BIRTH_DT2")]
        public DateTimeOffset XfrInfoLbenBirthDt2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TYPE2")]

        public long XfrInfoLbenType2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_SUR_NAME3")]
        public string XfrInfoLbenSurName3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TEL3")]
        public string XfrInfoLbenTel3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_OTHER_NAME3")]
        public string XfrInfoLbenOtherName3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_OCCUPATION3")]
        public string XfrInfoLbenOccupation3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_MARITAL_STATUS3")]
        public string XfrInfoLbenMaritalStatus3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_JOB_CLASS3")]
        public string XfrInfoLbenJobClass3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_CUST_RELATION3")]
        public string XfrInfoLbenCustRelation3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_ADDRESS3")]
        public string XfrInfoLbenAddress3 { get; set; }

        [JsonProperty("XFR_INFO_LCP_RIDER_TYPE3")]
        public string XfrInfoLcpRiderType3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TYPE3")]
        public string XfrInfoLbenType3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_SUR_NAME4")]
        public string XfrInfoLbenSurName4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TEL4")]
        public string XfrInfoLbenTel4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_OTHER_NAME4")]
        public string XfrInfoLbenOtherName4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_OCCUPATION4")]
        public string XfrInfoLbenOccupation4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_MARITAL_STATUS4")]
        public string XfrInfoLbenMaritalStatus4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_JOB_CLASS4")]
        public string XfrInfoLbenJobClass4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_CUST_RELATION4")]
        public string XfrInfoLbenCustRelation4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_ADDRESS4")]
        public string XfrInfoLbenAddress4 { get; set; }

        [JsonProperty("XFR_INFO_LCP_RIDER_TYPE4")]
        public string XfrInfoLcpRiderType4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TYPE4")]
        public string XfrInfoLbenType4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_SUR_NAME5")]
        public string XfrInfoLbenSurName5 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TEL5")]
        public string XfrInfoLbenTel5 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_OTHER_NAME5")]
        public string XfrInfoLbenOtherName5 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_OCCUPATION5")]
        public string XfrInfoLbenOccupation5 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_MARITAL_STATUS5")]
        public string XfrInfoLbenMaritalStatus5 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_JOB_CLASS5")]
        public string XfrInfoLbenJobClass5 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_CUST_RELATION5")]
        public string XfrInfoLbenCustRelation5 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_ADDRESS5")]
        public string XfrInfoLbenAddress5 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TYPE5")]
        public string XfrInfoLbenType5 { get; set; }

        [JsonProperty("XFR_INFO_NATIONAML_NO")]
        public string XfrInfoNationamlNo { get; set; }

        [JsonProperty("XFR_INFO_SCAN_SERIAL")]
        public long XfrInfoScanSerial { get; set; }

        [JsonProperty("XFR_INFO_MST_TRN_TYPE")]
        public long XfrInfoMstTrnType { get; set; }

        [JsonProperty("XFR_INFO_MST_REN_POL_TYPE")]
        public long XfrInfoMstRenPolType { get; set; }

        [JsonProperty("XFR_INFO_MST_LONG_TERM_FLAG")]
        public long XfrInfoMstLongTermFlag { get; set; }

        [JsonProperty("XFR_INFO_MST_DOC_TYPE")]
        public long XfrInfoMstDocType { get; set; }

        //[JsonProperty("XFR_INFO_MST_ENDT_SERIAL")]
        //public string XfrInfoMstEndtSerial { get; set; }

        //[JsonProperty("XFR_INFO_MST_DOC_NO")]
        //public string XfrInfoMstDocNo { get; set; }

        [JsonProperty("XFR_INFO_CAR_BODY_TYPE")]
        public string XfrInfoCarBodyType { get; set; }

        [JsonProperty("XFR_INFO_POLICY_KEY")]
        public string XfrInfoPolicyKey { get; set; }

        [JsonProperty("XFR_INFO_HAS_DISCOUNT")]
        public bool XfrInfoHasDiscount { get; set; }

        [JsonProperty("XFR_INFO_DISCOUNT_RATE")]
        public long XfrInfoDiscountRate { get; set; }

        [JsonProperty("XFR_INFO_REFERRAL_CODE")]
        public string XfrInfoReferralCode { get; set; }

        [JsonProperty("XFR_INFO_ISAPSS")]
        public string XfrInfoIsapss { get; set; }

        [JsonProperty("XFR_INFO_ISREFERRAL_POLICY")]
        public string XfrInfoIsreferralPolicy { get; set; }

        [JsonProperty("XFR_INFO_USE_CUSTOM_RATE")]
        public bool XfrInfoUseCustomRate { get; set; }

        [JsonProperty("XFR_INFO_QUOTE_NO")]
        public string XfrInfoQuoteNo { get; set; }

        [JsonProperty("XFR_INFO_PERIOD_CONTRIB")]
        public long XfrInfoPeriodContrib { get; set; }

        [JsonProperty("AmountPaid")]
        public long AmountPaid { get; set; }

        [JsonProperty("PaymentSource")]
        public string PaymentSource { get; set; }

        [JsonProperty("TransRef")]
        public string TransRef { get; set; }

        [JsonProperty("RequestSource")]
        public string RequestSource { get; set; }
        [JsonProperty("RequesterUsername")]
        public string RequesterUsername { get; set; }
        [JsonProperty("CustomerDeliveryAddress")]
        public string CustomerDeliveryAddress { get; set; }

        [JsonProperty("XFR_INFO_ANY_YES_NMQ")]
        public bool XfrInfoAnyYesNmq { get; set; }

        [JsonProperty("XFR_INFO_ISPAY_NOW")]
        public bool XfrInfoIspayNow { get; set; }

        [JsonProperty("XFR_INFO_PAY_NOW_TRANS_REF")]
        public string XfrInfoPayNowTransRef { get; set; }

        public string AgentCode { get; set; }

        [JsonProperty("LifeProposalForm")]
        public LifeProposalForm LifeProposalForm { get; set; }

        [JsonProperty("NonMedQuestionaire")]
        public LifeProposalForm NonMedQuestionaire { get; set; }

        [JsonProperty("OtherRequirements")]
        public List<LifeProposalForm> OtherRequirements { get; set; }

        [JsonProperty("XFR_INFO_BOOK_FROM_BALANCE")]
        public bool XFR_INFO_BOOK_FROM_BALANCE { get; set; }

        //public int XFR_INFO_SOURCE_BUISNESS { get; set; }

        public string XFR_INFO_MST_REMARKS { get; set; }
        public int Bentitle1 { get; set; }

        public int Bentitle2 { get; set; }

        public int Bentitle3 { get; set; }

        public int Bentitle4 { get; set; }

        public int Bentitle5 { get; set; }

    }

    public partial class LifeProposalForm
    {
        [JsonProperty("FileName")]
        public string FileName { get; set; }

        [JsonProperty("ContentType")]
        public string ContentType { get; set; }

        [JsonProperty("FileContent")]
        public string FileContent { get; set; }

        [JsonProperty("Extension")]
        public string Extension { get; set; }

        [JsonProperty("FieldName")]
        public string FieldName { get; set; }
    }
    
}


