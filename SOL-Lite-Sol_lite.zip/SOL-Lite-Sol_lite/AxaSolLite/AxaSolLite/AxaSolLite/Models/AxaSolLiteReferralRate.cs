﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class AxaSolLiteReferralRate
    {
        public string AgentCode { get; set; }
        public string AgentFullName { get; set; }
        public string CustomerFullName { get; set; }
        public string ReferralLink { get; set; }
        public string PolicyName { get; set; }
        public string Sbu { get; set; }
        public string SbuName { get; set; }

    }
}
