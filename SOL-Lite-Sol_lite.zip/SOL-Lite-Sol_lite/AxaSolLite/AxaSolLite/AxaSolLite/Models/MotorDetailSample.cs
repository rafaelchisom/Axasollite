﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class MotorDetailSample
    {
        [JsonProperty("IsSuccessful")]
        public bool IsSuccessful { get; set; }

        [JsonProperty("Result")]
        public Sample Result { get; set; }
    }

    public partial class Sample
    {
        [JsonProperty("MakeList")]
        public MakeList[] MakeList { get; set; }
    }

    public partial class MakeList
    {
        [JsonProperty("Id")]
        public int Id { get; set; }

        [JsonProperty("Name")]
        public string Name { get; set; }

    }
}
