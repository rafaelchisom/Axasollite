﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class MotorRiderResponse
    {
        public int ID { get; set; }
        public string RateName { get; set; }
        public double RateValue { get; set; }
        public int RateStatus { get; set; }
        public int PolicyTypeID { get; set; }
    }
}
