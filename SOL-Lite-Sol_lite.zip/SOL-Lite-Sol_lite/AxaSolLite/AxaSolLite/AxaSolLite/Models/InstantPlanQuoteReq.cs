﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
   public class InstantPlanQuoteReq
    {
        public int Id { get; set; }
        public string Premium { get; set; }
        public string SumAssured { get; set; }
    }
}
