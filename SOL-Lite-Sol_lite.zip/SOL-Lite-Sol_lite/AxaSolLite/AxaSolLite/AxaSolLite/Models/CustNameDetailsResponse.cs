﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{

    public class CustNameDetailsResponse
    {
        public bool IsToggled { get; set; }
        [JsonProperty("customerNo")]

        public string CustomerNo { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("phoneNumber")]
        public string PhoneNumber { get; set; }

        [JsonProperty("typeCode")]

        public string TypeCode { get; set; }

        [JsonProperty("customerType")]
        public string CustomerType { get; set; }

        [JsonProperty("mobileNumber")]
        public string MobileNumber { get; set; }

        [JsonProperty("address")]
        public string Address { get; set; }

        [JsonProperty("policies")]
        public string Policies { get; set; }
    }
}
