﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class TravelCostResponse
    {
        public bool IsSuccessful { get; set; }
        public string message { get; set; }

        [JsonProperty("ReturnedObject")]
        public TravelReturnedObject ReturnedObject { get; set; }

        public object ReturnCode { get; set; }
    }

    public class TravelPlanCostDto
    {
        public string Plan { get; set; }
        public string PlanID { get; set; }
        public double PlanCost { get; set; }
        public string PlanCode { get; set; }
        public string GeoCoverageArea { get; set; }
        public string[] BenefitValue { get; set; }
        public object Program { get; set; }
        public object Area { get; set; }
    }

    public class TravelReturnedObject
    {
        public List<TravelPlanCostDto> TravelPlanCost { get; set; }
        public string[] BenefitName { get; set; }
        public int NumberOfPersons { get; set; }
    }
}
