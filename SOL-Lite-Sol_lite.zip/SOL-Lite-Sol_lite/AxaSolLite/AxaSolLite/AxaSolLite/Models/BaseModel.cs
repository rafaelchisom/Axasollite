﻿using SQLite;
using System;

namespace AxaSolLite.Models
{
    public abstract class BaseModel
    {
        [PrimaryKey, AutoIncrement]
        public Guid Id { get; set; }

        public int? DisplayOrder { get; set; }

        public DateTime DateCreated { get; set; }

        public DateTime? DateUpdated { get; set; }

        public bool IsDeleted { get; set; }

        public bool IsDirty { get; set; }

        public override string ToString()
        {
            return string.Format("Type: {0} Id: {1}", base.ToString(), Id);
        }

        public string IdString
        {
            get { return Id.ToString(); }
        }
    }
}
