﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class TravelProduct : BaseModel
    {
        public TravelProduct()
        {
            Id = Guid.NewGuid();
        }

        public Guid ProspectId { get; set; }
        public Guid ProductPlanId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public DateTime DateofBirth { get; set; }
        public string BVN { get; set; }
        public string PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
        public string Address { get; set; }
        public string Nationality { get; set; }
        public string State { get; set; }
        public string PassportNumber { get; set; }
        public string PlanType { get; set; }
        public string PolicyType { get; set; }
        public DateTime CoverStartDate { get; set; }
        public DateTime CoverEndDate { get; set; }
        public string Destination { get; set; }
        public string Duration { get; set; }
        public string No_of_Persons { get; set; }
        public string Purpose_of_Trip { get; set; }
        public DateTime ReturnDate { get; set; }
        public int NoOfFirstAgeCategory { get; set; }
        public int NoOfSecondAgeCategory { get; set; }
        public int NoOfThirdAgeCategory { get; set; }
        public int NoOfFourthAgeCategory { get; set; }
        public string ProposalNumber { get; set; }
        public byte[] InternationalPassport { get; set; }
        public double Premium { get; set; }
        public string Variant { get; set; }
        public int Branch { get; set; }
        public string RICode { get; set; }
    }
}
