﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public partial class VerifyPayStackPaymentResponse
    {
        [JsonProperty("status")]
        public bool Status { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("data")]
        public Data Data { get; set; }
    }

    public partial class Data
    {
        [JsonProperty("amount")]
        public long Amount { get; set; }

        [JsonProperty("currency")]
        public string Currency { get; set; }

        [JsonProperty("transaction_date")]
        public DateTimeOffset TransactionDate { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("reference")]
        public string Reference { get; set; }

        [JsonProperty("domain")]
        public string Domain { get; set; }

        [JsonProperty("metadata")]
        public Metadata Metadata { get; set; }

        [JsonProperty("gateway_response")]
        public string GatewayResponse { get; set; }

        [JsonProperty("message")]
        public object Message { get; set; }

        [JsonProperty("channel")]
        public string Channel { get; set; }

        [JsonProperty("ip_address")]
        public string IpAddress { get; set; }

        [JsonProperty("log")]
        public object Log { get; set; }

        [JsonProperty("fees")]
        public object Fees { get; set; }

        [JsonProperty("authorization")]
        public Authorization Authorization { get; set; }

        [JsonProperty("customer")]
        public Customer Customer { get; set; }

        [JsonProperty("plan")]
        public object Plan { get; set; }
    }

    public partial class Authorization
    {
        [JsonProperty("authorization_code")]
        public object AuthorizationCode { get; set; }

        [JsonProperty("card_type")]
        public object CardType { get; set; }

        [JsonProperty("last4")]
        public object Last4 { get; set; }

        [JsonProperty("exp_month")]
        public object ExpMonth { get; set; }

        [JsonProperty("exp_year")]
        public object ExpYear { get; set; }

        [JsonProperty("bin")]
        public object Bin { get; set; }

        [JsonProperty("bank")]
        public object Bank { get; set; }

        [JsonProperty("channel")]
        public object Channel { get; set; }

        [JsonProperty("reusable")]
        public object Reusable { get; set; }

        [JsonProperty("country_code")]
        public object CountryCode { get; set; }
    }

    public partial class Customer
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("customer_code")]
        public string CustomerCode { get; set; }

        [JsonProperty("first_name")]
        public object FirstName { get; set; }

        [JsonProperty("last_name")]
        public object LastName { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }
    }

   
}
