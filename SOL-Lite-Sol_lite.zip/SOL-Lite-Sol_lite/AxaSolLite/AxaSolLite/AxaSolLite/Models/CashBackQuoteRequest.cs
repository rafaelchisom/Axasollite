﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
   public class CashBackQuoteRequest
    {
        [JsonProperty("ageNextBirthDayField")]
        public string AgeNextBirthDayField { get; set; }

        [JsonProperty("proposalNameField")]
        public string ProposalNameField { get; set; }

        [JsonProperty("desiredSumAssuredField")]
        public double DesiredSumAssuredField { get; set; }

        [JsonProperty("desiredPolicyTermField")]
        public int DesiredPolicyTermField { get; set; }

        [JsonProperty("isSinglePremiumField")]
        public int IsSinglePremiumField { get; set; }

        [JsonProperty("criticalIllnessRiderField")]
        public int CriticalIllnessRiderField { get; set; }

        [JsonProperty("extendedCoverField")]
        public double ExtendedCoverField { get; set; }

        [JsonProperty("permanentDisabilityField")]
        public double PermanentDisabilityField { get; set; }
    }
}
