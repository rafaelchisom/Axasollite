﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class Prospect : BaseModel
    {
        public Guid UserId { get; set; }

        public string ProspectId { get; set; }
        public long ClientId { get; set; }
        public int? TitleId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }

        public string FullName { get; set; }
        //public string FullName => $" {FirstName} {LastName}";
        public string CustomerName { get; set; }

        public string NameSuffix { get; set; }
        public string Alias { get; set; }
        public int Age { get; set; }
        public int PolicyTerm { get; set; }
        public int Country { get; set; }
        public int MaritalStatus { get; set; }
        public string Profession { get; set; }
        public string Occupation { get; set; }
        public string Employer { get; set; }
        public DateTime Birthdate { get; set; }
        public int Gender { get; set; }
        public int Smoker { get; set; }
        public int? ParentId { get; set; }
        public int? RelationshipToParentId { get; set; }
        public int? Agentid { get; set; }
        public int? ComparisonAgeId { get; set; }
        public decimal? GrossMonthlyincome { get; set; }
        public string Email { get; set; }
        public string MobileNumber { get; set; }
        public string CustomerNumber { get; set; }
        public int? ClientDetailId { get; set; }
        public int? ReferrerClientId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? OccupationId { get; set; }
        public int? GlobalClientId { get; set; }
        public string SalesForceId { get; set; }
        public bool? IsClient { get; set; }
        public DateTime? LastSyncDate { get; set; }
        public byte[] ProfilePicture { get; set; }
        public string Address { get; set; }
        public string StateOfOrigin { get; set; }
        public string Nationality { get; set; }
        public bool CaseCreated { get; set; }
        public string CaseId { get; set; }
        public string OnboardingCase_app_uid { get; set; }
        public bool IsConsent { get; set; }
        public bool IsInsertedProspectSignature { get; set; }
        public string LifeAimsBalance { get; set; }
        public string NonLifeAimsBalance { get; set; }
        public string TotalAimsBalance { get; set; }
        public bool IsEkycStatus { get; set; }
        public bool IsLeadAccount { get; set; }
        public bool IsCaseId { get; set; }
    }

}
