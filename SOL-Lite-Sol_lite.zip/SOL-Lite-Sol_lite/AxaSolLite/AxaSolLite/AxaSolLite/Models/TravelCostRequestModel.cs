﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class TravelCostRequestModel
    {
        public string Email { get; set; }
        public string Phone { get; set; }
        public List<int> Ages { get; set; }
        public int NoOfPerson { get; set; }
        public int DestinationID { get; set; }
        public int TravelInsuranceType { get; set; }
        public int PolicyType { get; set; }
        public string PlanCode { get; set; }
        public int Duration { get; set; }
        public int Cost { get; set; }
    }
}
