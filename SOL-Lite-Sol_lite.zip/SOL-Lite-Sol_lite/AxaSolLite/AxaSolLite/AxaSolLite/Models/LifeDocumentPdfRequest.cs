﻿using AxaSolLite.Models.CustomerOnboardingCreateCase;
using System;
using System.Collections.Generic;

namespace AxaSolLite.Models
{
    public class LifeDocumentPdfRequest
    {
        public Prospect Customer { get; set; }
        public Agent LoggedAgent { get; set; }
        public FileVariable Signature { get; set; }
        public ProposalQuestionnaire ProposalQuestionnaire { get; set; }
        public LifeSummaryRequest LifeSummaryRequest { get; set; }
        public NMQPdfRequest NMQPdfRequest { get; set; }
    }

    public class NMQPdfRequest
    {        
        public string Height { get; set; }
        public string Weight { get; set; }
        public bool IsQuestionOne { get; set; }
        public bool IsQuestionTwo { get; set; }
        public bool IsQuestionThree { get; set; }
        public bool IsQuestionFour { get; set; }
        public bool IsQuestionFive { get; set; }
        public bool IsQuestionSix { get; set; }
        public bool IsQuestionSeven { get; set; }
        public bool IsQuestionEight { get; set; }
        public bool IsQuestionNine { get; set; }
        public bool IsQuestionTen { get; set; }
        public bool IsQuestionEleven { get; set; }
        public bool IsQuestionTwelve { get; set; }
        public bool IsQuestionThirteen { get; set; }
        public bool IsQuestionForteen { get; set; }
        public bool IsQuestionFifteen { get; set; }
        public bool IsQuestionSixteen { get; set; }
        public bool IsQuestionSeventeen { get; set; }
        public string ExtraDetails { get; set; }
        public int NoOfChildren { get; set; }
        public DateTime ExpectedDeliveryDate { get; set; }
    }

    public class LifeSummaryRequest
    {
        public string PolicyType { get; set; }
        public int PolicyTerm { get; set; }
        public decimal SumAssured { get; set; }
        public decimal TotalPremium { get; set; }
        public string PaymentFrequency { get; set; }
        public string BankName { get; set; }
        public string AccountNumber { get; set; }
        public string BVN { get; set; }
        public string DynamicColumnName1 { get; set; }
        public string DynamicColumnName2 { get; set; }
        public string DynamicColumnValue1 { get; set; }
        public string DynamicColumnValue2 { get; set; }
        public List<BeneficiaryDetails> BeneficiaryList { get; set; }
    }
    
}
