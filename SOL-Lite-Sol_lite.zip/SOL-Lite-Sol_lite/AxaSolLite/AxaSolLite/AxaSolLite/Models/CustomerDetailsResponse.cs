﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class CustomerDetailsReponse
    {
        public bool IsSuccessful { get; set; }
        public Res Result { get; set; }
    }
    public class Res
    {
        public decimal AcctBalance { get; set; }
        public int Nationality { get; set; }
        public int? Gender { get; set; }
        public List<Policies> Policies { get; set; }
        public string CustomerNumber { get; set; }
        public string CustomerName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public string CustomerAddress { get; set; }
    }
    public class Policies
    {
        public string PolicyId { get; set; }
        public string CustomerNumber { get; set; }
        public string PolicyKey { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int PolClassCode { get; set; }
        public string PolClassName { get; set; }
        public int PolTypeCode { get; set; }
        public string PolTypeName { get; set; }
        public int PolYear { get; set; }
        public int UnderWritingYear { get; set; }
        public DateTime? RegistrationDate { get; set; }
        public int PolStatus { get; set; }
    }
}
