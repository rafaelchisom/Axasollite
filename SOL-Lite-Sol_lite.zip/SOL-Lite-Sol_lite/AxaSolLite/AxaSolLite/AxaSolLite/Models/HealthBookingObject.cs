﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public partial class HealthBookingObject
    {
        [JsonProperty("Ownership")]
        public long Ownership { get; set; }

        [JsonProperty("PlanPrice")]
        public double PlanPrice { get; set; }

        [JsonProperty("HealthPlan")]
        public string HealthPlan { get; set; }

        [JsonProperty("CoverDuration")]
        public long CoverDuration { get; set; }

        [JsonProperty("TransactionRef")]
        public string TransactionRef { get; set; }

        [JsonProperty("HealthCustomer")]
        public HealthCustomer HealthCustomer { get; set; }

        [JsonProperty("SponsorInfo")]
        public SponsorInfo SponsorInfo { get; set; }

        [JsonProperty("BeneficiaryInfo")]
        public List<BeneficiaryInfo> BeneficiaryInfo { get; set; }
    }

    public partial class BeneficiaryInfo
    {
        [JsonProperty("Surname")]
        public string Surname { get; set; }

        [JsonProperty("Othernames")]
        public string Othernames { get; set; }

        [JsonProperty("Email")]
        public string Email { get; set; }

        [JsonProperty("MobileNo")]
        public string MobileNo { get; set; }

        [JsonProperty("Gender")]
        public string Gender { get; set; }

        [JsonProperty("Address")]
        public string Address { get; set; }

        [JsonProperty("StateOfResidence")]
        public string StateOfResidence { get; set; }

        [JsonProperty("Town")]
        public string Town { get; set; }

        [JsonProperty("BeneficiaryRelationship")]
        public string BeneficiaryRelationship { get; set; }

        [JsonProperty("HasPreExistingConditions")]
        public string HasPreExistingConditions { get; set; }

        [JsonProperty("PreExistingConditions")]
        public string PreExistingConditions { get; set; }

        [JsonProperty("BeneficiaryHospitalLocation")]
        public string BeneficiaryHospitalLocation { get; set; }

        [JsonProperty("Hospital")]
        public string Hospital { get; set; }

        [JsonProperty("DOB")]
        public DateTimeOffset Dob { get; set; }

        [JsonProperty("CoverDuration")]
        public long CoverDuration { get; set; }

        [JsonProperty("Genotype")]
        public string Genotype { get; set; }
    }

    public partial class HealthCustomer
    {
        [JsonProperty("Surname")]
        public string Surname { get; set; }

        [JsonProperty("Othernames")]
        public string Othernames { get; set; }

        [JsonProperty("Email")]
        public string Email { get; set; }

        [JsonProperty("MobileNo")]
        public string MobileNo { get; set; }

        [JsonProperty("DOB")]
        public DateTimeOffset Dob { get; set; }

        [JsonProperty("Gender")]
        public string Gender { get; set; }

        [JsonProperty("Address")]
        public string Address { get; set; }

        [JsonProperty("StateOfResidence")]
        public string StateOfResidence { get; set; }

        [JsonProperty("Town")]
        public string Town { get; set; }

        [JsonProperty("Source")]
        public string Source { get; set; }

        [JsonProperty("Genotype")]
        public string Genotype { get; set; }

        [JsonProperty("NoofBeneficiaries")]
        public long NoofBeneficiaries { get; set; }

        [JsonProperty("HospitalLocation")]
        public string HospitalLocation { get; set; }

        [JsonProperty("Hospital")]
        public string Hospital { get; set; }

        [JsonProperty("HasPreExistingConditions")]
        public bool HasPreExistingConditions { get; set; }

        [JsonProperty("PreExistingConditions")]
        public string PreExistingConditions { get; set; }

        [JsonProperty("DatePaymentMade")]
        public DateTimeOffset DatePaymentMade { get; set; }

        [JsonProperty("UploadedFile")]
        public string UploadedFile { get; set; }

        [JsonProperty("Hash")]
        public string Hash { get; set; }
    }

    public partial class SponsorInfo
    {
        [JsonProperty("Surname")]
        public string Surname { get; set; }

        [JsonProperty("Othernames")]
        public string Othernames { get; set; }

        [JsonProperty("Email")]
        public string Email { get; set; }

        [JsonProperty("MobileNo")]
        public string MobileNo { get; set; }

        [JsonProperty("Gender")]
        public string Gender { get; set; }

        [JsonProperty("Address")]
        public string Address { get; set; }

        [JsonProperty("DOB")]
        public DateTimeOffset Dob { get; set; }

        [JsonProperty("UploadedFile")]
        public string UploadedFile { get; set; }
    }

    public class HealthBookingResponse
    {
        [JsonProperty("IsSuccessful")]
        public bool IsSuccessful { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("ReturnedObject")]
        public HealthReturnedObject ReturnedObject { get; set; }

        [JsonProperty("ReturnCode")]
        public object ReturnCode { get; set; }
    }

    public class HealthReturnedObject
    {
        [JsonProperty("TransactionReference")]
        public string TransactionReference { get; set; }

        public string EnrolleeID { get; set; }
    }
}
    
