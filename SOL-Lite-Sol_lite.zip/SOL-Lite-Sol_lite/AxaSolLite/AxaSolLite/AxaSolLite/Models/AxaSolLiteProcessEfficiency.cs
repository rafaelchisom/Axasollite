﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class AxaSolLiteProcessEfficiency
    {
        public string AgentFullName { get; set; }
        public string AgentCode { get; set; }
        public string Complaint { get; set; }
        public bool IsResolved { get; set; }

    }
}
