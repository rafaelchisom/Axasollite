﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class TravelCertRequest
    {
        public string PolicyHolder { get; set; }
        public string Telephone { get; set; }
        public string PassportNo { get; set; }
        public string City { get; set; }
        public string PolicyNo { get; set; }
        public string EmailAddress { get; set; }
        public string CustomerNumber { get; set; }

        public string SPTO { get; set; }
        public string PremiumPerinsured { get; set; }
        public string NoOfPassengers { get; set; }
        public string EffectiveFrom { get; set; }
        public string Expiry { get; set; }

        public string PolicyPeriod { get; set; }
        public string PaymentMethod { get; set; }
        public string NetPremium { get; set; }
        public string Surcharge { get; set; }
        public string Taxes { get; set; }

        public string Total { get; set; }
        public string DestinationArea { get; set; }
        public string CountryOfOrigin { get; set; }
        public string Product { get; set; }
        public string AgentCode { get; set; }
        public string AgentEmail { get; set; }

        public string Name { get; set; }
        public string Passport { get; set; }
        public string DateOfBirth { get; set; }
        public string IssuedBy { get; set; }
        public string SignedDate { get; set; }

        public bool IsGroup { get; set; }

        //group
        public string GPolicyHolder { get; set; }

        public string GTelephone { get; set; }
        public string GPassportNo { get; set; }
        public string GPolicyNo { get; set; }
        public string GSPTO { get; set; }

        public string GNoOfPassengers { get; set; }
        public string GEffectiveFrom { get; set; }
        public string GExpiry { get; set; }
        public string GPolicyPeriod { get; set; }
        public string GPaymentMethod { get; set; }

        public string GDestinationArea { get; set; }
        public string GProduct { get; set; }
        public string CertLocation { get; set; }
        public List<Travelers> Travellers { get; set; }

        public string GSignedDate { get; set; }
    }

    public class Travelers
    {
        public string GNames { get; set; }
        public string GPassports { get; set; }
        public string GDateOfBirths { get; set; }
    }
}
