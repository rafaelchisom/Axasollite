﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class CustomerUpdateResponse
    {
        [JsonProperty("app_uid")]
        public object AppUid { get; set; }

        [JsonProperty("app_number")]
        public object AppNumber { get; set; }

        [JsonProperty("ActionMessage")]
        public string ActionMessage { get; set; }

        [JsonProperty("StatusMessage")]
        public object StatusMessage { get; set; }

        [JsonProperty("ActionStatus")]
        public bool ActionStatus { get; set; }

        [JsonProperty("error")]
        public object Error { get; set; }
    }

    public partial class Error
    {
        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("error_description")]
        public string ErrorDescription { get; set; }
    }
}
