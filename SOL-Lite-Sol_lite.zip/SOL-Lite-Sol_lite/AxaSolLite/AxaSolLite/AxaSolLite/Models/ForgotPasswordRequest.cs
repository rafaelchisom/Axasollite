﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class ForgotPasswordRequest
    {
        public string OTP { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
