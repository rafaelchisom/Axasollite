﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
  public  class LeadGeneratorRequest
    {
        [JsonProperty("Title")]
        public string Title { get; set; }
        [JsonProperty("MiddleName")]
        public string MiddleName { get; set; }
        [JsonProperty("LastName")]
        public string LastName { get; set; }
        [JsonProperty("FirstName")]
        public string FirstName { get; set; }
        [JsonProperty("EmailAddress")]
        public string EmailAddress { get; set; }
        [JsonProperty("PhoneNumber")]
        public string PhoneNumber { get; set; }
        [JsonProperty("DateOfBirth")]
        public string DateOfBirth { get; set; }
        [JsonProperty("Gender")]
        public string Gender { get; set; }
        [JsonProperty("ResidenceAddress")]
        public string ResidenceAddress { get; set; }
    }
}
