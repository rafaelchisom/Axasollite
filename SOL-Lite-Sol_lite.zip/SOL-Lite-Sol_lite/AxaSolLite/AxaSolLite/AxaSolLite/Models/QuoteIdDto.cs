﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class QuoteIdDto
    {
        public Guid? Id { get; set; }
        public string QuoteId { get; set; }
        public string Surname { get; set; }
        public string OtherNames { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string PolicyType { get; set; }
        public string AgentCode { get; set; }
        public string Amount { get; set; }
        public string PolicyCode { get; set; }
        public string PolicyClass { get; set; }
        public bool IsSent { get; set; }
        public DateTime? AddedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? IsMyAXASol { get; set; }
    }
}
