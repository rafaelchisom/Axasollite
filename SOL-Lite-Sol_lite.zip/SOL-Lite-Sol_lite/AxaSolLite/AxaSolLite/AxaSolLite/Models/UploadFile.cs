﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class UploadFile : BaseModel
    {
        public UploadFile()
        {
            Id = Guid.NewGuid();
        }
        public string FileLabel { get; set; }
        public byte[] Content { get; set; }
        public string DocumentCategory { get; set; }
    }
}
