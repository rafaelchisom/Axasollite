﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;

namespace AxaSolLite.Models
{
    public class SearchCustomerResponse
    {
        [JsonProperty("IsSuccessful")]
        public bool IsSuccessful { get; set; }


        [JsonProperty("Result")]
        public List<Result> Response { get; set; }
    }
    public class Result : BaseModel, INotifyPropertyChanged
    {
        private bool _isToggled;
        public string CustomerNumber { get; set; }
        public string CustomerName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public string CustomerAddress { get; set; }

        public bool IsToggled
        {
            get { return _isToggled; }
            set
            {
                _isToggled = value;
                OnPropertyChanged();
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }
}
