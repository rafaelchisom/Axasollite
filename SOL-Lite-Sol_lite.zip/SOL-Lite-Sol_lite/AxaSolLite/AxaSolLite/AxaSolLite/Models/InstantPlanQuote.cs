﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class InstantPlanQuote
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("premium")]
        public long Premium { get; set; }

        [JsonProperty("premiumFormatted")]
        public string PremiumFormatted { get; set; }

        [JsonProperty("accidentBenefit")]
        public long AccidentBenefit { get; set; }

        [JsonProperty("sumAssured")]
        public long SumAssured { get; set; }

        [JsonProperty("status")]
        public bool Status { get; set; }
    }
}
