﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Globalization;

namespace AxaSolLite.Models
{
    public partial class CustomerOnboardingRequest
    {
        [JsonProperty("Title")]
        public long Title { get; set; }

        [JsonProperty("MiddleName")]
        public string MiddleName { get; set; }

        [JsonProperty("ResidenceAddress")]
        public string ResidenceAddress { get; set; }

        [JsonProperty("City")]
        public string City { get; set; }

        [JsonProperty("Gender")]
        public long Gender { get; set; }

        [JsonProperty("Fax")]
        public string Fax { get; set; }

        [JsonProperty("StateOfOrigin")]
        public long StateOfOrigin { get; set; }

        [JsonProperty("Nationality")]
        public long Nationality { get; set; }

        [JsonProperty("Occupation")]
        public string Occupation { get; set; }

        [JsonProperty("LastTransDate")]
        public DateTimeOffset LastTransDate { get; set; }

        [JsonProperty("LastTransTime")]
        public long LastTransTime { get; set; }

        [JsonProperty("Salary")]
        public long Salary { get; set; }

        [JsonProperty("BankBranchTrfTo")]
        public long BankBranchTrfTo { get; set; }

        [JsonProperty("IbankNo")]
        public string IbankNo { get; set; }

        [JsonProperty("Religion")]
        public long Religion { get; set; }

        [JsonProperty("Through")]
        public long Through { get; set; }

        [JsonProperty("Colecter")]
        public long Colecter { get; set; }

        [JsonProperty("AcmProf")]
        public long AcmProf { get; set; }

        [JsonProperty("TransRef")]
        public string TransRef { get; set; }

        [JsonProperty("Source")]
        public long Source { get; set; }

        [JsonProperty("ExceptionExist")]
        public byte ExceptionExist { get; set; }

        [JsonProperty("ChannelCode")]
        public string ChannelCode { get; set; }

        [JsonProperty("ClientCode")]
        public string ClientCode { get; set; }

        [JsonProperty("LastName")]
        public string LastName { get; set; }

        [JsonProperty("FirstName")]
        public string FirstName { get; set; }

        [JsonProperty("DateOfBirth")]
        public DateTimeOffset DateOfBirth { get; set; }

        [JsonProperty("EmailAddress")]
        public string EmailAddress { get; set; }

        [JsonProperty("PhoneNumber")]
        public string PhoneNumber { get; set; }

    }

    public partial class CustomerOnboardingRequest
    {
        public static CustomerOnboardingRequest FromJson(string json) => JsonConvert.DeserializeObject<CustomerOnboardingRequest>(json, Converter.Settings);
    }

    public static class Serialize
    {
        public static string ToJson(this CustomerOnboardingRequest self) => JsonConvert.SerializeObject(self, Converter.Settings);
    }

    internal static class Converter
    {
        public static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
        {
            MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
            DateParseHandling = DateParseHandling.None,
            Converters =
            {
                new IsoDateTimeConverter { DateTimeStyles = DateTimeStyles.AssumeUniversal }
            },
        };
    }
}
