﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class TravelQuotesResponse
    {
        [JsonProperty("content")]
        public Content Content { get; set; }

        [JsonProperty("pagination")]
        public object Pagination { get; set; }

        [JsonProperty("success")]
        public bool Success { get; set; }

        [JsonProperty("type")]
        public int Type { get; set; }

        [JsonProperty("title")]
        public object Title { get; set; }

        [JsonProperty("status")]
        public object Status { get; set; }

        [JsonProperty("detail")]
        public object Detail { get; set; }

        [JsonProperty("instance")]
        public object Instance { get; set; }

        [JsonProperty("validationErrors")]
        public object ValidationErrors { get; set; }

        [JsonProperty("message")]
        public object Message { get; set; }

        [JsonProperty("code")]
        public object Code { get; set; }

        [JsonProperty("path")]
        public object Path { get; set; }
    }

    public partial class Content
    {
        [JsonProperty("travelPlanCost")]
        public TravelPlanCost[] TravelPlanCost { get; set; }

        [JsonProperty("benefitName")]
        public string[] BenefitName { get; set; }

        [JsonProperty("numberOfPersons")]
        public int NumberOfPersons { get; set; }
    }

    public partial class TravelPlanCost
    {
        [JsonProperty("planName")]
        public string PlanName { get; set; }

        public int PlanId { get; set; }

        [JsonProperty("planCost")]
        public double PlanCost { get; set; }

        [JsonProperty("planCode")]
        public string PlanCode { get; set; }

        [JsonProperty("geoCoverageArea")]
        public string GeoCoverageArea { get; set; }

        [JsonProperty("benefitValue")]
        public string[] BenefitValue { get; set; }

        [JsonProperty("program")]
        public int Program { get; set; }

        [JsonProperty("area")]
        public int Area { get; set; }

        [JsonProperty("uid")]
        public Guid Uid { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }
    }
}
