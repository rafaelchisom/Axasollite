﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class GenBizBranch
    {
        public int BranchCode { get; set; }
        public string BranchName { get; set; }
    }
}
