﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class BankDTO
    {
        [JsonProperty("idField")]
        public string IdField { get; set; }

        [JsonProperty("nameField")]
        public string NameField { get; set; }

        [JsonProperty("sortCodeField")]
        public string SortCodeField { get; set; }
    }
}
