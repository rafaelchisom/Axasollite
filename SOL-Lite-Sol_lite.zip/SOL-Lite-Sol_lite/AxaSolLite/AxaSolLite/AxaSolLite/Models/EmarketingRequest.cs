﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class EmarketingRequest
    {
        public string ProspectName { get; set; }
        public string AgentName { get; set; }
        public string ProductName { get; set; }
        public string DateCreated { get; set; }
        public string AgentEmail { get; set; }
        public string AgentPhoneNumber { get; set; }
        public string EmailAddress { get; set; }
    }
}
