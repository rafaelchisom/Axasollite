﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class FeedbackRequest
    {
        public string AgentEmailAddress { get; set; }
        public string AgentCode { get; set; }
        public string Body { get; set; }

    }
}
