﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class ApprovalLogRequest
    {
        public string PolicyDetails { get; set; }
        public string CaseId { get; set; }
        public string AgentCode { get; set; }
        public string TMAgentCode { get; set; }
        public string AMMAgentCode { get; set; }

        public string CreatedBy { get; set; }
        public bool IsApproved { get; set; }
        public bool IsRejected { get; set; }
    }

    public class UpdateApprovaLog
    {

        public bool IsApproved { get; set; }
        public bool IsRejected { get; set; }
        public string ModifiedBy { get; set; }
        public string Comment { get; set; }
        public string CaseId { get; set; }


    }
    public class ApprovalLog
    {
        public string PolicyDetails { get; set; }
        public string CaseId { get; set; }
        public string AgentCode { get; set; }
        public string TMAgentCode { get; set; }
        public string AMMAgentCode { get; set; }

        public string CreatedBy { get; set; }
        public bool IsApproved { get; set; }
        public bool IsRejected { get; set; }
        public string ModifiedBy { get; set; }
        public string Comment { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime DateModified { get; set; }


    }
}
