﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class RenewalBookingResponse
    {
        public bool IsSuccessful { get; set; }
        public string Message { get; set; }
        public string PolicyId { get; set; }
        public string PolicyKey { get; set; }
        public string PolicyNo { get; set; }
        public string CustomerNo { get; set; }
        public string CustomerName { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public decimal SumInsured { get; set; }
        public decimal Premium { get; set; }
    }
}
