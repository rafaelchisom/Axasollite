﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class SelectedHospitals
    {
        public static string SelectedHospitalName { get; set; }
        public static List<string> HospitalName { get; set; }
    }
}
