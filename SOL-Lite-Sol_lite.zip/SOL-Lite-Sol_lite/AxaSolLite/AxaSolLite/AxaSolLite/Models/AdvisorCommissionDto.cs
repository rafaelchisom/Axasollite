﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class AdvisorCommissionDto
    {

        public string Username { get; set; }


        public string MonthlyBudget { get; set; }


        public string MonthlyActual { get; set; }


        public string PercentageAchieved { get; set; }


        public string IndividualLifeInflow { get; set; }


        public string IndividualLifeCommission { get; set; }


        public long IndividualLifeBonus { get; set; }


        public string GroupLifeInflow { get; set; }


        public string GroupLifeCommission { get; set; }


        public long GroupLifeBonus { get; set; }


        public string LifeInflow { get; set; }


        public string LifeCommission { get; set; }


        public long LifeBonus { get; set; }


        public string Total { get; set; }
    }
}
