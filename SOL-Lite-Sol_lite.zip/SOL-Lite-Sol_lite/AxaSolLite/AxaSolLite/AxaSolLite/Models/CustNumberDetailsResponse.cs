﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class CustNumberDetailsResponse
    {
        [JsonProperty("customerNo")]
        public string CustomerNo { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("phoneNumber")]
        public string PhoneNumber { get; set; }

        [JsonProperty("typeCode")]

        public string TypeCode { get; set; }

        [JsonProperty("customerType")]
        public string CustomerType { get; set; }

        [JsonProperty("mobileNumber")]
        public string MobileNumber { get; set; }

        [JsonProperty("address")]
        public string Address { get; set; }

        [JsonProperty("policies")]
        public List<Policy> Policies { get; set; }
    }

    public partial class Policy
    {
        [JsonProperty("policyID")]
        public string PolicyId { get; set; }

        [JsonProperty("policyKey")]
        public string PolicyKey { get; set; }

        [JsonProperty("customerNo")]
        public string CustomerNo { get; set; }

        [JsonProperty("startDate")]
        public string StartDate { get; set; }

        [JsonProperty("endDate")]
        public string EndDate { get; set; }

        [JsonProperty("product")]
        public string Product { get; set; }

        [JsonProperty("branch")]

        public string Branch { get; set; }

        [JsonProperty("office")]

        public string Office { get; set; }

        [JsonProperty("sbu")]

        public string Sbu { get; set; }

        [JsonProperty("businessType")]

        public string BusinessType { get; set; }

        [JsonProperty("sumInsured")]
        public double SumInsured { get; set; }

        [JsonProperty("premium")]
        public double Premium { get; set; }

        [JsonProperty("policyClass")]
        public int PolicyClass { get; set; }

        [JsonProperty("policyType")]
        public long PolicyType { get; set; }

        [JsonProperty("policyYear")]
        public int PolicyYear { get; set; }

        [JsonProperty("policyMonth")]
        public int PolicyMonth { get; set; }

        [JsonProperty("policyNo")]
        public int PolicyNo { get; set; }

        [JsonProperty("transactionType")]
        public int TransactionType { get; set; }
    }
}
