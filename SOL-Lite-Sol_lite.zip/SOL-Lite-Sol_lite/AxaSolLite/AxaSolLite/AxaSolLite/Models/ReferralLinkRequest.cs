﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
  public  class ReferralLinkRequest
    {
        
        public string EmailAddress { get; set; }
        public string CustomerNumber { get; set; }
        public string FullName { get; set; }
        public string Plan { get; set; }
        public string ReferralLink { get; set; }
    
}
}
