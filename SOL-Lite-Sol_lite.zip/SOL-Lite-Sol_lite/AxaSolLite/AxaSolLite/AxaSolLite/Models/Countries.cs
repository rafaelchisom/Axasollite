﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public  class Countries
    {
        public string Country { get; set; }
        public int CountryCode { get; set; }
    }
}
