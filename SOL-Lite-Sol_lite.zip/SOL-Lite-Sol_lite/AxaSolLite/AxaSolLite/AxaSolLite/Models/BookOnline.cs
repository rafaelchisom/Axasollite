﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class BookOnline : BaseModel
    {
        public BookOnline()
        {
            Id = Guid.NewGuid();
        }
        public Guid ProductPlanId { get; set; }
        public string AgentName { get; set; }
        public string IntiationDate { get; set; }
        public string EmailAddress { get; set; }
        public string SBU { get; set; }
        public string AgentCode { get; set; }
        public string TransactionType { get; set; }
        public string CustomerNo { get; set; }
        public string DSA { get; set; }
        public string DSACode { get; set; }
        public string PolicyClass { get; set; }
        public int PolicyTerm { get; set; }
        public decimal SumAssured { get; set; }
        public int AgeBeginPolicy { get; set; }
        public int AgeEndPolicy { get; set; }
        public double MaxMaturityValue { get; set; }
        public double MinMaturityValue { get; set; }
        public string PaymentFrequency { get; set; }
        public decimal AnnualPremium { get; set; }
        public decimal TotalPremium { get; set; }
        public decimal Amount { get; set; }
        public decimal Contribution { get; set; }
        public decimal LifeCoverValue { get; set; }
        public string PolicyStartDate { get; set; }
        public string PolicyEndDate { get; set; }
        public string PaymentDate { get; set; }
        public string AmbitionReason { get; set; }
        public decimal ExpectedInterest { get; set; }
        public decimal ExpectedFuture { get; set; }
        public List<BeneficiaryDetails> BeneficiaryList { get; set; }
        public string BankName { get; set; }
        public string BankAccountNumber { get; set; }
        public string BVN { get; set; }
        public string Assurer { get; set; }
        public string ForceLife { get; set; }
        public byte[] NewSignaturePicture { get; set; }
        public bool IsExisitingPolicy { get; set; }
        public bool IsProposalDeclined { get; set; }
        public string Height { get; set; }
        public string Weight { get; set; }
        public bool IsQuestionOne { get; set; }
        public bool IsQuestionTwo { get; set; }
        public bool IsQuestionThree { get; set; }
        public bool IsQuestionFour { get; set; }
        public bool IsQuestionFive { get; set; }
        public bool IsQuestionSix { get; set; }
        public bool IsQuestionSeven { get; set; }
        public bool IsQuestionEight { get; set; }
        public bool IsQuestionNine { get; set; }
        public bool IsQuestionTen { get; set; }
        public bool IsQuestionEleven { get; set; }
        public bool IsQuestionTwelve { get; set; }
        public bool IsQuestionThirteen { get; set; }
        public bool IsQuestionForteen { get; set; }
        public bool IsQuestionFifteen { get; set; }
        public bool IsQuestionSixteen { get; set; }
        public bool IsQuestionSeventeen { get; set; }
        public string ExtraDetails { get; set; }
        public int NoOfChildren { get; set; }
        public DateTime ExpectedDeliveryDate { get; set; }
        public bool AnyYesNMQ { get; set; }
        public int BranchCode { get; set; }
        public bool IsExtendedCover { get; set; }
        public bool IsPermanentDisability { get; set; }
        public string ProjectionSheetDocument { get; set; }
    }   

    public class BeneficiaryDetails
    {
        public int TitleCode { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName => $" {FirstName} {LastName}";
        public string Type { get; set; }
        public int TypeCode { get; set; }
        public string Relationship { get; set; }
        public int RelationshipCode { get; set; }
        public int Occupation { get; set; }
        public string Address { get; set; }
        public string MaritalStatus { get; set; }
        public int MaritalStatusCode { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime DateOfBirth { get; set; }
        public int Gender { get; set; }
        public bool IsVisible { get; set; }
        public string OccupationName { get; set; }
    }
}
