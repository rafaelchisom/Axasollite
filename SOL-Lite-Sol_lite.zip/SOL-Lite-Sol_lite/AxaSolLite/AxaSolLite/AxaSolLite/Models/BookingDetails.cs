﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class BookingDetails
    {
        public string CustomerNumber { get; set; }
        public string CustomerName { get; set; }
        public string PolicyName { get; set; }
        public string PolicyKey { get; set; }
        public int IsPolicyID { get; set; }
        public int IsCaseID { get; set; }
        public string AgentCode { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}

