﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class ExtraTravellers
    {
        public Guid Id { get; set; }
        public Guid TravelProductId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public string GroupPassportNumber { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string FullName => $"{FirstName} {LastName}";
        public int Age => (DateTime.Today.Year - DateOfBirth.Year);
    }
}
