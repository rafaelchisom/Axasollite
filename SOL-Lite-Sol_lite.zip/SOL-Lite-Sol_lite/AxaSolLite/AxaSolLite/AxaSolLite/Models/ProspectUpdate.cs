﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class ProspectUpdate
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string EmailAddress { get; set; }
        public string NewFirstName { get; set; }
        public string NewLastName { get; set; }
        public int NewTitle { get; set; }
        public DateTime NewDateOfBirth { get; set; }
        public string NewMiddleName { get; set; }
        public string NewPhoneNumber { get; set; }
        public string NewEmail { get; set; }
        public string NewAddress { get; set; }
        public int NewGender { get; set; }
    }
}
