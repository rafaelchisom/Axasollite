﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class MotorTruePriceResponseModel
    {
        [JsonProperty("IsSuccessful")]
        public bool IsSuccessful { get; set; }

        [JsonProperty("Result")]
        public Resultz Result { get; set; }
    }

    public partial class Resultz
    {
        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("data")]
        public Data Data { get; set; }
    }

    public partial class Data
    {
        [JsonProperty("price")]
        public Price Price { get; set; }
    }

    public partial class Price
    {
        [JsonProperty("fair_condition")]
        public double FairCondition { get; set; }

        [JsonProperty("good_condition")]
        public double GoodCondition { get; set; }
    }
}
