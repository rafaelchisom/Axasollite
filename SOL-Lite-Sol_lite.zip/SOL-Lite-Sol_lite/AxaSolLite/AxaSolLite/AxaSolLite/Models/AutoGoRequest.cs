﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class AutoGoRequest
    {
        public int XFR_INFO_MST_MAJ_INS_TYPE { get; set; }


        public int XFR_INFO_MST_POL_TYPE { get; set; }


        public decimal XFR_INFO_ACM_ANN_SALARY { get; set; }


        public int XFR_INFO_CUST_PREV_POLICY_FLAG { get; set; }


        public string XFR_INFO_MST_CUST_NO { get; set; }


        public int XFR_INFO_MST_BRANCH { get; set; }


        public int XFR_INFO_MST_OFFICE { get; set; }


        public string XFR_INFO_MST_AGENT_NO { get; set; }


        public int XFR_INFO_MST_THROUGH { get; set; }


        public int XFR_INFO_MST_UW_YEAR { get; set; }


        public int XFR_INFO_MST_PAY_TYPE { get; set; }


        public DateTime XFR_INFO_MST_INS_ST_DT { get; set; }


        public int XFR_INFO_MST_PERIOD { get; set; }


        public string XFR_INFO_SCO_MO_PLATE_NO { get; set; }


        public string XFR_INFO_SCO_MO_PLATE_COLOUR { get; set; }


        public string XFR_INFO_SCO_MO_MAKE { get; set; }


        public string XFR_INFO_SCO_MO_MODEL { get; set; }


        public string XFR_INFO_SCO_MO_PROD_YEAR { get; set; }


        public long XFR_INFO_SCO_MO_CHAS_CD { get; set; }


        public string XFR_INFO_SCO_MO_ENG_NO { get; set; }


        public string XFR_INFO_SCO_MO_CHAS_NO { get; set; }


        public string XFR_INFO_SCO_MO_REG_PLACE { get; set; }


        public string XFR_INFO_SCO_FEX_RATE { get; set; }


        public string XFR_INFO_SCO_SUM_INSURED { get; set; }


        public DateTime XFR_INFO_SCAN_DATE { get; set; }


        public int XFR_INFO_MST_DOC_NO { get; set; }


        public int XFR_INFO_MST_MIN_INS_TYPE { get; set; }


        public int XFR_INFO_MST_DOC_TYPE { get; set; }

        public string XFR_INFO_BASIC_PREM_RATE { get; set; }
        public bool XFR_INFO_ISPAY_NOW { get; set; }
        public string XFR_INFO_PAY_NOW_TRANS_REF { get; set; }
        public string XFR_INFO_QUOTE_NO { get; set; }
        public string XFR_INFO_MST_SUBJECTS_INSURED { get; set; }
        public bool XFR_INFO_BOOK_FROM_BALANCE { get; set; }

        [JsonProperty("AmountPaid")]
        public decimal AmountPaid { get; set; }

        [JsonProperty("PaymentSource")]
        public string PaymentSource { get; set; }


        public object XFR_INFO_APPLY_NPNC { get; set; }
        public int XFR_INFO_SOURCE_BUISNESS { get; set; }

        [JsonProperty("TransRef")]
        public string TransRef { get; set; }

        [JsonProperty("RequestSource")]
        public string RequestSource { get; set; }
    }
}
