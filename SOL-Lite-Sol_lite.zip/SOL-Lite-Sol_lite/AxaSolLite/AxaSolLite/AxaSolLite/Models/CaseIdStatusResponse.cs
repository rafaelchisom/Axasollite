﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public partial class CaseIdStatusResponse
    {
        [JsonProperty("APP_UID")]
        public string AppUid { get; set; }

        [JsonProperty("APP_TITLE")]
        public string AppTitle { get; set; }

        [JsonProperty("APP_DESCRIPTION")]
        public string AppDescription { get; set; }

        [JsonProperty("APP_NUMBER")]
        public string AppNumber { get; set; }

        [JsonProperty("APP_PARENT")]
        public string AppParent { get; set; }

        [JsonProperty("APP_STATUS")]
        public string AppStatus { get; set; }

        [JsonProperty("APP_STATUS_ID")]
        public long AppStatusId { get; set; }

        [JsonProperty("PRO_UID")]
        public string ProUid { get; set; }

        [JsonProperty("APP_PROC_STATUS")]
        public string AppProcStatus { get; set; }

        [JsonProperty("APP_PROC_CODE")]
        public string AppProcCode { get; set; }

        [JsonProperty("APP_PARALLEL")]
        public string AppParallel { get; set; }

        [JsonProperty("APP_INIT_USER")]
        public string AppInitUser { get; set; }

        [JsonProperty("APP_CUR_USER")]
        public string AppCurUser { get; set; }

        [JsonProperty("APP_CREATE_DATE")]
        public string AppCreateDate { get; set; }

        [JsonProperty("APP_INIT_DATE")]
        public string AppInitDate { get; set; }

        [JsonProperty("APP_FINISH_DATE")]
        public object AppFinishDate { get; set; }

        [JsonProperty("APP_UPDATE_DATE")]
        public string AppUpdateDate { get; set; }

        [JsonProperty("APP_DATA")]
        public AppData AppData { get; set; }

        [JsonProperty("APP_PIN")]
        public string AppPin { get; set; }



        [JsonProperty("APP_DRIVE_FOLDER_UID")]
        public string AppDriveFolderUid { get; set; }

        [JsonProperty("APP_ROUTING_DATA")]
        public string AppRoutingData { get; set; }

        [JsonProperty("STATUS")]
        public string Status { get; set; }

        [JsonProperty("TITLE")]
        public string Title { get; set; }

        [JsonProperty("DESCRIPTION")]
        public string Description { get; set; }

        [JsonProperty("CREATOR")]
        public string Creator { get; set; }

        [JsonProperty("CREATE_DATE")]
        public string CreateDate { get; set; }

        [JsonProperty("UPDATE_DATE")]
        public string UpdateDate { get; set; }
    }

    public partial class AppData
    {


        [JsonProperty("approveRejectOption")]

        public string ApproveRejectOption { get; set; }

        [JsonProperty("approveRejectOption_label")]

        public string ApproveRejectOptionLabel { get; set; }

        [JsonProperty("is_approved")]

        public string is_approved { get; set; }

        [JsonProperty("is_approved_label")]

        public string is_approved_label { get; set; }




    }
}

