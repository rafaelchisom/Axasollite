﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class ProductLogDataRequest
    {
        public string TableName { get; set; }
        public string ParentId { get; set; }
        public string SerializedData { get; set; }
        public string ProductLogId { get; set; }
    }



    public class UpdateProductLogDataRequest
    {
        public string ProductLogId { get; set; }
        public string SerializedData { get; set; }
    }
}
