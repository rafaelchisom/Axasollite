﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class RefreshButtonRequest
    {
        [JsonProperty("QuoteId")]
        public string QuoteId { get; set; }
    }
}
