﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class PersonalAccidentBookingDTO
    {
        [JsonProperty("XFR_INFO_MST_MAJ_INS_TYPE")]
        public long XfrInfoMstMajInsType { get; set; }

        [JsonProperty("XFR_INFO_MST_MIN_INS_TYPE")]
        public long XfrInfoMstMinInsType { get; set; }

        [JsonProperty("XFR_INFO_MST_POL_TYPE")]
        public long XfrInfoMstPolType { get; set; }

        [JsonProperty("XFR_INFO_MST_BRANCH")]
        public long XfrInfoMstBranch { get; set; }

        [JsonProperty("XFR_INFO_MST_OFFICE")]
        public long XfrInfoMstOffice { get; set; }

        [JsonProperty("XFR_INFO_MST_AGENT_NO")]
        public string XfrInfoMstAgentNo { get; set; }

        [JsonProperty("XFR_INFO_MST_PAY_TYPE")]
        public long XfrInfoMstPayType { get; set; }

        [JsonProperty("XFR_INFO_MST_PERIOD")]
        public long XfrInfoMstPeriod { get; set; }

        [JsonProperty("XFR_INFO_MST_CUST_NO")]
        public string XfrInfoMstCustNo { get; set; }

        [JsonProperty("XFR_INFO_CUST_PREV_POLICY_FLAG")]
        public long XfrInfoCustPrevPolicyFlag { get; set; }

        [JsonProperty("XFR_INFO_MST_UW_YEAR")]
        public long XfrInfoMstUwYear { get; set; }

        [JsonProperty("XFR_INFO_MST_REG_DT")]
        public DateTimeOffset XfrInfoMstRegDt { get; set; }

        [JsonProperty("XFR_INFO_MST_INS_ST_DT")]
        public DateTimeOffset XfrInfoMstInsStDt { get; set; }

        [JsonProperty("XFR_INFO_MST_THROUGH")]
        public long XfrInfoMstThrough { get; set; }

        [JsonProperty("XFR_INFO_MST_SOURCE")]
        public long XfrInfoMstSource { get; set; }

        [JsonProperty("XFR_INFO_NATIONAML_NO")]
        public string XfrInfoNationamlNo { get; set; }

        [JsonProperty("XFR_INFO_MST_SUBJECTS_INSURED")]
        public string XfrInfoMstSubjectsInsured { get; set; }

        [JsonProperty("XFR_INFO_MST_TRN_TYPE")]
        public long XfrInfoMstTrnType { get; set; }

        [JsonProperty("XFR_INFO_MST_REN_POL_TYPE")]
        public long XfrInfoMstRenPolType { get; set; }

        [JsonProperty("XFR_INFO_MST_LONG_TERM_FLAG")]
        public long XfrInfoMstLongTermFlag { get; set; }

        [JsonProperty("XFR_INFO_MST_DOC_NO")]
        public long XfrInfoMstDocNo { get; set; }

        [JsonProperty("XFR_INFO_MST_DOC_TYPE")]
        public long XfrInfoMstDocType { get; set; }

        [JsonProperty("XFR_INFO_SCO_FEX_RATE")]
        public long XfrInfoScoFexRate { get; set; }

        [JsonProperty("XFR_INFO_ISREFERRAL_POLICY")]
        public string XfrInfoIsreferralPolicy { get; set; }

        [JsonProperty("XFR_INFO_QUOTE_NO")]
        public string XfrInfoQuoteNo { get; set; }

        [JsonProperty("AmountPaid")]
        public long AmountPaid { get; set; }

        [JsonProperty("PaymentSource")]
        public string PaymentSource { get; set; }

        [JsonProperty("TransRef")]
        public string TransRef { get; set; }

        [JsonProperty("RequestSource")]
        public string RequestSource { get; set; }

        [JsonProperty("XFR_INFO_ISPAY_NOW")]
        public bool XfrInfoIspayNow { get; set; }

        [JsonProperty("XFR_INFO_PAY_NOW_TRANS_REF")]
        public string XfrInfoPayNowTransRef { get; set; }

        public bool XFR_INFO_BOOK_FROM_BALANCE { get; set; }

        [JsonProperty("SubjectCover")]
        public List<SubjectCover> SubjectCover { get; set; }
    }

    public partial class SubjectCover
    {
        [JsonProperty("XFR_INFO_SCO_SUBJECT_DESC")]
        public string XfrInfoScoSubjectDesc { get; set; }

        [JsonProperty("XFR_INFO_SCO_SUBJECT_DESC2")]
        public string XfrInfoScoSubjectDesc2 { get; set; }

        [JsonProperty("XFR_INFO_SCO_SUBJECT_DESC3")]
        public string XfrInfoScoSubjectDesc3 { get; set; }

        [JsonProperty("XFR_INFO_SCO_SUBJECT_DESC4")]
        public string XfrInfoScoSubjectDesc4 { get; set; }

        [JsonProperty("XFR_INFO_SCO_REMARKS")]
        public string XfrInfoScoRemarks { get; set; }

        [JsonProperty("XFR_INFO_SCO_STAT_CD")]
        public long XfrInfoScoStatCd { get; set; }

        [JsonProperty("XFR_INFO_SCO_LOC_CD")]
        public long XfrInfoScoLocCd { get; set; }

        [JsonProperty("XFR_INFO_SCO_AREA_CD")]
        public long XfrInfoScoAreaCd { get; set; }

        [JsonProperty("XFR_INFO_SCO_SUBJECT_TYPE")]
        public long XfrInfoScoSubjectType { get; set; }

        [JsonProperty("XFR_INFO_SCO_SUM_INSURED")]
        public long XfrInfoScoSumInsured { get; set; }

        [JsonProperty("XFR_INFO_SCO_DEATH_SUM_INSURED")]
        public long XfrInfoScoDeathSumInsured { get; set; }

        [JsonProperty("XFR_INFO_SCO_MEDEX_SUM_INSURED")]
        public long XfrInfoScoMedexSumInsured { get; set; }

        [JsonProperty("XFR_INFO_SCO_PERM_DISAB_SUM_INSURED")]
        public long XfrInfoScoPermDisabSumInsured { get; set; }

        [JsonProperty("XFR_INFO_SCO_TTD_SUM_INSURED")]
        public long XfrInfoScoTtdSumInsured { get; set; }

        [JsonProperty("DiscountRate")]
        public long DiscountRate { get; set; }

        [JsonProperty("Rates")]
        public List<Rate> Rates { get; set; }
    }

    public partial class Rate
    {
        [JsonProperty("RateCode")]
        public string RateCode { get; set; }

        [JsonProperty("NumberOfMonths")]
        public long NumberOfMonths { get; set; }
    }
}
