﻿using System.Collections;

namespace AxaSolLite.Models.CustomerOnboardingCreateCase
{
    public class FileVariable 
    {
        public string FileName { get; set; }
        public string ContentType { get; set; }
        public string FileContent { get; set; }
        public string Extension { get; set; }
        public string FieldName { get; set; }
    }

    public class FileVariable2
    {
        public string appDocUid { get; set; }
        public string name { get; set; }
        public string version { get; set; }
    }
}
