﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Models.CustomerOnboardingCreateCase
{
    public class CaseVariable2
    {
        public string VariableName { get; set; }
        public List<CaseVariable>[] VariableValues { get; set; }
    }
}
