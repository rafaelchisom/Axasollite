﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Models.CustomerOnboardingCreateCase
{
    public class CreatePMCaseResponse
    {
        public string app_uid { get; set; }
        public string app_number { get; set; }
        public ErrorReport error { get; set; }
    }

    public class ErrorReport
    {
        public string code { get; set; }
        public string message { get; set; }
        public string error_description { get; set; }
    }

    public class FileUploadResponse
    {
        public string docVersion { get; set; }
        public string appDocUid { get; set; }
        public ErrorReport error { get; set; }
    }

    public class EditCaseResponse
    {
        public string success { get; set; }
        public ErrorReport error { get; set; }
    }
}
