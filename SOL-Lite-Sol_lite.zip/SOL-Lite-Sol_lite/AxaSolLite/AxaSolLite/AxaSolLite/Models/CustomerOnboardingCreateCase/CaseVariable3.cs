﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Models.CustomerOnboardingCreateCase
{
    public class CaseVariable3
    {
        public string FileVariableName { get; set; }
        public List<FileVariable>[] VariableValues { get; set; }
    }
}
