﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Models.CustomerOnboardingCreateCase
{
    public class CaseVariables
    {
        public List<CaseVariable> caseVariable { get; set; }

        public List<CaseVariable2> gridVariable { get; set; }

        public List<CaseVariable3> fileVariables { get; set; }
    }
}
