﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Models.CustomerOnboardingCreateCase
{
    public class CaseVariable
    {
        public string VariableName { get; set; }
        public string VariableValue { get; set; }
    }
}
