﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Models.CustomerOnboardingCreateCase
{
    public class PMRequestParam
    {
        public string username { get; set; }
        public string name { get; set; }
        public string password { get; set; }
        public string app_uid { get; set; }
        public string pro_uid { get; set; }
        public string tas_uid { get; set; }
        public string del_index { get; set; }
        public CaseVariables caseVariables { get; set; }
        //public CaseVariables fileVariables { get; set; }
        public string[] triggers { get; set; }
        public string[] fileTriggers { get; set; }
    }
}
