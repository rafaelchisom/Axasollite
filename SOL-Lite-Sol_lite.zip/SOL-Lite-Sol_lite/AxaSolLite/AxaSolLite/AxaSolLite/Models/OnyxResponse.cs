﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class OnyxResponse
    {
        public double PenaltyRate { get; set; }
        public double VehicleValue { get; set; }
    }
}
