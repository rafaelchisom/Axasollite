﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class SerializedMotorRenewalObject
    {
        public Guid ProductPlanId { get; set; }
        public string Serializedbject { get; set; }
    }
}
