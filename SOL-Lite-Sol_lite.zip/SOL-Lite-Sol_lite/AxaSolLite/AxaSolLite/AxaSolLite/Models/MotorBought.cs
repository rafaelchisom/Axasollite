﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class MotorBought
    {
        public int Id { get; set; }
        public string VehicleName { get; set; }
        public int YearOfManufacture { get; set; }
    }
}
