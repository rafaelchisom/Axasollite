﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class SavePaymentReferenceRequest
    {
        public string QuoteId { get; set; }
        public string PaymentReference { get; set; }
        public string PaymentPlatform { get; set; }
    }
}
