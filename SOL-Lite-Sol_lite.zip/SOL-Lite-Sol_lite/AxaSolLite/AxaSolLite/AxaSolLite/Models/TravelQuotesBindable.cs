﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class TravelQuotesBindable : BaseModel
    {
        public string PlanCode { get; set; }
        public string PlanName { get; set; }
        public string PlanCost { get; set; }
        public string FirstBenefitValue { get; set; }
        public string SecondBenefitValue { get; set; }
        public string ThirdBenefitValue { get; set; }
        public string FourthBenefitValue { get; set; }
        public string FifthBenefitValue { get; set; }
    }
}
