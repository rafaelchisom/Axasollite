﻿using AxaSolLite.Models.CustomerOnboardingCreateCase;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class HealthProduct
    {
        public int OwnershipType { get; set; }
        public string State { get; set; }
        public string Town { get; set; }
        public string Gender { get; set; }
        public string Genotype { get; set; }
        public string PreferredHospitalLocation { get; set; }
        public string PreferredHospital { get; set; }
        public double Value { get; set; }
        public string Plan { get; set; }
        public string APIKey { get; set; }
        public string Salt { get; set; }
        public string URL { get; set; }
        public string token { get; set; }
        public string MaritalStatus { get; set; }
        public string BloodGroup { get; set; }
        public string Occupation { get; set; }
        public string AnsweredQuestions { get; set; }
        public List<HealthPreExistingConditions> PreExistingConditions { get; set; }
        public List<HealthBeneficiary> Beneficiaries { get; set; }
        public List<FileVariable> UploadedDocuments { get; set; }
    }

    public class HealthBookingRequest
    {
        public Guid ProductId { get; set; }
        public string RequestBody { get; set; }
    }
}
