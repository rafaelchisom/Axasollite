﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class LogItemModel
    {
        public string Name { get; set; }
        public string CustomerNumber { get; set; }
        public string PolicyName { get; set; }
        public string PolicyId { get; set; }
        public string CaseId { get; set; }
        public bool IsCaseId { get; set; }
        public bool IsPolicyId { get; set; }
    }
}
