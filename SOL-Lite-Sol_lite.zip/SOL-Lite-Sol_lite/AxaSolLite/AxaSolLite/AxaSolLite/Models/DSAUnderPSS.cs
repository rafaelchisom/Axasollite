﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class DSAUnderPSS
    {
        public string AgentCode { get; set; }
        public string FullName { get; set; }
        public string PSSCode { get; set; }
        public string LgType { get; set; }
        public string PssName { get; set; }
        public string SBU { get; set; }
        public string Surname { get; set; }
        public string Firstname { get; set; }
        public string Status { get; set; }
        public string PolicyRegion { get; set; }
        public string PolicyRegionID { get; set; }
    }
}
