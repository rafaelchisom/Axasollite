﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class BonusLifePremiumRequest
    {
        public string Age { get; set; }
        public string SumAssured { get; set; }
        public string RiderCode { get; set; }
        public string PayPeriod { get; set; }
        public string InsPeriod { get; set; }
    }

    public class BonusLifeResponse
    {
        public string[] resultField { get; set; }
    }
}
