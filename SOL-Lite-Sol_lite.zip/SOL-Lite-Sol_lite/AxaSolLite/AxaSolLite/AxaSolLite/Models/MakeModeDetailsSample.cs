﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class MakeModeDetailsSample
    {
        [JsonProperty("IsSuccessful")]
        public bool IsSuccessful { get; set; }

        [JsonProperty("Result")]
        public MotorModel Result { get; set; }
    }

    public partial class MotorModel
    {
        [JsonProperty("modelList")]
        public ModelList[] ModelList { get; set; }
    }

    public partial class ModelList
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("makeId")]
        public long MakeId { get; set; }
    }
}
