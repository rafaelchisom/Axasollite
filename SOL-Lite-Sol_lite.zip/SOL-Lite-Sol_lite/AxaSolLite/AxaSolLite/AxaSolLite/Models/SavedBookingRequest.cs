﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
   public class SavedBookingRequest
    {

        public string BookingRequest { get; set; }
        public string ProductPlan { get; set; }
        public string AgentCode { get; set; }

    }
}
