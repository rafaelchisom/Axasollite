﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class PopupOptions
    {
        public string Name { get; set; }
        public string Color { get; set; }
        public string Size { get; set; }
    }
}
