﻿using AxaSolLite.Models.CustomerOnboardingCreateCase;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class HealthApprovalDetails
    {
        public bool IsGroup { get; set; }
        public string PlanName { get; set; }
        public string Duration { get; set; }
        public string Surname { get; set; }
        public string EMAIL { get; set; }
        public string DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string GENOTYPE { get; set; }
        public string CONTACTADDRESS { get; set; }
        public string BVN { get; set; }
        public string HOSPITAL1 { get; set; }
        public string PLANPRICE { get; set; }
        public string OTHERNAMES { get; set; }
        public string MOBILENO { get; set; }
        public string OCCUPATION { get; set; }
        public string MARITALSTATUS { get; set; }
        public string BLOODGROUP { get; set; }
        public string STATEOFRESIDENCE { get; set; }
        public string MAILINGADDRESS { get; set; }
        public string HOSPITAL2 { get; set; }
        public string HASCONDITIONS { get; set; }
        public string CONDITIONS { get; set; }
        public string ADDITIONALINFORMATION { get; set; }

        public string AgentName { get; set; }
        public string AgentCode { get; set; }
        public string SBU { get; set; }
        public string SBUCode { get; set; }
        public string SubAgent { get; set; }

        public List<FileVariable> Documents { get; set; }
        public List<HealthApprovalBeneficiary> Beneficiaries { get; set; }
    }

    public class HealthApprovalBeneficiary
    {
        public string FullName { get; set; }
        public string DateOfBirth { get; set; }
        public string Genotype { get; set; }
        public string BloodGroup { get; set; }
        public string SelectedHospital { get; set; }
        public string Address { get; set; }
    }
}
