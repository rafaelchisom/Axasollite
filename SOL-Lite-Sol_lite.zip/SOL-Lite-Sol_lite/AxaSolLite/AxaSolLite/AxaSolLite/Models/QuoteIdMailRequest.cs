﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class QuoteIdMailRequest
    {
        public string CustomerName { get; set; }
        public string CustomerNumber { get; set; }
        public string PolicyName { get; set; }
        public string QuoteId { get; set; }
        public string Sender { get; set; }
        public string CC { get; set; }
        public string EmailAddress { get; set; }
    }
}
