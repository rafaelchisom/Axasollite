﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class AccountBalanceResponse
    {
        public bool IsSuccessful { get; set; }
        public Balance balances { get; set; }
        public string Message { get; set; }
    }
    public class Balance
    {
        public string CustomerNo { get; set; }
        public double lifeBalance { get; set; }
        public double nonLifeBalance { get; set; }
        public double availBalance { get; set; }

    }
}
