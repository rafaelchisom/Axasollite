﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class AdvisorDetailsDto
    {
        [JsonProperty("Email")]
        public string Email { get; set; }

        [JsonProperty("PhoneNumber")]
        public string PhoneNumber { get; set; }

        [JsonProperty("SbuCode")]
        public long SbuCode { get; set; }

        [JsonProperty("SbuName")]
        public string SbuName { get; set; }

        [JsonProperty("AgentCode")]
        public string AgentCode { get; set; }

        [JsonProperty("SubAgentCode")]
        public string SubAgentCode { get; set; }

        [JsonProperty("AgentName")]
        public string AgentName { get; set; }

        [JsonProperty("PolicyRegion")]
        public string PolicyRegion { get; set; }
    }
}
