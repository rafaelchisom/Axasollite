﻿using Newtonsoft.Json;
using System;

namespace AxaSolLite.Models
{
    public class CustomerOnboardingResponse
    {
        [JsonProperty("IsSuccessful")]
        public bool IsSuccessful { get; set; }

        [JsonProperty("Result")]
        public Result Customer { get; set; }
        
        public class Result
        {
            [JsonProperty("CustomerNumber")]
            public string CustomerNumber { get; set; }

            [JsonProperty("CustomerName")]
            public string CustomerName { get; set; }

            [JsonProperty("DateOfBirth")]
            public DateTimeOffset DateOfBirth { get; set; }

            [JsonProperty("EmailAddress")]
            public string EmailAddress { get; set; }

            [JsonProperty("PhoneNumber")]
            public string PhoneNumber { get; set; }

            [JsonProperty("CustomerAddress")]
            public string CustomerAddress { get; set; }
        }
    }
}
