﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
   public class GetAgentDetailsResponse
    {
        public string AgentCode { get; set; }


        public string Staffno { get; set; }


        public string Surname { get; set; }


        public string Firstname { get; set; }


        public string OtherName { get; set; }

        public string FullName => $" {Firstname} {Surname}";


        public string Gender { get; set; }


        public string CurrentLevel { get; set; }


        public string Confirmationstatus { get; set; }


        public string Recruitmentagency { get; set; }


        public string Status { get; set; }


        public string ResignationDate { get; set; }


        public string DateOfEntry { get; set; }


        public string MobileNo { get; set; }


        public string EmailAddress { get; set; }




        public string PssUsername { get; set; }


        public string SsType { get; set; }


        public string Office { get; set; }


        public string Branch { get; set; }


        public string BmUsername { get; set; }


        public string BankCode { get; set; }


        public string BankAccountNumber { get; set; }


        public string EchannelCode { get; set; }

        public string BankAccountName { get; set; }


        public string PssHouse { get; set; }


        public string MailingList { get; set; }


        public string SortCode { get; set; }


        public string Bvn { get; set; }


        public string LastPromotionDate { get; set; }


        public object MeansOfIdentification { get; set; }


        public string BankName { get; set; }


        public string SBU { get; set; }


        public string ActionMessage { get; set; }


        public string ModifiedBy { get; set; }


        public string DateModified { get; set; }


        public string LastPromotionDate1 { get; set; }


        public string ResignationDate1 { get; set; }


        public object Photo { get; set; }


        public string NextOfKinSurname { get; set; }


        public string NextOfKinFirstName { get; set; }


        public string NextOfKinAddress { get; set; }


        public string NextOfKinMobileNo { get; set; }


        public string NextOfKinRelationship { get; set; }


        public string Division { get; set; }


        public int Group { get; set; }


        public int Unit { get; set; }


        public string BusinessSource { get; set; }


        public string SubAgentCode { get; set; }
    }
}
