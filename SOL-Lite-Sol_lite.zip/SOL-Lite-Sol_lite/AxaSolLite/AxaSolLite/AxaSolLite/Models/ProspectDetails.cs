﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class ProspectDetails
    {
        public string ProspectId { get; set; }
        public int Title { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public int Gender { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
        public string CustomerAddress { get; set; }
        public string CustomerNumber { get; set; }
        public bool CaseCreated { get; set; }
       
        public string CreatedBy { get; set; }
        public string AgentCode { get; set; }
        public DateTime DateCreated { get; set; }
        public string Sbu { get; set; }
        public string AgentType { get; set; }
        public string FullName => $" {FirstName} {LastName}";
    }
    public class ProspectToUpdate
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
        public string CustomerNumber { get; set; }
    }
    public class CheckExistingProspectModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
    }
    public class ProspectCaseCreated
    {
        public string CustomerNumber { get; set; }
        public bool CaseCreated { get; set; }
    }
}
