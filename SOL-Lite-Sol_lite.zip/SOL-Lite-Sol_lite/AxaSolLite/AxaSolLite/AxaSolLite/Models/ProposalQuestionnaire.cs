﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class ProposalQuestionnaire
    {
        public bool IsExistingPolicy { get; set; }
        public string ExistingPolicyDetails { get; set; }
        public string ExistingPolicyLifeAssuranceValue { get; set; }
        public string Assurer { get; set; }
        public bool IsProposalDeclined { get; set; }
        public string DeclinedProposalDetail { get; set; }
        public bool IsNonScheduledFlight { get; set; }
        public bool IsArmedForces { get; set; }
        public string MedicalGrade { get; set; }
        public bool IsAdditionalFacts { get; set; }
        public string AdditionalFacts { get; set; }
        public bool IsResideOutsideNigeria { get; set; }
        public string IndicatedCountry { get; set; }
    }
}
