﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class TravelBookingRequest
    {
        [JsonProperty("XFR_INFO_MST_MAJ_INS_TYPE")]
        public int XfrInfoMstMajInsType { get; set; }

        [JsonProperty("XFR_INFO_MST_POL_TYPE")]
        public int XfrInfoMstPolType { get; set; }

        [JsonProperty("XFR_INFO_MST_MIN_INS_TYPE")]
        public int XfrInfoMstMinInsType { get; set; }

        [JsonProperty("XFR_INFO_ACM_ANN_SALARY")]
        public decimal XfrInfoAcmAnnSalary { get; set; }

        [JsonProperty("XFR_INFO_CUST_PREV_POLICY_FLAG")]
        public int XfrInfoCustPrevPolicyFlag { get; set; }

        [JsonProperty("XFR_INFO_MST_CUST_NO")]
        public string XfrInfoMstCustNo { get; set; }

        [JsonProperty("XFR_INFO_MST_BRANCH")]
        public int XfrInfoMstBranch { get; set; }

        [JsonProperty("XFR_INFO_MST_OFFICE")]
        public int XfrInfoMstOffice { get; set; }

        [JsonProperty("XFR_INFO_MST_AGENT_NO")]
        public string XfrInfoMstAgentNo { get; set; }

        [JsonProperty("XFR_INFO_MST_THROUGH")]
        public int XfrInfoMstThrough { get; set; }

        [JsonProperty("XFR_INFO_MST_UW_YEAR")]
        public int XfrInfoMstUwYear { get; set; }

        [JsonProperty("XFR_INFO_MST_PAY_TYPE")]
        public int XfrInfoMstPayType { get; set; }

        [JsonProperty("XFR_INFO_MST_INS_ST_DT")]
        public DateTimeOffset XfrInfoMstInsStDt { get; set; }

        [JsonProperty("XFR_INFO_MST_PERIOD")]
        public int XfrInfoMstPeriod { get; set; }

        [JsonProperty("XFR_INFO_SCO_SUBJECT_TYPE1")]
        public string XfrInfoScoSubjectType1 { get; set; }

        [JsonProperty("XFR_INFO_SCO_SUBJECT_TYPE2")]
        public string XfrInfoScoSubjectType2 { get; set; }

        [JsonProperty("XFR_INFO_MST_DOC_NO")]
        public int XfrInfoMstDocNo { get; set; }

        [JsonProperty("XFR_INFO_SCO_FEX_RATE")]
        public string XfrInfoScoFexRate { get; set; }

        public string XFR_INFO_RI_PLAN { get; set; }

        [JsonProperty("SCO_SUBJECT_DESC")]
        public string ScoSubjectDesc { get; set; }

        [JsonProperty("XFR_INFO_SCO_SUM_INSURED")]
        public string XfrInfoScoSumInsured { get; set; }

        public string XFR_INFO_BASIC_PREM_RATE { get; set; }

        [JsonProperty("XFR_INFO_LBEN_CUST_RELATION")]
        public int XfrInfoLbenCustRelation { get; set; }

        [JsonProperty("XFR_INFO_LBEN_SUR_NAME")]
        public string XfrInfoLbenSurName { get; set; } //object

        [JsonProperty("XFR_INFO_LBEN_OTHER_NAME")]
        public string XfrInfoLbenOtherName { get; set; } //object

        [JsonProperty("XFR_INFO_LBEN_ADDRESS")]
        public string XfrInfoLbenAddress { get; set; } //object 

        [JsonProperty("XFR_INFO_LBEN_TEL")]
        public string XfrInfoLbenTel { get; set; } //object

        [JsonProperty("XFR_INFO_LBEN_OCCUPATION")]
        public object XfrInfoLbenOccupation { get; set; }

        [JsonProperty("XFR_INFO_LBEN_JOB_CLASS")]
        public object XfrInfoLbenJobClass { get; set; }

        [JsonProperty("XFR_INFO_LBEN_MARITAL_STATUS")]
        public int XfrInfoLbenMaritalStatus { get; set; }

        [JsonProperty("XFR_INFO_LBEN_BIRTH_DT1")]
        public DateTimeOffset XfrInfoLbenBirthDt1 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TYPE1")]
        public int XfrInfoLbenType1 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_CUST_RELATION2")]
        public int XfrInfoLbenCustRelation2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_SUR_NAME2")]
        public string XfrInfoLbenSurName2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_OTHER_NAME2")]
        public string XfrInfoLbenOtherName2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_ADDRESS2")]
        public string XfrInfoLbenAddress2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TEL2")]
        public string XfrInfoLbenTel2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_OCCUPATION2")]
        public object XfrInfoLbenOccupation2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_JOB_CLASS2")]
        public object XfrInfoLbenJobClass2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_MARITAL_STATUS2")]
        public int XfrInfoLbenMaritalStatus2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_BIRTH_DT2")]
        public DateTimeOffset XfrInfoLbenBirthDt2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TYPE2")]
        public int XfrInfoLbenType2 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_CUST_RELATION3")]
        public int XfrInfoLbenCustRelation3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_SUR_NAME3")]
        public string XfrInfoLbenSurName3 { get; set; } //object

        [JsonProperty("XFR_INFO_LBEN_OTHER_NAME3")]
        public string XfrInfoLbenOtherName3 { get; set; } //object

        [JsonProperty("XFR_INFO_LBEN_ADDRESS3")]
        public string XfrInfoLbenAddress3 { get; set; } //object 

        [JsonProperty("XFR_INFO_LBEN_TEL3")]
        public string XfrInfoLbenTel3 { get; set; } //object

        [JsonProperty("XFR_INFO_LBEN_OCCUPATION3")]
        public object XfrInfoLbenOccupation3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_JOB_CLASS3")]
        public object XfrInfoLbenJobClass3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_MARITAL_STATUS3")]
        public int XfrInfoLbenMaritalStatus3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_BIRTH_DT3")]
        public DateTimeOffset XfrInfoLbenBirthDt3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TYPE3")]
        public int XfrInfoLbenType3 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_CUST_RELATION4")]
        public int XfrInfoLbenCustRelation4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_SUR_NAME4")]
        public string XfrInfoLbenSurName4 { get; set; } //object

        [JsonProperty("XFR_INFO_LBEN_OTHER_NAME4")]
        public string XfrInfoLbenOtherName4 { get; set; } //object

        [JsonProperty("XFR_INFO_LBEN_ADDRESS4")]
        public string XfrInfoLbenAddress4 { get; set; } //object 

        [JsonProperty("XFR_INFO_LBEN_TEL4")]
        public string XfrInfoLbenTel4 { get; set; } //object

        [JsonProperty("XFR_INFO_LBEN_OCCUPATION4")]
        public object XfrInfoLbenOccupation4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_JOB_CLASS4")]
        public object XfrInfoLbenJobClass4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_MARITAL_STATUS4")]
        public int XfrInfoLbenMaritalStatus4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_BIRTH_DT4")]
        public DateTimeOffset XfrInfoLbenBirthDt4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TYPE4")]
        public int XfrInfoLbenType4 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_CUST_RELATION5")]
        public int XfrInfoLbenCustRelation5 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_SUR_NAME5")]
        public string XfrInfoLbenSurName5 { get; set; } //object

        [JsonProperty("XFR_INFO_LBEN_OTHER_NAME5")]
        public string XfrInfoLbenOtherName5 { get; set; } //object

        [JsonProperty("XFR_INFO_LBEN_ADDRESS5")]
        public string XfrInfoLbenAddress5 { get; set; } //object 

        [JsonProperty("XFR_INFO_LBEN_TEL5")]
        public string XfrInfoLbenTel5 { get; set; } //object

        [JsonProperty("XFR_INFO_LBEN_OCCUPATION5")]
        public object XfrInfoLbenOccupation5 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_JOB_CLASS5")]
        public object XfrInfoLbenJobClass5 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_MARITAL_STATUS5")]
        public int XfrInfoLbenMaritalStatus5 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_BIRTH_DT5")]
        public DateTimeOffset XfrInfoLbenBirthDt5 { get; set; }

        [JsonProperty("XFR_INFO_LBEN_TYPE5")]
        public int XfrInfoLbenType5 { get; set; }

        [JsonProperty("XFR_INFO_MST_DOC_TYPE")]
        //[JsonConverter(typeof(ParseStringConverter))]
        public int XfrInfoMstDocType { get; set; }

        [JsonProperty("AmountPaid")]
        public decimal AmountPaid { get; set; }

        [JsonProperty("PaymentSource")]
        public string PaymentSource { get; set; }

        [JsonProperty("TransRef")]
        public string TransRef { get; set; }

        [JsonProperty("RequestSource")]
        public string RequestSource { get; set; }

        [JsonProperty("XFR_INFO_ISPAY_NOW")]
        public bool XfrInfoMstIsPayNow { get; set; }

        [JsonProperty("XFR_INFO_PAY_NOW_TRANS_REF")]
        public string XfrInfoPayNowTransRef { get; set; }
        public bool XFR_INFO_BOOK_FROM_BALANCE { get; set; }
        public string XFR_INFO_QUOTE_NO { get; set; }
    }
}
