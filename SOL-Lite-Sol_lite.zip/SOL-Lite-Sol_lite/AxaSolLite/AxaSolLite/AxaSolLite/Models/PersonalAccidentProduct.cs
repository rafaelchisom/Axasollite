﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class PersonalAccidentProduct
    {
        public string paymentChannel { get; set; }
        public int Branch { get; set; }
        public string DSACode { get; set; }
        public string DSAName { get; set; }
        public string PaymentFrequency { get; set; }
        public string SponsorIDType { get; set; }
        public string BenefitValue { get; set; }
        public bool IsJoint { get; set; }
        public string SpouseFirstName { get; set; }
        public string SpouseLastName { get; set; }
        public string SpouseEmailAddress { get; set; }
        public string SpousePhoneNumber { get; set; }
        public int SpouseTitle { get; set; }
        public string SpouseGender { get; set; }
        public string SpouseOccupation { get; set; }
        public DateTime SpouseDateofBirth { get; set; }
        public string SpouseIDType { get; set; }
        public double Premium { get; set; }
        public List<PersonalAccidentBeneficiary> Beneficiaries { get; set; }
        public PersonalAccidentCalcResponse CostResponse { get; set; }

    }
    public class PersonalAccidentBeneficiary
    {
        public int Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
        public string Relationship { get; set; }
        public bool IsForSponsor { get; set; }
        public decimal Proportion { get; set; }
        public string FullName => $" {FirstName} {LastName}";
        public string ProportionPercentage => $" {Proportion} %";
    }

    public class PersonalAccidentRepositoryObject
    {
        public Guid ProductPlanId { get; set; }
        public string SerializedProductDetails { get; set; }
    }
}


