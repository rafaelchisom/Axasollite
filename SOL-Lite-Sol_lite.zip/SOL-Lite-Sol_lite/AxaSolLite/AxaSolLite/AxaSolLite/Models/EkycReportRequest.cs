﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class EkycReportRequest
    {
        public int CaseID { get; set; }
        public int PolicyRegion { get; set; }
        public string CaseTitle { get; set; }
        public string SentBy { get; set; }
        public string ApprovalLevel { get; set; }
        public DateTime DateSent { get; set; }
        public string CaseStatus { get; set; }
        public string CurrentUser { get; set; }

    }
    public class UpdateEkycStatus
    {
        public string CaseStatus { get; set; }
        public int CaseID { get; set; }
    }
}
