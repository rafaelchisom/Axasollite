﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class PersonalAccidentCalcResponse
    {
        [JsonProperty("Beneficiary")]
        public List<Beneficiary> Beneficiary { get; set; }

        [JsonProperty("TotalPremium")]
        public double TotalPremium { get; set; }

        [JsonProperty("DiscountPremium")]
        public double DiscountPremium { get; set; }
    }

    public class Beneficiary
    {
        [JsonProperty("Benefit")]
        public List<Benefit> Benefit { get; set; }

        [JsonProperty("GrossPremium")]
        public double GrossPremium { get; set; }
    }

    public class Benefit
    {
        [JsonProperty("RiderCode")]
        public string RiderCode { get; set; }

        [JsonProperty("Benefit")]
        public double BenefitBenefit { get; set; }

        [JsonProperty("RiderRate")]
        public double RiderRate { get; set; }

        [JsonProperty("RiderPremium")]
        public double RiderPremium { get; set; }

        [JsonProperty("NumberOfMonths")]
        public int NumberOfMonths { get; set; }
    }
}
