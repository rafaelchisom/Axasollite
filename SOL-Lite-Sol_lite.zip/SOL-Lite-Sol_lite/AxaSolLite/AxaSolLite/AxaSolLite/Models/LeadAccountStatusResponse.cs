﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
  public  class LeadAccountStatusResponse
    {
        [JsonProperty("customerNo")]
        public string CustomerNo { get; set; }

        [JsonProperty("isFullyKYCed")]
        public bool IsFullyKyCed { get; set; }

        [JsonProperty("isLeadAccount")]
        public bool IsLeadAccount { get; set; }
    }
}
