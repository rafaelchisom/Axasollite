﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class SyncDate
    {
        public DateTime LastSyncDate { get; set; }
    }
}
