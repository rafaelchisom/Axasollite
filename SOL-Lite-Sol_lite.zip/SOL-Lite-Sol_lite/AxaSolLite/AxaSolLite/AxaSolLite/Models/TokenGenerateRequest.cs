﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
   public  class TokenGenerateRequest
    {
        public string userName { get; set; }
        public string password { get; set; }
        public string grant_type { get; set; }
    }
}
