﻿using System;

namespace AxaSolLite.Models
{
    public class MotorProduct : BaseModel
    {
        public MotorProduct()
        {
            Id = Guid.NewGuid();
        }
        public Guid ProductPlanId { get; set; }
        public string CarUse { get; set; }
        public string EngineNumber { get; set; }
        public string ChassisNumber { get; set; }
        public string PlateNumber { get; set; }
        public string VehicleMake { get; set; }
        public string VehicleModel { get; set; }
        public string VehicleYear { get; set; }
        public string VehicleValue { get; set; }
        public string RegistrationNumber { get; set; }
        public string StartDate { get; set; }
        public double Premium { get; set; }
        public bool IsRateConcession { get; set; }
        public double CheckiMaxValue { get; set; }
        public double CheckiMinValue { get; set; }
        public int CheckiRemarks { get; set; }
        public string MotorMakeId { get; set; }
        public string MotorModelId { get; set; }
        public string BaseRate { get; set; }
        public string GeneratedSummaryPdf { get; set; }
        public int Branch { get; set; }
        public int MyProperty { get; set; }
        public bool IsEditCarDetails { get; set; }
        public int CarColorCode { get; set; }
        public string CarColor { get; set; }
        public string PolicyId { get; set; }
        public bool ColorChanged { get; set; }
        public bool PlateNumberChanged { get; set; }
        public bool IsPostGracePeriod { get; set; }
    }

    public class MotorRiders
    {
        public Guid MotorProductId { get; set; }
        public double BaseRateAmount { get; set; }
        public bool IsEBB { get; set; }
        public double EBBAmount { get; set; }
        public bool IsCarTracker { get; set; }
        public double CarTrackerAmount { get; set; }
        public bool IsFlood { get; set; }
        public double FloodAmount { get; set; }
        public bool IsExtraTppd { get; set; }
        public double ExtraTppdAmount { get; set; }
        public string ExtraTppdValue { get; set; }
        public string ExtraTppdChoice { get; set; }
        public string EBB { get; set; }
        public string Flood { get; set; }
        public string CarTracker { get; set; }
        public string ExtraTppd { get; set; }
        public double BaseRatePercentage { get; set; }
        public double EBBPercentage { get; set; }
        public double FloodPercentage { get; set; }
        public double AdditionalCharges { get; set; }

    }

    public class Documents
    {
        public Guid MotorProductId { get; set; }
        public string FileName { get; set; }
        public string ContentType { get; set; }
        public string FileContent { get; set; }
        public string Extension { get; set; }
        public string FieldName { get; set; }
    }
}
