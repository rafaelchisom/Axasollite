﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class EForms
    {
        public int Id { get; set; }
        public string Eform { get; set; }
        public int ProductId { get; set; }
    }

    public class Products
    {
        public int Id { get; set; }
        public string Product { get; set; }
    }
}
