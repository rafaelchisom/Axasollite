﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
 public   class CashBackQuoteResponse
    {
        [JsonProperty("displayedDesiredPolicyTermField")]
        public int DisplayedDesiredPolicyTermField { get; set; }

        [JsonProperty("proposalNameField")]
        public string ProposalNameField { get; set; }

        [JsonProperty("ageNextBirthdayField")]
        public int AgeNextBirthdayField { get; set; }

        [JsonProperty("sumAssuredField")]
        public double SumAssuredField { get; set; }

        [JsonProperty("paymentTermField")]
        public int PaymentTermField { get; set; }

        [JsonProperty("deathPremiumField")]
        public double DeathPremiumField { get; set; }

        [JsonProperty("riderPremiumField")]
        public PremiumField[] RiderPremiumField { get; set; }

        [JsonProperty("periodicPremiumField")]
        public PremiumField[] PeriodicPremiumField { get; set; }

        [JsonProperty("annualPremiumField")]
        public string AnnualPremiumField { get; set; }

        [JsonProperty("totalPremiumField")]
        public string TotalPremiumField { get; set; }

        [JsonProperty("policyPeriodField")]
        public int PolicyPeriodField { get; set; }
    }

    public partial class PremiumField
    {
        [JsonProperty("val1Field")]
        public string Val1Field { get; set; }

        [JsonProperty("val2Field")]
        public string Val2Field { get; set; }
    }

}
