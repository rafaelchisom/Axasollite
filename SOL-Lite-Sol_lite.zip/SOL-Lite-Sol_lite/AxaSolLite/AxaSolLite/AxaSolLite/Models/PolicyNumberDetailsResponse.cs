﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class PolicyNumberDetailsResponse
    {
        public Guid ProductPlanId { get; set; }

        [JsonProperty("vehPlateNo")]
        public string VehPlateNo { get; set; }

        [JsonProperty("vehMakeCode")]
        public int VehMakeCode { get; set; }

        [JsonProperty("vehMakeName")]
        public string VehMakeName { get; set; }

        [JsonProperty("vehModel")]
        public string VehModel { get; set; }

        [JsonProperty("chasisCode")]

        public string ChasisCode { get; set; }

        [JsonProperty("chasisNo")]
        public string ChasisNo { get; set; }

        [JsonProperty("engineNo")]
        public string EngineNo { get; set; }

        [JsonProperty("vehProdYear")]
        public int VehProdYear { get; set; }

        [JsonProperty("driversName")]
        public string DriversName { get; set; }

        [JsonProperty("vehColorCode")]
        public int VehColorCode { get; set; }

        [JsonProperty("premiumBreakdown")]
        public PremiumBreakdown PremiumBreakdown { get; set; }

        [JsonProperty("policyID")]
        public string PolicyId { get; set; }

        [JsonProperty("policyKey")]
        public string PolicyKey { get; set; }

        [JsonProperty("customerNo")]
        public string CustomerNo { get; set; }

        [JsonProperty("startDate")]
        public string StartDate { get; set; }

        [JsonProperty("endDate")]
        public string EndDate { get; set; }

        [JsonProperty("product")]
        public string Product { get; set; }

        [JsonProperty("branch")]

        public string Branch { get; set; }

        [JsonProperty("office")]

        public string Office { get; set; }

        [JsonProperty("sbu")]

        public string Sbu { get; set; }

        [JsonProperty("businessType")]

        public string BusinessType { get; set; }

        [JsonProperty("sumInsured")]
        public double SumInsured { get; set; }

        [JsonProperty("premium")]
        public double Premium { get; set; }

        [JsonProperty("policyClass")]
        public int PolicyClass { get; set; }

        [JsonProperty("policyType")]
        public int PolicyType { get; set; }

        [JsonProperty("policyYear")]
        public int PolicyYear { get; set; }

        [JsonProperty("policyMonth")]
        public int PolicyMonth { get; set; }

        [JsonProperty("policyNo")]
        public int PolicyNo { get; set; }

        [JsonProperty("transactionType")]
        public int TransactionType { get; set; }

        [JsonProperty("agentNo")]
        public string AgentNo { get; set; }

        [JsonProperty("subAgentNo")]
        public string SubAgentNo { get; set; }

        public bool IsRenewal { get; set; }

        public bool IsConversion { get; set; }

        public bool IsAddition { get; set; }

        public bool IsChecked { get; set; }
    }
    public partial class PremiumBreakdown
    {
        [JsonProperty("basicPremium")]
        public string BasicPremium { get; set; }

        [JsonProperty("basicPremiumRate")]
        public string BasicPremiumRate { get; set; }

        [JsonProperty("tppdPremium")]
        public string TppdPremium { get; set; }

        [JsonProperty("ebbPremium")]
        public string EbbPremium { get; set; }

        [JsonProperty("ebbPremiumRate")]
        public string EbbPremiumRate { get; set; }

        [JsonProperty("floodPremium")]
        public string FloodPremium { get; set; }

        [JsonProperty("floodPremiumRate")]
        public string FloodPremiumRate { get; set; }

        [JsonProperty("srccPremium")]
        public string SrccPremium { get; set; }

        [JsonProperty("srccPremiumRate")]
        public string SrccPremiumRate { get; set; }

        [JsonProperty("extrachargePremium")]
        public string ExtrachargePremium { get; set; }
    }
    public class PolicyDetailsResponseToSave
    {
        public Guid ProductPlanId { get; set; }
        public string PolicyDetailsResponse { get; set; }
    }
}
