﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class PersonalAccidentBookingResponse
    {
        [JsonProperty("IsSuccessful")]
        public bool IsSuccessful { get; set; }

        [JsonProperty("Message")]
        public string Message { get; set; }

        [JsonProperty("Policykey")]
        public string Policykey { get; set; }

        [JsonProperty("InsStartDate")]
        public string InsStartDate { get; set; }

        [JsonProperty("CustomerNo")]
        public string CustomerNo { get; set; }

        [JsonProperty("InsEndDate")]
        public string InsEndDate { get; set; }

        [JsonProperty("SumAssured")]
        public string SumAssured { get; set; }

        [JsonProperty("PolicyNo")]
        public string PolicyNo { get; set; }

        [JsonProperty("PolicyID")]
        public string PolicyId { get; set; }

        [JsonProperty("PolicyDocNo")]
        public string PolicyDocNo { get; set; }

        [JsonProperty("IsVouchered")]
        public bool IsVouchered { get; set; }

        [JsonProperty("CustomerName")]
        public string CustomerName { get; set; }

        [JsonProperty("Premium")]
        public long Premium { get; set; }

        [JsonProperty("IsVoucheredResponse")]
        public object IsVoucheredResponse { get; set; }

        [JsonProperty("TransRef")]
        public string TransRef { get; set; }
    }
}
