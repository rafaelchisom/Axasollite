﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class LifeBookingResponse
    {
        public bool IsSuccesful { get; set; }
        public string PolicyID { get; set; }
        public string PolicyKey { get; set; }
        public string SumAssured { get; set; }
        public string PolicyNo { get; set; }
        public string Message { get; set; }
        public bool PolicyBooked { get; set; }
        public bool CaseCreated { get; set; }
        public string CaseID { get; set; }
    }
}
