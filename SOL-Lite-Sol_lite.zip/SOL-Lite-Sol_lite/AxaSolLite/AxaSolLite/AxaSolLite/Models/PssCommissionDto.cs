﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class PssCommissionDto
    {
        [JsonProperty("DSM_Level")]
        public string DsmLevel { get; set; }

        [JsonProperty("ConfirmationStatus")]
        public string ConfirmationStatus { get; set; }

        [JsonProperty("DSM_Code")]
        public string DsmCode { get; set; }

        [JsonProperty("DSM_Name")]
        public string DsmName { get; set; }

        [JsonProperty("NumberOfLG")]
        
        public long NumberOfLg { get; set; }

        [JsonProperty("NumberOfSLG")]
        
        public long NumberOfSlg { get; set; }

        [JsonProperty("NumberOfCP")]
        
        public long NumberOfCp { get; set; }

        [JsonProperty("MotorInflow")]
        public string MotorInflow { get; set; }

        [JsonProperty("NonMotorInflow")]
        public string NonMotorInflow { get; set; }

        [JsonProperty("MonthlyActual")]
        public string MonthlyActual { get; set; }

        [JsonProperty("MonthlyBudget")]
        public string MonthlyBudget { get; set; }

        [JsonProperty("MotorCommission")]
        public string MotorCommission { get; set; }

        [JsonProperty("NonMotorCommission")]
        public string NonMotorCommission { get; set; }

        [JsonProperty("MonthlyTotalCommission")]
        public string MonthlyTotalCommission { get; set; }

        [JsonProperty("PercentageAchieved")]
        public double PercentageAchieved { get; set; }

        [JsonProperty("Monthly_MotorOverride")]
        public string MonthlyMotorOverride { get; set; }

        [JsonProperty("Monthly_NonMotorOverride")]
        public string MonthlyNonMotorOverride { get; set; }

        [JsonProperty("Total_Monthly_Override")]
        public string TotalMonthlyOverride { get; set; }

        [JsonProperty("YTDMotorInflow")]
        public string YtdMotorInflow { get; set; }

        [JsonProperty("YTDNonMotorInflow")]
        public string YtdNonMotorInflow { get; set; }

        [JsonProperty("YTDActual")]
        public string YtdActual { get; set; }

        [JsonProperty("YTDBudget")]
        public string YtdBudget { get; set; }

        [JsonProperty("YTDMotorCommission")]
        public string YtdMotorCommission { get; set; }

        [JsonProperty("YTDNonMotorCommission")]
        public string YtdNonMotorCommission { get; set; }

        [JsonProperty("YTDTotalCommission")]
        public string YtdTotalCommission { get; set; }

        [JsonProperty("YTDLifeInflow")]
        public string YtdLifeInflow { get; set; }

        [JsonProperty("YTDLifeCommission")]
        public string YtdLifeCommission { get; set; }

        [JsonProperty("LifeInflow")]
        public string LifeInflow { get; set; }

        [JsonProperty("LifeCommission")]
        public string LifeCommission { get; set; }

        [JsonProperty("MonthlyLifeOverride")]
        public string MonthlyLifeOverride { get; set; }

        [JsonProperty("YTDMotorOverride")]
        public string YtdMotorOverride { get; set; }

        [JsonProperty("YTDNonMotorOverride")]
        public string YtdNonMotorOverride { get; set; }

        [JsonProperty("YTDLifeOverride")]
        public string YtdLifeOverride { get; set; }

        [JsonProperty("YTDTotalOverride")]
        public string YtdTotalOverride { get; set; }
    }
}
