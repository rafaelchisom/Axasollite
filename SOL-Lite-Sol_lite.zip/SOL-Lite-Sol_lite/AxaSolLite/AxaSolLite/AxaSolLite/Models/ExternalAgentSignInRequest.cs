﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class ExternalAgentSignInRequest
    {
        public string username { get; set; }

        public string password { get; set; }
    }
}
