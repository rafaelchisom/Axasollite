﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class DigitalAPICredentials
    {
        public string Url { get; set; }
        public string Base64EncodedUsernamePassword { get; set; }
    }

    public class HealthAPICredentials
    {
        public string APIKey { get; set; }
        public string Salt { get; set; }
        public string URL { get; set; }
    }
}
