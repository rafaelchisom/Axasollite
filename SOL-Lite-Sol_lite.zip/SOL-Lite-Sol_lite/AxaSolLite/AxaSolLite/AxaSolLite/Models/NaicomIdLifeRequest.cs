﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class NaicomIdLifeRequest
    {
        [JsonProperty("coverageStartDate")]
        public DateTime CoverageStartDate { get; set; }

        [JsonProperty("coverageEndDate")]
        public DateTime CoverageEndDate { get; set; }

        [JsonProperty("policyInternalID")]
        public string PolicyInternalId { get; set; }

        [JsonProperty("policyDescription")]
        public string PolicyDescription { get; set; }

        [JsonProperty("customerName")]
        public string CustomerName { get; set; }

        [JsonProperty("addressLine")]
        public string AddressLine { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("cityLGA")]
        public string CityLga { get; set; }

        [JsonProperty("birthDate")]
        public DateTime BirthDate { get; set; }

        [JsonProperty("gender")]
        public string Gender { get; set; }

        [JsonProperty("nationality")]
        public string Nationality { get; set; }

        [JsonProperty("idNo")]
        public string IdNo { get; set; }

        [JsonProperty("occupation")]
        public string Occupation { get; set; }

        [JsonProperty("marital")]
        public string Marital { get; set; }

        [JsonProperty("phoneWork")]
        public string PhoneWork { get; set; }

        [JsonProperty("phoneMobile")]
        public string PhoneMobile { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("productName")]
        public string ProductName { get; set; }

        [JsonProperty("productType")]
        public string ProductType { get; set; }

        [JsonProperty("insuredValue")]
        public string InsuredValue { get; set; }

        [JsonProperty("premium")]
        public string Premium { get; set; }

        [JsonProperty("commissionFee")]
        public string CommissionFee { get; set; }

        [JsonProperty("docNo")]
        public int DocNo { get; set; }

        [JsonProperty("lifeIndividualBeneficiaries")]
        public LifeIndividualBeneficiary[] LifeIndividualBeneficiaries { get; set; }
    }

    public partial class LifeIndividualBeneficiary
    {
        [JsonProperty("insuredNo")]
        public string InsuredNo { get; set; }

        [JsonProperty("beneficiaryName")]
        public string BeneficiaryName { get; set; }

        [JsonProperty("beneficiaryAddress")]
        public string BeneficiaryAddress { get; set; }

        [JsonProperty("beneficiaryBirthDate")]
        public DateTime BeneficiaryBirthDate { get; set; }

        [JsonProperty("beneficiaryGender")]
        public string BeneficiaryGender { get; set; }

        [JsonProperty("beneficiaryPhone")]
        public string BeneficiaryPhone { get; set; }

        [JsonProperty("beneficiaryEmail")]
        public string BeneficiaryEmail { get; set; }

        [JsonProperty("beneficiaryIDDoc")]
        public string BeneficiaryIdDoc { get; set; }

        [JsonProperty("beneficiaryIDNo")]
        public string BeneficiaryIdNo { get; set; }

        [JsonProperty("beneficiaryRelationship")]
        public string BeneficiaryRelationship { get; set; }

        [JsonProperty("beneficiaryNote")]
        public string BeneficiaryNote { get; set; }

        [JsonProperty("benefitProportions")]
        public string BenefitProportions { get; set; }
    }

    public class NaicomIdLoad
    {
        public string RequestPayload { get; set; }
        public bool IsLife { get; set; }
    }
}
