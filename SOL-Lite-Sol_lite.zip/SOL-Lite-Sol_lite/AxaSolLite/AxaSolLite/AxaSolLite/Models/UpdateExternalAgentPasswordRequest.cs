﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class UpdateExternalAgentPasswordRequest
    {
        public string username { get; set; }

        public string password { get; set; }
    }
}
