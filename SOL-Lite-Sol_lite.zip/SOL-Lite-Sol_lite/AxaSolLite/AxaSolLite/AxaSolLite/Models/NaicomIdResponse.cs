﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class NaicomIdResponse
    {
        [JsonProperty("isSucceed")]
        public bool IsSucceed { get; set; }

        [JsonProperty("policyUniqueID")]
        public string PolicyUniqueId { get; set; }

        [JsonProperty("errCodes")]
        public object ErrCodes { get; set; }

        [JsonProperty("errMsgs")]
        public object ErrMsgs { get; set; }

        [JsonProperty("errMsg")]
        public object ErrMsg { get; set; }

        [JsonProperty("warnMsgs")]
        public object WarnMsgs { get; set; }
    }
}
