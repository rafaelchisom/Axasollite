﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class BonusLifeprojectionsheetRequest
    {
        public string Agent_Name { get; set; }
        public string Issue_Date { get; set; }
        public string Customer_Name { get; set; }
        public string Phone_Number { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string Total_Premium { get; set; }
        public string Premium_Frequency { get; set; }
        public string Policy_Term { get; set; }
        public string Customer_Signature { get; set; }
        public string AgentEmail { get; set; }



        #region Age
        public string Age_1 { get; set; }
        public string Age_2 { get; set; }
        public string Age_3 { get; set; }
        public string Age_4 { get; set; }
        public string Age_5 { get; set; }
        public string Age_6 { get; set; }
        public string Age_7 { get; set; }
        public string Age_8 { get; set; }
        public string Age_9 { get; set; }
        public string Age_10 { get; set; }
        public string Age_11 { get; set; }
        public string Age_12 { get; set; }
        public string Age_13 { get; set; }
        public string Age_14 { get; set; }
        public string Age_15 { get; set; }

        #endregion
        #region Contribution
        public string Contribution_1 { get; set; }
        public string Contribution_2 { get; set; }
        public string Contribution_3 { get; set; }
        public string Contribution_4 { get; set; }
        public string Contribution_5 { get; set; }
        public string Contribution_6 { get; set; }
        public string Contribution_7 { get; set; }
        public string Contribution_8 { get; set; }
        public string Contribution_9 { get; set; }
        public string Contribution_10 { get; set; }
        public string Contribution_11 { get; set; }
        public string Contribution_12 { get; set; }
        public string Contribution_13 { get; set; }
        public string Contribution_14 { get; set; }
        public string Contribution_15 { get; set; }


        #endregion
        #region Premium
        public string Premium_1 { get; set; }
        public string Premium_2 { get; set; }
        public string Premium_3 { get; set; }
        public string Premium_4 { get; set; }
        public string Premium_5 { get; set; }
        public string Premium_6 { get; set; }
        public string Premium_7 { get; set; }
        public string Premium_8 { get; set; }
        public string Premium_9 { get; set; }
        public string Premium_10 { get; set; }
        public string Premium_11 { get; set; }
        public string Premium_12 { get; set; }
        public string Premium_13 { get; set; }
        public string Premium_14 { get; set; }
        public string Premium_15 { get; set; }

        #endregion
        #region Investible
        public string Investible_1 { get; set; }
        public string Investible_2 { get; set; }
        public string Investible_3 { get; set; }
        public string Investible_4 { get; set; }
        public string Investible_5 { get; set; }
        public string Investible_6 { get; set; }
        public string Investible_7 { get; set; }
        public string Investible_8 { get; set; }
        public string Investible_9 { get; set; }
        public string Investible_10 { get; set; }
        public string Investible_11 { get; set; }
        public string Investible_12 { get; set; }
        public string Investible_13 { get; set; }
        public string Investible_14 { get; set; }
        public string Investible_15 { get; set; }


        #endregion
        #region Sum_assured
        public string Sum_assured_1 { get; set; }
        public string Sum_assured_2 { get; set; }
        public string Sum_assured_3 { get; set; }
        public string Sum_assured_4 { get; set; }
        public string Sum_assured_5 { get; set; }
        public string Sum_assured_6 { get; set; }
        public string Sum_assured_7 { get; set; }
        public string Sum_assured_8 { get; set; }
        public string Sum_assured_9 { get; set; }
        public string Sum_assured_10 { get; set; }
        public string Sum_assured_11 { get; set; }
        public string Sum_assured_12 { get; set; }
        public string Sum_assured_13 { get; set; }
        public string Sum_assured_14 { get; set; }
        public string Sum_assured_15 { get; set; }


        #endregion
        #region Account_Value
        public string Account_Value_1 { get; set; }
        public string Account_Value_2 { get; set; }
        public string Account_Value_3 { get; set; }
        public string Account_Value_4 { get; set; }
        public string Account_Value_5 { get; set; }
        public string Account_Value_6 { get; set; }
        public string Account_Value_7 { get; set; }
        public string Account_Value_8 { get; set; }
        public string Account_Value_9 { get; set; }
        public string Account_Value_10 { get; set; }
        public string Account_Value_11 { get; set; }
        public string Account_Value_12 { get; set; }
        public string Account_Value_13 { get; set; }
        public string Account_Value_14 { get; set; }
        public string Account_Value_15 { get; set; }

        #endregion
        #region Surrender_Value
        public string Surrender_Value_1 { get; set; }
        public string Surrender_Value_2 { get; set; }
        public string Surrender_Value_3 { get; set; }
        public string Surrender_Value_4 { get; set; }
        public string Surrender_Value_5 { get; set; }
        public string Surrender_Value_6 { get; set; }
        public string Surrender_Value_7 { get; set; }
        public string Surrender_Value_8 { get; set; }
        public string Surrender_Value_9 { get; set; }
        public string Surrender_Value_10 { get; set; }
        public string Surrender_Value_11 { get; set; }
        public string Surrender_Value_12 { get; set; }
        public string Surrender_Value_13 { get; set; }
        public string Surrender_Value_14 { get; set; }
        public string Surrender_Value_15 { get; set; }


        #endregion

    }
}
