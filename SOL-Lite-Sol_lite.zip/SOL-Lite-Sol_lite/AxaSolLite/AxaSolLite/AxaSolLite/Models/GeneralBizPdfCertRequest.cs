﻿using AxaSolLite.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class GeneralBizPdfCertRequest
    {
        public string CoverType { get; set; }

        public string CertificateNo { get; set; }

        public string PolicyId { get; set; }

        public string PolicyNo { get; set; }

        public string NameOfPolicyHolder { get; set; }

        public string RegistrationNo { get; set; }

        public string VehicleType { get; set; }

        public string VehicleMake { get; set; }

        public string VehicleModel { get; set; }

        public string VehicleLimitedTo => VehicleMake + " " + VehicleModel;

        public string Color { get; set; }

        public string ChassisNumber { get; set; }

        public string IssueDate { get; set; }

        public string ExpiryDate { get; set; }

        public string LincenseStatus { get; set; }

        public ProductType ProductType { get; set; }

        public string NaicomId { get; set; }

        #region Customer Details

        public string CustEmail { get; set; }

        public string CustName { get; set; }

        public string RefCode { get; set; }

        public string Product { get; set; }

        public string AgentEmail { get; set; }

        public string CustomerNo { get; set; }

        #endregion Customer Details
    }
}
