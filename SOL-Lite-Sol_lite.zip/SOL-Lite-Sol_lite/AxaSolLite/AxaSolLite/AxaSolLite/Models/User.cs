﻿using SQLite;
using System;

namespace AxaSolLite.Models
{
    public class User
    {
        [PrimaryKey, AutoIncrement]
        public Guid Id { get; set; }

        public int GlobalAgentId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public int GenderId { get; set; }
        public string EmailAddress { get; set; }
        public int RoleId { get; set; }
        public string Address { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string Salt { get; set; }
        public Nullable<int> LoginAttempts { get; set; }
        public DateTime? LastSuccessfulLoginDate { get; set; }
        public DateTime? LastSyncDate { get; set; }
        public DateTime? FirstLoginDate { get; set; }
        public DateTime? LastSyncUpInprogressDate { get; set; }
        public DateTime? LastSyncDownDate { get; set; }
        public DateTime? LastClientSyncDownDate { get; set; }
        public DateTime? LastClientSyncUpDate { get; set; }
        public DateTime? LastBankInfoSyncDate { get; set; }
        public string ContactNo { get; set; }
        public string SecurityCode { get; set; }
        public string RequestToken { get; set; }
        public DateTime? SecCodeExpiryDate { get; set; }
        public int AgentId { get; set; }
        public byte[] AgentProfilePicture { get; set; }
        public string ChannelCode { get; set; }
    }
}
