﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class PaperFna
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public DateTime DateOfUpload { get; set; }
        public string UploadedFile { get; set; }
        public string AgentName { get; set; }
        public string AgentCode { get; set; }
        public string Sbu { get; set; }
    }
    public class PaperFnaRequest
    {
        public string EmailAddress { get; set; }
        public string AgentEmail { get; set; }

        public string FullName { get; set; }
        public string AgentName { get; set; }
        public string ContentType { get; set; }

        public string PaperFnaFile { get; set; }
    }
}
