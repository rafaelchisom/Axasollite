﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class LifeSavingsResponse
    {
        [JsonProperty("interestRate")]
        public string InterestRate { get; set; }

        [JsonProperty("lifeCover")]
        public string LifeCover { get; set; }

        [JsonProperty("TotalSavings")]
        public string TotalSavings { get; set; }

        [JsonProperty("TotalInterest")]
        public string TotalInterest { get; set; }

        [JsonProperty("TotalBalance")]
        public string TotalBalance { get; set; }

        [JsonProperty("summary")]
        public string Summary { get; set; }


    }
  
}
