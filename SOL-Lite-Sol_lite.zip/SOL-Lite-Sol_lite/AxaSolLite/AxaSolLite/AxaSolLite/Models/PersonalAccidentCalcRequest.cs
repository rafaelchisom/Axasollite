﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class PersonalAccidentCalcRequest
    {
        [JsonProperty("PolicyType")]
        public int PolicyType { get; set; }

        [JsonProperty("Benefit")]
        public double Benefit { get; set; }

        [JsonProperty("NumberOfMonths")]
        public int NumberOfMonths { get; set; }

        [JsonProperty("NoOfBeneficiaries")]
        public int NoOfBeneficiaries { get; set; }

        [JsonProperty("DiscountRate")]
        public int DiscountRate { get; set; }
    }
}
