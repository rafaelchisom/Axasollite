﻿using AxaSolLite.Models.CustomerOnboardingCreateCase;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class Motor
    {
        //public Guid ProductPlanId { get; set; }
        public MotorProduct MotorProduct { get; set; }
        public List<FileVariable> FileNameList { get; set; }
        public MotorRiders Riders { get; set; }
    }
}
