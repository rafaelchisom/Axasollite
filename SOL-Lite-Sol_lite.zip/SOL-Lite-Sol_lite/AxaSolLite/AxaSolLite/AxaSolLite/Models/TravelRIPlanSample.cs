﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class TravelRIPlanSample
    {
        public bool IsSuccessful { get; set; }
        public List<RISample> Result { get; set; }
    }

    public class RISample
    {
        public int MinDays { get; set; }
        public int MaxDays { get; set; }
        public string CODE { get; set; }
        public string NAME { get; set; }
        public string Description { get; set; }
    }

    public class TravelRIPlanRequest
    {
        public int NumberOfDays { get; set; }
        public string PlanName { get; set; }
    }
}
