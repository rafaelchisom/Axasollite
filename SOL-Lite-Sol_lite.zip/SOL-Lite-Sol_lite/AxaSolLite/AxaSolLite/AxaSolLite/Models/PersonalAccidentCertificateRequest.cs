﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class PersonalAccidentCertificateRequest
    {
        public string PolicyId { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string AccidentalDeathBenefit { get; set; }
        public string PermanentDisability { get; set; }
        public string MedicalExpenses { get; set; }
        public string SpouseName { get; set; }
        public string Premium { get; set; }
        public string FrequencyOfPayment { get; set; }
        public string Beneficiary1 { get; set; }
        public string Beneficiary2 { get; set; }
        public string Beneficiary3 { get; set; }
        public string Beneficiary4 { get; set; }
        public string CustomerName { get; set; }
        public string IssueDate { get; set; }
        public string EmailAddress { get; set; }
        public string AgentEmailAddress { get; set; }
        public string TransactionReference { get; set; }
        public string ProductName { get; set; }
        public string CustomerNumber { get; set; }
    }
}
