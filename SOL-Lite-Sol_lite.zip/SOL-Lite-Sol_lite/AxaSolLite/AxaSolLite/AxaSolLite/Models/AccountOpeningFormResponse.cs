﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Models
{
    public class AccountOpeningFormResponse
    {
        public bool IsSuccessful { get; set; }
        public string Document { get; set; }
        public string DocumentPath { get; set; }
        public string ContentType { get; set; }
        public string Extension { get; set; }
    }
}
