﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class SaveCertificateDetailsRequest
    {
        public string RequestData { get; set; }
        public string QuoteId { get; set; }
        public bool IsLife { get; set; }
    }
}
