﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class AgentBookingCaseMailRequest
    {
        public string AgentName { get; set; }
        public string ProductClass { get; set; }
        public string ProductType { get; set; }
        public string CustomerNumber { get; set; }
        public string CaseId { get; set; }
        public string AgentEmail { get; set; }
    }
}
