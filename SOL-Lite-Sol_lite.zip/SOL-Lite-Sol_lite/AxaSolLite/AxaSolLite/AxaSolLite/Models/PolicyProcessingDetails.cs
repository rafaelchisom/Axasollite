﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class PolicyProcessingDetails
    {
        public string PolicyRegion { get; set; }
        public int PolicyRegionID { get; set; }
    }
}
