﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class TokenRequest
    {
        public string Client_key { get; set; }

        public string Api_key { get; set; }

        public string Api_secret { get; set; }
    }
}
