﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class EduPlanPdfCertRequest
    {
        public string CertificateNo { get; set; }
        public string PolicyId { get; set; }
        public string LifeAssured { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string AgeNextBirthday { get; set; }
        public string SumAssured { get; set; }
        public string Premium { get; set; }
        public DateTime StartDate { get; set; }
        public string PeriodOfCover { get; set; }
        public DateTime EndDate { get; set; }
        public string PolicyTerm { get; set; }
        public string PaymentFrequency { get; set; }
        public string BeneficiaryFullName { get; set; }
        public DateTime IssueDate { get; set; }
        public string NaicomId { get; set; }
        #region Customer Details

        public string CustEmail { get; set; }

        public string CustName { get; set; }

        public string RefCode { get; set; }

        public string Product { get; set; }

        public string AgentEmail { get; set; }

        public string CustomerNo { get; set; }

        #endregion Customer Details
    }
}
