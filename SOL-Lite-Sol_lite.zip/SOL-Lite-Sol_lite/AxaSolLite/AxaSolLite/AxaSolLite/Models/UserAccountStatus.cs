﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class UserAccountStatus
    {
        public string UserName { set; get; }
        public int LoginCount { set; get; }
        public bool IsDisabled { set; get; }
        public DateTime DateInserted { set; get; }
    }
    public class InsertAccountStatus
    {
        public string UserName { set; get; }
        public int LoginCount { set; get; }

    }
}
