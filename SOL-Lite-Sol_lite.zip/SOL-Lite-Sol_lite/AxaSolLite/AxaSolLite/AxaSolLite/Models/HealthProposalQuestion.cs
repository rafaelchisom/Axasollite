﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class HealthProposalQuestion
    {
        public string Question { get; set; }
        public bool IsToggled { get; set; }
    }
}
