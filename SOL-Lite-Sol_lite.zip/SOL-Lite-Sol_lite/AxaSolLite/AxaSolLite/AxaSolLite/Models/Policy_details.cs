﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
  public  class Policy_details
    {
        public string AgentCode { get; set;  }
        public string ProductType { get; set; }
        public string Premium { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string CustomerNumber { get; set; }
        public string PaymentType { get; set; }
      
        public string Product { get; set; }
        public ProposalDetails Proposal_details { get; set; }


    }
    public class Approval_details : BaseModel
    {
        
        public string AgentCode { get; set; }
        public string ProductType { get; set; }
        public string Premium { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string CustomerNumber { get; set; }
        public string PaymentType { get; set; }
        public string CaseId { get; set; }
        public bool IsRejected { get; set; }
        public bool IsApproved { get; set; }
        public string ApprovalType { get; set; }
        public string Comments { get; set; }
        public string ModifiedBy { get; set; }
        public string DateModified { get; set; }
        public string Product { get; set; }
        public string CustomerFullName { get; set; }
        public string CustomerDateofBirth { get; set; }
        public string PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
        public string AmountPaid { get; set; }
        public string PolicyTerm { get; set; }
        public string SumAssured { get; set; }
        public string PaymentFrequency { get; set; }
        public string BeneficiaryFullName { get; set; }
        public string BeneficiaryPhoneNumber { get; set; }
        public string BeneficiaryDateofBirth { get; set; }
        public string MotorType { get; set; }
        public string MotorModel { get; set; }
        public string RegNo { get; set; }
        public string EngNo { get; set; }



    }
    public class ProposalDetails
    {
        public string CustomerFullName { get; set; }
        public string CustomerDateofBirth { get; set; }
        public string PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
        public string AmountPaid { get; set; }
        public string PolicyTerm { get; set; }
        public string SumAssured { get; set; }
        public string PaymentFrequency { get; set; }
        public string BeneficiaryFullName { get; set; }
        public string BeneficiaryPhoneNumber { get; set; }
        public string BeneficiaryDateofBirth { get; set; }
        public string MotorType { get; set; }
        public string MotorModel { get; set; }
        public string RegNo { get; set; }
        public string EngNo { get; set; }
       

    }
}
