﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class SyncDataSample
    {
        public bool IsSuccessful { get; set; }

        public List<ResultSample> Result { get; set; }
    }

    public class ResultSample
    {
        public int CODE { get; set; }
        public string NAME { get; set; }
        public string Description { get; set; }
    }
}
