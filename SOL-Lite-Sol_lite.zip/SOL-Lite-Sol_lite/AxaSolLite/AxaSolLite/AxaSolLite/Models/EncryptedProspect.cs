﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class EncryptedProspect : BaseModel
    {
        public EncryptedProspect()
        {
            Id = Guid.NewGuid();
        }
        public Guid ProspectId { get; set; }
        public string Prospect { get; set; }
    }
}
