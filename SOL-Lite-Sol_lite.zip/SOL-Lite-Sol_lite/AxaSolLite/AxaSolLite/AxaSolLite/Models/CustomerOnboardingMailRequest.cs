﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AxaSolLite.Models
{
    public class CustomerOnboardingMailRequest
    {
        public string AgentName { get; set; }
        public string CaseId { get; set; }
        public string AgentEmailAddress { get; set; }
        public string CustomerNumber { get; set; }
        public string CustomerName { get; set; }
        public string CustomerEmailAddress { get; set; }
    }
}
