﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
   public class LifeSavingsRequest
    {
        [JsonProperty("SavingsAmt")]
        public double SavingsAmt { get; set; }

        [JsonProperty("PaymentFrequency")]
        public int PaymentFrequency { get; set; }

        [JsonProperty("Period")]
        public int Period { get; set; }
    }
}
