﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class LifeSavingPdfCertRequest
    {
        public string PolicyId { get; set; }
        public string PolicyType { get; set; }
        public string LifeAssured { get; set; }
        public string DateOfBirth { get; set; }
        public string AgeNextBirthday { get; set; }
        public string SumAssured { get; set; }
        public string Premium { get; set; }
        public string AnnualContribution { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string PaymentFrequency { get; set; }

        public string BeneficiaryFullNameOne { get; set; }
        public string BeneficiaryFullNameTwo { get; set; }
        public string BeneficiaryFullNameThree { get; set; }
        public string CertificateNo { get; set; }
        public string IssueDate { get; set; }
        public string NaicomId { get; set; }
        #region Customer Details

        public string CustEmail { get; set; }

        public string CustName { get; set; }

        public string RefCode { get; set; }

        public string Product { get; set; }

        public string AgentEmail { get; set; }

        public string CustomerNo { get; set; }

        #endregion Customer Details
    }
}
