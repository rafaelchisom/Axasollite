﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
   
        public partial class getMaxBenefitResponse
        {
            [JsonProperty("projectionsField")]
            public ProjectionsField[] ProjectionsField { get; set; }

            [JsonProperty("illusDateField")]
            public DateTimeOffset IllusDateField { get; set; }

            [JsonProperty("lowerProjectionsField")]
            public Dictionary<string, long>[] LowerProjectionsField { get; set; }

            [JsonProperty("higherProjectionsField")]
            public Dictionary<string, long>[] HigherProjectionsField { get; set; }

            [JsonProperty("finalPremiumLowerField")]
            public long FinalPremiumLowerField { get; set; }

            [JsonProperty("finalPremiumHigherField")]
            public long FinalPremiumHigherField { get; set; }

            [JsonProperty("invRateField")]
            public InvRateField InvRateField { get; set; }

            [JsonProperty("cashBackField")]
            public CashBackField[] CashBackField { get; set; }

            [JsonProperty("maturityAcctBalanceLowerField")]
            public long MaturityAcctBalanceLowerField { get; set; }

            [JsonProperty("maturityAcctBalanceHigherField")]
            public long MaturityAcctBalanceHigherField { get; set; }
        }

        public partial class CashBackField
        {
            [JsonProperty("yearField")]
            public long YearField { get; set; }

            [JsonProperty("amountField")]
            public long AmountField { get; set; }
        }

        public partial class InvRateField
        {
            [JsonProperty("lowerRateField")]
            public long LowerRateField { get; set; }

            [JsonProperty("higherRateField")]
            public long HigherRateField { get; set; }
        }

        public partial class ProjectionsField
        {
            [JsonProperty("polYearField")]
            public long PolYearField { get; set; }

            [JsonProperty("yrlyProjLowerField")]
            public long YrlyProjLowerField { get; set; }

            [JsonProperty("yrlyProjHigherField")]
            public long YrlyProjHigherField { get; set; }

            [JsonProperty("surrValLowerField")]
            public long SurrValLowerField { get; set; }

            [JsonProperty("surrValHigherField")]
            public long SurrValHigherField { get; set; }
        }

        public partial class MaxBenefitResponse
        {
            public static MaxBenefitResponse FromJson(string json) => JsonConvert.DeserializeObject<MaxBenefitResponse>(json, Converter.Settings);
        }

        //public static class Serialize
        //{
        //    public static string ToJson(this MaxBenefitResponse self) => JsonConvert.SerializeObject(self, Converter.Settings);
        //}

        //internal static class Converter
        //{
        //    public static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
        //    {
        //        MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
        //        DateParseHandling = DateParseHandling.None,
        //        Converters =
        //        {
        //            new IsoDateTimeConverter { DateTimeStyles = DateTimeStyles.AssumeUniversal }
        //        },
        //    };
        //}
    
}
