﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class ApprovalMail
    {
        public string EmailAddress { get; set; }
        public string AgentEmail { get; set; }

        public string FullName { get; set; }
        public string CaseId { get; set; }
        public string Comments { get; set; }
        public string ApprovalType { get; set; }
        public bool IsApproved { get; set; }

    }
    public class ApprovalRquestMail
    {
        public string EmailAddress { get; set; }
        public string AgentEmail { get; set; }

        public string FullName { get; set; }
        public string CaseId { get; set; }
        public string AdvisorFullName { get; set; }

    }
}
