﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class HealthPreExistingConditions
    {
        public int Id { get; set; }
        public string PreexistingCondition1 { get; set; }
        public bool IsToggled { get; set; }
    }

    public class Genotypes
    {
        public int Id { get; set; }
        public string Genotype1 { get; set; }
    }

    public class Plans
    {
        public string Name { get; set; }
        public int Code { get; set; }
        public string Value { get; set; }
    }

    public class Towns
    {
        public string TownName { get; set; }
        public string TownCode { get; set; }
    }

    public class HealthStates
    {
        public string State { get; set; }
        public string StateCode { get; set; }
        public string HealthStateCode { get; set; }
    }

    public class Hospitals
    {
        public bool IsSuccessful { get; set; }
        public string message { get; set; }
        public List<ReturnedObject> ReturnedObject { get; set; }
    }

    public class ReturnedObject : BaseModel
    {
        public string Specialisation { get; set; }
        public string HospitalDetails { get; set; }
    }

    public class HealthBeneficiary
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName => $" {FirstName} {LastName}";
        public string MiddleName { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string State { get; set; }
        public string Town { get; set; }
        public string Address { get; set; }
        public string Gender { get; set; }
        public string Genotype { get; set; }
        public string PreferredHospitalLocation { get; set; }
        public string PreferredHospital { get; set; }
        public bool IsVisible { get; set; }
        public string MaritalStatus { get; set; }
        public string BloodGroup { get; set; }
        public string Occupation { get; set; }
        public List<HealthPreExistingConditions> PreExistingConditions { get; set; }
    }
}
