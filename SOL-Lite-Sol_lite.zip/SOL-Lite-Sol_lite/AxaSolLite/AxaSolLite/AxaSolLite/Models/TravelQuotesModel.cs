﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class TravelQuotesModel
    {
        [JsonProperty("uid")]
        public string Uid { get; set; }

        [JsonProperty("Email")]
        public string Email { get; set; }

        [JsonProperty("MobileNo")]
        public string MobileNo { get; set; }

        [JsonProperty("DOB")]
        public DateTime Dob { get; set; }

        [JsonProperty("Destination")]
        public int Destination { get; set; }

        [JsonProperty("DestinationName")]
        public string DestinationName { get; set; }

        [JsonProperty("StartDate")]
        public DateTime StartDate { get; set; }

        [JsonProperty("EndDate")]
        public DateTime EndDate { get; set; }

        [JsonProperty("Duration")]
        public int Duration { get; set; }

        [JsonProperty("TravelType")]
        public int TravelType { get; set; }

        [JsonProperty("PlanId")]
        public int PlanId { get; set; }

        [JsonProperty("PlanName")]
        public string PlanName { get; set; }

        [JsonProperty("Amount")]
        public double Amount { get; set; }

        [JsonProperty("IsGroup")]
        public bool IsGroup { get; set; }

        [JsonProperty("IsFamily")]
        public bool IsFamily { get; set; }

        [JsonProperty("Ages")]
        public int[] Ages { get; set; }

        [JsonProperty("NoOfPerson")]
        public int NoOfPerson { get; set; }

        [JsonProperty("PolicyType")]
        public int PolicyType { get; set; }

        [JsonProperty("IsExistingCustomer")]
        public bool IsExistingCustomer { get; set; }

        [JsonProperty("CustomerNo")]
        public string CustomerNo { get; set; }

        [JsonProperty("Program")]
        public int Program { get; set; }

        [JsonProperty("Area")]
        public int Area { get; set; }

        [JsonProperty("ReferralProductReference")]
        public string ReferralProductReference { get; set; }

        [JsonProperty("ReferralType")]
        public string ReferralType { get; set; }
    }
}
