﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxaSolLite.Models
{
    public class EmarketingStatus : BaseModel
    {
        public EmarketingStatus()
        {
            Id = Guid.NewGuid();
        }
        public Guid ProspectId { get; set; }
        public string Date { get; set; }
        public string Product { get; set; }
        public bool IsSent { get; set; }
    }
}
